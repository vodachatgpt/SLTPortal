﻿
using System;
using System.Configuration;
using System.Web.Http;
using System.Web.Http.Cors;

namespace SLTProject
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Read allowed frontend origins from Web.config.
            string allowedOrigins =
                ConfigurationManager.AppSettings["CorsAllowedOrigins"];

            if (string.IsNullOrWhiteSpace(allowedOrigins))
            {
                throw new ConfigurationErrorsException(
                    "CorsAllowedOrigins is missing from Web.config.");
            }

            var cors = new EnableCorsAttribute(
                origins: allowedOrigins,
                headers: "Authorization,Content-Type,Accept",
                methods: "GET,POST,PUT,PATCH,DELETE,OPTIONS"
            );

            // Allow browser clients to read the API responses.
            // Authorization is still enforced separately by
            // SltAdmin / guest authorization attributes.
            config.EnableCors(cors);

            // Attribute routing
            config.MapHttpAttributeRoutes();

            // Conventional routing
            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new
                {
                    id = RouteParameter.Optional
                }
            );
        }
    }
}
