(function(){
 'use strict';
 const $=id=>document.getElementById(id);
 function state(text){$('authState').textContent=text;}
 function pushInfo(text){$('pushStatus').textContent=text;}
 function errorText(e){return e&&e.message||String(e);}
 function describeEnvironment(){const parts=[
   'Secure context: '+String(window.isSecureContext),
   'Service workers: '+('serviceWorker'in navigator?'supported':'unavailable'),
   'Push API: '+('PushManager'in window?'supported':'unavailable'),
   'Notification permission: '+PartnerGuestPush.permission()
  ];$('envState').textContent=parts.join(' · ');}
 async function verify(){if(!guestToken()){state('Not signed in.');return;}
  try{const me=await guestMe();const s=getSession()||{};s.user=Object.assign({},s.user,me);saveSession(s);state('Signed in: '+(me.FullName||me.Email||'Guest')+' (guest session verified).');}
  catch(e){state('Session verification failed: '+errorText(e));}
 }
 $('guestTestLogin').addEventListener('submit',async ev=>{ev.preventDefault();const btn=$('signInBtn');btn.disabled=true;
  try{
   const code=$('guestPasscode').value.trim();if(!/^[0-9]{6}$/.test(code))throw Error('Enter exactly six digits.');
   const result=await guestLogin(code);
   const token=result.Token||result.token;
   if(!token)throw Error('SLT guest login did not return a token.');
   // Do not persist passcodes or expose bearer tokens in the UI.
   const expires=result.ExpiresAt||result.expiresAt||result.SessionExpiresAt||null;
   saveSession({user:result.Guest||result.User||result.user||{},token,expiresAt:expires});
   $('guestPasscode').value='';PartnerGuestPush.reset();
   await verify();
  }catch(e){state('Login failed: '+errorText(e));}finally{btn.disabled=false;}
 });
 $('verifyBtn').addEventListener('click',verify);
 $('enableBtn').addEventListener('click',async()=>{const b=$('enableBtn');b.disabled=true;
  try{const r=await PartnerGuestPush.enable();pushInfo('Enable response: '+JSON.stringify({subscribed:!!r.subscribed})+'\nCheck Subscription to confirm backend registration.');}
  catch(e){pushInfo('Enable failed: '+errorText(e));}finally{b.disabled=false;describeEnvironment();}
 });
 $('statusBtn').addEventListener('click',async()=>{try{const r=await PartnerGuestPush.status();pushInfo(JSON.stringify({supported:r.supported,permission:r.permission,subscribed:r.subscribed,serverSubscribed:r.serverSubscribed},null,2));}catch(e){pushInfo('Status failed: '+errorText(e));}});
 $('disableBtn').addEventListener('click',async()=>{try{await PartnerGuestPush.disable();pushInfo('Unsubscribed from browser push.');}catch(e){pushInfo(errorText(e));}});
 $('logoutBtn').addEventListener('click',async()=>{
  if(guestToken()){
   try{const result=await PartnerGuestPush.beforeLogout();if(result&&result.errorCode)pushInfo('Unlink warning: '+result.warning);}catch(e){pushInfo('Unlink warning: '+errorText(e));}
  }
  clearSession();PartnerGuestPush.reset();state('Signed out.');
 });
 describeEnvironment();verify();
})();
