/* =========================================================
   SLT App - Shared helpers (loaded on every page)
   Original partner file names and session conventions preserved.
   ========================================================= */
const STORAGE = {
  session: 'slt.session',
  inviteId: 'slt.inviteId',
  accessDone: 'slt.accessDone',
  storiesSeen: 'slt.storiesSeen'
};
const APP_ROOT = new URL('../', document.currentScript.src).href;
function readStorage(key) { try { return localStorage.getItem(key); } catch (_) { return null; } }
function writeStorage(key,value) { try { localStorage.setItem(key,value); } catch (_) {} }
function removeStorage(key) { try { localStorage.removeItem(key); } catch (_) {} }
function getSession() {
  let session = null;
  try { session = JSON.parse(readStorage(STORAGE.session)); } catch (_) {}
  if (session && session.expiresAt) {
    const expiry = Date.parse(session.expiresAt);
    if (Number.isFinite(expiry) && expiry < Date.now()) { clearSession(); return null; }
  }
  return session;
}
function saveSession(session) { writeStorage(STORAGE.session, JSON.stringify(session)); }
function clearSession() {
  removeStorage(STORAGE.session);
  removeStorage(STORAGE.accessDone);
  removeStorage(STORAGE.storiesSeen);
}
function resetEverything() {
  clearSession();
  removeStorage(STORAGE.inviteId);
  removeStorage('slt.tourRegistered');
  removeStorage('slt.testPhase');
  removeStorage('slt.dummyWeatherTable');
  removeStorage('slt.dummyReadIds');
}
function getInviteId() {
  const fromLink = new URLSearchParams(location.search).get('id');
  if (fromLink) writeStorage(STORAGE.inviteId, fromLink);
  return fromLink || readStorage(STORAGE.inviteId) || '';
}
function saveCodeFromLink() {
  const params = new URLSearchParams(location.search);
  const code = (params.get('code') || '').replace(/\D/g,'').slice(0,6);
  if (!code) return;
  try { sessionStorage.setItem('slt.linkCode', code); } catch (_) {}
  params.delete('code');
  const query = params.toString();
  history.replaceState(null,'',location.pathname + (query?'?'+query:'') + location.hash);
}
function takeCodeFromLink() {
  let code = null;
  try { code=sessionStorage.getItem('slt.linkCode');sessionStorage.removeItem('slt.linkCode'); } catch (_) {}
  return code;
}
saveCodeFromLink();
function isInstalledApp() {
  return matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
}
function isIphoneOrIpad() {
  return /iPhone|iPad|iPod/.test(navigator.userAgent) ||
    (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
}
function showToast(message) {
  let toast=document.getElementById('toast');
  if(!toast){toast=document.createElement('div');toast.id='toast';toast.className='toast-msg';document.body.appendChild(toast);}
  toast.textContent=message;toast.classList.add('show');clearTimeout(toast.timer);
  toast.timer=setTimeout(()=>toast.classList.remove('show'),3000);
}
if(CONFIG.testMode && new URLSearchParams(location.search).get('reset')==='1') {
  resetEverything();
  const goToStart=()=>location.replace(APP_ROOT+'index.html');
  if(window.caches) caches.keys().then(keys=>Promise.all(keys.map(key=>caches.delete(key)))).then(goToStart,goToStart);
  else goToStart();
  throw new Error('Resetting...');
}
// Keep the partner PWA/offline worker registration. Push uses a different worker scope (/push/).
if ('serviceWorker' in navigator && window.isSecureContext) {
  navigator.serviceWorker.register(APP_ROOT + 'sw.js').catch(()=>{});
}
