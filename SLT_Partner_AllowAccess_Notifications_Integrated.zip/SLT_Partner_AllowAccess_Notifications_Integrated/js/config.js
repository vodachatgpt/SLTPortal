/* Partner guest notification integration. Adjust apiBaseUrl before testing. */
const CONFIG = {
  useLiveApi: true,
  testMode: true,
  apiBaseUrl: 'https://localhost:44384/api', // SLTProject Web API 2 /api (no trailing slash)
  endpoints: {
    verifyCode: '/auth/verify-code', resendCode: '/auth/resend-code',
    saveAccess: '/users/access',
    notifications: '/slt-notifications/guest/inbox',
    markRead: '/slt-notifications/guest',
    notificationStatus: '/slt-notifications/guest/inbox',
    contacts: '/contacts', registerTour: '/tour/register',
    getWeather: '/weather', saveWeather: '/weather',
    guestLogin: '/guest-auth/login', guestMe: '/guest-auth/me'
  },
  globalPushServiceUrl: 'https://pulse.vodafone.com.eg/SPPowers/webpushapi/',
  globalPushApplicationCode: 'SLT_APP',
  day0Date: '2026-12-08', testPhase: '', tourId: 'PYRAMIDS-2026-12-11',
  tourUserFields: ['id', 'fullName', 'email', 'mobile'],
  weatherUrl: 'https://api.open-meteo.com/v1/forecast?latitude=30.0444&longitude=31.2357&daily=weather_code,temperature_2m_max,temperature_2m_min&forecast_days=5&timezone=Africa%2FCairo',
  weatherKeepMinutes: 60, autoSubmitCode: false, resendWaitSeconds: 30
};
