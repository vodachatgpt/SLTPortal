# SLT Partner Guest Notifications — integrated with Allow Access

## Files and naming
This is an **overlay**, not the whole partner application. Keep your existing partner `index.html`, `html/Home.html`, `html/InvitationCode.html`, `html/Splash.html`, `sw.js`, `manifest.webmanifest`, Bootstrap, media, `css/style.css`, `css/Pages.css`, `css/Onboarding.css`, `js/dummy-data.js`, and other pages. Copy the **contents** of this folder to the partner app root. Do not nest the folder twice.

### Existing filenames retained
- `html/AllowAccess.html`, `js/AllowAccess.js`: original install + allow notifications steps; the Allow button registers browser push to the current SLT guest via SDK and backend.
- `html/Notifications.html`, `js/Notifications.js`: inbox, unread status, mark as read, enable/check/disable push.
- `js/config.js`, `js/app.js`, `js/api.js`: same filenames and existing helper function names, with the backend/notification adapter; `app.js` retains root `sw.js` registration and `slt.session` storage.

### Additional supporting files
- `html/GuestPushTest.html` and `js/GuestPushTest.js`: six-digit guest passcode login and subscription diagnostics, used to test the existing backend without replacing the partner invitation flow.
- `js/global-browser-push.v10.3.js`, `js/slt-guest-push.js`, `js/guest-push.js`, `push/global-push-sw.js`: push SDK, SLT backend adapter and **dedicated** service worker under `/push/`.
- `css/notifications-integration.css`: scoped extras for inbox and status text.

## Test the real admin dashboard
1. Back up the existing partner frontend, then merge the package file paths exactly as shown. Preserve original home/sidebar/PWA assets.
2. In `js/config.js`, set `apiBaseUrl` to the real SLT Web API `/api` URL (no trailing slash). Set `globalPushServiceUrl` and `globalPushApplicationCode` to the values used by your working SLT guest push integration. Leave API keys in the backend, never JS. `useLiveApi` must be `true`.
3. Serve the partner app over trusted HTTPS (or localhost for local testing), not `file://`. If different API and frontend origins are used, configure the SLT backend CORS to allow the partner origin and `Authorization`/`Content-Type` headers and preflight OPTIONS.
4. Open `/html/GuestPushTest.html`, enter an active guest's six-digit passcode, and click **Sign In**. This uses `POST /api/guest-auth/login` and saves the returned guest bearer token in the existing `slt.session` format. Verify using `GET /api/guest-auth/me`. A previously activated guest may need to reuse an existing session token rather than log in again; avoid resetting passcodes to test.
5. Open `/html/AllowAccess.html` to exercise the partner's original installation/onboarding. Click **Allow notifications**. It calls the SDK from the user gesture and registers push via the SLT backend (`POST /api/slt-notifications/guest/registration-token`, `GET /api/slt-notifications/guest/push/config`, `POST /api/slt-notifications/guest/push/subscriptions`). Your existing `saveAccess` endpoint is still called best-effort (it may be a partner-specific API).
6. On iPhone/iPad, install the PWA to the home screen and open it from there before granting web push permission; a regular Safari tab is not sufficient for iOS web push.
7. Open `/html/Notifications.html` and click **Check Status**. Browser `subscribed` and backend `serverSubscribed` should both be true. If they aren't, check console/network, HTTPS, `/push/global-push-sw.js` path, VAPID keys and provider connectivity.
8. In the SLT Admin dashboard, send a notification to this exact guest. The backend stores the notification and attempts push delivery. In the partner page click **Refresh**, confirm it appears unread, then click it to mark read.
9. Test **Unread only**, pagination, disable and re-enable push. Notifications still show in the inbox even if push delivery is blocked by a browser/network/provider.

## Guest notification API contract
- `GET /api/slt-notifications/guest/inbox?page=1&pageSize=10&unreadOnly=false` -> `{Items:[{NotificationId,Title,MessageText,CreatedAt,IsRead}],UnreadCount,TotalPages,...}`.
- `POST /api/slt-notifications/guest/{id}/read`.
- `POST /api/slt-notifications/guest/registration-token`.
- `GET /api/slt-notifications/guest/push/config`.
- `POST /api/slt-notifications/guest/push/subscriptions`.
- `POST /api/slt-notifications/guest/push/subscriptions/status`.
- `POST /api/slt-notifications/guest/push/subscriptions/unsubscribe`.

## Caveats
`verifyCode`, `resendCode`, `saveAccess`, `registerTour`, contacts and weather endpoints are retained from the partner's code, but their corresponding backend routes were not independently verified. For actual SLT Guest authentication, use the provided guest test page until those production flows are wired to the backend. Onboarding `saveAccess` errors do not block navigation to `Splash.html`. The bundle has not been live-tested against a deployed API/Global Push service.
