# SLT Partner PWA integration — existing pages only

## Scope of this deliverable
This is an **integration overlay** built from the latest available *previous Partner integration package*, not your complete current Partner source. No extra HTML pages are created. Your original `InvitationCode.html`, `Home.html`, `Splash.html`, `index.html`, `sw.js`, and `manifest.webmanifest` were **not** provided, so this ZIP does not overwrite them. It does include full replacement versions of the integration files listed below and one new JavaScript file that injects the email/passcode controls into the **existing** `InvitationCode.html` at runtime.

### Changed/added files in this overlay
- `js/config.js` — live API configuration, `request-passcode` route, no test mode
- `js/api.js` — request passcode; mixed 6-character guest login; guest session save; legacy verify/resend adapters; notification inbox/read APIs
- `js/app.js` — preserve `slt.session`, root PWA worker, mixed-code sanitization, auto-load login adapter on existing `InvitationCode.html`
- `js/partner-slt-auth.js` — **new JS only**: injects email and six-character code controls into your existing invitation page and redirects to existing AllowAccess page on login
- `css/notifications-integration.css` — scoped sign-in/notification styling
- `html/AllowAccess.html`, `js/AllowAccess.js` — existing onboarding page, user-gesture push registration, safe skip
- `html/Notifications.html`, `js/Notifications.js` — real guest inbox, read/unread, pagination, push status (removed link to the old test page)
- `js/global-browser-push.v10.3.js`, `js/slt-guest-push.js`, `js/guest-push.js` — previous Global Push SDK and SLT adapter
- `push/global-push-sw.js` — separate `/push/` scoped worker, **not** replacing your root `sw.js`

## Step-by-step deployment
1. **Back up** your Partner PWA and test on stage. Copy the extracted files into the PWA root *preserving folders*: `js/`, `css/`, `html/`, `push/`. Do **not** replace your existing root `sw.js` or `manifest.webmanifest`.
2. Edit `js/config.js`: set `apiBaseUrl` to `https://YOUR-HOST/api` (no trailing `/`), `useLiveApi: true`, `testMode: false`; verify `globalPushServiceUrl` and `globalPushApplicationCode` against the backend's live Global Push installation. Do not put application API keys in JavaScript.
3. Make sure your **existing `html/InvitationCode.html`** includes the original shared scripts in this order before closing `</body>`:
   ```html
   <script src="../js/config.js"></script>
   <script src="../js/app.js"></script>
   <script src="../js/api.js"></script>
   ```
   `app.js` automatically loads `partner-slt-auth.js` on `InvitationCode.html`; you do **not** create a new HTML page. The adapter inserts its email/code form at the start of your existing `<main>`. **The original InvitationCode markup was not available, so its old login form is not automatically removed**. For a polished single-form UI, supply that file or hide/replace the old form after inspecting your own markup. Do not delete application navigation or branding.
4. Keep `html/AllowAccess.html` and `html/Notifications.html` at their existing URLs, and ensure navigation references those existing URLs. On successful guest login the adapter saves `slt.session` and navigates to `AllowAccess.html`.
5. Serve the PWA and API via **HTTPS**, with the partner origin explicitly allowed by backend CORS for `Authorization`, `Content-Type` and `OPTIONS`. Never use `file://` for push testing.
6. Your PWA root service worker remains `sw.js`. The supplied push worker installs with **scope `/push/`**. Verify these scopes do not conflict in DevTools > Application > Service Workers. The root worker should not cache API responses, passcodes, or guest inbox data.
7. Confirm `manifest.webmanifest` `scope` and `start_url` point to your existing installable Partner PWA. If it precaches JavaScript, update its cache version to force delivery of new files. HTTPS, valid manifest and PWA installation are prerequisites for supported mobile push; on iPhone/iPad, launch from the installed Home Screen app.
8. Guest enters email -> `POST /api/guest-auth/request-passcode` -> email and SMS -> guest enters six-character alphanumeric code -> `POST /api/guest-auth/login` -> token in existing `slt.session`. **Do not log passcodes or tokens.** The passcode request returns a generic response even when an address is not eligible.
9. Guest presses **Allow notifications** on `AllowAccess.html` -> SDK calls SLT backend's registration token/config/subscription endpoints. Skipping push does **not** block guest inbox access. Browser permission must be requested from an explicit user action.
10. Admin sends a notification from SLT Admin. On existing `Notifications.html`, guest can refresh, select unread only, page and click an unread message to mark it read. Check `PartnerGuestPush.status()` from the same page to diagnose subscriptions.

## Relevant endpoints
- `POST /api/guest-auth/request-passcode` `{ "Email": "guest@example.com" }`
- `POST /api/guest-auth/login` `{ "Passcode": "A7B2C9" }` (mixed six-character format; server issues the exact code)
- `GET /api/guest-auth/me` (guest bearer)
- `GET /api/slt-notifications/guest/inbox?page=1&pageSize=10&unreadOnly=false` (guest bearer)
- `POST /api/slt-notifications/guest/{id}/read` (guest bearer)
- `POST /api/slt-notifications/guest/registration-token` (guest bearer)
- `GET /api/slt-notifications/guest/push/config` (guest bearer)
- `POST /api/slt-notifications/guest/push/subscriptions` (guest bearer)
- `POST /api/slt-notifications/guest/push/subscriptions/status` (guest bearer)
- `POST /api/slt-notifications/guest/push/subscriptions/unsubscribe` (guest bearer)

## Test checklist
- Open existing invitation page on HTTPS; new email entry and passcode entry show near top (if they don't, check script loading and console).
- Request passcode; verify generic confirmation and email/SMS receipt.
- Sign in with latest six-character code and verify network 200, `slt.session`, and navigation to AllowAccess.
- Install PWA; reopen; confirm existing session persists if valid.
- Tap Allow Notifications; verify permission and subscription status. On iOS, open installed PWA before asking permission.
- Admin targets this guest; verify push (if provider works) and the SQL-backed inbox independently.
- Open inbox and mark unread message read; unread count changes.
- Deny/skip push and verify inbox still works.
- Test expired token (401), iOS/Android, offline shell, and service worker upgrade.

## Important limitations
- The actual original `InvitationCode.html` and its legacy script were unavailable. The adapter **adds** a working email-first form to that page, but cannot seamlessly remove or rewrite unknown original fields/listeners. The existing `Home.html` notification badge cannot be modified without its source; inbox and push still work on the included Notifications page.
- `saveAccess`, `registerTour`, contacts and weather hooks carried over from the earlier Partner adapter may require mapping to your existing API separately. `AllowAccess.js` continues after a failed `saveAccess` call to avoid blocking entry.
- No backend or actual deployed PWA/API tests were performed. Match `apiBaseUrl`, CORS and Global Push provider configuration to your real environment before production rollout.
