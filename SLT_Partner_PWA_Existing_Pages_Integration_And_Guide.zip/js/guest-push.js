/* Partner-side Global Browser Push V10.3 integration.
   Uses authenticated guest session. Permission requested ONLY on explicit click. */
(function(root){
  'use strict';
  let instance=null;
  function getToken(){return guestToken();}
  function create(){
    if(!getToken())throw Error('Sign in as a guest first.');
    if(!root.SLTGuestPush)throw Error('Missing Global Push SDK adapter.');
    if(!CONFIG.globalPushServiceUrl||!CONFIG.globalPushApplicationCode)throw Error('Configure Global Push service URL and application code in js/config.js.');
    if(!instance){
      instance=root.SLTGuestPush.create({
        sltApiBase:apiBase(),
        globalPushServiceUrl:CONFIG.globalPushServiceUrl,
        applicationCode:CONFIG.globalPushApplicationCode,
        workerUrl:APP_ROOT+'push/global-push-sw.js',
        workerScope:APP_ROOT+'push/',
        getGuestToken:getToken
      });
    }
    return instance;
  }
  root.PartnerGuestPush={
    supported(){return !!root.isSecureContext&&'Notification'in root&&'serviceWorker'in navigator&&'PushManager'in root;},
    permission(){return 'Notification'in root?Notification.permission:'unsupported';},
    async enable(){return create().enable();},
    async status(){return create().status();},
    async synchronize(){return create().synchronize();},
    async disable(){return create().disable();},
    async beforeLogout(){if(!getToken())return{removed:false};return create().beforeLogout();},
    reset(){instance=null;}
  };
})(window);
