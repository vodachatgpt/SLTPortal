/* SLT Partner API adapter. Existing functions retained for compatibility. */
function apiBase(){return String(CONFIG.apiBaseUrl||'').replace(/\/+$/,'');}
function guestToken(){const s=getSession();return s && (s.token||s.Token)||'';}
async function callApi(endpoint,body,method){
  method=(method||'POST').toUpperCase();
  const token=guestToken();
  const headers={'Accept':'application/json'};
  if(method!=='GET')headers['Content-Type']='application/json';
  if(token)headers.Authorization='Bearer '+token;
  let response;
  try {response=await fetch(apiBase()+endpoint,{method,headers,body:method==='GET'?undefined:JSON.stringify(body||{}),cache:'no-store',credentials:'omit'});}
  catch(err){throw new Error('No connection to SLT API. Check HTTPS, CORS, URL and network access.');}
  const data=await response.json().catch(()=>({}));
  if(!response.ok){const detail=data.Message||data.message||data.ExceptionMessage||'HTTP '+response.status;const e=new Error(detail);e.status=response.status;throw e;}
  return data;
}
async function guestLogin(passcode){
  const clean=String(passcode||'').trim().toUpperCase();
  if (!/^[A-Z0-9]{6}$/.test(clean)) throw Error('Enter a six-character passcode.');
  return callApi(CONFIG.endpoints.guestLogin,{Passcode:clean},'POST');
}
async function requestGuestPasscode(email){
  const clean=String(email||'').trim();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(clean)) throw Error('Enter a valid registered email address.');
  return callApi(CONFIG.endpoints.requestPasscode,{Email:clean},'POST');
}
function saveGuestLoginResult(result){
  const token=result&&(result.Token||result.token);
  if(!token) throw Error('The guest login response did not contain a token.');
  const expires=result.ExpiresAt||result.expiresAt||result.SessionExpiresAt||null;
  saveSession({user:result.Guest||result.User||result.user||{},token,expiresAt:expires});
  return getSession();
}
async function guestMe(){return callApi(CONFIG.endpoints.guestMe,null,'GET');}
async function verifyCode(inviteId,code){if(!CONFIG.useLiveApi){await wait(DUMMY.delayMs);const user=DUMMY.validCodes[code];if(!user)throw Error('Invalid code');return{user,token:'dummy-token-'+user.id,expiresAt:DUMMY.sessionExpiresAt};}const result=await guestLogin(code);saveGuestLoginResult(result);return {user:result.Guest||result.User||result.user||{},token:result.Token||result.token,expiresAt:result.ExpiresAt||result.expiresAt||result.SessionExpiresAt||null};}
async function resendCode(inviteId){if(!CONFIG.useLiveApi){await wait(DUMMY.delayMs);return{message:'A new code has been sent.'};}const email=String(readStorage('slt.guestEmail')||'');if(!email)throw Error('Enter your registered email first.');return requestGuestPasscode(email);}
async function saveAccess(installedApp,notifications){const s=getSession();const body={userId:s?s.user.id:'',installedApp,notifications};if(!CONFIG.useLiveApi){await wait(DUMMY.delayMs);return{saved:true}}return callApi(CONFIG.endpoints.saveAccess,body);}
async function registerTour(attending){const body={tourId:CONFIG.tourId,attending,user:pickUserFields(CONFIG.tourUserFields)};if(!CONFIG.useLiveApi){await wait(DUMMY.delayMs);return{registered:attending}}return callApi(CONFIG.endpoints.registerTour,body);}
function pickUserFields(names){const s=getSession();const u=s?s.user:{};const result={};names.forEach(n=>{if(u[n]!==undefined)result[n]=u[n]});return result;}
/* Backend shape: {Items:[{NotificationId,Title,MessageText,CreatedAt,IsRead}],UnreadCount,Page,TotalPages,...} */
async function getNotificationPage(page=1,pageSize=10,unreadOnly=false){
  if(!CONFIG.useLiveApi){const read=dummyReadIds();const all=DUMMY.notifications.map(n=>({NotificationID:n.NotificationID,NotificationTitle:n.NotificationTitle,NotificationDetails:n.NotificationDetails,NotificationTime:n.NotificationTime,NotificationStatus:read.includes(n.NotificationID)?'Read':'Unread'}));const filter=unreadOnly?all.filter(x=>x.NotificationStatus==='Unread'):all;return {Items:filter.slice((page-1)*pageSize,page*pageSize),UnreadCount:all.filter(x=>x.NotificationStatus==='Unread').length,Page:page,TotalPages:Math.ceil(filter.length/pageSize),Total:filter.length};}
  return callApi(CONFIG.endpoints.notifications+'?page='+encodeURIComponent(page)+'&pageSize='+encodeURIComponent(pageSize)+'&unreadOnly='+String(unreadOnly),null,'GET');
}
function normalizeNotification(x){
  return {NotificationID:x.NotificationId??x.NotificationID,NotificationTitle:x.Title??x.NotificationTitle,NotificationDetails:x.MessageText??x.NotificationDetails,NotificationTime:x.CreatedAt??x.NotificationTime,NotificationStatus:(x.IsRead===true||x.NotificationStatus==='Read')?'Read':'Unread',ClickUrl:x.ClickUrl||''};
}
async function getNotifications(){const p=await getNotificationPage(1,100,false);return (p.Items||[]).map(normalizeNotification);}
async function markNotificationRead(id){
  if(!CONFIG.useLiveApi){const ids=dummyReadIds();if(!ids.includes(id))ids.push(id);writeStorage('slt.dummyReadIds',JSON.stringify(ids));return{saved:true};}
  const number=Number(id);if(!Number.isSafeInteger(number)||number<=0)throw Error('Invalid notification ID.');
  return callApi(CONFIG.endpoints.markRead+'/'+number+'/read',{},'POST');
}
function dummyReadIds(){try{return JSON.parse(readStorage('slt.dummyReadIds'))||[]}catch(_){return[]}}
async function getUnreadCount(){if(!CONFIG.useLiveApi){const list=await getNotifications();return list.filter(n=>n.NotificationStatus==='Unread').length;}const p=await getNotificationPage(1,1,false);return Number(p.UnreadCount)||0;}
async function getContacts(){if(!CONFIG.useLiveApi){await wait(300);return DUMMY.contacts;}return callApi(CONFIG.endpoints.contacts,null,'GET');}
async function getSavedWeather(){if(!CONFIG.useLiveApi){await wait(300);let saved;try{saved=JSON.parse(readStorage('slt.dummyWeatherTable'))}catch(_){}return saved&&(Date.now()-new Date(saved.savedAt))/60000<CONFIG.weatherKeepMinutes?saved:null;}const d=await callApi(CONFIG.endpoints.getWeather,null,'GET');return d&&d.days&&d.days.length?d:null;}
async function saveWeather(weather){if(!CONFIG.useLiveApi){writeStorage('slt.dummyWeatherTable',JSON.stringify(weather));return;}return callApi(CONFIG.endpoints.saveWeather,{weather});}
async function fetchExternalWeather(){const r=await fetch(CONFIG.weatherUrl);if(!r.ok)throw Error('Weather service error');const d=await r.json();return{savedAt:new Date().toISOString(),days:d.daily.time.map((date,i)=>({date,max:Math.round(d.daily.temperature_2m_max[i]),min:Math.round(d.daily.temperature_2m_min[i]),code:d.daily.weather_code[i]}))};}
function wait(ms){return new Promise(resolve=>setTimeout(resolve,ms));}
