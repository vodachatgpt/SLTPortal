/* Global Browser Push SDK v1 (standalone, no framework dependencies).
 * The consuming app MUST host global-push-sw.js on its OWN origin. Never put application API keys in JS.
 * tokenProvider is an authenticated call to the consuming APP backend, not the central service.
 */
(function (root) {
  'use strict';
  function urlBase64Decode(value) {
    const b64 = value.replace(/-/g, '+').replace(/_/g, '/');
    const raw = atob(b64 + '='.repeat((4 - b64.length % 4) % 4));
    return Uint8Array.from(raw, c => c.charCodeAt(0));
  }
  function randomUuid() {
    if (root.crypto && typeof root.crypto.randomUUID === 'function') return root.crypto.randomUUID();
    if (!root.crypto || !root.crypto.getRandomValues) throw new Error('Secure crypto API required.');
    const a = new Uint8Array(16); root.crypto.getRandomValues(a);
    a[6] = (a[6] & 0x0f) | 0x40; a[8] = (a[8] & 0x3f) | 0x80;
    const hex = Array.from(a, b => b.toString(16).padStart(2, '0')).join('');
    return [hex.slice(0,8),hex.slice(8,12),hex.slice(12,16),hex.slice(16,20),hex.slice(20)].join('-');
  }
  class GlobalBrowserPush {
    constructor(options) {
      if (!options || !options.serviceUrl || !options.applicationCode || typeof options.tokenProvider !== 'function')
        throw new Error('serviceUrl, applicationCode and tokenProvider are required.');
      this.serviceUrl = options.serviceUrl.replace(/\/+$/, '');
      this.applicationCode = options.applicationCode;
      this.workerUrl = options.workerUrl || './global-push-sw.js';
      this.workerScope = options.workerScope || './';
      this.tokenProvider = options.tokenProvider;
      this.requestProvider = options.requestProvider || null;
      this.storageKey = 'globalbrowserpush:device:' + this.applicationCode;
    }
    get deviceId() {
      let id = root.localStorage.getItem(this.storageKey);
      if (!id) { id = randomUuid(); root.localStorage.setItem(this.storageKey, id); }
      return id;
    }
    supported() {
      return !!(root.isSecureContext && 'serviceWorker' in navigator && 'PushManager' in root && 'Notification' in root);
    }
    async token() {
      const result = await this.tokenProvider();
      const token = typeof result === 'string' ? result : result && result.token;
      if (!token) throw new Error('The application backend did not supply a registration token.');
      return token;
    }
    endpoint(action) {
      const query = 'applicationCode=' + encodeURIComponent(this.applicationCode);
      return this.serviceUrl + '/api/push/v1/' + action + '?' + query;
    }
    async request(action, method, data, token) {
      if (this.requestProvider) return this.requestProvider(action, method, data);
      const headers = { 'Content-Type': 'application/json' };
      if (token) headers.Authorization = 'Bearer ' + token;
      const response = await root.fetch(this.endpoint(action), {
        method, mode: 'cors', credentials: 'omit', cache: 'no-store', headers,
        body: data === undefined ? undefined : JSON.stringify(data)
      });
      if (!response.ok) throw new Error('Push service ' + action + ' HTTP ' + response.status);
      return response.json();
    }
    async registration() {
      const registration = await navigator.serviceWorker.register(this.workerUrl, { scope: this.workerScope });
      if (registration.active) return registration;
      const worker = registration.installing || registration.waiting;
      if (!worker) throw new Error('No active service worker. Retry after reloading.');
      await Promise.race([
        new Promise((resolve,reject) => {
          if (worker.state === 'activated') return resolve();
          const fn = () => {
            if (worker.state === 'activated') { worker.removeEventListener('statechange',fn); resolve(); }
            else if (worker.state === 'redundant') { worker.removeEventListener('statechange',fn); reject(new Error('Service worker failed.')); }
          };
          worker.addEventListener('statechange',fn);
        }),
        new Promise((_, reject) => setTimeout(() => reject(new Error('Service worker activation timed out.')), 15000))
      ]);
      return registration;
    }
    // Call ONLY from a genuine user click. Permission must be requested before awaited calls.
    async enable() {
      if (!this.supported()) throw new Error('Browser Push API requires a supported browser and HTTPS.');
      if (Notification.permission === 'denied') throw new Error('Notifications blocked in browser settings.');
      const permission = Notification.permission === 'granted' ? 'granted' : await Notification.requestPermission();
      if (permission !== 'granted') throw new Error('Notification permission not granted.');
      const registration = await this.registration();
      const config = await this.request('config', 'GET');
      const vapidKey = config.publicKey || config.vapidPublicKey || config.publicVapidKey || (config.vapid && config.vapid.publicKey);
      if (!vapidKey) throw new Error('Global Push config did not provide a VAPID public key. Check /guest/push/config response.');
      const key = urlBase64Decode(vapidKey);
      let subscription = await registration.pushManager.getSubscription();
      if (subscription) {
        const existing = subscription.options && subscription.options.applicationServerKey;
        const oldKey = existing ? new Uint8Array(existing) : null;
        if (!oldKey || oldKey.length !== key.length || oldKey.some((b,i) => b !== key[i])) {
          await subscription.unsubscribe(); subscription = null;
        }
      }
      if (!subscription) subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true, applicationServerKey: key
      });
      const data = subscription.toJSON();
      data.clientDeviceId = this.deviceId;
      data.browserName = (navigator.userAgent || 'Browser').slice(0,80);
      const response = await this.request('subscriptions','POST',data,this.requestProvider ? null : await this.token());
      return Object.assign({subscribed:true}, response || {});
    }
    async status() {
      const result = { supported:this.supported(),permission:'unavailable',deviceId:null,subscribed:false,serverSubscribed:false };
      if (!result.supported) return result;
      result.permission = Notification.permission;
      if (result.permission !== 'granted') return result;
      const registration = await this.registration();
      const subscription = await registration.pushManager.getSubscription();
      result.subscribed = !!subscription;
      if (!subscription) return result;
      result.deviceId = this.deviceId;
      const server = await this.request('subscriptions/status','POST',{
        clientDeviceId:this.deviceId, endpoint:subscription.endpoint
      },this.requestProvider ? null : await this.token());
      result.serverSubscribed = server.subscribed === true;
      return result;
    }
    async synchronize() {
      if (!this.supported() || Notification.permission !== 'granted') return {subscribed:false};
      const registration=await this.registration();
      const subscription=await registration.pushManager.getSubscription();
      if (!subscription) return {subscribed:false};
      const data=subscription.toJSON();data.clientDeviceId=this.deviceId;
      data.browserName=(navigator.userAgent || 'Browser').slice(0,80);
      return this.request('subscriptions','POST',data,this.requestProvider ? null : await this.token());
    }
    // Call during authenticated logout. Do not automatically unsubscribe another browser profile.
    async disable() {
      if (!this.supported()) return {removed:false};
      const registration=await this.registration();
      const subscription=await registration.pushManager.getSubscription();
      if (!subscription) return {removed:false};
      const result=await this.request('subscriptions/unsubscribe','POST',{
        clientDeviceId:this.deviceId,endpoint:subscription.endpoint
      },this.requestProvider ? null : await this.token());
      await subscription.unsubscribe();
      return result;
    }
  }
  root.GlobalBrowserPush = GlobalBrowserPush;
})(typeof window !== 'undefined' ? window : globalThis);
