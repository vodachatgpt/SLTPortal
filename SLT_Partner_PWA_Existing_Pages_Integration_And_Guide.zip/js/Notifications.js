/* SLT Partner notification list. Works with actual SLTProject guest inbox. */
(function(){
 'use strict';
 const el=document.getElementById('notifyList');if(!el)return;
 const $=id=>document.getElementById(id);
 let page=1,pages=1,unreadOnly=false,loading=false;
 function escapeText(v){return String(v==null?'':v).replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));}
 function formatNotificationTime(v){
   if(!v)return'';
   const short=/^(\d{1,2}):(\d{2})/.exec(String(v));
   if(short&&String(v).length<=8){const h=Number(short[1]);return String(h%12||12).padStart(2,'0')+':'+short[2]+' '+(h>=12?'PM':'AM');}
   // SQL EgyptDateTimeService.Now returns Cairo wall clock without a zone.
   const raw=String(v);const hasZone=/Z$|[+-]\d{2}:?\d{2}$/.test(raw);
   const date=new Date(hasZone?raw:raw.replace(' ','T')+'+02:00');
   if(!Number.isFinite(date.getTime()))return raw;
   const iso=new Intl.DateTimeFormat('en-CA',{timeZone:'Africa/Cairo',year:'numeric',month:'2-digit',day:'2-digit'}).format(date);
   const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Africa/Cairo',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
   const opts={timeZone:'Africa/Cairo',hour:'2-digit',minute:'2-digit',hour12:true};
   if(iso!==today){opts.day='numeric';opts.month='short';}
   return new Intl.DateTimeFormat('en-GB',opts).format(date);
 }
 function setStatus(t){if($('notifyStatus'))$('notifyStatus').textContent=t||'';}
 function checkSession(){
   if(!guestToken()) {el.innerHTML='<li class="page-message">Please sign in as a Guest from InvitationCode.html.</li>';setStatus('Guest authentication is required.');return false;}
   return true;
 }
 function render(items){
  el.innerHTML=items.length?items.map(n=>{
    const unread=n.NotificationStatus==='Unread',id=escapeText(n.NotificationID);
    return `<li><button type="button" class="notify-item ${unread?'unread':''}" data-id="${id}"><span class="notify-logo"><img src="../media/assets/VFLogo.svg" alt=""></span><span class="notify-body"><span class="notify-title d-block">${escapeText(n.NotificationTitle)}</span><span class="notify-text d-block">${escapeText(n.NotificationDetails)}</span><span class="notify-time">${escapeText(formatNotificationTime(n.NotificationTime))} ${unread?'<span class="notify-dot" aria-label="Unread"></span>':''}</span></span></button></li>`;
  }).join(''):'<li class="page-message">No notifications yet.</li>';
 }
 async function load(){
  if(loading||!checkSession())return;
  loading=true;el.innerHTML='<li class="page-message">Loading notifications…</li>';
  try{
   const data=await getNotificationPage(page,10,unreadOnly);
   pages=Math.max(1,Number(data.TotalPages)||1);
   const items=(data.Items||[]).map(normalizeNotification);
   render(items);
   if($('unreadCount'))$('unreadCount').textContent=Number(data.UnreadCount)||0;
   if($('pageInfo'))$('pageInfo').textContent='Page '+page+' of '+pages;
   if($('prevPage'))$('prevPage').disabled=page<=1;
   if($('nextPage'))$('nextPage').disabled=page>=pages;
   setStatus('');
  }catch(err){el.innerHTML='<li class="page-message">'+escapeText(err.message)+'</li>';setStatus(err.message);}finally{loading=false;}
 }
 el.addEventListener('click',async event=>{
  const item=event.target.closest('.notify-item');if(!item||!item.classList.contains('unread'))return;
  item.disabled=true;
  try{await markNotificationRead(item.dataset.id);await load();}
  catch(err){setStatus('Failed to mark notification as read: '+err.message);item.disabled=false;}
 });
 if($('refreshNotifications'))$('refreshNotifications').addEventListener('click',()=>{page=1;load()});
 if($('unreadOnly'))$('unreadOnly').addEventListener('change',e=>{unreadOnly=e.target.checked;page=1;load()});
 if($('prevPage'))$('prevPage').addEventListener('click',()=>{if(page>1){page--;load()}});
 if($('nextPage'))$('nextPage').addEventListener('click',()=>{if(page<pages){page++;load()}});
 if($('enablePush'))$('enablePush').addEventListener('click',async()=>{
  const b=$('enablePush');b.disabled=true;
  try{const result=await PartnerGuestPush.enable();setStatus('Push enabled: '+JSON.stringify({subscribed:!!result.subscribed}));}
  catch(err){setStatus('Push registration failed: '+err.message)}finally{b.disabled=false}
 });
 if($('checkPush'))$('checkPush').addEventListener('click',async()=>{
  try{const s=await PartnerGuestPush.status();setStatus('Browser push: permission='+s.permission+', subscribed='+s.subscribed+', provider registered='+s.serverSubscribed);}
  catch(err){setStatus(err.message)}
 });
 if($('disablePush'))$('disablePush').addEventListener('click',async()=>{
  try{await PartnerGuestPush.disable();setStatus('Push unsubscribed from this browser.');}catch(err){setStatus(err.message)}
 });
 window.PartnerGuestNotifications={refresh:load};
 document.addEventListener('DOMContentLoaded',load);
})();
