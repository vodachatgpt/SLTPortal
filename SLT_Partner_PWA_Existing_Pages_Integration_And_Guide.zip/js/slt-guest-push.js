/* SLT Guest Push adapter for Global Browser Push V10.3.
 * Uses the guest JWT obtained AFTER passcode login. Never sends passcodes to Global Push.
 * Requires global-browser-push.v10.3.js to load first.
 */
(function (root) {
  'use strict';
  function create(options) {
    options = options || {};
    if (typeof root.GlobalBrowserPush !== 'function') throw new Error('Load the Global Browser Push V10.3 SDK first.');
    const apiBase = String(options.sltApiBase || '').replace(/\/+$/, '');
    if (!apiBase) throw new Error('sltApiBase must point to the trusted SLT backend /api.');
    const getGuestToken = options.getGuestToken || (() => root.localStorage.getItem('slt_guest_token'));
    const push = new root.GlobalBrowserPush({
      serviceUrl: options.globalPushServiceUrl,
      applicationCode: options.applicationCode,
      workerUrl: options.workerUrl || './global-push-sw.js',
      workerScope: options.workerScope || './',
      // Preferred: same-origin SLT backend proxy. No browser-to-Global-Push
      // CORS requirement; Global Push application API key stays server-side.
      requestProvider: async (action, method, data) => {
        const guestToken = getGuestToken();
        if (!guestToken) throw new Error('Guest must sign in first.');
        const endpoint = apiBase + '/slt-notifications/guest/push/' + action;
        const response = await root.fetch(endpoint, {
          method: method,
          headers: {
            Authorization: 'Bearer ' + guestToken,
            ...(method !== 'GET' ? { 'Content-Type': 'application/json' } : {})
          },
          credentials: 'omit', cache: 'no-store',
          body: method === 'GET' ? undefined : JSON.stringify(data || {})
        });
        const result = await response.json().catch(() => ({}));
        if (!response.ok) {
          const message = result.Message || result.message ||
            'SLT browser push registration HTTP ' + response.status;
          throw new Error(message +
            (result.ProviderStatus ? ' (provider HTTP ' + result.ProviderStatus + ')' : ''));
        }
        return result;
      },
      tokenProvider: async () => {
        const guestJwt = getGuestToken();
        if (!guestJwt) throw new Error('Guest must sign in with their passcode first.');
        const response = await root.fetch(apiBase + '/slt-notifications/guest/registration-token', {
          method: 'POST',
          headers: { 'Authorization': 'Bearer ' + guestJwt, 'Content-Type': 'application/json' },
          credentials: 'omit', cache: 'no-store', body: '{}'
        });
        if (!response.ok) {
          if (response.status === 401 || response.status === 403) throw new Error('Guest session expired. Please sign in again.');
          throw new Error('Cannot register notifications (SLT HTTP ' + response.status + ').');
        }
        const data = await response.json();
        if (!data || !data.token) throw new Error('SLT backend did not return a registration token.');
        return data.token;
      }
    });
    let bound = false;
    return {
      supported: () => push.supported(),
      get deviceId() { return push.deviceId; },
      // Call ONLY on Enable Notifications button click, after passcode login.
      async enable() {
        if (!getGuestToken()) throw new Error('Guest must sign in with their passcode first.');
        const result = await push.enable();
        bound = !!result.subscribed;
        return result;
      },
      async status() {
        if (!getGuestToken()) return { subscribed:false, reason:'not-authenticated' };
        return push.status();
      },
      // After JWT validation, optionally rebind an existing subscription to this guest.
      // Do not ask for browser permission automatically.
      async synchronize() {
        if (!getGuestToken()) return {subscribed:false, reason:'not-authenticated'};
        const result = await push.synchronize();
        bound = !!result.subscribed;
        return result;
      },
      async disable() {
        if (!getGuestToken()) throw new Error('Guest session required to unlink the subscription.');
        const result = await push.disable();
        bound = false;
        return result;
      },
      // On logout: best-effort server unlink, then local browser unsubscribe even on network failure.
      // Your application must clear the guest JWT AFTER this call.
      async beforeLogout() {
        try { return await this.disable(); }
        catch (err) {
          if (root.navigator.serviceWorker) {
            const reg = await root.navigator.serviceWorker.getRegistration(options.workerScope || './');
            const sub = reg && await reg.pushManager.getSubscription();
            if (sub) await sub.unsubscribe();
          }
          // The server may keep a stale record. Inform caller for cleanup/retry.
          return {removed:false,warning:'Server unlink not confirmed; local subscription disabled.',errorCode:'REMOTE_UNLINK_FAILED'};
        }
      },
      get wasEnabledThisSession(){return bound;}
    };
  }
  root.SLTGuestPush = { create };
})(typeof window !== 'undefined' ? window : globalThis);
