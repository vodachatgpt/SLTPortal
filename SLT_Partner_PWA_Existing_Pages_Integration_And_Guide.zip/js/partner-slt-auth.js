/* SLT Partner PWA — email-first guest login on EXISTING InvitationCode.html.
 * No new HTML page. Existing app.js, config.js, api.js must load on this page.
 * Mounts a self-contained form because the original InvitationCode.html markup
 * was not included in the supplied integration overlay.
 */
(function(){
  'use strict';
  const launch=()=>{
    if(document.getElementById('sltPwaLogin'))return;
    const main=document.querySelector('main')||document.body;
    const section=document.createElement('section');
    section.id='sltPwaLogin';
    section.className='slt-pwa-login';
    section.innerHTML=`
      <h2>Sign in to SLT</h2>
      <p>Enter the email address registered for your invitation. We'll send your passcode by email and SMS.</p>
      <form id="sltPwaRequestForm" novalidate>
        <label for="sltPwaEmail">Registered email</label>
        <input id="sltPwaEmail" type="email" autocomplete="email" inputmode="email" required placeholder="name@example.com">
        <button type="submit" id="sltPwaSendButton">Send passcode</button>
      </form>
      <form id="sltPwaCodeForm" novalidate>
        <label for="sltPwaPasscode">Six-character passcode</label>
        <input id="sltPwaPasscode" type="text" autocomplete="one-time-code" autocapitalize="characters" spellcheck="false" maxlength="6" pattern="[A-Za-z0-9]{6}" placeholder="A7B2C9" required>
        <button type="submit" id="sltPwaLoginButton">Sign in</button>
      </form>
      <p id="sltPwaLoginStatus" role="status" aria-live="polite"></p>`;
    main.insertBefore(section,main.firstChild);
    const $=id=>document.getElementById(id);
    const status=$('sltPwaLoginStatus');
    const email=$('sltPwaEmail');
    const code=$('sltPwaPasscode');
    email.value=readStorage('slt.guestEmail')||'';
    const setStatus=(message,error)=>{status.textContent=message||'';status.classList.toggle('error',!!error)};
    $('sltPwaRequestForm').addEventListener('submit',async e=>{
      e.preventDefault();e.stopPropagation();
      const btn=$('sltPwaSendButton');btn.disabled=true;
      try{
        const clean=email.value.trim();
        await requestGuestPasscode(clean);
        writeStorage('slt.guestEmail',clean);
        setStatus('If the email is registered and eligible, a passcode will be sent by email and SMS.');
        code.focus();
      }catch(err){setStatus(err.message||'Cannot request a passcode.',true)}
      finally{btn.disabled=false}
    });
    code.addEventListener('input',()=>{code.value=code.value.replace(/[^a-zA-Z0-9]/g,'').toUpperCase().slice(0,6)});
    $('sltPwaCodeForm').addEventListener('submit',async e=>{
      e.preventDefault();e.stopPropagation();
      const btn=$('sltPwaLoginButton');btn.disabled=true;
      try{
        const result=await guestLogin(code.value);
        saveGuestLoginResult(result);
        if(window.PartnerGuestPush&&typeof PartnerGuestPush.reset==='function')PartnerGuestPush.reset();
        code.value='';
        setStatus('Welcome to SLT. Opening your app…');
        location.assign(new URL('AllowAccess.html',location.href).href);
      }catch(err){setStatus(err.message||'Unable to sign in.',true)}
      finally{btn.disabled=false}
    });
  };
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',launch);
  else launch();
})();
