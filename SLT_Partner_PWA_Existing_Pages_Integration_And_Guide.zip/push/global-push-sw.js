/* Dedicated push service worker for the partner test client.
   Scope: /push/ — does not replace the existing PWA sw.js. */
self.addEventListener('push', event => {
  let data={};
  try{if(event.data)data=event.data.json()}catch(_){data={body:event.data?event.data.text():''}}
  const name=String(data.title||'SLT Notification').slice(0,120);
  const message=String(data.body||'You have a new message.').slice(0,500);
  // Only open safe pages on this application's own origin.
  const fallback=new URL('../html/Notifications.html',self.registration.scope);
  let target=fallback;
  try{if(data.url){const candidate=new URL(data.url,fallback);if(candidate.origin===fallback.origin)target=candidate}}catch(_){}
  event.waitUntil(self.registration.showNotification(name,{
    body:message,tag:String(data.id||Date.now()),
    icon:'../media/assets/VFLogo.svg',badge:'../media/assets/VFLogo.svg',
    data:{url:target.href}
  }));
});
self.addEventListener('notificationclick',event=>{
  event.notification.close();
  const fallback=new URL('../html/Notifications.html',self.registration.scope);
  let dest=fallback;
  try{const candidate=new URL(event.notification.data&&event.notification.data.url||fallback.href,fallback);if(candidate.origin===fallback.origin)dest=candidate}catch(_){}
  event.waitUntil((async()=>{
    const windows=await clients.matchAll({type:'window',includeUncontrolled:true});
    for(const page of windows){if(page.url===dest.href&&page.focus)return page.focus()}
    return clients.openWindow(dest.href);
  })());
});
