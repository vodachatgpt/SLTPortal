(function () {
    "use strict";
    window.sltSelectModuleTab = function (name) {
        var tabs = document.querySelectorAll("[data-module-tab]");
        var panels = document.querySelectorAll("[data-module-pane]");
        tabs.forEach(function (tab) {
            var active = tab.getAttribute("data-module-tab") === name;
            tab.classList.toggle("is-active", active);
            tab.setAttribute("aria-selected", active ? "true" : "false");
            tab.tabIndex = active ? 0 : -1;
        });
        panels.forEach(function (panel) {
            panel.hidden = panel.getAttribute("data-module-pane") !== name;
        });
    };
    document.addEventListener("click", function (event) {
        var tab = event.target.closest("[data-module-tab]");
        if (tab) window.sltSelectModuleTab(tab.getAttribute("data-module-tab"));
    });
})();
