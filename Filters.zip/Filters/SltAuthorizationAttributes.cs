﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Web;
using System.Web.Http;
using System.Web.Http.Controllers;
using SLTProject.Data;
using SLTProject.Services;

namespace SLTProject.Filters
{
    public enum SltAccessType { Admin, Guest, AdminOrGuest }

    public abstract class SltAuthorizationAttribute : AuthorizeAttribute
    {
        private readonly SltAccessType _access;
        protected SltAuthorizationAttribute(SltAccessType access) { _access = access; }

        protected override bool IsAuthorized(HttpActionContext context)
        {
            var authorization = context.Request.Headers.Authorization;
            if (authorization == null ||
                !string.Equals(authorization.Scheme, "Bearer", StringComparison.OrdinalIgnoreCase) ||
                string.IsNullOrWhiteSpace(authorization.Parameter) ||
                authorization.Parameter.Length > 300)
                return false;

            byte[] hash;
            using (var sha = SHA256.Create())
                hash = sha.ComputeHash(Encoding.UTF8.GetBytes(authorization.Parameter));

            // Egypt-local datetime2 convention adopted by the SLT login services.
            DateTime now = EgyptDateTimeService.Now;
            using (var db = new SLTEntities())
            {
                if (_access != SltAccessType.Guest)
                {
                    var admin = db.Admins.AsNoTracking()
                        .Where(a => a.SessionTokenHash == hash && a.IsActive &&
                                    !a.IsDeleted && a.SessionExpiresAt > now)
                        .Select(a => new { a.Id, a.Email, a.FullName })
                        .FirstOrDefault();
                    if (admin != null)
                    {
                        SetPrincipal(context, "Admin", admin.Id.ToString(), admin.Email, admin.FullName);
                        context.Request.Properties["SLTAdminId"] = admin.Id;
                        context.Request.Properties["SLTAdminEmail"] = admin.Email;
                        context.Request.Properties["SLTUserType"] = "Admin";
                        return true;
                    }
                }

                if (_access != SltAccessType.Admin)
                {
                    var guest = db.Guests.AsNoTracking()
                        .Where(g => g.SessionTokenHash == hash && !g.IsDeleted &&
                                    g.SessionExpiresAt > now)
                        .Select(g => new { g.Id, g.Email, g.FullName })
                        .FirstOrDefault();
                    if (guest != null)
                    {
                        SetPrincipal(context, "Guest", guest.Id.ToString(), guest.Email, guest.FullName);
                        context.Request.Properties["SLTGuestId"] = guest.Id;
                        context.Request.Properties["SLTGuestEmail"] = guest.Email;
                        context.Request.Properties["SLTUserType"] = "Guest";
                        return true;
                    }
                }
            }
            return false;
        }

        private static void SetPrincipal(HttpActionContext context,
            string role, string id, string email, string fullName)
        {
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, id),
                new Claim(ClaimTypes.Name, string.IsNullOrWhiteSpace(email) ? id : email),
                new Claim(ClaimTypes.Role, role),
                new Claim("SLTUserType", role)
            };
            if (!string.IsNullOrWhiteSpace(email)) claims.Add(new Claim(ClaimTypes.Email, email));
            if (!string.IsNullOrWhiteSpace(fullName)) claims.Add(new Claim("SLTFullName", fullName));
            var principal = new ClaimsPrincipal(new ClaimsIdentity(claims, "SLT-Bearer"));
            context.RequestContext.Principal = principal;
            Thread.CurrentPrincipal = principal;
            if (HttpContext.Current != null) HttpContext.Current.User = principal;
        }
    }

    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, Inherited = true)]
    public sealed class SltAdminAttribute : SltAuthorizationAttribute
    {
        public SltAdminAttribute() : base(SltAccessType.Admin) { }
    }

    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, Inherited = true)]
    public sealed class SltGuestAttribute : SltAuthorizationAttribute
    {
        public SltGuestAttribute() : base(SltAccessType.Guest) { }
    }

    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, Inherited = true)]
    public sealed class SltAdminOrGuestAttribute : SltAuthorizationAttribute
    {
        public SltAdminOrGuestAttribute() : base(SltAccessType.AdminOrGuest) { }
    }
}
