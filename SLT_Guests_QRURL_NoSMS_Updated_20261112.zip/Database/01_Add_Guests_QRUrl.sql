-- Run on SLTProject database BEFORE publishing updated GuestsService.
-- This adds URL metadata; it does not download third-party images.
IF COL_LENGTH('dbo.Guests', 'QRUrl') IS NULL
BEGIN
    ALTER TABLE dbo.Guests ADD QRUrl NVARCHAR(2048) NULL;
END;
GO
-- Then right-click your EF6 .edmx -> Update Model from Database -> Guests.
-- Ensure the generated Guest entity contains public string QRUrl { get; set; }.
