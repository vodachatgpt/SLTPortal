SLT Guests: 2026-11-12 changes — from the supplied Guest.zip only
==================================================================
Included replacement files:
  Guest/GuestsController.cs
  Guest/GuestsService.cs
  Guest/GuestPasscodeResendController.cs
  Guest/GuestPasscodeResendService.cs
  Guest/guests-admin.html
  Guest/guests-admin.js
  Guest/Guest_Excel_Example.xlsx (reference-only sample, not a source code file)
  Database/01_Add_Guests_QRUrl.sql
  Config/Web.config-notes.txt

CHANGES
- Guest passcode reset/resend is email-only; this removes SmsService calls from the uploaded files.
- Guest SMS template CRUD controller endpoints removed.
- Guest invitation POST attempts to disable SendSms on its request DTO; full SMS removal
  requires the original GuestOperationsService and any other SmsService callers.
- Guest admin page: removed SMS Sent grid column, SMS checkbox in Send Invitations,
  notification box in Create/Edit, QR Images tab and Upload/Replace QR actions;
  kept View QR action; added Clear Filters button; added QRUrl to guest form.
- QRUrl: HTTPS domain URL is persisted on Guests and returned in GuestView.
  Existing QR image endpoint serves folder/database QR first; otherwise redirects
  to QRUrl. No downloading or copying the external image into SQL.
- PhoneNumber: optional + prefix, e.g. +201001234567 or 01001234567.
- Download Excel Template endpoint now appends PhoneNumber/QRUrl as text columns,
  with an Examples worksheet and an Instructions worksheet.
- GuestsService.ImportAsync reads QRUrl and PhoneNumber without changing staging schema.
- GuestsController.Import uses GuestOperationsService.ImportAsync and applies QRUrl
  AFTER successfully imported rows; QRUrl update is a second database transaction.
  If that step fails, earlier import may already have committed.

DEPLOY STEPS
1) Back up database and project.
2) Run Database/01_Add_Guests_QRUrl.sql.
3) EF6 DB-first: update model from database in your EDMX, refresh Guests entity,
   and verify property QRUrl exists (string). Build after this refresh.
4) Replace the 4 C# + 2 frontend files listed above.
5) Redeploy and hard refresh the page (CTRL+F5).
6) Download the new template FROM THE API and check Examples sheet.
7) Upload a REAL guest with local phone and QRUrl; GET /api/guests/{id}/qr
   should redirect to the URL if no folder / SQL QR is present.
8) Test Save/Edit, Reset Passcode (email only), Send Invitations (email only),
   Clear Filters, and both Excel import modes.

IMPORTANT LIMITATIONS / NOT INCLUDED
- Supplied ZIP does NOT contain GuestOperationsService.cs (the actual invitation
  distributor and the primary Guest import validator) nor any shared SMS service,
  other controllers, Web.config, or shared frontend invitation scripts.
  Therefore this package CANNOT establish that absolutely every backend SMS
  connection is removed, or that global Excel import permits local phone numbers.
  Update the GuestOperationsService validation and distribution code as well if
  it still requires +country code or calls SmsService.
- This package has NOT been compiled against your full .NET Framework solution.
- The example URLs on the Examples sheet are documentation, not real QR images.
- A browser redirected to an external QR URL needs access to that host.
- Current QR upload API endpoints remain in the backend for compatibility although
  the upload UI has been removed.
