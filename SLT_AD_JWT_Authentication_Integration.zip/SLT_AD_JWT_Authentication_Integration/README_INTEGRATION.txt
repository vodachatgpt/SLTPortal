SLT ACTIVE DIRECTORY + JWT AUTHENTICATION
=========================================

Contents
--------
Controllers/AuthController.cs
Models/AuthRequest.cs
Services/IAuthService.cs
Services/AuthService.cs
Services/Security/JwtManager.cs
Services/Security/CustomAuthorize.cs
Deployment/WEB_CONFIG_AUTH_SETTINGS.txt

Authentication flow
-------------------
1. Client POSTs /api/auth/login with:
   - Header name configured by Auth_APIKeyName (default X-SLT-API-Key)
   - Header value matching Auth_ClientId
   - JSON { "LoginName": "DOMAIN\\username", "Password": "..." }

2. AuthService validates the supplied credentials against Active Directory.
   LDAP_Path must identify a reachable AD domain/DC.

3. AuthService reads the AD user's mail attribute (or UPN fallback).

4. That email must match an active, non-deleted dbo.Admins row:
   dbo.Admins.IsActive = 1
   dbo.Admins.IsDeleted = 0

5. JWT is generated with:
   - AdminId
   - FullName
   - email
   - NTAccount
   - role = SLTAdmin
   - issuer/audience
   - 24-hour expiry (1440 minutes maximum)

6. Protected requests use:
   Authorization: Bearer <JWT>

7. CustomAuthorize calls Auth_BaseUrl + Auth_ValidateToken_Endpoint.
   The SLT validate-token endpoint validates the JWT locally AND checks that
   AdminId/email still map to an active, non-deleted dbo.Admins row.
   JwtManager then validates the signature locally again before creating
   the ClaimsPrincipal. Disabling/deleting an admin therefore invalidates
   their token on the next protected request.

Routes
-----
POST /api/auth/login
POST /api/auth/validate-token

How to add to the SLT project
-----------------------------
1. Copy the files into the matching folders.
2. If this is an old-style .NET Framework project, use
   Project > Add Existing Item for each .cs file, or add Compile entries
   to the .csproj.
3. Merge Deployment/WEB_CONFIG_AUTH_SETTINGS.txt into Web.config appSettings.
4. Add/verify references:
   - System.DirectoryServices
   - System.DirectoryServices.AccountManagement
   - System.IdentityModel
   - System.Net.Http
   - System.Configuration
   - System.Data
   - System.Data.Entity (EF6)
   - System.IdentityModel.Tokens.Jwt
   - Microsoft.IdentityModel.Tokens
   - Newtonsoft.Json
5. Ensure System.IdentityModel.Tokens.Jwt and Microsoft.IdentityModel.Tokens
   package versions are compatible with each other.
6. Confirm WebApiConfig.Register uses attribute routing:
      config.MapHttpAttributeRoutes();
7. Set LDAP_Path, Auth_ClientId, JwtSecretKey, Auth_BaseUrl and the JWT
   issuer/audience values for the environment.
8. Build the solution.

How to protect existing admin controllers
------------------------------------------
Add:
    using SLTProject.Services.Security;

Then decorate an admin-only controller or action with:
    [CustomAuthorize]

Apply this to administrator endpoints only. Do NOT put this attribute on:
- Guest passcode login
- Guest bearer-token endpoints
- Weather endpoints that are intentionally unauthenticated
- The /api/auth/login or /api/auth/validate-token actions

If an existing controller still has [SltAdmin], it will continue to use that
existing filter. Replace [SltAdmin] with [CustomAuthorize] only on the
controllers/actions that should accept this new AD/JWT authentication.
Do not place both attributes unless you deliberately want both checks.

Admin table behavior
--------------------
dbo.Admins remains the SLT administrator allow-list. AD authentication alone
does not grant access. The AD user's email must match an active, non-deleted
dbo.Admins row. No admin passcode is checked or changed by this new flow.
The new JWT is stateless and does not update Admins.SessionTokenHash.
The active/non-deleted Admins row is checked again at token-validation time.

Important AD connectivity limitation
------------------------------------
This flow still requires the SLT API server to contact Active Directory.
It does NOT bypass an unavailable Domain Controller. If the server cannot
reach AD, login returns HTTP 503. Configure LDAP_Path to a reachable DC/domain
and check DNS, firewall, LDAP/Kerberos connectivity, and service-account/
machine network permissions.

Validation endpoint architecture
---------------------------------
The sample integration uses a remote validation HTTP call on each protected
request. This package preserves that pattern. Auth_BaseUrl must point to the
same SLT application instance/environment that issued the token, and the
endpoint must be reachable from the SLT server itself. This introduces one
additional HTTP request per protected API request. If the application is
behind a reverse proxy or virtual directory, set Auth_BaseUrl to the
correct internal application root.

Security
--------
- Never log the submitted password or JWT.
- Use HTTPS except local development.
- Auth_ClientId is visible if embedded in frontend JavaScript; do not treat
  it as a secret or as the primary authentication mechanism.
- Use a random JWT signing key of at least 32 UTF-8 bytes.
- Keep the signing key consistent across all SLT instances.
- JWTs expire after 24 hours by default.
