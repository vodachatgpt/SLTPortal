using System.ComponentModel.DataAnnotations;

namespace SLTProject.Models
{
    public class AuthRequest
    {
        [Required]
        [StringLength(256)]
        public string LoginName { get; set; }

        [Required]
        [StringLength(512)]
        public string Password { get; set; }
    }

    public class ValidateTokenRequest
    {
        [Required]
        public string Token { get; set; }
    }

    public class AuthLoginResult
    {
        public string Token { get; set; }
        public long AdminId { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        public System.DateTime ExpiresAt { get; set; }
    }

    public class TokenValidationResponse
    {
        public bool IsValid { get; set; }
    }
}
