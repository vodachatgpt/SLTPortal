using System;
using System.Configuration;
using System.Diagnostics;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using SLTProject.Models;
using SLTProject.Services;
using SLTProject.Services.Security;

namespace SLTProject.Controllers
{
    [RoutePrefix("api/auth")]
    public class AuthController : ApiController
    {
        private readonly IAuthService _authService;

        public AuthController()
            : this(new AuthService())
        {
        }

        public AuthController(IAuthService authService)
        {
            if (authService == null)
                throw new ArgumentNullException("authService");

            _authService = authService;
        }

        // POST api/auth/login
        // Header: X-SLT-API-Key: <Auth_ClientId>
        // Body: { "LoginName": "DOMAIN\\username", "Password": "..." }
        [HttpPost]
        [AllowAnonymous]
        [Route("login")]
        public async Task<IHttpActionResult> Login(AuthRequest request)
        {
            if (request == null ||
                string.IsNullOrWhiteSpace(request.LoginName) ||
                string.IsNullOrWhiteSpace(request.Password))
            {
                return BadRequest("LoginName and Password are required.");
            }

            string headerName =
                ConfigurationManager.AppSettings["Auth_APIKeyName"];

            string configuredApiKey =
                ConfigurationManager.AppSettings["Auth_ClientId"];

            if (string.IsNullOrWhiteSpace(headerName) ||
                string.IsNullOrWhiteSpace(configuredApiKey))
            {
                Trace.TraceError(
                    "[SLT Auth] Auth_APIKeyName or Auth_ClientId is missing.");
                return Content(
                    HttpStatusCode.InternalServerError,
                    new { Message = "Authentication is not configured correctly." });
            }

            System.Collections.Generic.IEnumerable<string> headerValues;
            if (!Request.Headers.TryGetValues(headerName, out headerValues))
            {
                Trace.TraceWarning(
                    "[SLT Auth] Missing API key header for login {0}.",
                    SafeLoginName(request.LoginName));

                return Content(
                    HttpStatusCode.Unauthorized,
                    new { Message = "API Key header is required." });
            }

            string suppliedApiKey = headerValues.FirstOrDefault();

            if (!FixedTimeEquals(suppliedApiKey, configuredApiKey))
            {
                Trace.TraceWarning(
                    "[SLT Auth] Invalid API key for login {0}.",
                    SafeLoginName(request.LoginName));

                return Content(
                    HttpStatusCode.Unauthorized,
                    new { Message = "Invalid API Key." });
            }

            try
            {
                AuthLoginResult result =
                    await _authService.AuthenticateUserAsync(request);

                if (result == null)
                {
                    Trace.TraceWarning(
                        "[SLT Auth] Authentication rejected for {0}.",
                        SafeLoginName(request.LoginName));

                    return Unauthorized();
                }

                // Never log the submitted password or the JWT.
                Trace.TraceInformation(
                    "[SLT Auth] Successful login for {0}, AdminId={1}.",
                    SafeLoginName(request.LoginName),
                    result.AdminId);

                return Ok(new
                {
                    Token = result.Token,
                    TokenType = "Bearer",
                    ExpiresAt = result.ExpiresAt,
                    Admin = new
                    {
                        result.AdminId,
                        result.FullName,
                        result.Email,
                        Role = "SLTAdmin"
                    }
                });
            }
            catch (PrincipalServerDownException ex)
            {
                Trace.TraceError(
                    "[SLT Auth] Active Directory unavailable for {0}: {1}",
                    SafeLoginName(request.LoginName),
                    ex);

                return Content(
                    HttpStatusCode.ServiceUnavailable,
                    new
                    {
                        Message = "Active Directory is unavailable. Check LDAP connectivity and try again."
                    });
            }
            catch (PrincipalOperationException ex)
            {
                Trace.TraceError(
                    "[SLT Auth] Active Directory operation failed for {0}: {1}",
                    SafeLoginName(request.LoginName),
                    ex);

                return Content(
                    HttpStatusCode.ServiceUnavailable,
                    new
                    {
                        Message = "Active Directory could not complete the authentication request."
                    });
            }
            catch (ConfigurationErrorsException ex)
            {
                Trace.TraceError("[SLT Auth] Configuration error: {0}", ex);

                return Content(
                    HttpStatusCode.InternalServerError,
                    new { Message = "Authentication configuration is incomplete." });
            }
            catch (Exception ex)
            {
                Trace.TraceError(
                    "[SLT Auth] Login failed for {0}: {1}",
                    SafeLoginName(request.LoginName),
                    ex);

                return InternalServerError(ex);
            }
        }

        // POST api/auth/validate-token
        // Called by JwtManager from CustomAuthorize.
        // This endpoint validates locally and does not call JwtManager.GetPrincipalAsync,
        // avoiding a recursive HTTP validation loop.
        [HttpPost]
        [AllowAnonymous]
        [Route("validate-token")]
        public async Task<IHttpActionResult> ValidateToken(ValidateTokenRequest request)
        {
            if (request == null ||
                string.IsNullOrWhiteSpace(request.Token) ||
                request.Token.Length > 8192)
            {
                return Ok(new { IsValid = false });
            }

            try
            {
                var principal =
                    JwtManager.ValidateTokenLocally(request.Token);

                string email = principal == null
                    ? null
                    : principal.Claims
                        .Where(c => c.Type == "email" ||
                                    c.Type == System.Security.Claims.ClaimTypes.Email)
                        .Select(c => c.Value)
                        .FirstOrDefault();

                string adminIdValue = principal == null
                    ? null
                    : principal.Claims
                        .Where(c => c.Type == "AdminId")
                        .Select(c => c.Value)
                        .FirstOrDefault();

                long adminId;
                bool hasAdminId =
                    long.TryParse(adminIdValue, out adminId) &&
                    adminId > 0;

                bool validIdentity =
                    principal != null &&
                    principal.Identity != null &&
                    principal.Identity.IsAuthenticated &&
                    principal.IsInRole("SLTAdmin") &&
                    hasAdminId &&
                    !string.IsNullOrWhiteSpace(email);

                if (!validIdentity)
                    return Ok(new { IsValid = false });

                bool activeAdmin =
                    await _authService.IsAdminActiveAsync(adminId, email);

                return Ok(new { IsValid = activeAdmin });
            }
            catch (Exception ex)
            {
                Trace.TraceInformation(
                    "[SLT Auth] Token validation rejected: {0}",
                    ex.Message);

                return Ok(new { IsValid = false });
            }
        }

        private static string SafeLoginName(string value)
        {
            return (value ?? string.Empty).Trim();
        }

        private static bool FixedTimeEquals(string left, string right)
        {
            if (left == null || right == null || left.Length != right.Length)
                return false;

            int difference = 0;

            for (int i = 0; i < left.Length; i++)
                difference |= left[i] ^ right[i];

            return difference == 0;
        }
    }
}
