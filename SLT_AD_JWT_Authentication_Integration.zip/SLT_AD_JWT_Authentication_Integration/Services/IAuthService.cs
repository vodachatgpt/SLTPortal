using System.Threading.Tasks;
using SLTProject.Models;

namespace SLTProject.Services
{
    public interface IAuthService
    {
        Task<AuthLoginResult> AuthenticateUserAsync(AuthRequest request);

        Task<bool> IsAdminActiveAsync(long adminId, string email);
    }
}
