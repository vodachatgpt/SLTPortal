using Microsoft.IdentityModel.Tokens;
using SLTProject.Data;
using SLTProject.Models;
using SLTProject.Services.Security;
using System;
using System.Configuration;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Threading.Tasks;

namespace SLTProject.Services
{
    public class AuthService : IAuthService
    {
        public async Task<AuthLoginResult> AuthenticateUserAsync(
            AuthRequest request)
        {
            if (request == null ||
                string.IsNullOrWhiteSpace(request.LoginName) ||
                string.IsNullOrWhiteSpace(request.Password))
            {
                return null;
            }

            string loginName = request.LoginName.Trim();
            string email;
            string adDisplayName;

            // This authenticates against Active Directory.
            // The configured LDAP_Path must point to a reachable AD domain/DC.
            using (PrincipalContext context = CreatePrincipalContext())
            {
                bool authenticated = context.ValidateCredentials(
                    loginName,
                    request.Password,
                    ContextOptions.Negotiate);

                if (!authenticated)
                    return null;

                using (UserPrincipal adUser =
                    FindAdUser(context, loginName))
                {
                    if (adUser == null)
                        return null;

                    email = NormalizeEmail(
                        !string.IsNullOrWhiteSpace(adUser.EmailAddress)
                            ? adUser.EmailAddress
                            : adUser.UserPrincipalName);

                    adDisplayName = adUser.DisplayName;
                }
            }

            if (string.IsNullOrWhiteSpace(email))
                return null;

            // dbo.Admins remains the SLT allow-list.
            // AD credentials alone do not grant SLT administrator access.
            using (var db = new SLTEntities())
            {
                var admin = await db.Admins.SqlQuery(@"
                    SELECT TOP (1) *
                    FROM dbo.Admins
                    WHERE LOWER(LTRIM(RTRIM(Email))) = @email
                      AND IsActive = 1
                      AND IsDeleted = 0",
                    new SqlParameter("@email", SqlDbType.NVarChar, 320)
                    {
                        Value = email
                    })
                    .FirstOrDefaultAsync();

                if (admin == null)
                    return null;

                string fullName =
                    !string.IsNullOrWhiteSpace(admin.FullName)
                        ? admin.FullName
                        : adDisplayName;

                DateTime expiresAt;
                string token = JwtManager.CreateAdminToken(
                    admin.Id,
                    fullName,
                    admin.Email,
                    loginName,
                    out expiresAt);

                return new AuthLoginResult
                {
                    Token = token,
                    AdminId = admin.Id,
                    FullName = fullName,
                    Email = admin.Email,
                    ExpiresAt = expiresAt
                };
            }
        }


        public async Task<bool> IsAdminActiveAsync(
            long adminId,
            string email)
        {
            email = NormalizeEmail(email);

            if (adminId <= 0 || string.IsNullOrWhiteSpace(email))
                return false;

            using (var db = new SLTEntities())
            {
                return await db.Admins.AnyAsync(a =>
                    a.Id == adminId &&
                    a.Email == email &&
                    a.IsActive &&
                    !a.IsDeleted);
            }
        }

        private static PrincipalContext CreatePrincipalContext()
        {
            string ldapPath =
                ConfigurationManager.AppSettings["LDAP_Path"];

            string ldapDomain =
                ConfigurationManager.AppSettings["LDAP_Domain"];

            if (string.IsNullOrWhiteSpace(ldapPath))
                ldapPath = ldapDomain;

            if (string.IsNullOrWhiteSpace(ldapPath))
            {
                throw new ConfigurationErrorsException(
                    "Set LDAP_Path or LDAP_Domain in Web.config.");
            }

            ldapPath = ldapPath.Trim();

            // Supports LDAP://dc.example.com/DC=example,DC=com
            // and LDAPS://dc.example.com/DC=example,DC=com.
            Uri ldapUri;
            if (Uri.TryCreate(ldapPath, UriKind.Absolute, out ldapUri) &&
                (ldapUri.Scheme.Equals("ldap", StringComparison.OrdinalIgnoreCase) ||
                 ldapUri.Scheme.Equals("ldaps", StringComparison.OrdinalIgnoreCase)))
            {
                string container = ldapUri.AbsolutePath.Trim('/');

                return new PrincipalContext(
                    ContextType.Domain,
                    ldapUri.Host,
                    string.IsNullOrWhiteSpace(container) ? null : container);
            }

            // Otherwise LDAP_Path is the AD DNS domain or DC host,
            // e.g. corp.example.com.
            return new PrincipalContext(
                ContextType.Domain,
                ldapPath);
        }

        private static UserPrincipal FindAdUser(
            PrincipalContext context,
            string loginName)
        {
            string identityValue = loginName;
            IdentityType identityType = IdentityType.SamAccountName;

            if (loginName.IndexOf('\\') >= 0)
            {
                identityValue =
                    loginName.Substring(loginName.LastIndexOf('\\') + 1);
                identityType = IdentityType.SamAccountName;
            }
            else if (loginName.IndexOf('@') >= 0)
            {
                identityType = IdentityType.UserPrincipalName;
            }

            UserPrincipal user = UserPrincipal.FindByIdentity(
                context,
                identityType,
                identityValue);

            if (user == null)
            {
                user = UserPrincipal.FindByIdentity(
                    context,
                    loginName);
            }

            return user;
        }

        private static string NormalizeEmail(string value)
        {
            return (value ?? string.Empty)
                .Trim()
                .ToLowerInvariant();
        }
    }
}
