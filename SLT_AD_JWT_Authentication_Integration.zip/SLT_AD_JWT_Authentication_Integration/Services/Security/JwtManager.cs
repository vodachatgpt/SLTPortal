using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using SLTProject.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace SLTProject.Services.Security
{
    public static class JwtManager
    {
        private static readonly HttpClient HttpClient =
            CreateHttpClient();

        private static HttpClient CreateHttpClient()
        {
            int timeoutSeconds = 10;
            string configuredTimeout =
                ConfigurationManager.AppSettings["Auth_ValidationTimeoutSeconds"];

            if (!string.IsNullOrWhiteSpace(configuredTimeout))
            {
                int parsed;
                if (int.TryParse(configuredTimeout, out parsed) &&
                    parsed >= 1 && parsed <= 120)
                {
                    timeoutSeconds = parsed;
                }
            }

            return new HttpClient
            {
                Timeout = TimeSpan.FromSeconds(timeoutSeconds)
            };
        }

        public static string CreateAdminToken(
            long adminId,
            string fullName,
            string email,
            string ntAccount,
            out DateTime expiresAtUtc)
        {
            string secret =
                ConfigurationManager.AppSettings["JwtSecretKey"];
            string issuer =
                ConfigurationManager.AppSettings["JwtIssuer"];
            string audience =
                ConfigurationManager.AppSettings["JwtAudience"];

            if (string.IsNullOrWhiteSpace(secret) ||
                Encoding.UTF8.GetByteCount(secret) < 32)
            {
                throw new ConfigurationErrorsException(
                    "JwtSecretKey must contain at least 32 UTF-8 bytes.");
            }

            if (string.IsNullOrWhiteSpace(issuer))
                throw new ConfigurationErrorsException("JwtIssuer is missing.");

            if (string.IsNullOrWhiteSpace(audience))
                throw new ConfigurationErrorsException("JwtAudience is missing.");

            int expiryMinutes = 1440;
            string configuredExpiry =
                ConfigurationManager.AppSettings["JwtExpiryMinutes"];

            if (!string.IsNullOrWhiteSpace(configuredExpiry) &&
                (!int.TryParse(configuredExpiry, out expiryMinutes) ||
                 expiryMinutes < 1))
            {
                throw new ConfigurationErrorsException(
                    "JwtExpiryMinutes must be a positive integer.");
            }

            // SLT admin tokens are capped at 24 hours.
            if (expiryMinutes > 1440)
                expiryMinutes = 1440;

            DateTime now = DateTime.UtcNow;
            expiresAtUtc = now.AddMinutes(expiryMinutes);

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, ntAccount ?? email),
                new Claim("NTAccount", ntAccount ?? string.Empty),
                new Claim("AdminId", adminId.ToString(
                    System.Globalization.CultureInfo.InvariantCulture)),
                new Claim(ClaimTypes.Email, email ?? string.Empty),
                new Claim("email", email ?? string.Empty),
                new Claim("FullName", fullName ?? string.Empty),
                new Claim(ClaimTypes.Role, "SLTAdmin"),
                new Claim("role", "SLTAdmin")
            };

            var key = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(secret));

            var credentials = new SigningCredentials(
                key,
                SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: issuer,
                audience: audience,
                claims: claims,
                notBefore: now,
                expires: expiresAtUtc,
                signingCredentials: credentials);

            return new JwtSecurityTokenHandler()
                .WriteToken(token);
        }

        // Local signature/issuer/audience/lifetime validation.
        // Used by api/auth/validate-token and after remote validation.
        public static ClaimsPrincipal ValidateTokenLocally(string token)
        {
            if (string.IsNullOrWhiteSpace(token) || token.Length > 8192)
                throw new SecurityTokenException("Token is missing or too long.");

            string secret =
                ConfigurationManager.AppSettings["JwtSecretKey"];
            string issuer =
                ConfigurationManager.AppSettings["JwtIssuer"];
            string audience =
                ConfigurationManager.AppSettings["JwtAudience"];

            if (string.IsNullOrWhiteSpace(secret) ||
                Encoding.UTF8.GetByteCount(secret) < 32 ||
                string.IsNullOrWhiteSpace(issuer) ||
                string.IsNullOrWhiteSpace(audience))
            {
                throw new ConfigurationErrorsException(
                    "JWT validation settings are missing or invalid.");
            }

            var validationParameters = new TokenValidationParameters
            {
                ValidateIssuer = true,
                ValidIssuer = issuer,
                ValidateAudience = true,
                ValidAudience = audience,
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(
                    Encoding.UTF8.GetBytes(secret)),
                ValidateLifetime = true,
                RequireExpirationTime = true,
                RequireSignedTokens = true,
                ClockSkew = TimeSpan.FromSeconds(30),
                NameClaimType = ClaimTypes.Name,
                RoleClaimType = ClaimTypes.Role
            };

            var handler = new JwtSecurityTokenHandler();
            SecurityToken validatedToken;

            ClaimsPrincipal principal = handler.ValidateToken(
                token,
                validationParameters,
                out validatedToken);

            return principal;
        }

        // Mirrors the supplied integration pattern:
        // POST {Auth_BaseUrl}/{Auth_ValidateToken_Endpoint}
        // Body: { "Token": "<jwt>" }
        public static async Task<ClaimsPrincipal> GetPrincipalAsync(
            string token)
        {
            if (string.IsNullOrWhiteSpace(token))
                return null;

            string baseUrl =
                ConfigurationManager.AppSettings["Auth_BaseUrl"];
            string endpoint =
                ConfigurationManager.AppSettings["Auth_ValidateToken_Endpoint"];

            if (string.IsNullOrWhiteSpace(baseUrl) ||
                string.IsNullOrWhiteSpace(endpoint))
            {
                throw new JwtValidationUnavailableException(
                    "Auth_BaseUrl or Auth_ValidateToken_Endpoint is missing.");
            }

            Uri validationUri;
            try
            {
                string normalizedBase = baseUrl.TrimEnd('/') + "/";
                validationUri = new Uri(
                    new Uri(normalizedBase, UriKind.Absolute),
                    endpoint.TrimStart('/'));
            }
            catch (Exception ex)
            {
                throw new JwtValidationUnavailableException(
                    "The configured JWT validation URL is invalid.", ex);
            }

            try
            {
                var payload = new ValidateTokenRequest
                {
                    Token = token
                };

                string json = JsonConvert.SerializeObject(payload);

                using (var request = new HttpRequestMessage(
                    HttpMethod.Post,
                    validationUri))
                {
                    request.Content = new StringContent(
                        json,
                        Encoding.UTF8,
                        "application/json");

                    using (HttpResponseMessage response =
                        await HttpClient.SendAsync(request))
                    {
                        if (response.StatusCode == HttpStatusCode.Unauthorized ||
                            response.StatusCode == HttpStatusCode.Forbidden)
                        {
                            return null;
                        }

                        if (!response.IsSuccessStatusCode)
                        {
                            throw new JwtValidationUnavailableException(
                                "JWT validation endpoint returned HTTP " +
                                (int)response.StatusCode + ".");
                        }

                        string responseJson =
                            await response.Content.ReadAsStringAsync();

                        TokenValidationResponse result =
                            JsonConvert.DeserializeObject<TokenValidationResponse>(
                                responseJson);

                        if (result == null || !result.IsValid)
                            return null;
                    }
                }

                // Verify locally as well. The remote endpoint is not trusted
                // to supply claims; it only confirms validity.
                return ValidateTokenLocally(token);
            }
            catch (JwtValidationUnavailableException)
            {
                throw;
            }
            catch (HttpRequestException ex)
            {
                throw new JwtValidationUnavailableException(
                    "Could not contact the JWT validation endpoint.", ex);
            }
            catch (TaskCanceledException ex)
            {
                throw new JwtValidationUnavailableException(
                    "JWT validation endpoint timed out.", ex);
            }
        }
    }

    public sealed class JwtValidationUnavailableException : Exception
    {
        public JwtValidationUnavailableException(string message)
            : base(message)
        {
        }

        public JwtValidationUnavailableException(
            string message,
            Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
