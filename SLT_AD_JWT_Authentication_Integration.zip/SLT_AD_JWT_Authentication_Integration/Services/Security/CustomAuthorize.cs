using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;

namespace SLTProject.Services.Security
{
    // Use on SLT administrator-only controllers/actions.
    // This validates the signed 24-hour SLT admin JWT and requires
    // AdminId + the SLTAdmin role. Guest endpoints should keep their
    // existing guest-token authentication.
    public class CustomAuthorize : AuthorizationFilterAttribute
    {
        public override async Task OnAuthorizationAsync(
            HttpActionContext actionContext,
            CancellationToken cancellationToken)
        {
            if (actionContext.Request.Method == HttpMethod.Options)
                return;

            bool allowAnonymous =
                actionContext.ActionDescriptor
                    .GetCustomAttributes<AllowAnonymousAttribute>()
                    .Any() ||
                actionContext.ControllerContext.ControllerDescriptor
                    .GetCustomAttributes<AllowAnonymousAttribute>()
                    .Any();

            if (allowAnonymous)
                return;

            var authHeader =
                actionContext.Request.Headers.Authorization;

            if (authHeader == null ||
                !string.Equals(
                    authHeader.Scheme,
                    "Bearer",
                    StringComparison.OrdinalIgnoreCase) ||
                string.IsNullOrWhiteSpace(authHeader.Parameter))
            {
                SetUnauthorized(actionContext);
                return;
            }

            try
            {
                ClaimsPrincipal principal =
                    await JwtManager.GetPrincipalAsync(
                        authHeader.Parameter);

                if (principal == null ||
                    principal.Identity == null ||
                    !principal.Identity.IsAuthenticated)
                {
                    SetUnauthorized(actionContext);
                    return;
                }

                bool hasAdminId = principal.Claims.Any(c =>
                    c.Type == "AdminId" &&
                    long.TryParse(c.Value, out _));

                bool isSltAdmin = principal.IsInRole("SLTAdmin");

                if (!hasAdminId || !isSltAdmin)
                {
                    SetUnauthorized(actionContext);
                    return;
                }

                actionContext.RequestContext.Principal = principal;

                if (HttpContext.Current != null)
                    HttpContext.Current.User = principal;

                Thread.CurrentPrincipal = principal;
            }
            catch (JwtValidationUnavailableException ex)
            {
                System.Diagnostics.Trace.TraceError(
                    "[SLT CustomAuthorize] JWT validation unavailable: {0}",
                    ex);

                actionContext.Response =
                    actionContext.Request.CreateResponse(
                        HttpStatusCode.ServiceUnavailable,
                        new
                        {
                            Message =
                                "Token validation service is temporarily unavailable."
                        });
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceWarning(
                    "[SLT CustomAuthorize] Token rejected: {0}",
                    ex.Message);

                SetUnauthorized(actionContext);
            }
        }

        private static void SetUnauthorized(
            HttpActionContext actionContext)
        {
            actionContext.Response =
                actionContext.Request.CreateResponse(
                    HttpStatusCode.Unauthorized,
                    new
                    {
                        Message = "Unauthorized: SLT admin token is invalid or expired."
                    });

            actionContext.Response.Headers.WwwAuthenticate.Add(
                new System.Net.Http.Headers.AuthenticationHeaderValue(
                    "Bearer"));
        }
    }
}
