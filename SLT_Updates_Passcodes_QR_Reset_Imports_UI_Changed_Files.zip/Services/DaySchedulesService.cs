
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using ClosedXML.Excel;
using SLTProject.Data;
using SLTProject.Models.Dtos;

namespace SLTProject.Services
{
    public class DaySchedulesService
    {
        // ==========================================
        // VALIDATION HELPERS
        // ==========================================

        private static string Required(
            string value,
            int max,
            string field)
        {
            return ScheduleTransportExcel.Limit(
                value, max, field, true);
        }

        private static string Optional(
            string value,
            int max,
            string field)
        {
            return ScheduleTransportExcel.Limit(
                value, max, field);
        }

        private static string ItemType(string value)
        {
            return Required(value, 100, "ItemType");
        }

        private static async Task<string> ResolveIconNameAsync(SLTEntities db, string name)
        {
            if (string.IsNullOrWhiteSpace(name))
                return null;

            string requested = name.Trim();
            string normalized = requested.ToLowerInvariant();

            var matches = await db.BlurIcons
                .AsNoTracking()
                .Where(x => !x.IsDeleted && x.Name.ToLower() == normalized)
                .Select(x => x.Name)
                .Take(2)
                .ToListAsync();

            if (matches.Count == 0)
            {
                throw new ArgumentException(
                    "BlurIconName '" + requested +
                    "' was not found. Enter an existing Blur Icon name.");
            }

            if (matches.Count > 1)
            {
                throw new ArgumentException(
                    "More than one active Blur Icon matches '" + requested +
                    "' ignoring letter case. Rename duplicate icon records first.");
            }

            // Persist the canonical name exactly as it exists in the BlurIcons table.
            return matches[0];
        }

        private static void Validate(DayScheduleInput input)
        {
            if (input == null)
            {
                throw new ArgumentException(
                    "Day schedule is required.");
            }

            if (input.Date == default(DateTime))
            {
                throw new ArgumentException(
                    "Date is required.");
            }

            ItemType(input.ItemType);

            Required(input.Title, 250, "Title");

            Optional(
                input.BlurIconName,
                150,
                "BlurIconName");

            Optional(
                input.DressCode,
                150,
                "DressCode");

            Optional(
                input.LocationName,
                250,
                "LocationName");

            Optional(
                input.MapsLink,
                1000,
                "MapsLink");

            if (input.StartTime.HasValue &&
                (input.StartTime.Value < TimeSpan.Zero ||
                 input.StartTime.Value >= TimeSpan.FromDays(1)))
            {
                throw new ArgumentException(
                    "Invalid StartTime.");
            }

            if (input.EndTime.HasValue &&
                (input.EndTime.Value < TimeSpan.Zero ||
                 input.EndTime.Value >= TimeSpan.FromDays(1)))
            {
                throw new ArgumentException(
                    "Invalid EndTime.");
            }

            if (input.StartTime.HasValue &&
                input.EndTime.HasValue &&
                input.EndTime.Value <= input.StartTime.Value)
            {
                throw new ArgumentException(
                    "EndTime must be after StartTime.");
            }
        }

        // ==========================================
        // APPLY INPUT TO ENTITY
        // ==========================================

        private static void Apply(
            DaySchedule entity,
            DayScheduleInput input)
        {
            entity.Date = input.Date.Date;

            entity.ItemType = ItemType(input.ItemType);

            entity.Title = Required(
                input.Title, 250, "Title");

            entity.BlurIconName = Optional(
                input.BlurIconName,
                150,
                "BlurIconName");

            entity.StartTime = input.StartTime;

            entity.EndTime = input.EndTime;

            entity.ShortNote = Optional(
                input.ShortNote,
                100000,
                "ShortNote");

            entity.DressCode = Optional(
                input.DressCode,
                150,
                "DressCode");

            entity.LocationName = Optional(
                input.LocationName,
                250,
                "LocationName");

            entity.MapsLink = Optional(
                input.MapsLink,
                1000,
                "MapsLink");
        }

        // ==========================================
        // MAP ENTITY TO DTO
        // ==========================================

        public static DayScheduleDto Map(DaySchedule entity)
        {
            if (entity == null)
                return null;

            return new DayScheduleDto
            {
                Id = entity.Id,

                Date = entity.Date,

                ItemType = entity.ItemType,

                Title = entity.Title,

                BlurIconName = entity.BlurIconName,

                StartTime = entity.StartTime,

                EndTime = entity.EndTime,

                ShortNote = entity.ShortNote,

                DressCode = entity.DressCode,

                LocationName = entity.LocationName,

                MapsLink = entity.MapsLink,

                CreatedAt = entity.CreatedAt,

                CreatedBy = entity.CreatedBy,

                ModifiedAt = entity.ModifiedAt,

                ModifiedBy = entity.ModifiedBy,

                IsDeleted = entity.IsDeleted,

                DeletedAt = entity.DeletedAt,

                DeletedBy = entity.DeletedBy,

                RetentionDateCreated =
                    entity.RetentionDateCreated,

                RetentionDateModified =
                    entity.RetentionDateModified
            };
        }

        // ==========================================
        // GET ALL
        // ==========================================

        public async Task<List<DayScheduleDto>> GetAllAsync()
        {
            using (var db = new SLTEntities())
            {
                var items = await db.DaySchedules
                    .AsNoTracking()
                    .Where(x => !x.IsDeleted)
                    .OrderBy(x => x.Date)
                    .ThenBy(x => x.StartTime)
                    .ThenBy(x => x.Id)
                    .ToListAsync();

                return items.Select(Map).ToList();
            }
        }

        // ==========================================
        // GET BY ID
        // ==========================================

        public async Task<DayScheduleDto> GetAsync(long id)
        {
            using (var db = new SLTEntities())
            {
                var item = await db.DaySchedules
                    .AsNoTracking()
                    .FirstOrDefaultAsync(x =>
                        x.Id == id &&
                        !x.IsDeleted);

                return Map(item);
            }
        }

        // ==========================================
        // CREATE
        // ==========================================

        public async Task<DayScheduleDto> CreateAsync(
            DayScheduleInput input,
            string actor)
        {
            Validate(input);

            using (var db = new SLTEntities())
            {
                var now = EgyptDateTimeService.Now;

                var entity = new DaySchedule
                {
                    CreatedAt = now,
                    CreatedBy = actor,
                    RetentionDateCreated = now,
                    IsDeleted = false
                };

                input.BlurIconName = await ResolveIconNameAsync(db, input.BlurIconName);
                Apply(entity, input);

                db.DaySchedules.Add(entity);

                await db.SaveChangesAsync();

                return Map(entity);
            }
        }

        // ==========================================
        // UPDATE
        // ==========================================

        public async Task<DayScheduleDto> UpdateAsync(
            long id,
            DayScheduleInput input,
            string actor)
        {
            Validate(input);

            using (var db = new SLTEntities())
            {
                var entity = await db.DaySchedules
                    .FirstOrDefaultAsync(x =>
                        x.Id == id &&
                        !x.IsDeleted);

                if (entity == null)
                    return null;

                input.BlurIconName = await ResolveIconNameAsync(db, input.BlurIconName);
                Apply(entity, input);

                var now = EgyptDateTimeService.Now;

                entity.ModifiedAt = now;
                entity.ModifiedBy = actor;
                entity.RetentionDateModified = now;

                await db.SaveChangesAsync();

                return Map(entity);
            }
        }

        // ==========================================
        // SOFT DELETE
        // ==========================================

        public async Task<bool> DeleteAsync(
            long id,
            string actor)
        {
            using (var db = new SLTEntities())
            {
                var entity = await db.DaySchedules
                    .FirstOrDefaultAsync(x =>
                        x.Id == id &&
                        !x.IsDeleted);

                if (entity == null)
                    return false;

                var now = EgyptDateTimeService.Now;

                entity.IsDeleted = true;
                entity.DeletedAt = now;
                entity.DeletedBy = actor;
                entity.ModifiedAt = now;
                entity.ModifiedBy = actor;
                entity.RetentionDateModified = now;

                await db.SaveChangesAsync();

                return true;
            }
        }

        // ==========================================
        // EXCEL TEMPLATE
        // ==========================================

        public byte[] GetTemplate()
        {
            using (var workbook = new XLWorkbook())
            using (var stream = new MemoryStream())
            {
                var sheet = workbook.Worksheets.Add("Import");
                ScheduleTransportExcel.WriteTemplateHeaders(
                    sheet,
                    "Date", "ItemType", "Title", "BlurIconName",
                    "StartTime", "EndTime", "ShortNote", "DressCode",
                    "LocationName", "MapsLink");

                ScheduleTransportExcel.WriteInstructions(
                    workbook,
                    "Import modes: UpdateOnly, Upsert, ReplaceAll.",
                    "UpdateOnly: update matching active schedules only; it never creates new records.",
                    "Upsert: update a matching active schedule or create a new schedule when no match exists.",
                    "ReplaceAll: soft-delete all active Day Schedules, then insert the valid rows in this workbook. Use only with a complete workbook.",
                    "For a partial update, provide Date + Title, then only the fields you want to change. Empty cells preserve stored values.",
                    "The template excludes Id. Date + Title identify existing schedules. Legacy files containing Id still work.",
                    "New schedules require Date, ItemType and Title.",
                    "BlurIconName must match an active Blur Icon name. Uppercase/lowercase is ignored; the canonical database name is saved.",
                    "Date format: d/MM/yy (for example 4/12/26). Time format: HH:mm (24-hour).",
                    "Do not use ReplaceAll for a partial-update workbook.");

                workbook.SaveAs(stream);
                return stream.ToArray();
            }
        }

        // ==========================================
        // EXCEL BULK IMPORT
        // ==========================================

        public async Task<ExcelImportResult> ImportAsync(
            Stream stream,
            string actor,
            string mode = "Upsert")
        {
            mode = ScheduleTransportExcel.NormalizeImportMode(mode);

            var report = new ExcelImportResult { Mode = mode };

            using (var workbook = ScheduleTransportExcel.Open(stream))
            {
                var sheet = workbook.Worksheet(1);
                var headers = ScheduleTransportExcel.Headers(sheet);

                if (mode == "ReplaceAll")
                {
                    ScheduleTransportExcel.Require(headers, "Date", "ItemType", "Title");
                }
                else if (!headers.ContainsKey("Id") &&
                         (!headers.ContainsKey("Date") || !headers.ContainsKey("Title")))
                {
                    throw new ArgumentException(
                        "Provide an Id column, or both Date and Title columns to identify existing schedules.");
                }

                var last = sheet.LastRowUsed();
                if (last == null || last.RowNumber() < 2)
                    return report;

                if (last.RowNumber() > 10001)
                    throw new ArgumentException("Maximum 10000 rows per upload.");

                report.TotalRows = last.RowNumber() - 1;

                var seenIds = new HashSet<long>();
                var seenKeys = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

                using (var db = new SLTEntities())
                {
                    // ReplaceAll is prepared and validated before existing records are touched.
                    if (mode == "ReplaceAll")
                    {
                        var prepared = new List<Tuple<int, DayScheduleInput>>();

                        for (int rowNumber = 2; rowNumber <= last.RowNumber(); rowNumber++)
                        {
                            var row = sheet.Row(rowNumber);
                            if (ScheduleTransportExcel.Empty(row, headers))
                            {
                                report.Skipped++;
                                continue;
                            }

                            string column = "Record";
                            string value = "";

                            try
                            {
                                string dateText = ScheduleTransportExcel.Text(row, headers, "Date");
                                string typeText = ScheduleTransportExcel.Text(row, headers, "ItemType");
                                string titleText = ScheduleTransportExcel.Text(row, headers, "Title");

                                column = "Date";
                                value = dateText;

                                var input = new DayScheduleInput
                                {
                                    Date = ScheduleTransportExcel.Date(dateText, "Date"),
                                    ItemType = typeText,
                                    Title = titleText,
                                    BlurIconName = ScheduleTransportExcel.Text(row, headers, "BlurIconName"),
                                    StartTime = ScheduleTransportExcel.Time(
                                        ScheduleTransportExcel.Text(row, headers, "StartTime"), "StartTime"),
                                    EndTime = ScheduleTransportExcel.Time(
                                        ScheduleTransportExcel.Text(row, headers, "EndTime"), "EndTime"),
                                    ShortNote = ScheduleTransportExcel.Text(row, headers, "ShortNote"),
                                    DressCode = ScheduleTransportExcel.Text(row, headers, "DressCode"),
                                    LocationName = ScheduleTransportExcel.Text(row, headers, "LocationName"),
                                    MapsLink = ScheduleTransportExcel.Text(row, headers, "MapsLink")
                                };

                                column = "Record";
                                value = "";
                                Validate(input);

                                column = "BlurIconName";
                                value = input.BlurIconName ?? "";
                                input.BlurIconName = await ResolveIconNameAsync(db, input.BlurIconName);

                                string naturalKey = input.Date.Date.ToString("yyyyMMdd") + "|" +
                                    input.Title.Trim().ToLowerInvariant();

                                if (!seenKeys.Add(naturalKey))
                                {
                                    column = "Date + Title";
                                    value = dateText + " | " + titleText;
                                    throw new ArgumentException(
                                        "Duplicate Date + Title in the Excel file.");
                                }

                                prepared.Add(Tuple.Create(rowNumber, input));
                            }
                            catch (Exception ex)
                            {
                                string inferred = ScheduleTransportExcel.ErrorColumn(ex.Message, headers.Keys);
                                if (inferred != "Record") column = inferred;
                                if (string.IsNullOrWhiteSpace(value))
                                    value = ScheduleTransportExcel.ErrorValue(row, headers, column);
                                report.AddError(rowNumber, column, value, ex.Message);
                            }
                        }

                        // Safety: never wipe the current schedule when the workbook has no valid rows.
                        if (prepared.Count == 0)
                            return report;

                        DateTime deleteTime = EgyptDateTimeService.Now;
                        var existing = await db.DaySchedules
                            .Where(x => !x.IsDeleted)
                            .ToListAsync();

                        foreach (var entity in existing)
                        {
                            entity.IsDeleted = true;
                            entity.DeletedAt = deleteTime;
                            entity.DeletedBy = actor;
                            entity.ModifiedAt = deleteTime;
                            entity.ModifiedBy = actor;
                            entity.RetentionDateModified = deleteTime;
                        }

                        await db.SaveChangesAsync();
                        report.SoftDeleted = existing.Count;

                        foreach (var item in prepared)
                        {
                            try
                            {
                                DateTime now = EgyptDateTimeService.Now;
                                var entity = new DaySchedule
                                {
                                    CreatedAt = now,
                                    CreatedBy = actor,
                                    RetentionDateCreated = now,
                                    IsDeleted = false
                                };

                                Apply(entity, item.Item2);
                                db.DaySchedules.Add(entity);
                                await db.SaveChangesAsync();
                                report.Inserted++;
                            }
                            catch (Exception ex)
                            {
                                DetachPendingChanges(db);
                                report.AddError(item.Item1, "Record", item.Item2.Title, ex.Message);
                            }
                        }

                        return report;
                    }

                    // UpdateOnly / Upsert
                    for (int rowNumber = 2; rowNumber <= last.RowNumber(); rowNumber++)
                    {
                        var row = sheet.Row(rowNumber);
                        if (ScheduleTransportExcel.Empty(row, headers))
                        {
                            report.Skipped++;
                            continue;
                        }

                        string errorColumn = "Record";
                        string errorValue = "";

                        try
                        {
                            string rawId = ScheduleTransportExcel.Text(row, headers, "Id");
                            long id = 0;

                            if (!string.IsNullOrWhiteSpace(rawId) &&
                                (!long.TryParse(rawId, out id) || id <= 0))
                            {
                                errorColumn = "Id";
                                errorValue = rawId;
                                throw new ArgumentException("Id must be a positive integer.");
                            }

                            if (id > 0 && !seenIds.Add(id))
                            {
                                errorColumn = "Id";
                                errorValue = rawId;
                                throw new ArgumentException("Duplicate Id in Excel file.");
                            }

                            string dateText = ScheduleTransportExcel.Text(row, headers, "Date");
                            string typeText = ScheduleTransportExcel.Text(row, headers, "ItemType");
                            string titleText = ScheduleTransportExcel.Text(row, headers, "Title");

                            DateTime? parsedDate = null;
                            if (!string.IsNullOrWhiteSpace(dateText))
                            {
                                errorColumn = "Date";
                                errorValue = dateText;
                                parsedDate = ScheduleTransportExcel.Date(dateText, "Date");
                            }

                            DaySchedule entity = null;
                            if (id > 0)
                            {
                                entity = await db.DaySchedules.FirstOrDefaultAsync(x =>
                                    x.Id == id && !x.IsDeleted);

                                if (entity == null)
                                {
                                    errorColumn = "Id";
                                    errorValue = rawId;
                                    throw new ArgumentException(
                                        "Active schedule Id " + id + " was not found.");
                                }
                            }
                            else
                            {
                                if (!parsedDate.HasValue || string.IsNullOrWhiteSpace(titleText))
                                {
                                    throw new ArgumentException(
                                        "Provide an Id or both Date and Title to identify the schedule.");
                                }

                                string lookupTitle = titleText.Trim().ToLowerInvariant();
                                DateTime lookupStart = parsedDate.Value.Date;
                                DateTime lookupEnd = lookupStart.AddDays(1);
                                entity = await db.DaySchedules.FirstOrDefaultAsync(x =>
                                    !x.IsDeleted &&
                                    x.Date >= lookupStart && x.Date < lookupEnd &&
                                    x.Title.ToLower() == lookupTitle);
                            }

                            if (mode == "UpdateOnly" && entity == null)
                            {
                                errorColumn = "Id";
                                errorValue = rawId;
                                throw new ArgumentException(
                                    "Schedule was not found. UpdateOnly does not create records.");
                            }

                            var input = new DayScheduleInput
                            {
                                Date = parsedDate.HasValue
                                    ? parsedDate.Value
                                    : (entity == null ? default(DateTime) : entity.Date),
                                ItemType = typeText.Length > 0
                                    ? typeText : (entity == null ? null : entity.ItemType),
                                Title = titleText.Length > 0
                                    ? titleText : (entity == null ? null : entity.Title),
                                BlurIconName = ValueText(row, headers, "BlurIconName",
                                    entity == null ? null : entity.BlurIconName),
                                StartTime = ValueTime(row, headers, "StartTime",
                                    entity == null ? (TimeSpan?)null : entity.StartTime),
                                EndTime = ValueTime(row, headers, "EndTime",
                                    entity == null ? (TimeSpan?)null : entity.EndTime),
                                ShortNote = ValueText(row, headers, "ShortNote",
                                    entity == null ? null : entity.ShortNote),
                                DressCode = ValueText(row, headers, "DressCode",
                                    entity == null ? null : entity.DressCode),
                                LocationName = ValueText(row, headers, "LocationName",
                                    entity == null ? null : entity.LocationName),
                                MapsLink = ValueText(row, headers, "MapsLink",
                                    entity == null ? null : entity.MapsLink)
                            };

                            Validate(input);

                            string naturalKey = input.Date.Date.ToString("yyyyMMdd") + "|" +
                                input.Title.Trim().ToLowerInvariant();
                            if (!seenKeys.Add(naturalKey))
                            {
                                errorColumn = "Date + Title";
                                errorValue = dateText + " | " + titleText;
                                throw new ArgumentException(
                                    "Duplicate Date + Title in the Excel file.");
                            }

                            string normalizedTitle = input.Title.Trim().ToLowerInvariant();
                            DateTime duplicateStart = input.Date.Date;
                            DateTime duplicateEnd = duplicateStart.AddDays(1);
                            // EF6 must not evaluate entity.Id on a null entity
                            // while translating this expression (TargetException).
                            long excludedId = entity == null ? 0L : entity.Id;
                            bool duplicateInDatabase = await db.DaySchedules.AnyAsync(x =>
                                !x.IsDeleted &&
                                x.Date >= duplicateStart && x.Date < duplicateEnd &&
                                x.Title.ToLower() == normalizedTitle &&
                                (excludedId == 0L || x.Id != excludedId));

                            if (duplicateInDatabase)
                            {
                                errorColumn = "Date + Title";
                                errorValue = dateText + " | " + titleText;
                                throw new ArgumentException(
                                    "An active Day Schedule already exists with this Date + Title.");
                            }

                            errorColumn = "BlurIconName";
                            errorValue = input.BlurIconName ?? "";
                            input.BlurIconName = await ResolveIconNameAsync(db, input.BlurIconName);

                            bool inserted = entity == null;
                            DateTime now = EgyptDateTimeService.Now;

                            if (inserted)
                            {
                                entity = new DaySchedule
                                {
                                    CreatedAt = now,
                                    CreatedBy = actor,
                                    RetentionDateCreated = now,
                                    IsDeleted = false
                                };
                                Apply(entity, input);
                                db.DaySchedules.Add(entity);
                            }
                            else
                            {
                                Apply(entity, input);
                                entity.ModifiedAt = now;
                                entity.ModifiedBy = actor;
                                entity.RetentionDateModified = now;
                            }

                            await db.SaveChangesAsync();
                            if (inserted) report.Inserted++;
                            else report.Updated++;
                        }
                        catch (Exception ex)
                        {
                            DetachPendingChanges(db);

                            string inferred = ScheduleTransportExcel.ErrorColumn(ex.Message, headers.Keys);
                            string column = inferred != "Record" ? inferred : errorColumn;
                            if (string.IsNullOrWhiteSpace(errorValue))
                                errorValue = ScheduleTransportExcel.ErrorValue(row, headers, column);
                            report.AddError(rowNumber, column, errorValue, ex.Message);
                        }
                    }
                }
            }

            return report;
        }

        private static void DetachPendingChanges(SLTEntities db)
        {
            var pending = db.ChangeTracker.Entries()
                .Where(x =>
                    x.State == System.Data.Entity.EntityState.Added ||
                    x.State == System.Data.Entity.EntityState.Modified ||
                    x.State == System.Data.Entity.EntityState.Deleted)
                .ToList();

            foreach (var entry in pending)
                entry.State = System.Data.Entity.EntityState.Detached;
        }

        // ==========================================
        // EXCEL HELPERS
        // ==========================================

        private static string ValueText(
            IXLRow row,
            Dictionary<string, int> headers,
            string key,
            string existing)
        {
            var value = ScheduleTransportExcel.Text(
                row, headers, key);

            return value.Length > 0
                ? value
                : existing;
        }

        private static TimeSpan? ValueTime(
            IXLRow row,
            Dictionary<string, int> headers,
            string key,
            TimeSpan? existing)
        {
            var value = ScheduleTransportExcel.Text(
                row, headers, key);

            return value.Length > 0
                ? ScheduleTransportExcel.Time(value, key)
                : existing;
        }
        // ============================================================
        // ADMIN TABLE: DATABASE-SIDE PAGING AND FILTERED XLSX EXPORT
        // The public unpaged GetAllAsync API remains unchanged.
        // ============================================================
        public Task<SltTablePage<DayScheduleDto>> GetPagedAsync(SltTableQuery filter)
        {
            return SltTableDataService.SchedulesAsync(filter ?? new SltTableQuery());
        }

        public Task<byte[]> ExportFilteredAsync(SltTableQuery filter)
        {
            return SltTableDataService.ExportXlsxAsync<DayScheduleDto>(
                SltTableDataService.SchedulesAsync,
                filter ?? new SltTableQuery(),
                new[] { "Id", "Date", "ItemType", "Title", "StartTime", "EndTime", "LocationName", "BlurIconName" });
        }

    }
}
