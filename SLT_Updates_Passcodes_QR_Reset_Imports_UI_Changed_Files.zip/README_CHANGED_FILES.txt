SLTProject targeted update — 10 Nov 2026
Copy Services/* to project Services; Controllers/* to Controllers; Frontend/* to Frontend.
All ZIP files are complete files, not partial snippets.
Updated areas: shuffled 3 letters + 3 digits guest/admin passcodes (legacy digits kept), mail/SMS delivery on guest admin reset, QR modal buttons, consistent search/paging styling, weather page search/paging, Excel date/driver phone formats, Day Schedules without Id column, EF6 null-reference fix, Event Driver template import date handling.
IMPORTANT: templates are downloaded dynamically from the API. Publish the updated Services DLL, then download a NEW template before uploading. Older templates may have the wrong Excel number formats.
Existing records identified by Date+Title for day schedules; Event Drivers by Email+ScheduleTitle (ScheduleDate may be needed if title repeats).
Backend compile not executed against the EF6 EDMX model, so rebuild/test in Visual Studio before production release.
