(async function () {
  'use strict';
  const $ = id => document.getElementById(id);
  if (!$('weatherCards')) return;
  if (typeof sltRequireAdmin === 'function' && !await sltRequireAdmin()) return;
  let weatherRows = [];
  let weatherPage = 1;
  const weatherPageSize = 5;
  const filterArea = document.createElement('div');
  filterArea.className = 'slt-weather-filters';
  filterArea.innerHTML = '<label>Search forecasts<input id="weatherSearch" type="search" placeholder="Search location, date or conditions"></label>';
  const pager = document.createElement('div');
  pager.className = 'slt-weather-pager';
  pager.innerHTML = '<button type="button" data-weather-prev>Previous</button><span data-weather-page aria-live="polite"></span><button type="button" data-weather-next>Next</button>';
  $('weatherCards').before(filterArea);
  $('weatherCards').after(pager);
  filterArea.querySelector('input').addEventListener('input', () => { weatherPage = 1; renderCards(); });
  pager.addEventListener('click', e => {
    if (e.target.closest('[data-weather-prev]')) weatherPage = Math.max(1, weatherPage - 1);
    else if (e.target.closest('[data-weather-next]')) weatherPage++;
    else return;
    renderCards();
  });
  const esc = v => window.sltEscape(v == null ? '' : String(v));
  const items = r => Array.isArray(r) ? r : [r?.Data,r?.Records,r?.Result,r?.Items,r?.data].find(Array.isArray) || [];
  const desc = code => {
    const n = Number(code);
    if (n===0) return ['Clear skies','☀'];
    if ([1,2].includes(n)) return ['Partly cloudy','⛅'];
    if (n===3) return ['Overcast','☁'];
    if ([45,48].includes(n)) return ['Foggy','≋'];
    if ([51,53,55,56,57].includes(n)) return ['Drizzle','☂'];
    if ([61,63,65,66,67,80,81,82].includes(n)) return ['Rain showers','☂'];
    if ([71,73,75,77,85,86].includes(n)) return ['Snow','❄'];
    if ([95,96,99].includes(n)) return ['Thunderstorms','ϟ'];
    return ['Conditions available','☼'];
  };
  const formatDate = value => {
    const formatted = window.sltFormatDateOnly ? window.sltFormatDateOnly(value) : String(value || '').slice(0,10);
    return formatted === '—' ? 'Date pending' : formatted;
  };
  const temp = n => n==null?'—':Math.round(Number(n))+'°';
  const metric = (label,value,unit) => `<div class="slt-weather-metric"><small>${label}</small><strong>${value==null?'—':esc(value)+unit}</strong></div>`;
  function renderCards() {
    const q = document.getElementById('weatherSearch').value.trim().toLowerCase();
    const filtered = weatherRows.filter(row => !q || [row.LocationName, row.ForecastDate, desc(row.WeatherCode)[0]].join(' ').toLowerCase().includes(q));
    const pages = Math.max(1, Math.ceil(filtered.length / weatherPageSize));
    weatherPage = Math.min(weatherPage, pages);
      $('weatherCards').innerHTML=filtered.slice((weatherPage - 1) * weatherPageSize, weatherPage * weatherPageSize).map(row=>{
        const [label,emoji]=desc(row.WeatherCode);
        return `<article class="slt-weather-day"><div class="slt-weather-day-top"><span class="slt-weather-day-icon" aria-hidden="true">${emoji}</span><span class="slt-weather-day-city">${esc(row.LocationName||'Event location')}</span></div><div class="slt-weather-day-date">${esc(formatDate(row.ForecastDate))}</div><div class="slt-weather-day-temps"><strong>${temp(row.MaxTemperatureC)}</strong><span>Low ${temp(row.MinTemperatureC)}</span></div><div class="slt-weather-day-condition">${esc(label)}</div><div class="slt-weather-day-foot"><span>☂ ${row.PrecipitationMm == null?'—':esc(row.PrecipitationMm)+' mm'}</span><span>➤ ${row.MaxWindSpeedKmh == null?'—':esc(row.MaxWindSpeedKmh)+' km/h'}</span></div></article>`;
      }).join('');
    pager.querySelector('[data-weather-page]').textContent = 'Page ' + weatherPage + ' of ' + pages + ' · ' + filtered.length + ' matches';
    pager.querySelector('[data-weather-prev]').disabled = weatherPage <= 1;
    pager.querySelector('[data-weather-next]').disabled = weatherPage >= pages;
  }
  async function load() {
    $('weatherMessage').textContent='';
    $('weatherFeatured').innerHTML='<div class="slt-weather-placeholder">Loading your weather outlook…</div>';
    $('weatherCards').innerHTML='';
    try {
      const forecasts=items(await sltRequest('/weather-forecasts'))
        .filter(x=>x && x.ForecastDate)
        .sort((a,b)=>String(a.ForecastDate).localeCompare(String(b.ForecastDate)));
      $('weatherCount').textContent=forecasts.length+' saved forecast'+(forecasts.length===1?'':'s');
      weatherRows = forecasts;
      weatherPage = 1;
      if (!forecasts.length) {
        $('weatherFeatured').innerHTML='<div class="slt-weather-empty"><div>☀</div><h3>No forecast data yet</h3><p>Once weather is saved by your integration, the outlook will appear here automatically.</p></div>';
        $('weatherCards').innerHTML='';return;
      }
      const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Africa/Cairo'}).format(new Date());
      const main=forecasts.find(x=>(window.sltDateInputValue?window.sltDateInputValue(x.ForecastDate):String(x.ForecastDate).slice(0,10))>=today)||forecasts[0];
      const [condition,icon]=desc(main.WeatherCode);
      $('weatherFeatured').innerHTML=`<article class="slt-weather-spotlight"><div class="slt-weather-spotlight-copy"><span class="slt-weather-kicker">✦ FEATURED FORECAST</span><h2>${esc(main.LocationName||'SLT event location')}</h2><p>${esc(formatDate(main.ForecastDate))}</p><div class="slt-weather-big"><span>${temp(main.MaxTemperatureC)}</span><span class="slt-weather-big-icon" aria-hidden="true">${icon}</span></div><div class="slt-weather-condition">${esc(condition)} <span>· Low ${temp(main.MinTemperatureC)}</span></div></div><div class="slt-weather-metrics">${metric('Precipitation',main.PrecipitationMm,' mm')}${metric('Maximum wind',main.MaxWindSpeedKmh,' km/h')}${metric('Time zone',main.TimeZone||'—','')}</div></article>`;
      renderCards();
    } catch(err) {
      $('weatherFeatured').innerHTML='<div class="slt-weather-empty"><div>☁</div><h3>Forecast currently unavailable</h3><p>Check the backend connection and retry.</p></div>';
      $('weatherMessage').textContent=err.message||'Could not load weather forecasts.';
    }
  }
  $('weatherRefresh').addEventListener('click',load);
  await load();
})();
