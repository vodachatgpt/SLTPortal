
(function () {
    "use strict";

    // ============================================================
    // SLT ADMIN APPLICATION SHELL
    // Vodafone Dark Experience
    // ============================================================

    const CONFIG = {
        dashboard: "dashboard.html",
        login: "admin-login.html",

        themeFile: "assets/admin-dark-theme.css",
        themeVersion: "9",

        serviceWorker: "./service-worker.js",

        emailStorageKey: "slt_admin_email",

        enablePWA: true
    };

    const $ = id => document.getElementById(id);

    const nav = document.querySelector(
        ".slt-dashboard-nav"
    );

    const currentPage =
        window.location.pathname
            .split("/")
            .pop()
            .toLowerCase() || CONFIG.dashboard;

    // ============================================================
    // SIDEBAR NAVIGATION COLLECTIONS
    // ============================================================

    const groups = [
        {
            title: "WORKSPACE",
            items: [
                {
                    url: "dashboard.html",
                    label: "Overview",
                    icon: "house"
                },
                {
                    url: "admins-admin.html",
                    label: "Administrators",
                    icon: "users"
                }
            ]
        },
        {
            title: "GUEST INFORMATION",
            items: [
                {
                    url: "guests-admin.html",
                    label: "Guests",
                    icon: "user-round"
                },
                {
                    url: "airport-transfers-admin.html",
                    label: "Airport Transfers",
                    icon: "plane"
                },
            ]
        },
        {
            title: "EVENT INFORMATION",
            items: [
                {
                    url: "phases-admin.html",
                    label: "Phases",
                    icon: "layers"
                },
                {
                    url: "day-schedules-admin.html",
                    label: "Day Schedules",
                    icon: "calendar-days"
                },
                {
                    url: "guest-event-drivers-admin.html",
                    label: "Event Drivers",
                    icon: "car-front"
                }
            ]
        },
        {
            title: "SYSTEM INFORMATION",
            items: [
                {
                    url: "blur-icons-admin.html",
                    label: "Blurb Icons",
                    icon: "sparkles"
                },
                {
                    url: "help-support-admin.html",
                    label: "Help & Support",
                    icon: "life-buoy"
                },
                {
                    url: "notifications-admin.html",
                    label: "Notifications",
                    icon: "bell"
                }
            ]
        },
        {
            title: "TEMPLATES",
            items: [
                {
                    url: "sms-templates-admin.html",
                    label: "SMS Templates",
                    icon: "message-square"
                },
                {
                    url: "email-templates-admin.html",
                    label: "Email Templates",
                    icon: "mail"
                },
                {
                    url: "weather-admin.html",
                    label: "Weather Forecast",
                    icon: "cloud-sun"
                }
            ]
        }
    ];

    // ============================================================
    // GLOBAL DARK THEME
    // ============================================================

    function initializeTheme() {
        if (!nav) return;
        let saved;
        try { saved = localStorage.getItem('slt_admin_theme'); } catch (_) {}
        let dark = saved === 'dark';
        // Unified portal stylesheet is included directly by every page.
        const oldLink = document.getElementById('sltDarkTheme');
        if (oldLink) oldLink.disabled = true;
        function applyTheme() {
            document.documentElement.classList.toggle('slt-dark-admin',dark);
            document.body.classList.toggle('slt-dark-admin',dark);

            const control=document.getElementById('sltThemeToggle');
            if(control) {
                control.textContent=dark?'☀ Light mode':'☾ Dark mode';
                control.setAttribute('aria-pressed',String(dark));
                control.setAttribute('aria-label',dark?'Switch to light mode':'Switch to dark mode');
            }
        }
        window.sltToggleAdminTheme=function(){
            dark=!dark;
            try {localStorage.setItem('slt_admin_theme',dark?'dark':'light');}catch(_){}
            applyTheme();
        };
        applyTheme();
    }

    function createThemeToggle() {
        if (!nav) return;
        const target = document.querySelector('.slt-topbar-actions') || document.querySelector('.slt-dashboard-nav') || document.querySelector('.slt-header');
        if (!target || document.getElementById('sltThemeToggle')) return;
        const button=document.createElement('button');button.id='sltThemeToggle';
        button.className='slt-theme-switch';button.type='button';
        button.onclick=function(){window.sltToggleAdminTheme();};
        target.insertBefore(button,target.firstChild);
        button.textContent=document.documentElement.classList.contains('slt-dark-admin')?'☀ Light mode':'☾ Dark mode';
    }

    // ============================================================
    // HELPER FUNCTIONS
    // ============================================================

    function escapeHtml(value) {

        return String(value == null ? "" : value)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#39;");
    }

    function getCurrentPage() {

        for (const group of groups) {

            const page = group.items.find(
                item =>
                    item.url.toLowerCase() === currentPage
            );

            if (page) return page;
        }

        return {
            label: "Workspace",
            url: CONFIG.dashboard
        };
    }

    function getAdminEmail() {

        try {
            return (
                localStorage.getItem(
                    CONFIG.emailStorageKey
                ) ||
                sessionStorage.getItem(
                    CONFIG.emailStorageKey
                ) ||
                ""
            );
        } catch (error) {
            return "";
        }
    }

    function getAdminFirstName() {

        const email = getAdminEmail();

        if (!email || !email.includes("@")) {
            return "Admin";
        }

        const localPart = email
            .split("@")[0]
            .trim();

        const firstPart = localPart
            .split(/[._-]/)[0]
            .replace(/[^a-zA-Z]/g, "");

        if (!firstPart) {
            return "Admin";
        }

        return firstPart.charAt(0).toUpperCase() +
            firstPart.slice(1).toLowerCase();
    }

    function getAdminInitials() {

        const name = getAdminFirstName();

        return name
            ? name.charAt(0).toUpperCase()
            : "A";
    }

    function getFormattedDate() {

        return new Intl.DateTimeFormat("en-GB", {
            day: "2-digit",
            month: "2-digit",
            year: "numeric",
            timeZone: "Africa/Cairo"
        }).format(new Date());
    }

    function getGreeting() {

        const hour = new Date().getHours();

        if (hour < 12) {
            return "Good morning";
        }

        if (hour < 17) {
            return "Good afternoon";
        }

        return "Good evening";
    }

    // Expose for existing dashboard scripts if needed.
    window.sltAdminDisplayName = getAdminFirstName;
    window.sltAdminGreeting = getGreeting;

    // Inline, dependency-free icons. No external icon fonts or CDN.
    const iconPaths = {
        "house": '<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
        "users": '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
        "user-round": '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
        "plane": '<path d="m22 2-7 20-4-9-9-4 20-7Z"/><path d="M22 2 11 13"/>',
        "car-front": '<path d="m5 17-1 4M19 17l1 4M5 17h14M5 17l-1-6 2-6h12l2 6-1 6M4 11h16"/><circle cx="7.5" cy="14" r=".7"/><circle cx="16.5" cy="14" r=".7"/>',
        "layers": '<path d="m12 2 9 5-9 5-9-5 9-5ZM3 12l9 5 9-5M3 17l9 5 9-5"/>',
        "calendar-days": '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18M8 14h.01M12 14h.01M16 14h.01M8 18h.01M12 18h.01"/>',
        "cloud-sun": '<path d="M12 2v2M4.93 4.93l1.42 1.42M2 12h2M20 12h2M17.65 6.35l1.42-1.42"/><path d="M16 8a5 5 0 0 0-8.9 3.1A4.5 4.5 0 0 0 8.5 20H18a4 4 0 0 0 0-8h-.1A5 5 0 0 0 16 8Z"/>',
        "sparkles": '<path d="m12 3 1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3ZM19 17l.7 1.3L21 19l-1.3.7L19 21l-.7-1.3L17 19l1.3-.7L19 17Z"/>',
        "life-buoy": '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/><path d="m5.6 5.6 3.6 3.6m5.6 5.6 3.6 3.6m0-12.8-3.6 3.6m-5.6 5.6-3.6 3.6"/>',
        "mail": '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m2 6 10 7 10-7"/>',
        "bell": '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9ZM10 21h4"/>',
        "chevron": '<path d="m9 18 6-6-6-6"/>',
        "logout": '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
        "shield": '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="m9 12 2 2 4-4"/>'
    };

    function sidebarIcon(name) {
        return '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
            (iconPaths[name] || iconPaths.layers) + '</svg>';
    }

    // ============================================================
    // SIDEBAR BRAND
    // ============================================================

    function renderBrand() {

        if (!nav) return;

        const brand = nav.querySelector(
            ".slt-brand"
        );

        if (!brand) return;

        brand.href = CONFIG.dashboard;

        brand.innerHTML = `
            <span class="slt-brand-mark">S</span>

            <span class="slt-brand-name">
                <strong>SLT <em>Admin</em></strong>
                <small>EVENT CONTROL CENTER</small>
            </span>
        `;
    }

    // ============================================================
    // SIDEBAR MENU
    // ============================================================

    function renderSidebar() {

        if (!nav) return;

        const links = nav.querySelector(
            ".slt-nav-links"
        );

        if (!links) return;

        const fragments = [];

        groups.forEach(function (group, groupIndex) {

            fragments.push(`
                <div class="slt-nav-caption
                    ${groupIndex > 0
                        ? "slt-nav-caption-secondary"
                        : ""}">
                    <span>${escapeHtml(group.title)}</span>
                </div>
            `);

            group.items.forEach(function (item) {

                const isActive =
                    item.url.toLowerCase() === currentPage;

                fragments.push(`
                    <a
                        href="${escapeHtml(item.url)}"
                        class="${isActive
                            ? "slt-nav-active"
                            : ""}"
                        ${isActive
                            ? 'aria-current="page"'
                            : ""}>

                        <span
                            class="slt-nav-symbol"
                            aria-hidden="true">
                            ${sidebarIcon(item.icon)}
                        </span>

                        <span class="slt-nav-label">
                            ${escapeHtml(item.label)}
                        </span>

                        <span class="slt-nav-chevron" aria-hidden="true">${sidebarIcon("chevron")}</span>

                    </a>
                `);
            });
        });

        // Guest Portal removed permanently
        // from the sidebar collection.

        links.innerHTML = fragments.join("");

        // Preserve the existing logout link and its registered handler.
        const logout = nav.querySelector("#sltLogout");
        if (logout) {
            logout.classList.add("slt-sidebar-logout");
            if (!logout.querySelector(".slt-logout-icon")) {
                logout.innerHTML = '<span class="slt-logout-icon">' + sidebarIcon("logout") +
                    '</span><span>Sign out</span><span class="slt-nav-chevron">' + sidebarIcon("chevron") + '</span>';
            }
        }
        if (!nav.querySelector(".slt-sidebar-footer")) {
            const footer = document.createElement("div");
            footer.className = "slt-sidebar-footer";
            footer.innerHTML = '<span class="slt-footer-shield">' + sidebarIcon("shield") +
                '</span><span><strong>SLT Workspace</strong><small>Secure event operations</small></span>';
            if (logout) nav.insertBefore(footer, logout);
            else nav.appendChild(footer);
        }
    }

    // ============================================================
    // MOBILE SIDEBAR
    // ============================================================

    function closeMobileMenu() {

        document.body.classList.remove(
            "slt-nav-open"
        );

        const button = document.querySelector(
            ".slt-mobile-menu"
        );

        if (button) {

            button.setAttribute(
                "aria-expanded",
                "false"
            );
        }
    }

    function toggleMobileMenu() {

        const isOpen =
            document.body.classList.toggle(
                "slt-nav-open"
            );

        const button = document.querySelector(
            ".slt-mobile-menu"
        );

        if (button) {

            button.setAttribute(
                "aria-expanded",
                String(isOpen)
            );
        }
    }

    // ============================================================
    // TOP BAR
    // ============================================================

    function renderTopbar() {

        if (!nav) return;

        const main = document.querySelector(
            "main.slt-root"
        );

        if (!main) return;

        let topbar = main.querySelector(
            ".slt-topbar"
        );

        if (!topbar) {

            topbar = document.createElement("div");

            topbar.className = "slt-topbar";

            nav.insertAdjacentElement(
                "afterend",
                topbar
            );
        }

        const page = getCurrentPage();

        const name = getAdminFirstName();

        topbar.innerHTML = `
            <button
                type="button"
                class="slt-mobile-menu"
                aria-label="Toggle navigation"
                aria-expanded="false">
                ☰
            </button>

            <div class="slt-breadcrumb">

                <span class="slt-breadcrumb-root">
                    SLT Admin
                </span>

                <span>/</span>

                <strong>
                    ${escapeHtml(page.label)}
                </strong>

            </div>

            <div class="slt-topbar-actions">

                <span class="slt-topbar-date">
                    ${escapeHtml(getFormattedDate())}
                </span>

                <span
                    class="slt-avatar"
                    title="${escapeHtml(name)}"
                    aria-label="Administrator: ${escapeHtml(name)}">
                    ${escapeHtml(getAdminInitials())}
                </span>

            </div>
        `;

        const menuButton = topbar.querySelector(
            ".slt-mobile-menu"
        );

        if (menuButton) {

            menuButton.addEventListener(
                "click",
                toggleMobileMenu
            );
        }
    }

    // ============================================================
    // MOBILE NAVIGATION EVENTS
    // ============================================================

    function initializeMobileNavigation() {

        if (!nav) return;

        document.addEventListener(
            "click",
            function (event) {

                if (
                    !document.body.classList.contains(
                        "slt-nav-open"
                    )
                ) {
                    return;
                }

                const menuButton =
                    document.querySelector(
                        ".slt-mobile-menu"
                    );

                const insideNav =
                    nav.contains(event.target);

                const insideButton =
                    menuButton &&
                    menuButton.contains(event.target);

                if (!insideNav && !insideButton) {
                    closeMobileMenu();
                }
            }
        );

        document.addEventListener(
            "keydown",
            function (event) {

                if (event.key === "Escape") {
                    closeMobileMenu();
                }
            }
        );

        nav.addEventListener(
            "click",
            function (event) {

                const link = event.target.closest(
                    ".slt-nav-links a"
                );

                if (link) {
                    closeMobileMenu();
                }
            }
        );

        window.addEventListener(
            "resize",
            function () {

                if (window.innerWidth > 820) {
                    closeMobileMenu();
                }
            }
        );
    }

    // ============================================================
    // LOGOUT
    // ============================================================

    function initializeLogout() {

        const logout = $("sltLogout");

        if (!logout) return;

        logout.addEventListener(
            "click",
            function (event) {

                event.preventDefault();

                try {

                    if (
                        typeof window.sltClearAdminToken ===
                        "function"
                    ) {

                        window.sltClearAdminToken();

                    } else {

                        localStorage.removeItem(
                            "slt_admin_token"
                        );
                    }

                    localStorage.removeItem(
                        CONFIG.emailStorageKey
                    );

                    sessionStorage.removeItem(
                        CONFIG.emailStorageKey
                    );

                } catch (error) {

                    console.warn(
                        "SLT logout storage cleanup:",
                        error
                    );
                }

                window.location.replace(
                    CONFIG.login
                );
            }
        );
    }

    // ============================================================
    // PWA INSTALLATION
    // ============================================================

    let deferredInstallPrompt = null;

    function initializePWAInstall() {

        if (!CONFIG.enablePWA) return;

        const installButton = $("sltInstall");

        window.addEventListener(
            "beforeinstallprompt",
            function (event) {

                event.preventDefault();

                deferredInstallPrompt = event;

                if (installButton) {
                    installButton.hidden = false;
                }
            }
        );

        if (!installButton) return;

        installButton.addEventListener(
            "click",
            async function () {

                if (!deferredInstallPrompt) {
                    return;
                }

                const prompt = deferredInstallPrompt;

                deferredInstallPrompt = null;

                try {

                    await prompt.prompt();

                    await prompt.userChoice;

                } catch (error) {

                    console.warn(
                        "SLT PWA installation:",
                        error
                    );

                } finally {

                    installButton.hidden = true;
                }
            }
        );

        window.addEventListener(
            "appinstalled",
            function () {

                deferredInstallPrompt = null;

                if (installButton) {
                    installButton.hidden = true;
                }
            }
        );
    }

    // ============================================================
    // SERVICE WORKER
    // ============================================================

    function initializeServiceWorker() {

        if (!CONFIG.enablePWA) return;

        if (
            !("serviceWorker" in navigator) ||
            !window.isSecureContext
        ) {
            return;
        }

        window.addEventListener(
            "load",
            async function () {

                try {

                    const registration =
                        await navigator.serviceWorker.register(
                            CONFIG.serviceWorker
                        );

                    console.info(
                        "[SLT PWA] Service worker ready:",
                        registration.scope
                    );

                } catch (error) {

                    console.warn(
                        "[SLT PWA] Registration failed:",
                        error
                    );
                }
            }
        );
    }

    // ============================================================
    // INITIALIZATION
    // ============================================================

    // Global table/search styling across all admin modules.
    if (nav && !document.querySelector('link[data-slt-unified-tables]')) {
        const css = document.createElement('link');
        css.rel = 'stylesheet';
        css.href = 'assets/slt-unified-tables.css?v=2';
        css.setAttribute('data-slt-unified-tables', '');
        document.head.appendChild(css);
    }

    initializeTheme();

    if (nav) {

        renderBrand();

        renderSidebar();

        renderTopbar();
        createThemeToggle();

        initializeMobileNavigation();

        initializeLogout();
    }

    initializePWAInstall();

    initializeServiceWorker();

})();
