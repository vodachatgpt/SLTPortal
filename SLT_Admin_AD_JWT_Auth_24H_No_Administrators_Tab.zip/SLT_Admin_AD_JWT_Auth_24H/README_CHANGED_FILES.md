# SLT — Active Directory Admin Login + JWT + Remove Administrators Tab

This package is based on the latest uploaded SLT frontend (`Frontend(20261110-181648).zip`), `Controllers(8).zip`, `Services(9).zip`, and `Web(2).config`.

## What changed

### Administrator authentication
- Replaces admin email/passcode login with NT account + Windows password.
- Validates the Windows credentials against Active Directory using `PrincipalContext`.
- Resolves the AD user's email (mail attribute, then UPN fallback) and full name.
- Requires a matching row in `dbo.Admins` with `IsActive = 1` and `IsDeleted = 0`. This table is now only an administrator allow-list and identity source; no admin passcode or old session-token hash is checked.
- Issues an HMAC-SHA256 signed JWT. Lifetime is 24 hours (1,440 minutes) by default; the service enforces a maximum of 1,440 minutes.
- Validates JWT signature, issuer, audience and expiry on every protected admin request.
- Rechecks the active `dbo.Admins` allow-list row on each request, so deactivation blocks a JWT immediately.
- Keeps the existing `/api/admin-auth/login` and `/api/admin-auth/me` paths as compatibility routes. New routes are `/api/auth/login` and `/api/auth/me`.
- Updates `SltAdminOrGuestAttribute` so admin JWTs and existing guest tokens both continue to work. Guest-token validation still uses `GuestsService.CurrentAsync`.

### Frontend
- Replaces the admin email/passcode form with NT Account + network password.
- Sends the configured API-key header on the login request.
- Stores the returned JWT using the existing `slt_admin_token` storage helper.
- Removes the Administrators item from the sidebar.
- Removes `admins-admin.html` and `assets/admins-admin.js` from the frontend package.
- Changes all shared brand links from `admins-admin.html` to `dashboard.html`.
- Removes `admins` from the API helper's admin path list.
- Bumps shared JS query versions and the PWA cache key to force updated assets.
- Guest login and guest passcode UI remain unchanged.

## Files in this package

### Backend — add
- `Backend/Models/ShareAuthModel.cs`
- `Backend/Services/ISharepointAuthService.cs`
- `Backend/Services/SharepointAuthService.cs`
- `Backend/Controllers/AuthController.cs`
- `Backend/Filters/SltAdminJwtAuthorization.cs`

### Backend — replace
- `Backend/Filters/SltAdminAttribute.cs`
- `Backend/Filters/SltAdminOrGuestAttribute.cs`

### Frontend
- The complete updated `Frontend/` folder is included. Copy its contents over the deployed frontend after backing up the current folder.

### Configuration
- `Deployment/WEB_CONFIG_ADMIN_JWT_AUTH.xml` contains the appSettings fragment to merge into the existing Web.config.

## Mandatory removal from the backend project

The old controller exposes `/api/admin-auth/login` using passcodes and `/api/admins` CRUD/reset-passcode endpoints. Remove this source file from the project and disk:

- `Controllers/AdminsController .cs` (note the space before `.cs` in the uploaded archive filename)

Also remove these old admin-passcode-only service files from the project and disk if they are present:

- `Services/AdminService.cs`
- `Services/AdminLocalRecovery.cs`

No other controller should reference `AdminService`; in the uploaded controller/service set, the old `AdminsController` was its only controller consumer. Keep the `Admin` EF entity and `dbo.Admins` table because the JWT authorization allow-list still uses `Id`, `Email`, `IsActive` and `IsDeleted`.

Do not remove guest passcode code, `SLTPasscodePepper`, `GuestsService`, or guest authentication controllers.

## Project file / references

If the .NET Framework project uses explicit `<Compile Include="..." />` entries, add the five new backend `.cs` files and keep the two replacement filter files included. Remove the old controller/service Compile entries listed above.

Add the .NET Framework reference:

- `System.DirectoryServices.AccountManagement`

Install the JWT package if it is not already installed:

```powershell
Install-Package System.IdentityModel.Tokens.Jwt
```

This package supplies `Microsoft.IdentityModel.Tokens` and `System.IdentityModel.Tokens.Jwt` APIs used by the service. Keep package versions compatible with .NET Framework 4.7.2 and the rest of the solution.

## Web.config setup

Merge `Deployment/WEB_CONFIG_ADMIN_JWT_AUTH.xml` into the existing `<appSettings>`; do not replace the whole Web.config and do not duplicate existing keys.

- `LDAP_Path`: set to the AD DNS domain or LDAP server host reachable from IIS.
- `Auth_APIKeyName`: header name, default `X-SLT-API-Key`.
- `Auth_ClientId`: set the same value in `Frontend/assets/config.js` as `AUTH_CLIENT_ID`.
- `JwtIssuer`, `JwtAudience`: keep consistent between token issuance and validation.
- `JwtSecretKey`: use at least 32 random UTF-8 bytes. Keep the real value in deployment secret storage and do not commit it.
- `JwtExpiryMinutes`: defaults to 1,440 if omitted; service clamps values to 5–1,440 minutes. Set it to `1440` for a 24-hour token.

The browser-based API key is visible to anyone who can inspect the frontend. It is only an additional request gate, not a confidential secret or a substitute for AD authentication. For stronger protection, inject the header at a trusted reverse proxy rather than storing the value in browser JavaScript.

If frontend and API are on different origins, CORS must allow:
- `Authorization`
- `Content-Type`
- `X-SLT-API-Key`

Use HTTPS for the frontend and API. Do not log the supplied Windows password, JWT or API key.

## Provisioning administrators

There is no Administrators tab and no `/api/admins` management controller in this setup. Provision or deactivate allow-list rows through a controlled database/server-side process. An AD user's `mail` attribute (or UPN fallback) must match `dbo.Admins.Email`; the row must have `IsActive = 1` and `IsDeleted = 0`.

Existing passcode-related columns in `dbo.Admins` may remain unused; no database schema migration is required for this code. Do not use the old admin passcode reset/welcome email templates.

## Login test

`POST {{baseUrl}}/api/auth/login` (or compatibility route `/api/admin-auth/login`)

Headers:

```http
Content-Type: application/json
X-SLT-API-Key: <same value as Auth_ClientId>
```

Body:

```json
{
  "LoginName": "DOMAIN\\username",
  "Password": "Windows network password"
}
```

Success response:

```json
{
  "Token": "<signed JWT>"
}
```

Then call `GET {{baseUrl}}/api/auth/me` or `GET {{baseUrl}}/api/admin-auth/me` with:

```http
Authorization: Bearer <signed JWT>
```

The `/me` response includes `AdminId`, `Email`, `NTAccount` and `FullName`. Use the same Bearer token on existing `[SltAdmin]` endpoints.

## Important behavior

- Admin JWT validity: 24 hours (1,440 minutes) from login. Activity does not extend the expiration.
- Guest passcodes, guest login tokens, guest resend, guest imports and guest QR flows are unchanged.
- Admins without a matching active allow-list row are denied even if AD authentication succeeds.
- Deactivated/deleted admins are denied on the next protected request.
- Existing old admin bearer tokens are not compatible; admins must sign in again after deployment.

## Validation performed

The package was checked for frontend references to the deleted Administrators page, old admin passcode field IDs on the admin login page, and duplicate old brand links. Static JavaScript syntax and XML parsing checks are included in the build validation where available. It was not possible to run an end-to-end AD login or compile the .NET Framework solution in this Linux packaging environment; test against your IIS/AD environment before production.
