using SLTProject.Filters;
using SLTProject.Models;
using SLTProject.Services;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;

namespace SLTProject.Controllers
{
    [RoutePrefix("api/auth")]
    public class AuthController : ApiController
    {
        private readonly ISharepointAuthService _authService;

        public AuthController()
            : this(new SharepointAuthService())
        {
        }

        // Constructor injection remains available for a DI container.
        public AuthController(ISharepointAuthService authService)
        {
            _authService = authService ??
                throw new ArgumentNullException("authService");
        }

        // POST /api/auth/login
        // POST /api/admin-auth/login (legacy frontend route)
        [HttpPost]
        [AllowAnonymous]
        [Route("")]
        [Route("login")]
        [Route("~/api/admin-auth/login")]
        public async Task<IHttpActionResult> Login(
            [FromBody] ShareAuthModel request)
        {
            if (request == null)
                return BadRequest("Invalid request.");

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            if (string.IsNullOrWhiteSpace(request.LoginName) ||
                string.IsNullOrEmpty(request.Password))
            {
                return BadRequest("NT account and Windows password are required.");
            }

            string apiKeyName = ConfigurationManager.AppSettings["Auth_APIKeyName"];
            string clientId = ConfigurationManager.AppSettings["Auth_ClientId"];

            if (string.IsNullOrWhiteSpace(apiKeyName) ||
                string.IsNullOrWhiteSpace(clientId))
            {
                Trace.TraceError(
                    "SLT authentication API key settings are missing from Web.config.");

                return InternalServerError(
                    new ConfigurationErrorsException(
                        "Configure Auth_APIKeyName and Auth_ClientId in Web.config."));
            }

            IEnumerable<string> headerValues;

            if (!Request.Headers.TryGetValues(apiKeyName, out headerValues))
            {
                return Content(
                    HttpStatusCode.Unauthorized,
                    "API Key is required.");
            }

            string apiKeyValue = headerValues.FirstOrDefault();

            if (string.IsNullOrWhiteSpace(apiKeyValue))
            {
                return Content(
                    HttpStatusCode.Unauthorized,
                    "Invalid API Key.");
            }

            try
            {
                string token = await _authService.AuthenticateUserAsync(
                    request,
                    apiKeyName,
                    apiKeyValue);

                if (string.IsNullOrWhiteSpace(token))
                {
                    Trace.TraceWarning(
                        "SLT administrator login rejected for account {0}.",
                        request.LoginName);

                    return Content(
                        HttpStatusCode.Unauthorized,
                        new
                        {
                            Success = false,
                            Message = "Invalid Windows credentials or administrator access is not enabled."
                        });
                }

                Trace.TraceInformation(
                    "SLT administrator authenticated successfully: {0}",
                    request.LoginName);

                return Ok(new { Token = token });
            }
            catch (Exception ex)
            {
                Trace.TraceError(
                    "SLT administrator login controller failed: {0}",
                    ex);

                return InternalServerError();
            }
        }

        // GET /api/auth/me
        // GET /api/admin-auth/me (legacy frontend route)
        [HttpGet]
        [SltAdmin]
        [Route("me")]
        [Route("~/api/admin-auth/me")]
        public IHttpActionResult Me()
        {
            object adminId;
            object email;
            object ntAccount;
            object fullName;

            Request.Properties.TryGetValue("SLTAdminId", out adminId);
            Request.Properties.TryGetValue("SLTAdminEmail", out email);
            Request.Properties.TryGetValue("SLTAdminNTAccount", out ntAccount);
            Request.Properties.TryGetValue("SLTAdminFullName", out fullName);

            return Ok(new
            {
                Authenticated = true,
                AdminId = adminId,
                Email = email,
                NTAccount = ntAccount,
                FullName = fullName
            });
        }
    }
}
