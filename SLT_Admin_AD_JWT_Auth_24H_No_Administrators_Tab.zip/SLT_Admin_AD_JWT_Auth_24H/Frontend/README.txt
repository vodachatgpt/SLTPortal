SLT FRONTEND — WINDOWS / ACTIVE DIRECTORY ADMIN LOGIN

Pages:
- admin-login.html: NT account + Windows password login using AD and a signed JWT.
- dashboard.html: administrator overview.
- guests-admin.html: guest management, guest passcodes, QR images and Excel imports.
- phases-admin.html, day-schedules-admin.html, airport-transfers-admin.html, guest-event-drivers-admin.html, weather-admin.html, blur-icons-admin.html, help-support-admin.html, email-templates-admin.html and notifications-admin.html: operational modules.
- guest-login.html: guest passcode login.

CONFIGURATION
1. Set assets/config.js API_BASE to the real backend origin + /api.
2. Set AUTH_API_KEY_NAME and AUTH_CLIENT_ID to match Auth_APIKeyName and Auth_ClientId in backend Web.config.
3. The API key is visible in browser JavaScript. It is a request gate, not a confidential secret. Protect the API with HTTPS, restricted CORS, network controls and AD credentials.
4. The backend must implement /api/admin-auth/login and /api/admin-auth/me (compatibility routes are provided by AuthController), plus the existing guest and module APIs.
5. Provision administrators as active, non-deleted rows in dbo.Admins. The row email must match the AD mail attribute (or UPN fallback). The Administrators navigation/page and CRUD endpoints are removed.
6. Serve the frontend over HTTPS.
7. Guest authentication and guest passcodes remain unchanged.

The browser stores the signed admin JWT in localStorage using the existing SLT token helper. The token expires 24 hours (1,440 minutes) after login.
