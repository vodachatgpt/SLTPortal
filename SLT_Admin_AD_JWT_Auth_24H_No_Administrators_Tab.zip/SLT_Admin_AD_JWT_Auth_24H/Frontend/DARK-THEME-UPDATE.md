# SLT Admin Dark Theme — v9

Updated all admin pages to use `assets/admin-dark-theme.css` (previously empty). Styles are loaded in the HTML head, after other CSS, so the dark application appears before JavaScript loads. The shared `shell.js` reuses the same stylesheet instead of inserting a duplicate. Sidebar groups remain Workspace / Guest Information / Event Information / System Information; Guest Portal shortcut is removed from static HTML and dynamic navigation. Overview remains only five KPI cards and event carousel. Weather is read-only. PWA cache bumped to v9.

## Deployment
1. Replace the old Frontend folder with this folder; do not merge with old stale copies.
2. Verify `assets/config.js` API_BASE for your environment.
3. Unregister the previous service worker one time in DevTools > Application > Service Workers; then refresh.
4. The greeting takes the first segment of the logged-in administrator email saved by the login page.
5. The Logged In Guests statistic requires `GET /api/guests/statistics/logged-in`, or `FirstLoginAt` exposed in the guest list response.

Backend/API integration was not live-tested in this environment.
