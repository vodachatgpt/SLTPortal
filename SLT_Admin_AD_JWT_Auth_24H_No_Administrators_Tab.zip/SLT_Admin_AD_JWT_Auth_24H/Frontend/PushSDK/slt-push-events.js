/* Host THIS file on the consuming application's own HTTPS origin.
 * Do not register a service worker from the central global-service domain. */
self.addEventListener('push', function(event) {
  let data = {};
  try { if (event.data) data = event.data.json(); } catch (_) { /* malformed payload */ }
  let target = new URL('./', self.registration.scope);
  try {
    const proposed = new URL(data.url || './', self.registration.scope);
    if (proposed.origin === target.origin) target = proposed;
  } catch (_) { /* fall back to application root */ }
  event.waitUntil(self.registration.showNotification(String(data.title || 'New notification').slice(0,120), {
    body: String(data.body || 'You have a new message.').slice(0,500),
    tag: String(data.id || Date.now()),
    data: { url: target.href }
  }));
});
self.addEventListener('notificationclick', function(event) {
  event.notification.close();
  let target = new URL('./', self.registration.scope);
  try {
    const proposed = new URL(event.notification.data && event.notification.data.url || './', self.registration.scope);
    if (proposed.origin === target.origin) target = proposed;
  } catch (_) { /* use local scope */ }
  event.waitUntil((async function() {
    const pages = await clients.matchAll({ type:'window', includeUncontrolled:true });
    for (const page of pages) {
      if (page.url === target.href && typeof page.focus === 'function') return page.focus();
    }
    return clients.openWindow(target.href);
  })());
});
