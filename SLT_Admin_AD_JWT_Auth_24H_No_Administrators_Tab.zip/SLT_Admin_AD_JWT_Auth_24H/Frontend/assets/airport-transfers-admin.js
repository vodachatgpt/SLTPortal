window.SLT_SCHEDULE_MODULE = {
  "title": "Airport Transfers",
  "description": "Assign separate pickup and drop-off drivers to every guest.",
  "api": "airport-transfers",
  "columns": [
    [
      "Email",
      "Guest email"
    ],
    [
      "Type",
      "Transfer type"
    ],
    [
      "Date",
      "Date"
    ],
    [
      "DriverName",
      "Driver"
    ],
    [
      "DriverPhone",
      "Phone"
    ],
    [
      "WhatsApp",
      "WhatsApp"
    ]
  ],
  "fields": [
    [
      "Email",
      "Guest email *",
      "email",
      true
    ],
    [
      "Type",
      "Type *",
      "select",
      true,
      [
        "Pickup",
        "Drop-off"
      ]
    ],
    [
      "Date",
      "Date (DD/MM/YYYY) *",
      "date",
      true
    ],
    [
      "DriverName",
      "Driver name *",
      "text",
      true
    ],
    [
      "DriverPhone",
      "Driver phone *",
      "tel",
      true
    ],
    [
      "WhatsApp",
      "WhatsApp",
      "checkbox",
      false
    ]
  ],
  "search": "Email Type Date DriverName DriverPhone"
};
window.sltScheduleAdminInit();
