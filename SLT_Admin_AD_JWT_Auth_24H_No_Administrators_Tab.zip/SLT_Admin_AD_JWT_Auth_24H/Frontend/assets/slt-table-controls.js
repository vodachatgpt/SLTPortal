/* Shared controls for Guests, Airport Transfers, Day Schedules and Event Drivers. */
(function () {
    "use strict";

    window.sltCreateTableControls = function (
        resource,
        toolbarSelector,
        tableSelector,
        onChange
    ) {
        const toolbar = document.querySelector(toolbarSelector);
        const table = document.querySelector(tableSelector);

        if (!toolbar || !table) {
            throw new Error(
                "Missing table control target: " + resource
            );
        }

        let page = 1;
        let total = 0;
        let totalPages = 0;
        let debounceTimer = null;

        const filterSpecs = {
            "guests": [
                ["Email", "Email"],
                ["Hotel", "Hotel"],
                ["Activated", "Login", ["", "true", "false"]],
                ["TourRegister", "Tour", ["", "true", "false"]],
                ["From", "Arrival from (DD/MM/YYYY)", "date"],
                ["To", "Arrival to (DD/MM/YYYY)", "date"]
            ],

            "airport-transfers": [
                ["Email", "Email"],
                ["Type", "Type"],
                ["Driver", "Driver"],
                ["From", "From (DD/MM/YYYY)", "date"],
                ["To", "To (DD/MM/YYYY)", "date"]
            ],

            "day-schedules": [
                ["Type", "Type"],
                ["From", "From (DD/MM/YYYY)", "date"],
                ["To", "To (DD/MM/YYYY)", "date"]
            ],

            "guest-event-drivers": [
                ["Email", "Email"],
                ["Driver", "Driver"],
                ["DayScheduleId", "Schedule ID", "number"],
                ["From", "From (DD/MM/YYYY)", "date"],
                ["To", "To (DD/MM/YYYY)", "date"]
            ]
        };

        // ====================================================
        // FILTER CONTROLS
        // ====================================================

        const root = document.createElement("div");

        root.className = "slt-data-filters";
        root.setAttribute("aria-label", "Table filters");

        (filterSpecs[resource] || []).forEach(spec => {

            const label = document.createElement("label");

            label.textContent = spec[1];

            let input;

            if (Array.isArray(spec[2])) {

                input = document.createElement("select");

                spec[2].forEach(value => {

                    const option = document.createElement("option");

                    option.value = value;

                    option.textContent =
                        value === "" ? "All" :
                        value === "true" ? "Yes" :
                        value === "false" ? "No" :
                        value;

                    input.appendChild(option);
                });

            } else {

                input = document.createElement("input");

                input.type = spec[2] || "search";
                input.placeholder = spec[1];
            }

            input.dataset.sltFilter = spec[0];

            label.appendChild(input);
            root.appendChild(label);
        });

        // ====================================================
        // PAGE SIZE
        // ====================================================

        const pageSizeLabel = document.createElement("label");

        pageSizeLabel.textContent = "Rows per page";

        const pageSizeSelect = document.createElement("select");

        pageSizeSelect.dataset.sltFilter = "PageSize";

        pageSizeSelect.setAttribute(
            "aria-label",
            "Rows per page"
        );

        // Consistent five-row default for every shared admin table.
        const defaultPageSize = 5;

        [5, 10, 20, 50, 100].forEach(size => {

            const option = document.createElement("option");

            option.value = String(size);
            option.textContent = String(size);

            option.selected =
                size === defaultPageSize;

            pageSizeSelect.appendChild(option);
        });

        pageSizeLabel.appendChild(pageSizeSelect);
        root.appendChild(pageSizeLabel);

        // ====================================================
        // FILTERED EXPORT
        // ====================================================

        const exportButton = document.createElement("button");

        exportButton.type = "button";
        exportButton.className = "slt-btn slt-secondary";
        exportButton.textContent = "Export filtered Excel";

        exportButton.addEventListener(
            "click",
            exportFiltered
        );

        root.appendChild(exportButton);

        toolbar.appendChild(root);

        // ====================================================
        // PAGINATION FOOTER
        // ====================================================

        const footer = document.createElement("div");

        footer.className = "slt-paging";

        const previous = document.createElement("button");

        previous.type = "button";
        previous.textContent = "Previous";
        previous.className = "slt-btn slt-secondary";

        const next = document.createElement("button");

        next.type = "button";
        next.textContent = "Next";
        next.className = "slt-btn slt-secondary";

        const pageLabel = document.createElement("span");

        pageLabel.setAttribute("aria-live", "polite");

        footer.append(previous, pageLabel, next);

        table.parentElement.insertAdjacentElement(
            "afterend",
            footer
        );

        const searchInput =
            document.getElementById("search");

        // ====================================================
        // QUERY STRING
        // ====================================================

        function query(withPage) {

            const includePage = withPage !== false;

            const params = new URLSearchParams();

            if (includePage) {
                params.set("Page", String(page));
            }

            params.set(
                "PageSize",
                pageSizeSelect.value
            );

            if (searchInput && searchInput.value.trim()) {

                params.set(
                    "Search",
                    searchInput.value.trim()
                );
            }

            root.querySelectorAll(
                "[data-slt-filter]"
            ).forEach(element => {

                if (
                    element.dataset.sltFilter === "PageSize"
                ) {
                    return;
                }

                const value = String(
                    element.value || ""
                ).trim();

                if (value) {
                    params.set(
                        element.dataset.sltFilter,
                        value
                    );
                }
            });

            return params.toString();
        }

        // ====================================================
        // FILTER EVENTS
        // ====================================================

        function notifyChanged() {

            window.clearTimeout(debounceTimer);

            page = 1;

            if (typeof onChange === "function") {
                onChange();
            }
        }

        function debounceChange() {

            window.clearTimeout(debounceTimer);

            debounceTimer = window.setTimeout(
                notifyChanged,
                350
            );
        }

        root.addEventListener(
            "input",
            debounceChange
        );

        root.addEventListener(
            "change",
            notifyChanged
        );

        if (searchInput) {

            searchInput.addEventListener(
                "input",
                debounceChange
            );

            searchInput.addEventListener(
                "change",
                notifyChanged
            );
        }

        // ====================================================
        // PREVIOUS / NEXT
        // ====================================================

        previous.addEventListener("click", () => {

            if (page > 1) {

                page--;

                if (typeof onChange === "function") {
                    onChange();
                }
            }
        });

        next.addEventListener("click", () => {

            if (page < totalPages) {

                page++;

                if (typeof onChange === "function") {
                    onChange();
                }
            }
        });

        // ====================================================
        // READ API NUMBERS
        // ====================================================

        function readNumber(
            data,
            pascalName,
            camelName,
            fallback
        ) {

            if (
                data &&
                data[pascalName] != null
            ) {
                return Number(data[pascalName]);
            }

            if (
                data &&
                data[camelName] != null
            ) {
                return Number(data[camelName]);
            }

            return fallback;
        }

        // ====================================================
        // UPDATE PAGINATION
        // ====================================================

        function setResult(data) {

            data = data || {};

            total = readNumber(
                data,
                "Total",
                "total",
                0
            );

            page = readNumber(
                data,
                "Page",
                "page",
                page
            );

            const currentPageSize = readNumber(
                data,
                "PageSize",
                "pageSize",
                Number(pageSizeSelect.value)
            );

            totalPages = readNumber(
                data,
                "TotalPages",
                "totalPages",
                currentPageSize > 0
                    ? Math.ceil(total / currentPageSize)
                    : 0
            );

            pageLabel.textContent =
                "Page " + page +
                " of " + Math.max(totalPages, 1) +
                " · " + total.toLocaleString() +
                " records";

            previous.disabled = page <= 1;

            next.disabled =
                totalPages === 0 ||
                page >= totalPages;
        }

        // ====================================================
        // EXPORT ALL FILTERED RECORDS
        // ====================================================

        async function exportFiltered() {

            exportButton.disabled = true;

            try {

                const config =
                    window.SLT_CONFIG || {};

                const base = String(
                    config.API_BASE || "/api"
                ).replace(/\/+$/, "");

                const token = localStorage.getItem(
                    "slt_admin_token"
                );

                const response = await fetch(
                    base + "/" +
                    resource +
                    "/export?" +
                    query(false),
                    {
                        headers: token
                            ? {
                                Authorization:
                                    "Bearer " + token
                            }
                            : {},

                        cache: "no-store"
                    }
                );

                if (!response.ok) {

                    let detail = "";

                    try {

                        const body =
                            await response.json();

                        detail =
                            body.Message ||
                            body.message ||
                            "";

                    } catch (_) {

                        try {
                            detail = (
                                await response.text()
                            ).slice(0, 250);
                        } catch (_) {
                            detail = "";
                        }
                    }

                    throw new Error(
                        detail ||
                        "Export failed (" +
                        response.status +
                        ")."
                    );
                }

                const blob = await response.blob();

                if (!blob || !blob.size) {

                    throw new Error(
                        "The server returned an empty Excel file."
                    );
                }

                window.sltDownload(
                    blob,
                    "SLT_" +
                    resource +
                    "_filtered.xlsx",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                );

            } catch (error) {

                if (
                    typeof window.sltNotify === "function"
                ) {
                    window.sltNotify(
                        error.message,
                        "error"
                    );
                } else {
                    console.error(error);
                }

            } finally {
                exportButton.disabled = false;
            }
        }

        // ====================================================
        // PUBLIC API
        // ====================================================

        return {
            query: query,
            setResult: setResult,
            getTotal: () => total,
            getPage: () => page,
            getPageSize: () => Number(pageSizeSelect.value)
        };
    };

})();