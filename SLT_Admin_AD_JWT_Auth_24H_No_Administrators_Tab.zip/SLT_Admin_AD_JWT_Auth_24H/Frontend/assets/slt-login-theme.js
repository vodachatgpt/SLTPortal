(function(){
 'use strict';
 document.addEventListener('DOMContentLoaded',function(){
   let theme='light';
   try{theme=localStorage.getItem('slt_admin_theme')||'light';}catch(_){}
   const adminLogin=document.body.classList.contains('slt-login-body');
   function apply(){
     document.documentElement.classList.toggle('slt-light-login',adminLogin&&theme==='light');
     document.documentElement.classList.toggle('slt-dark-admin',!adminLogin&&theme==='dark');
     control.textContent=theme==='dark'?'☀ Light mode':'☾ Dark mode';
     control.setAttribute('aria-pressed',String(theme==='dark'));
   }
   const control=document.createElement('button');control.type='button';
   control.className='slt-theme-switch slt-login-theme-toggle';
   control.setAttribute('aria-label','Toggle light and dark theme');
   document.body.appendChild(control);
   control.onclick=function(){theme=theme==='dark'?'light':'dark';try{localStorage.setItem('slt_admin_theme',theme);}catch(_){}apply();};
   apply();
 });
})();
