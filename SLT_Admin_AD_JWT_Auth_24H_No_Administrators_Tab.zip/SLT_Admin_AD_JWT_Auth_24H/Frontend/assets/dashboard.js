(async function () {
  'use strict';
  const $ = id => document.getElementById(id);
  const safe = v => window.sltEscape(v == null ? '' : String(v));
  const grid = $('sltStats');
  if (!grid) return; // Never run Overview logic on other pages.
  if (typeof sltRequireAdmin === 'function' && !await sltRequireAdmin()) return;

  const list = r => Array.isArray(r) ? r : [r?.Data, r?.Records, r?.Result, r?.Items, r?.data].find(Array.isArray) || [];
  const fmtDate = v => {
    if (!v) return 'To be confirmed';
    const formatted = window.sltFormatDateOnly ? window.sltFormatDateOnly(v) : String(v).slice(0,10);
    return formatted === '—' ? 'To be confirmed' : formatted;
  };
  const fmtTime = v => {
    if (!v) return 'Time TBD';
    return window.sltFormatTimeOnly ? window.sltFormatTimeOnly(v) : String(v).slice(0,5);
  };
  function greet() {
    const email = localStorage.getItem('slt_admin_email') || '';
    const raw = (email.split('@')[0] || '').split(/[._-]/)[0].replace(/[^a-zA-Z]/g,'');
    const name = raw ? raw[0].toUpperCase() + raw.slice(1).toLowerCase() : 'Admin';
    const hour = new Date().getHours();
    const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';
    if ($('sltWelcomeHeading')) $('sltWelcomeHeading').textContent = `${greeting}, ${name}`;
    if ($('sltGreetingIcon')) $('sltGreetingIcon').textContent = hour < 12 ? '☀' : hour < 17 ? '✦' : '☾';
    const avatar = document.querySelector('.slt-avatar');
    if (avatar) avatar.textContent = name[0];
  }
  greet();
  window.addEventListener('focus',greet);
  const api = [
    ['guests','/guests'], ['schedules','/day-schedules'],
    ['transfers','/airport-transfers'], ['logged','/guests/statistics/logged-in']
  ];
  const state = { guests: [], schedules: [], transfers: [], logged: null };
  const failed = [];
  const responses = await Promise.allSettled(api.map(a => sltRequest(a[1])));
  responses.forEach((res,i) => {
    const key=api[i][0];
    if (res.status !== 'fulfilled') { failed.push(api[i][0]); return; }
    if (key === 'logged') {
      const n = Number(res.value?.LoggedInGuests);
      state.logged = Number.isFinite(n) && n >= 0 ? n : null;
    } else state[key] = list(res.value);
  });
  if (state.logged === null && state.guests.some(g=>Object.prototype.hasOwnProperty.call(g,'FirstLoginAt'))) {
    state.logged = state.guests.filter(g=>g.IsDeleted !== true && g.FirstLoginAt).length;
  }
  const guests = state.guests.filter(g=>g.IsDeleted !== true);
  const stat = (label,count,icon,url,hint) => `<a class="slt-stat-box slt-stat-link" href="${url}"><span class="slt-stat-top"><span class="slt-stat-icon">${icon}</span><span class="slt-stat-direction">↗</span></span><strong>${count == null ? '—' : Number(count).toLocaleString()}</strong><small>${safe(label)}</small><span class="slt-stat-caption">${safe(hint)}</span></a>`;
  grid.innerHTML = [
    stat('Total guests', failed.includes('guests')?null:guests.length,'♙','guests-admin.html','Registered attendees'),
    stat('Logged in guests',state.logged,'↪','guests-admin.html','First-time activations'),
    stat('Tour registrations',failed.includes('guests')?null:guests.filter(x=>x.TourRegister===true).length,'✓','guests-admin.html','Confirmed registrations'),
    stat('Scheduled activities',failed.includes('schedules')?null:state.schedules.length,'▦','day-schedules-admin.html','Across your event'),
    stat('Airport transfers',failed.includes('transfers')?null:state.transfers.length,'✈','airport-transfers-admin.html','Guest journeys')
  ].join('');
  const sorted = state.schedules.slice().sort((a,b)=>String(a.Date||'').localeCompare(String(b.Date||'')) || String(a.StartTime||'').localeCompare(String(b.StartTime||'')));
  const car = $('sltEventCarousel');
  if (car) {
    car.innerHTML = sorted.length ? sorted.slice(0,24).map((x,i)=>`<article class="slt-event-card"><div class="slt-event-card-top"><span class="slt-event-card-type">${safe(x.ItemType||'Event')}</span><span class="slt-event-number">${String(i+1).padStart(2,'0')}</span><span class="slt-event-ring" aria-hidden="true"></span><h3>${safe(x.Title||'SLT activity')}</h3></div><div class="slt-event-card-body"><div class="slt-event-card-info"><span>◷ ${safe(fmtTime(x.StartTime))}</span><span>▦ ${safe(fmtDate(x.Date))}</span></div><p>${safe(x.ShortNote||x.LocationName||'An unforgettable experience with the SLT team.')}</p>${x.LocationName?`<div class="slt-event-venue">⌖ ${safe(x.LocationName)}</div>`:''}<a href="day-schedules-admin.html">View event details <span>↗</span></a></div></article>`).join('') : `<div class="slt-carousel-empty"><div class="slt-event-empty-icon">✦</div><h3>${failed.includes('schedules')?'Events unavailable':'Your story starts here'}</h3><p>${failed.includes('schedules')?'Could not load schedules from the API.':'Add your first schedule to showcase the event.'}</p><a href="day-schedules-admin.html">Open day schedules ↗</a></div>`;
  }
  const prev = $('eventsPrev'),next=$('eventsNext');
  if (car && prev && next) {
    const step = () => (car.querySelector('.slt-event-card')?.getBoundingClientRect().width || 320) + 18;
    const sync = () => { prev.disabled=car.scrollLeft<=2;next.disabled=car.scrollLeft>=car.scrollWidth-car.clientWidth-2; };
    prev.addEventListener('click',()=>car.scrollBy({left:-step(),behavior:'smooth'}));
    next.addEventListener('click',()=>car.scrollBy({left:step(),behavior:'smooth'}));
    car.addEventListener('scroll',sync,{passive:true});window.addEventListener('resize',sync);requestAnimationFrame(sync);
  }
  const warning = $('dashboardWarning');
  if(warning) {
    const serious=failed.filter(k=>k!=='logged');
    warning.textContent=serious.length ? 'Unable to load: '+serious.join(', ')+'. Check API access and sign-in.' : '';
    warning.hidden=!serious.length;
  }
})();
