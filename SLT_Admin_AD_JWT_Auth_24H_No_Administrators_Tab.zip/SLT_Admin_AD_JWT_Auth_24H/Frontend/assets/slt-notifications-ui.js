/* Safe, limited Markdown display: all source text is escaped before formatting. */
(function (root) {
  'use strict';
  const esc = value => String(value == null ? '' : value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  function markdown(value) {
    return esc(value).split(/\r?\n/).map(line => {
      let x = line.replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>')
        .replace(/__(.+?)__/g,'<u>$1</u>')
        .replace(/\*(.+?)\*/g,'<em>$1</em>');
      if (/^\s*[-*]\s+/.test(x)) x = '<span class="slt-n-bullet">• '+x.replace(/^\s*[-*]\s+/, '')+'</span>';
      return x;
    }).join('<br>');
  }
  root.SLTNotificationUI = {esc,markdown};
})(window);
