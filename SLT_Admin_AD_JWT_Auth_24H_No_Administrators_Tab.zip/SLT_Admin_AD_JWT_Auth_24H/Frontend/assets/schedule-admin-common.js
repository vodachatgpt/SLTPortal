(function () {
    "use strict";

    window.sltScheduleAdminInit = async function () {
        var cfg = window.SLT_SCHEDULE_MODULE;
        if (!cfg) return;

        var $ = function (id) { return document.getElementById(id); };
        var esc = function (value) {
            return window.sltEscape(value == null ? "" : value);
        };
        var endpoint = "/" + cfg.api;

        if (!await window.sltRequireAdmin()) return;

        var rows = [];
        var editingId = null;
        var scheduleOptions = [];
        var blurbOptions = [];
        var tableControls = null;

        var formatDateDisplay = function (value) {
            return window.sltFormatDateOnly
                ? window.sltFormatDateOnly(value)
                : (value ? String(value).slice(0, 10) : "—");
        };

        var formatDateInput = function (value) {
            return window.sltDateInputValue
                ? window.sltDateInputValue(value)
                : (value ? String(value).slice(0, 10) : "");
        };

        var formatTime = function (value) {
            return window.sltFormatTimeOnly
                ? window.sltFormatTimeOnly(value)
                : (value ? String(value).slice(0, 5) : "—");
        };

        var formatTimeInput = function (value) {
            return window.sltTimeInputValue
                ? window.sltTimeInputValue(value)
                : (value ? String(value).slice(0, 5) : "");
        };

        function showValue(record, key) {
            var value = record[key];
            if (value == null || value === "") return "—";
            if (key === "Date") return esc(formatDateDisplay(value));
            if (key === "StartTime" || key === "EndTime") return esc(formatTime(value));
            if (key === "WhatsApp") return value ? "Yes" : "No";

            // The table displays the linked schedule title, while the record
            // continues to store and submit the numeric DayScheduleId.
            if (key === "DayScheduleId") {
                var schedule = scheduleOptions.find(function (item) {
                    return String(item.Id) === String(value);
                });
                return schedule ? esc(schedule.Title) : "Schedule unavailable";
            }

            return esc(value);
        }

        function render() {
            if (!tableControls) return;

            $("count").textContent = tableControls.getTotal() + " matching records";

            $("recordRows").innerHTML = rows.length
                ? rows.map(function (record) {
                    return "<tr>" +
                        cfg.columns.map(function (column) {
                            return "<td><span class=\"slt-compact\">" +
                                showValue(record, column[0]) +
                                "</span></td>";
                        }).join("") +
                        "<td><div class=\"slt-row-actions\">" +
                            "<button data-action=\"edit\" data-id=\"" + record.Id + "\" type=\"button\">Edit</button>" +
                            "<button data-action=\"delete\" data-id=\"" + record.Id + "\" type=\"button\">Delete</button>" +
                        "</div></td></tr>";
                }).join("")
                : "<tr><td colspan=\"" + (cfg.columns.length + 1) +
                    "\" class=\"slt-empty-state\">No matching records.</td></tr>";
        }

        async function refresh() {
            try {
                var results = await Promise.all([
                    window.sltRequest(endpoint + "/paged?" + tableControls.query()),
                    cfg.api === "guest-event-drivers"
                        ? window.sltRequest("/day-schedules")
                        : Promise.resolve([]),
                    cfg.api === "day-schedules"
                        ? window.sltRequest("/blur-icons")
                        : Promise.resolve([])
                ]);

                var result = results[0] || {};
                rows = Array.isArray(result.Items) ? result.Items : [];
                tableControls.setResult(result);
                scheduleOptions = Array.isArray(results[1]) ? results[1] : [];
                blurbOptions = Array.isArray(results[2]) ? results[2] : [];
                render();
            } catch (error) {
                window.sltNotify(error.message, "error");
            }
        }

        function fieldMarkup(field) {
            var name = field[0];
            var label = field[1];
            var type = field[2];
            var required = field[3];
            var choices = field[4] || [];
            var attr = required ? " required" : "";
            var inner = "";

            if (type === "select") {
                inner = "<select id=\"field_" + name + "\"" + attr + ">" +
                    "<option value=\"\">Select…</option>" +
                    choices.map(function (choice) {
                        return "<option value=\"" + esc(choice) + "\">" + esc(choice) + "</option>";
                    }).join("") + "</select>";
            } else if (type === "blurb") {
                // Free text + suggestions: the API resolves names without
                // case sensitivity and saves the canonical BlurIcons.Name.
                inner = "<input id=\"field_" + name + "\" type=\"text\" list=\"sltBlurIconNames\" maxlength=\"150\" autocomplete=\"off\" placeholder=\"Enter Blur Icon name\">" +
                    "<datalist id=\"sltBlurIconNames\">" +
                    blurbOptions.map(function (icon) {
                        return "<option value=\"" + esc(icon.Name) + "\"></option>";
                    }).join("") + "</datalist>";
            } else if (type === "schedule") {
                inner = "<select id=\"field_" + name + "\"" + attr + ">" +
                    "<option value=\"\">Select schedule…</option>" +
                    scheduleOptions.map(function (schedule) {
                        return "<option value=\"" + Number(schedule.Id) + "\">" +
                            esc(schedule.Title + " · " + formatDateDisplay(schedule.Date)) +
                            "</option>";
                    }).join("") + "</select>";
            } else if (type === "textarea") {
                inner = "<textarea id=\"field_" + name + "\" rows=\"3\"></textarea>";
            } else if (type === "checkbox") {
                inner = "<input id=\"field_" + name + "\" type=\"checkbox\">";
            } else {
                inner = "<input id=\"field_" + name + "\" type=\"" + type + "\"" + attr +
                    (type === "tel" ? " autocomplete=\"off\"" : "") +
                    (type === "email" ? " maxlength=\"320\"" : "") + ">";
            }

            var className = type === "textarea"
                ? "slt-field-wide"
                : (type === "checkbox" ? "slt-check-label" : "");

            return "<label class=\"" + className + "\">" + esc(label) + inner + "</label>";
        }

        function openEditor(record) {
            editingId = record ? Number(record.Id) : null;
            $("editTitle").textContent = (record ? "Edit " : "Add ") + cfg.title;
            $("dynamicFields").innerHTML = cfg.fields.map(fieldMarkup).join("");
            if (cfg.api === "airport-transfers" || cfg.api === "guest-event-drivers") {
                $("dynamicFields").insertAdjacentHTML("beforeend", '<fieldset style="grid-column:1/-1;border:1px solid #ddd;padding:14px;border-radius:10px">' +
                    '<legend>Guest notification</legend><label>Send notification<select id="recordNotifyMode">' +
                    '<option value="None">No notification</option><option value="Immediate">Immediate / automated</option>' +
                    '<option value="Scheduled">Scheduled — 15 minutes after saving</option></select></label>' +
                    '<label>Channel<select id="recordNotifyChannels"><option value="Both">Push + SMS</option>' +
                    '<option value="Push">Push</option><option value="Sms">SMS</option></select></label>' +
                    (cfg.api === "guest-event-drivers" ? '<label><input id="recordReminder" type="checkbox"> Remind guest 15 minutes before event start</label>' : '') + '</fieldset>');
            }

            cfg.fields.forEach(function (field) {
                var input = $("field_" + field[0]);
                var value = record ? record[field[0]] : null;
                if (field[2] === "checkbox") input.checked = Boolean(value);
                else if (field[2] === "date") input.value = formatDateInput(value);
                else if (field[2] === "time") input.value = formatTimeInput(value);
                else input.value = value == null ? "" : String(value);
            });

            window.sltOpenModal("editModal");
        }

        $("openCreate").addEventListener("click", function () {
            openEditor(null);
        });
        $("refresh").addEventListener("click", refresh);

        $("recordRows").addEventListener("click", async function (event) {
            var button = event.target.closest("button[data-action]");
            if (!button) return;

            var record = rows.find(function (item) {
                return Number(item.Id) === Number(button.dataset.id);
            });
            if (!record) return;

            if (button.dataset.action === "edit") {
                openEditor(record);
                return;
            }

            if (!await window.sltConfirm(
                "Soft delete this record? It will no longer appear in the active list.",
                "Delete record")) return;

            button.disabled = true;
            try {
                await window.sltRequest(endpoint + "/" + record.Id, { method: "DELETE" });
                window.sltNotify("Record deleted.");
                await refresh();
            } catch (error) {
                window.sltNotify(error.message, "error");
            } finally {
                button.disabled = false;
            }
        });

        $("recordForm").addEventListener("submit", async function (event) {
            event.preventDefault();
            var submit = $("saveBtn");
            if (submit.disabled) return;

            var payload = {};
            cfg.fields.forEach(function (field) {
                var input = $("field_" + field[0]);
                var value = field[2] === "checkbox" ? input.checked : input.value.trim();

                if (field[2] === "time") value = value ? value + ":00" : null;
                if (field[2] === "date") value = value ? value + "T00:00:00" : null;
                if (field[2] === "schedule") value = value ? Number(value) : 0;
                if (value === "" && !field[3]) value = null;

                payload[field[0]] = value;
            });

            submit.disabled = true;
            try {
                await window.sltRequest(
                    endpoint + (editingId ? "/" + editingId : "") +
                    ((cfg.api === "airport-transfers" || cfg.api === "guest-event-drivers") ?
                        "?notificationMode=" + encodeURIComponent($("recordNotifyMode").value) +
                        "&notificationChannels=" + encodeURIComponent($("recordNotifyChannels").value) +
                        (cfg.api === "guest-event-drivers" ? "&reminder=" + Boolean($("recordReminder").checked) : "") : ""),
                    {
                        method: editingId ? "PUT" : "POST",
                        body: JSON.stringify(payload)
                    }
                );
                window.sltCloseModal("editModal");
                window.sltNotify(editingId ? "Record updated." : "Record created.");
                await refresh();
            } catch (error) {
                window.sltNotify(error.message, "error");
            } finally {
                submit.disabled = false;
            }
        });

        // Excel files are binary; use fetch instead of the JSON request helper.
        function authHeader() {
            var token = localStorage.getItem("slt_admin_token");
            return token ? { Authorization: "Bearer " + token } : {};
        }

        async function parseError(response) {
            var fallback = "HTTP " + response.status;
            try {
                var data = await response.json();
                if (data.Errors && data.Errors.length) return data.Errors.slice(0, 8).join("\n");
                if (data.ModelState) return Object.values(data.ModelState).flat().join("\n");
                return data.Message || data.errorMessage || data.message || fallback;
            } catch (_) {
                try { return await response.text() || fallback; }
                catch (ignore) { return fallback; }
            }
        }

        async function fetchApi(suffix, options) {
            var base = window.SLT_CONFIG.API_BASE.replace(/\/$/, "");
            var settings = Object.assign({
                headers: authHeader(),
                credentials: "omit",
                cache: "no-store"
            }, options || {});
            settings.headers = Object.assign({}, authHeader(), settings.headers || {});

            var response = await fetch(base + endpoint + suffix, settings);
            if (!response.ok) throw new Error(await parseError(response));
            return response;
        }

        $("downloadTemplate").addEventListener("click", async function () {
            var button = $("downloadTemplate");
            button.disabled = true;
            try {
                var response = await fetchApi("/template");
                var blob = await response.blob();
                window.sltDownload(
                    blob,
                    cfg.api + "_Template.xlsx",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                );
            } catch (error) {
                window.sltNotify(error.message, "error");
            } finally {
                button.disabled = false;
            }
        });

        function updateImportFileName() {
            var file = $("excelFile").files && $("excelFile").files[0];
            var label = $("excelFileName");
            if (label) {
                label.textContent = file ? file.name : "No file selected";
                label.classList.toggle("has-file", !!file);
            }
            $("importBtn").disabled = !file;
        }

        $("excelFile").addEventListener("change", updateImportFileName);
        $("openImport").addEventListener("click", function () {
            $("importForm").reset();
            updateImportFileName();
            var report = $("sltImportReport");
            if (report) {
                report.hidden = true;
                report.innerHTML = "";
            }
            window.sltOpenModal("importModal");
        });

        $("importForm").addEventListener("submit", async function (event) {
            event.preventDefault();
            var file = $("excelFile").files[0];
            if (!file) {
                window.sltNotify("Choose an Excel workbook first.", "error");
                return;
            }
            if (!/\.xlsx$/i.test(file.name) || file.size > 10 * 1024 * 1024) {
                window.sltNotify("Choose an .xlsx file no larger than 10 MB.", "error");
                return;
            }

            var mode = $("importMode").value || "Upsert";
            if (mode === "ReplaceAll") {
                var confirmed = await window.sltConfirm(
                    "Replace All will soft-delete every active " + cfg.title +
                    " record before importing valid rows. Use this only with a complete workbook. Continue?",
                    "Confirm Replace All"
                );
                if (!confirmed) return;
            }

            var report = $("sltImportReport");
            if (report) {
                report.hidden = true;
                report.innerHTML = "";
            }

            var button = $("importBtn");
            button.disabled = true;
            try {
                var form = new FormData();
                form.append("file", file, file.name);

                var response = await fetchApi(
                    "/import?mode=" + encodeURIComponent(mode),
                    { method: "POST", body: form }
                );
                var result = await response.json();

                window.sltCloseModal("importModal");
                if (window.sltShowImportReport) {
                    window.sltShowImportReport(
                        "sltImportReport",
                        result,
                        cfg.title + " import · " + mode,
                        ".slt-schedule-card"
                    );
                }

                var failed = Number(result.Failed || result.failed || 0);
                var inserted = Number(result.Inserted || result.inserted || 0);
                var updated = Number(result.Updated || result.updated || 0);
                var skipped = Number(result.Skipped || result.skipped || 0);
                var softDeleted = Number(result.SoftDeleted || result.softDeleted || 0);

                window.sltNotify(
                    "Import completed. Inserted: " + inserted +
                    ", updated: " + updated +
                    ", skipped: " + skipped +
                    ", rows with errors: " + failed +
                    (softDeleted ? ", soft-deleted: " + softDeleted : ""),
                    failed > 0 ? "warning" : "success"
                );

                await refresh();
            } catch (error) {
                window.sltNotify(error.message, "error");
            } finally {
                button.disabled = false;
                updateImportFileName();
            }
        });

        try {
            tableControls = window.sltCreateTableControls(
                cfg.api,
                ".slt-schedule-filters",
                ".slt-table-scroll table",
                refresh
            );
        } catch (error) {
            window.sltNotify(error.message, "error");
            return;
        }

        updateImportFileName();
        await refresh();
    };
})();
