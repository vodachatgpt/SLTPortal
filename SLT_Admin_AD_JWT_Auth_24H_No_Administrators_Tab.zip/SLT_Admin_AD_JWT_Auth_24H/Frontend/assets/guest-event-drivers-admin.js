window.SLT_SCHEDULE_MODULE = {
  "title": "Event Drivers",
  "description": "Assign different drivers to guests for shared dinner, tour, and other schedule activities.",
  "api": "guest-event-drivers",
  "columns": [
    [
      "Email",
      "Guest email"
    ],
    [
      "DayScheduleId",
      "Schedule Title"
    ],
    [
      "DriverName",
      "Driver"
    ],
    [
      "DriverPhone",
      "Phone"
    ],
    [
      "WhatsApp",
      "WhatsApp"
    ]
  ],
  "fields": [
    [
      "Email",
      "Guest email *",
      "email",
      true
    ],
    [
      "DayScheduleId",
      "Schedule item *",
      "schedule",
      true
    ],
    [
      "DriverName",
      "Driver name *",
      "text",
      true
    ],
    [
      "DriverPhone",
      "Driver phone *",
      "tel",
      true
    ],
    [
      "WhatsApp",
      "WhatsApp",
      "checkbox",
      false
    ]
  ],
  "search": "Email DayScheduleId DriverName DriverPhone"
};
window.sltScheduleAdminInit();
