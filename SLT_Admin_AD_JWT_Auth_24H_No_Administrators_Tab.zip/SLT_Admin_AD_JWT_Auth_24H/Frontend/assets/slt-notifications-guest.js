(function(){
'use strict';const ui=window.SLTNotificationUI,$=id=>document.getElementById(id);
const tokenKey='slt_guest_token';let page=1,pages=0,push=null,pushReady=false,requestSequence=0;
function auth(path,options){const token=localStorage.getItem(tokenKey);if(!token)throw Error('Sign in first.');return sltRequest('/slt-notifications/guest/'+path,Object.assign({},options||{},{headers:Object.assign({},options&&options.headers,{Authorization:'Bearer '+token})}));}
function say(m){$('nGuestStatus').textContent=m;}
function signedIn(){return !!localStorage.getItem(tokenKey);}
function panelVisible(){const panel=$('nGuestPanel');return !!panel && !panel.hidden && !panel.classList.contains('slt-hidden');}
function loading(){ $('nGuestList').innerHTML='<div class="slt-n-empty"><span class="slt-n-spinner"></span> Loading your notifications…</div>'; }
async function load(){const seq=++requestSequence;if(!signedIn()||!panelVisible()){say('Sign in to view your notifications.');$('nGuestList').innerHTML='';return;}loading();
 try{const r=await auth('inbox?page='+page+'&pageSize=10&unreadOnly='+$('nGuestUnreadOnly').checked);if(seq!==requestSequence||!panelVisible())return;pages=r.TotalPages||0;
 $('nGuestCount').textContent=r.UnreadCount+' unread';$('nGuestPage').textContent='Page '+r.Page+' of '+Math.max(pages,1);
 $('nGuestPrev').disabled=page<=1;$('nGuestNext').disabled=page>=pages;
 $('nGuestList').innerHTML=(r.Items||[]).map(x=>'<article class="slt-n-item '+(x.IsRead?'':'unread')+'"><div class="slt-n-item-head"><strong>'+ui.esc(x.Title)+'</strong><span class="slt-n-badge">'+(x.IsRead?'Read':'Unread')+'</span></div><p class="slt-n-muted">'+ui.esc(window.sltFormatDateTime?window.sltFormatDateTime(x.CreatedAt):String(x.CreatedAt||'').replace('T',' ').slice(0,16))+' (Egypt time)</p><div class="slt-n-body">'+ui.markdown(x.MessageText)+'</div>'+(!x.IsRead?'<button class="slt-n-button" type="button" data-n-read="'+ui.esc(x.NotificationId)+'">Mark as read</button>':'')+'</article>').join('')||'<div class="slt-n-empty"><strong>All caught up</strong><p>No notifications match your filter.</p></div>';say('');}
 catch(err){if(seq!==requestSequence)return;$('nGuestList').innerHTML='<div class="slt-n-empty">Unable to load your inbox. Use Refresh to try again.</div>';say('Inbox unavailable: '+err.message);}}
function setupPush(){if(pushReady)return;const config=window.SLT_CONFIG||{};
 if(!window.SLTGuestPush||!config.GLOBAL_PUSH_BASE_URL||!config.GLOBAL_PUSH_APPLICATION_CODE){say('Inbox works. Browser push is not configured yet.');return;}
 try{push=window.SLTGuestPush.create({sltApiBase:config.API_BASE,globalPushServiceUrl:config.GLOBAL_PUSH_BASE_URL,applicationCode:config.GLOBAL_PUSH_APPLICATION_CODE,workerUrl:'./service-worker.js',workerScope:'./',getGuestToken:()=>localStorage.getItem(tokenKey)});pushReady=true;}
 catch(err){say(err.message);}}
$('nGuestEnable').onclick=async()=>{if(!signedIn()){say('Sign in first.');return;}setupPush();if(!push)return;
 const b=$('nGuestEnable');b.disabled=true;b.textContent='Enabling…';try{const r=await push.enable();
 const ok=!!(r && (r.subscribed===true || r.success===true || r.isSubscribed===true));
 say(ok?'Browser notifications enabled.':'Browser registration returned a response; check subscription status.');}catch(err){say('Browser push unavailable: '+err.message);}finally{b.disabled=false;b.textContent='Enable browser alerts';}};
$('nGuestList').addEventListener('click',async e=>{const b=e.target.closest('[data-n-read]');if(!b)return;b.disabled=true;try{await auth(b.dataset.nRead+'/read',{method:'POST'});await load();}catch(err){say(err.message);b.disabled=false;}});
$('nGuestRefresh').onclick=()=>{page=1;load();};$('nGuestUnreadOnly').onchange=()=>{page=1;load();};$('nGuestPrev').onclick=()=>{if(page>1){page--;load();}};$('nGuestNext').onclick=()=>{if(page<pages){page++;load();}};
window.sltGuestNotificationsRefresh=()=>{page=1;load();};
window.sltGuestPushStatus=async()=>{
 if(!signedIn())throw new Error('Guest login required.');
 setupPush();if(!push)throw new Error('Browser push settings or SDK unavailable.');
 return push.status();
};
window.sltGuestNotificationsBeforeLogout=async()=>{if(push){try{await push.beforeLogout();}catch(_){}}};
window.addEventListener('storage',e=>{if(e.key===tokenKey)load();});
setupPush();if(signedIn() && panelVisible())load();
})();
