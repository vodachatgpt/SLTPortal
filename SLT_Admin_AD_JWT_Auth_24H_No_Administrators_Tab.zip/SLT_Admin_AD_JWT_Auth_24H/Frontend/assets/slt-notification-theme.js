(function () {
  'use strict';
  if (!document.body || !document.body.classList.contains('slt-guest-experience')) return;
  var key = 'slt_guest_theme';
  var current = 'light';
  try { current = localStorage.getItem(key) || 'light'; } catch (_) {}
  function apply() {
    var dark = current === 'dark';
    document.documentElement.classList.toggle('slt-n-dark', dark);
    document.body.classList.toggle('slt-n-dark', dark);
    var b = document.getElementById('sltNotificationThemeToggle');
    if (b) { b.textContent = dark ? '☀ Light mode' : '☾ Dark mode'; b.setAttribute('aria-pressed', String(dark)); }
  }
  var b = document.createElement('button');
  b.type = 'button'; b.id = 'sltNotificationThemeToggle'; b.className = 'slt-n-button slt-n-theme-toggle';
  b.setAttribute('aria-label', 'Toggle notifications light and dark mode');
  b.addEventListener('click', function () {
    current = current === 'dark' ? 'light' : 'dark';
    try { localStorage.setItem(key, current); } catch (_) {}
    apply();
  });
  document.body.appendChild(b);
  apply();
})();
