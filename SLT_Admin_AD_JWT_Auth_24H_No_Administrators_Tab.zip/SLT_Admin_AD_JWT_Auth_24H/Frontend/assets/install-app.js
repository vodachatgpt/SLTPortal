
(function () {
    "use strict";

    const overlay = document.getElementById("sltInstallOverlay");
    const installBtn = document.getElementById("sltInstallButton");
    const continueBtn = document.getElementById("sltContinueButton");
    const instructions = document.getElementById("sltInstallInstructions");

    if (!overlay || !installBtn || !continueBtn || !instructions) {
        return;
    }

    const storageKey = "slt_install_dismissed";
    let deferredPrompt = null;

    const isStandalone = () =>
        window.matchMedia("(display-mode: standalone)").matches ||
        window.navigator.standalone === true;

    const isIOS = () =>
        /iPad|iPhone|iPod/.test(navigator.userAgent) ||
        (navigator.platform === "MacIntel" &&
            navigator.maxTouchPoints > 1);

    function hidePopup() {
        overlay.hidden = true;
    }

    function showPopup() {
        if (isStandalone()) return;
        if (localStorage.getItem(storageKey) === "1") return;

        overlay.hidden = false;

        if (deferredPrompt) {
            installBtn.hidden = false;
            instructions.hidden = true;
        } else {
            installBtn.hidden = true;
            instructions.hidden = false;

            if (isIOS()) {
                instructions.textContent =
                    "On iPhone or iPad, open this page in Safari, " +
                    "tap Share, then select Add to Home Screen.";
            } else {
                instructions.textContent =
                    "You can install this app from your browser menu " +
                    "when installation is available.";
            }
        }
    }

    // Save the native installation event for a user click.
    window.addEventListener("beforeinstallprompt", function (event) {
        event.preventDefault();
        deferredPrompt = event;

        if (!overlay.hidden) {
            installBtn.hidden = false;
            instructions.hidden = true;
        }
    });

    installBtn.addEventListener("click", async function () {
        if (!deferredPrompt) return;

        const promptEvent = deferredPrompt;
        deferredPrompt = null;

        installBtn.disabled = true;

        try {
            await promptEvent.prompt();
            await promptEvent.userChoice;
        } catch (error) {
            console.warn("App installation was not completed.", error);
        } finally {
            installBtn.disabled = false;
            installBtn.hidden = true;
            hidePopup();
        }
    });

    continueBtn.addEventListener("click", function () {
        localStorage.setItem(storageKey, "1");
        hidePopup();
    });

    window.addEventListener("appinstalled", function () {
        deferredPrompt = null;
        localStorage.setItem(storageKey, "1");
        hidePopup();
    });

    // Show the welcome popup immediately on first visit.
    showPopup();

    // Register PWA service worker, if supported.
    if ("serviceWorker" in navigator) {
        window.addEventListener("load", function () {
            navigator.serviceWorker.register("./service-worker.js")
                .catch(function (error) {
                    console.warn("Service worker registration failed:", error);
                });
        });
    }
})();
