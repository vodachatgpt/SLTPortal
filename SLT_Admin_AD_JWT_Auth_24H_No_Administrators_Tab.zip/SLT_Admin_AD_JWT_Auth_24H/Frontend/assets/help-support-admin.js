(async function () {
'use strict';const $=id=>document.getElementById(id);if(!await sltRequireAdmin())return;
let records=[],editingId=null;

    let supportPage = 1;
    const localPageSize = 5;
    const localPager = document.createElement("div");
    localPager.className = "slt-generic-paging";
    localPager.innerHTML = '<button type="button" data-dir="-1">Previous</button><span data-info></span><button type="button" data-dir="1">Next</button>';
    const localBody = document.getElementById("records");
    if (localBody && localBody.closest('table')) {
        const tableBox = localBody.closest('table').parentElement;
        tableBox.insertAdjacentElement('afterend', localPager);
    }
    localPager.addEventListener('click', function(e) {
        const btn = e.target.closest('button[data-dir]');
        if (!btn || btn.disabled) return;
        supportPage += Number(btn.dataset.dir);
        paint();
    });
    function paginateRecords(items) {
        const maxPage = Math.max(1, Math.ceil(items.length / localPageSize));
        supportPage = Math.min(maxPage, Math.max(1, supportPage));
        localPager.querySelector('[data-info]').textContent = 'Page ' + supportPage + ' of ' + maxPage + ' · ' + items.length + ' records';
        localPager.querySelector('[data-dir="-1"]').disabled = supportPage === 1;
        localPager.querySelector('[data-dir="1"]').disabled = supportPage >= maxPage;
        return items.slice((supportPage - 1) * localPageSize, supportPage * localPageSize);
    }
const keys=['EventContact','Transportation','Emergency','HealthandSafety'];const ids=['eventContact','transportation','emergency','healthSafety'];
function paint(){const tbody=$('records');tbody.innerHTML='';if(!records.length){tbody.innerHTML='<tr><td colspan="5">No support records yet.</td></tr>';return;}paginateRecords(records).forEach(item=>{const tr=document.createElement('tr');keys.forEach(k=>{const td=document.createElement('td');td.textContent=item[k]||'-';td.className='slt-support-snippet';tr.appendChild(td);});const td=document.createElement('td');td.innerHTML='<div class="slt-row-actions"><button type="button" data-action="edit">Edit</button><button type="button" data-action="delete">Delete</button></div>';td.querySelectorAll('button').forEach(b=>b.dataset.id=item.Id);tr.appendChild(td);tbody.appendChild(tr);});}
async function load(){try{const r=await sltRequest('/help-support');records=Array.isArray(r)?r:(r.Records||[]);paint();}catch(e){sltNotify(e.message,'error');}}
function open(item){editingId=item?item.Id:null;$('recordForm').reset();$('formTitle').textContent=item?'Edit Help & Support':'Add Help & Support';if(item)keys.forEach((k,i)=>{$(ids[i]).value=item[k]||'';});sltOpenModal('recordModal');}
$('openRecord').onclick=()=>open();$('refresh').onclick=load;
$('recordForm').onsubmit=async e=>{e.preventDefault();const data={};keys.forEach((k,i)=>data[k]=$(ids[i]).value.trim());if(!Object.values(data).some(Boolean)){sltNotify('Enter at least one support field.','error');return;}const b=$('saveRecord');b.disabled=true;try{await sltRequest(editingId?'/help-support/'+editingId:'/help-support',{method:editingId?'PUT':'POST',body:JSON.stringify(data)});sltCloseModal('recordModal');sltNotify(editingId?'Support updated.':'Support created.');await load();}catch(err){sltNotify(err.message,'error');}finally{b.disabled=false;}};
$('records').onclick=async e=>{const b=e.target.closest('button[data-action]');if(!b)return;const item=records.find(x=>x.Id===Number(b.dataset.id));if(!item)return;if(b.dataset.action==='edit'){open(item);return;}if(!await sltConfirm('Soft delete this support record?'))return;try{await sltRequest('/help-support/'+item.Id,{method:'DELETE'});sltNotify('Support record deleted.');await load();}catch(err){sltNotify(err.message,'error');}};await load();
})();