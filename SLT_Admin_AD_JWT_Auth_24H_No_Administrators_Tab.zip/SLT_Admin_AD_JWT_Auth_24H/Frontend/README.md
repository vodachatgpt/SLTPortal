# SLT Frontend

Static HTML/CSS/JavaScript frontend for the SLT Web API.

## Admin login
Administrators sign in with their Windows NT account and network password. The backend validates the credentials against Active Directory and returns a signed JWT. The frontend sends the configured API-key header only on the login request and sends the JWT as a Bearer token for protected endpoints.

Configure `assets/config.js`:
- `API_BASE`: backend origin ending in `/api`.
- `AUTH_API_KEY_NAME`: must match `Auth_APIKeyName` in Web.config.
- `AUTH_CLIENT_ID`: must match `Auth_ClientId` in Web.config.

**Security note:** browser JavaScript is public. `AUTH_CLIENT_ID` is visible to users and must not be treated as a secret. Use HTTPS, strict CORS, network restrictions and AD authentication.

## Administrator provisioning
The Administrators tab and its management page are removed. The backend uses `dbo.Admins` only as an allow-list: the AD email must match a row where `IsActive = 1` and `IsDeleted = 0`. Provision/disable allow-list rows through a controlled database or server-side administration process.

## Guest login
Guest passcode login and guest passcode management remain unchanged.


## Admin JWT expiration
The administrator JWT expires 24 hours (1,440 minutes) after login. API activity does not extend its lifetime. After expiration, the next protected API request returns HTTP 401 and the administrator must sign in again. Guest authentication is unchanged.
