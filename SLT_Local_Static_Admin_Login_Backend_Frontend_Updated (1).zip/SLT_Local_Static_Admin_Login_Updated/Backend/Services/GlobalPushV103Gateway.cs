
using System;
using System.Configuration;
using System.Globalization;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace SltPushIntegration
{
    /// <summary>
    /// Global Browser Push V10.3 integration.
    ///
    /// Compatible with:
    /// - .NET Framework 4.7 / 4.7.2
    /// - ASP.NET Web API 2
    /// - C# 7.3
    ///
    /// Uses direct HTTP connections without a proxy.
    /// The API key must remain on the backend.
    /// </summary>
    public sealed class GlobalPushV103Gateway
    {
        // ========================================================
        // RESPONSE MODEL
        // ========================================================

        public sealed class ServiceResult
        {
            public HttpStatusCode Status { get; set; }

            public JObject Body { get; set; }

            public string ErrorMessage { get; set; }

            public bool IsSuccess
            {
                get
                {
                    int status = (int)Status;

                    return status >= 200 && status < 300;
                }
            }
        }

        // ========================================================
        // CONFIGURATION HELPERS
        // ========================================================

        private static string Setting(
            string key,
            string defaultValue = null)
        {
            string value =
                ConfigurationManager.AppSettings[key];

            return string.IsNullOrWhiteSpace(value)
                ? defaultValue
                : value.Trim();
        }

        private static bool IsConfigured(string value)
        {
            return !string.IsNullOrWhiteSpace(value) &&
                   value.IndexOf(
                       "YOUR-",
                       StringComparison.OrdinalIgnoreCase) < 0;
        }

        private static string Required(string key)
        {
            string value = Setting(key);

            if (!IsConfigured(value))
            {
                throw new InvalidOperationException(
                    "Missing or invalid backend setting: " + key);
            }

            return value;
        }

        private static int TimeoutSeconds
        {
            get
            {
                int seconds;

                if (!int.TryParse(
                    Setting("SltPush.TimeoutSeconds", "25"),
                    NumberStyles.Integer,
                    CultureInfo.InvariantCulture,
                    out seconds))
                {
                    seconds = 25;
                }

                return Math.Max(
                    5,
                    Math.Min(120, seconds));
            }
        }

        public static string ApplicationCode
        {
            get
            {
                return Required("SltPush.ApplicationCode");
            }
        }

        public static string GlobalPushBaseUrl
        {
            get
            {
                return Required("SltPush.GlobalPushBaseUrl");
            }
        }

        // ========================================================
        // GUEST LAUNCH PATH
        // ========================================================

        public static string GuestLaunchPath
        {
            get
            {
                string path =
                    Required("SltPush.GuestLaunchPath");

                if (!IsSafeLocalPath(path))
                {
                    throw new InvalidOperationException(
                        "SltPush.GuestLaunchPath must be " +
                        "a safe root-relative path.");
                }

                return path;
            }
        }

        // ========================================================
        // GUEST REFERENCE
        //
        // Must match the reference supplied during
        // guest browser push registration.
        // ========================================================

        public static string GuestUserReference(int guestId)
        {
            if (guestId < 1)
            {
                throw new ArgumentOutOfRangeException(
                    "guestId");
            }

            return "SLT-GUEST:" +
                guestId.ToString(
                    CultureInfo.InvariantCulture);
        }

        // ========================================================
        // SAFE LOCAL PATH VALIDATION
        // ========================================================

        private static bool IsSafeLocalPath(string path)
        {
            if (string.IsNullOrWhiteSpace(path))
                return false;

            if (path.Length > 500)
                return false;

            if (!path.StartsWith(
                "/",
                StringComparison.Ordinal))
            {
                return false;
            }

            if (path.StartsWith(
                "//",
                StringComparison.Ordinal))
            {
                return false;
            }

            // .NET Framework-compatible character checks.
            if (path.IndexOf('\\') >= 0 ||
                path.IndexOf('\r') >= 0 ||
                path.IndexOf('\n') >= 0 ||
                path.IndexOf('\t') >= 0 ||
                path.IndexOf('%') >= 0 ||
                path.IndexOf('#') >= 0)
            {
                return false;
            }

            // Reject URL traversal segments.
            string pathname = path.Split('?')[0];

            string[] segments = pathname.Split('/');

            foreach (string segment in segments)
            {
                if (segment == "." || segment == "..")
                    return false;
            }

            // Reject control characters.
            foreach (char character in path)
            {
                if (char.IsControl(character))
                    return false;
            }

            Uri uri;

            if (!Uri.TryCreate(
                path,
                UriKind.Relative,
                out uri))
            {
                return false;
            }

            return !uri.IsAbsoluteUri;
        }

        // ========================================================
        // GUEST CLICK URL VALIDATION
        // ========================================================

        public static bool ValidGuestUrl(
            string candidate,
            string root)
        {
            if (string.IsNullOrEmpty(candidate))
                return true;

            if (!IsSafeLocalPath(candidate) ||
                !IsSafeLocalPath(root))
            {
                return false;
            }

            string candidatePath =
                candidate.Split('?')[0];

            string rootPath =
                root.Split('?')[0];

            if (rootPath == "/")
                return true;

            // Exact configured guest page.
            if (string.Equals(
                candidatePath,
                rootPath.TrimEnd('/'),
                StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            // Permit child paths only when the configured
            // root is a directory ending with slash.
            if (rootPath.EndsWith(
                "/",
                StringComparison.Ordinal))
            {
                return candidatePath.StartsWith(
                    rootPath,
                    StringComparison.OrdinalIgnoreCase);
            }

            return false;
        }

        // ========================================================
        // VALIDATE GLOBAL PUSH URL
        // ========================================================

        private static Uri GetServiceUri()
        {
            Uri uri;

            if (!Uri.TryCreate(
                GlobalPushBaseUrl,
                UriKind.Absolute,
                out uri))
            {
                throw new InvalidOperationException(
                    "Invalid Global Push base URL.");
            }

            // HTTPS is required except for localhost testing.
            if (uri.Scheme != Uri.UriSchemeHttps &&
                !(uri.IsLoopback &&
                  uri.Scheme == Uri.UriSchemeHttp))
            {
                throw new InvalidOperationException(
                    "Global Push requires HTTPS except " +
                    "for local development.");
            }

            if (!string.IsNullOrEmpty(uri.UserInfo) ||
                !string.IsNullOrEmpty(uri.Query) ||
                !string.IsNullOrEmpty(uri.Fragment))
            {
                throw new InvalidOperationException(
                    "Global Push base URL cannot contain " +
                    "credentials, query strings or fragments.");
            }

            return new Uri(
                uri.AbsoluteUri.TrimEnd('/') + "/",
                UriKind.Absolute);
        }

        // ========================================================
        // CREATE HTTP CLIENT
        //
        // NO PROXY
        // ========================================================

        private static HttpClient CreateClient()
        {
            var handler = new HttpClientHandler
            {
                UseProxy = false,

                AllowAutoRedirect = false,

                AutomaticDecompression =
                    DecompressionMethods.GZip |
                    DecompressionMethods.Deflate
            };

            var client = new HttpClient(handler);

            client.Timeout = TimeSpan.FromSeconds(
                TimeoutSeconds);

            return client;
        }

        // ========================================================
        // BUILD GLOBAL PUSH API URL
        // ========================================================

        private static Uri BuildEndpoint(
            Uri baseUri,
            string path)
        {
            if (string.IsNullOrWhiteSpace(path))
            {
                throw new ArgumentException(
                    "Global Push endpoint is required.",
                    "path");
            }

            string endpoint = path.Trim().Trim('/');

            if (endpoint.Length == 0 ||
                endpoint.Contains("..") ||
                endpoint.Contains("?") ||
                endpoint.Contains("#") ||
                endpoint.Contains("\\") ||
                endpoint.Contains(":") ||
                endpoint.Contains("%"))
            {
                throw new ArgumentException(
                    "Invalid Global Push endpoint.",
                    "path");
            }

            foreach (char character in endpoint)
            {
                bool allowed =
                    (character >= 'a' && character <= 'z') ||
                    (character >= 'A' && character <= 'Z') ||
                    (character >= '0' && character <= '9') ||
                    character == '-' ||
                    character == '_' ||
                    character == '/';

                if (!allowed)
                {
                    throw new ArgumentException(
                        "Invalid Global Push endpoint.",
                        "path");
                }
            }

            // Preserve any application path specified
            // by the configured server base URL.
            //
            // Example:
            // https://server/globalpush/
            //
            // Result:
            // https://server/globalpush/api/push/v1/notifications

            var builder = new UriBuilder(baseUri);

            string prefix =
                builder.Path.TrimEnd('/');

            builder.Path =
                prefix +
                "/api/push/v1/" +
                endpoint;

            builder.Query = "";
            builder.Fragment = "";

            return builder.Uri;
        }

        // ========================================================
        // SEND REQUEST
        //
        // This signature is compatible with your existing
        // SltNotificationsService.
        // ========================================================

        public async Task<ServiceResult> SendAsync(
            HttpMethod method,
            string path,
            JObject payload,
            CancellationToken cancellationToken,
            string origin = null)
        {
            if (method == null)
            {
                throw new ArgumentNullException(
                    "method");
            }

            // Validate configuration before making a request.
            Uri serviceUri = GetServiceUri();

            Uri endpoint = BuildEndpoint(
                serviceUri,
                path);

            string applicationCode = ApplicationCode;

            string apiKey =
                Required("SltPush.ApplicationApiKey");

            using (var client = CreateClient())
            using (var request = new HttpRequestMessage(
                method,
                endpoint))
            {
                // ================================================
                // REQUEST HEADERS
                // ================================================

                request.Headers.TryAddWithoutValidation(
                    "X-Application-Code",
                    applicationCode);

                request.Headers.TryAddWithoutValidation(
                    "X-Api-Key",
                    apiKey);

                // Preserve the Partner PWA origin when the SLT backend
                // performs the Global Push registration-token request.
                // The value is validated by SltNotificationsController
                // against the configured origin allow-list.
                if (!string.IsNullOrWhiteSpace(origin))
                {
                    request.Headers.TryAddWithoutValidation(
                        "Origin",
                        origin);
                }

                request.Headers.Accept.Add(
                    new MediaTypeWithQualityHeaderValue(
                        "application/json"));

                // ================================================
                // REQUEST JSON
                // ================================================

                if (payload != null)
                {
                    string json = payload.ToString(
                        Formatting.None);

                    request.Content = new StringContent(
                        json,
                        Encoding.UTF8,
                        "application/json");
                }

                // ================================================
                // PERFORM HTTP REQUEST
                // ================================================

                try
                {
                    using (var response =
                        await client.SendAsync(
                            request,
                            HttpCompletionOption.ResponseContentRead,
                            cancellationToken
                        ).ConfigureAwait(false))
                    {
                        string responseText =
                            response.Content == null
                                ? ""
                                : await response.Content
                                    .ReadAsStringAsync()
                                    .ConfigureAwait(false);

                        JObject body;

                        // ========================================
                        // PARSE RESPONSE
                        // ========================================

                        if (string.IsNullOrWhiteSpace(
                            responseText))
                        {
                            body = new JObject();
                        }
                        else
                        {
                            try
                            {
                                body = JObject.Parse(
                                    responseText);
                            }
                            catch (JsonException)
                            {
                                body = new JObject
                                {
                                    ["message"] =
                                        "Global Push returned " +
                                        "an unexpected response."
                                };
                            }
                        }

                        // ========================================
                        // HANDLE HTTP STATUS
                        // ========================================

                        string errorMessage = null;

                        if (!response.IsSuccessStatusCode)
                        {
                            errorMessage =
                                "Global Push returned HTTP " +
                                ((int)response.StatusCode)
                                    .ToString(
                                        CultureInfo.InvariantCulture) +
                                " (" +
                                response.ReasonPhrase +
                                ").";

                            // Never log the API key,
                            // request body or personal data.
                            System.Diagnostics.Trace.TraceWarning(
                                "[SLT Global Push] Request failed. " +
                                "HTTP status: " +
                                (int)response.StatusCode +
                                ", Path: " +
                                endpoint.AbsolutePath);
                        }
                        else
                        {
                            System.Diagnostics.Trace.TraceInformation(
                                "[SLT Global Push] Request accepted. " +
                                "HTTP status: " +
                                (int)response.StatusCode);
                        }

                        return new ServiceResult
                        {
                            Status = response.StatusCode,
                            Body = body,
                            ErrorMessage = errorMessage
                        };
                    }
                }
                catch (TaskCanceledException)
                {
                    System.Diagnostics.Trace.TraceWarning(
                        "[SLT Global Push] Request cancelled " +
                        "or timed out.");

                    throw;
                }
                catch (HttpRequestException ex)
                {
                    System.Diagnostics.Trace.TraceWarning(
                        "[SLT Global Push] HTTP error: " +
                        ex.GetType().Name);

                    throw;
                }
            }
        }

        // ========================================================
        // CONFIGURATION STATUS
        //
        // Does not expose API credentials.
        // ========================================================

        // Browser-facing operations use the authenticated SLT backend as a proxy.
        // The application API key is used ONLY to mint a guest-scoped token;
        // subscription requests use that token, not the application API key.
        public async Task<ServiceResult> BrowserOperationAsync(
            string action,
            JObject payload,
            string registrationToken,
            CancellationToken cancellationToken,
            string origin = null)
        {
            if (action != "config" && action != "subscriptions" &&
                action != "subscriptions/status" &&
                action != "subscriptions/unsubscribe")
                throw new ArgumentException("Unsupported push operation.", "action");

            if (action != "config" && string.IsNullOrWhiteSpace(registrationToken))
                throw new ArgumentException("Guest registration token required.", "registrationToken");

            var endpoint = BuildEndpoint(GetServiceUri(), action);
            var uri = new UriBuilder(endpoint);
            uri.Query = "applicationCode=" + Uri.EscapeDataString(ApplicationCode);

            using (var client = CreateClient())
            using (var request = new HttpRequestMessage(
                action == "config" ? HttpMethod.Get : HttpMethod.Post, uri.Uri))
            {
                request.Headers.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));

                // Global Push Allowed Origins must see the actual Partner
                // PWA origin, not the SLT API server origin.
                if (!string.IsNullOrWhiteSpace(origin))
                {
                    request.Headers.TryAddWithoutValidation(
                        "Origin",
                        origin);
                }

                if (action != "config")
                    request.Headers.Authorization =
                        new AuthenticationHeaderValue("Bearer", registrationToken);
                if (payload != null && action != "config")
                    request.Content = new StringContent(
                        payload.ToString(Formatting.None), Encoding.UTF8, "application/json");
                using (var response = await client.SendAsync(request, cancellationToken)
                    .ConfigureAwait(false))
                {
                    var raw = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                    JObject body;
                    try { body = JObject.Parse(raw); }
                    catch (JsonException) { body = new JObject(); }
                    return new ServiceResult {
                        Status = response.StatusCode,
                        Body = body,
                        ErrorMessage = response.IsSuccessStatusCode ? null :
                            "Global Push returned HTTP " + (int)response.StatusCode
                    };
                }
            }
        }

        public static object GetConfigurationStatus()
        {
            string baseUrl =
                Setting("SltPush.GlobalPushBaseUrl");

            string appCode =
                Setting("SltPush.ApplicationCode");

            string apiKey =
                Setting("SltPush.ApplicationApiKey");

            string guestPath =
                Setting("SltPush.GuestLaunchPath");

            return new
            {
                BaseUrlConfigured =
                    IsConfigured(baseUrl),

                ApplicationCodeConfigured =
                    IsConfigured(appCode),

                ApiKeyConfigured =
                    IsConfigured(apiKey),

                AllowedOriginsConfigured =
                    IsConfigured(
                        Setting("SltPush.AllowedOrigins") ??
                        Setting("CorsAllowedOrigins")),

                PartnerOriginConfigured =
                    IsConfigured(Setting("SltPush.PartnerOrigin")),

                GuestLaunchPathConfigured =
                    IsConfigured(guestPath) &&
                    IsSafeLocalPath(guestPath),

                ProxyEnabled = false,

                TimeoutSeconds = TimeoutSeconds
            };
        }
    }
}
