using SLTProject.Data;
using SLTProject.Filters;
using System;
using System.Data.Entity;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;

namespace SLTProject.Controllers
{
    // POST /api/SLTLimits/ClearAll
    // Clears only login throttle counters. It does not delete guests,
    // administrators, sessions, notifications or other audit records.
    [SltAdmin]
    [RoutePrefix("api/SLTLimits")]
    public sealed class SLTLimitsController : ApiController
    {
        [HttpPost]
        [Route("ClearAll")]
        public async Task<IHttpActionResult> ClearAll()
        {
            try
            {
                using (var db = new SLTEntities())
                {
                    var records = await db.SLTLoginRateLimits.ToListAsync();
                    int deletedCount = records.Count;

                    if (deletedCount > 0)
                    {
                        db.SLTLoginRateLimits.RemoveRange(records);
                        await db.SaveChangesAsync();
                    }

                    return Ok(new
                    {
                        Success = true,
                        DeletedRecords = deletedCount,
                        Message = "Login throttle records cleared successfully."
                    });
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError(
                    "SLT login throttle clear failed: " + ex);

                return Content(HttpStatusCode.InternalServerError, new
                {
                    Success = false,
                    Message = "Failed to clear login throttle records."
                });
            }
        }
    }
}
