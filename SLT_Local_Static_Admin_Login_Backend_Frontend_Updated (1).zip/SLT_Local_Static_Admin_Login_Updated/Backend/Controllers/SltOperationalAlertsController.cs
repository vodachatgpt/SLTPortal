using System;
using System.Configuration;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http;
using SLTProject.Filters;
using SLTProject.Services;

namespace SLTProject.Controllers
{
    // Uses the same Global Hangfire callback pattern as WeatherForecastController.
    // Configure/Remove are administrator-only; Global Hangfire calls ProcessDue.
    [RoutePrefix("api/operational-alerts")]
    public sealed class SltOperationalAlertsController : ApiController
    {
        private readonly SltOperationalAlertsSchedulerService _scheduler =
            new SltOperationalAlertsSchedulerService();

        [SltAdmin]
        [HttpPost]
        [Route("configure-scheduler")]
        public async Task<IHttpActionResult> ConfigureScheduler()
        {
            try
            {
                var result = await _scheduler.ScheduleAsync().ConfigureAwait(false);
                return Ok(new
                {
                    Status = "Scheduled",
                    JobKey = SltOperationalAlertsSchedulerService.JobKey,
                    Cron = SltOperationalAlertsSchedulerService.Cron,
                    Execution = "Global Hangfire HTTP callback",
                    Message = result
                });
            }
            catch (ConfigurationErrorsException ex)
            {
                return Content(HttpStatusCode.ServiceUnavailable, new
                {
                    Status = "ConfigurationError",
                    Message = ex.Message
                });
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError(
                    "Global Hangfire operational-alert registration failed: " + ex);
                return Content(HttpStatusCode.BadGateway, new
                {
                    Status = "Failed",
                    Message = "Could not register operational alerts with Global Hangfire. Check the server logs."
                });
            }
        }

        [SltAdmin]
        [HttpDelete]
        [Route("configure-scheduler")]
        public async Task<IHttpActionResult> RemoveScheduler()
        {
            try
            {
                string result = await _scheduler.RemoveAsync().ConfigureAwait(false);
                return Ok(new { Status = "Removed", Message = result });
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError(
                    "Global Hangfire operational-alert removal failed: " + ex);
                return Content(HttpStatusCode.BadGateway, new
                {
                    Status = "Failed",
                    Message = "Could not remove the operational-alert scheduler. Check the server logs."
                });
            }
        }

        [SltAdmin]
        [HttpGet]
        [Route("scheduler-status")]
        public IHttpActionResult SchedulerStatus()
        {
            return Ok(new
            {
                Scheduler = "GlobalHangfire",
                JobKey = SltOperationalAlertsSchedulerService.JobKey,
                Cron = SltOperationalAlertsSchedulerService.Cron,
                HangfireUrlConfigured =
                    !string.IsNullOrWhiteSpace(ConfigurationManager.AppSettings["HangfireApiUrl"]),
                ApiUrlConfigured =
                    !string.IsNullOrWhiteSpace(ConfigurationManager.AppSettings["ApiUrl"]),
                Note = "Configuration does not prove the external job is active; verify the job in the Global Hangfire dashboard."
            });
        }

        // Same model as WeatherForecastController.ProcessCleanup:
        // Global Hangfire posts to this callback every minute.
        // No SLTAlertsJobSecret or SLTAlertsAllowedSchedulerIps setting is required.
        [AllowAnonymous]
        [HttpPost]
        [Route("process-due")]
        public async Task<IHttpActionResult> ProcessDue()
        {
            try
            {
                object result = await new SltOperationalAlertsService()
                    .ProcessDueAsync(CancellationToken.None)
                    .ConfigureAwait(false);

                return Ok(new
                {
                    Status = "Success",
                    JobKey = SltOperationalAlertsSchedulerService.JobKey,
                    ExecutedAtUtc = DateTime.UtcNow,
                    Result = result
                });
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError(
                    "Operational alert callback failed: " + ex);
                return Content(HttpStatusCode.InternalServerError, new
                {
                    Status = "Failed",
                    Message = "Operational alert processing failed. See server logs."
                });
            }
        }
    }
}
