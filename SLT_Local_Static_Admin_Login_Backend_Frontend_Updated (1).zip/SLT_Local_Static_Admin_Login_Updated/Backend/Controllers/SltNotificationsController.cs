using System;
using System.Configuration;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http;
using SLTProject.Filters;
using SLTProject.Services;
using SltPushIntegration;
using Newtonsoft.Json.Linq;
using System.Net;
using System.Net.Http;

namespace SLTProject.Controllers
{
    [RoutePrefix("api/slt-notifications")]
    public sealed class SltNotificationsController : ApiController
    {
        private readonly SltNotificationsService service = new SltNotificationsService();

        private long IdentityId(string key)
        {
            object value;
            if (Request.Properties.TryGetValue(key, out value) && value != null)
            {
                long result;
                if (long.TryParse(Convert.ToString(value), out result) && result > 0) return result;
            }
            throw new UnauthorizedAccessException("Authenticated identity was not resolved.");
        }
        private string AdminEmail
        {
            get { object value; return Request.Properties.TryGetValue("SLTAdminEmail", out value) ? Convert.ToString(value) : null; }
        }

        // The browser Origin is not automatically forwarded by HttpClient.
        // Resolve and validate it before proxying requests to Global Push.
        private string ResolvePushOrigin()
        {
            string origin = null;
            System.Collections.Generic.IEnumerable<string> values;

            if (Request != null &&
                Request.Headers != null &&
                Request.Headers.TryGetValues("Origin", out values))
            {
                origin = values.FirstOrDefault();
            }

            if (string.IsNullOrWhiteSpace(origin))
                origin = ConfigurationManager.AppSettings["SltPush.PartnerOrigin"];

            string normalizedOrigin = NormalizeOrigin(origin);
            if (string.IsNullOrWhiteSpace(normalizedOrigin))
                throw new InvalidOperationException(
                    "Partner PWA origin is missing or invalid. Send an Origin header or configure SltPush.PartnerOrigin.");

            string allowedValue =
                ConfigurationManager.AppSettings["SltPush.AllowedOrigins"];

            if (string.IsNullOrWhiteSpace(allowedValue))
                allowedValue =
                    ConfigurationManager.AppSettings["CorsAllowedOrigins"];

            if (string.IsNullOrWhiteSpace(allowedValue))
                throw new InvalidOperationException(
                    "Configure SltPush.AllowedOrigins or CorsAllowedOrigins in Web.config.");

            var allowedOrigins = allowedValue
                .Split(new[] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(NormalizeOrigin)
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .ToList();

            if (!allowedOrigins.Contains(
                normalizedOrigin,
                StringComparer.OrdinalIgnoreCase))
            {
                throw new UnauthorizedAccessException(
                    "The Partner PWA origin is not included in the SLT push allowed-origin list.");
            }

            return normalizedOrigin;
        }

        private static string NormalizeOrigin(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return null;

            Uri uri;
            if (!Uri.TryCreate(value.Trim(), UriKind.Absolute, out uri))
                return null;

            if (!string.IsNullOrEmpty(uri.UserInfo) ||
                !string.IsNullOrEmpty(uri.Query) ||
                !string.IsNullOrEmpty(uri.Fragment))
                return null;

            if (uri.AbsolutePath != "/" &&
                !string.IsNullOrEmpty(uri.AbsolutePath))
                return null;

            bool secure =
                uri.Scheme.Equals(Uri.UriSchemeHttps, StringComparison.OrdinalIgnoreCase) ||
                (uri.IsLoopback &&
                 uri.Scheme.Equals(Uri.UriSchemeHttp, StringComparison.OrdinalIgnoreCase));

            if (!secure)
                return null;

            return uri.GetLeftPart(UriPartial.Authority).TrimEnd('/');
        }

        private static string ProviderMessage(JObject body)
        {
            if (body == null)
                return null;

            string[] fields =
            {
                "message",
                "Message",
                "error_description",
                "detail",
                "error"
            };

            foreach (string field in fields)
            {
                JToken token = body[field];
                if (token == null || token.Type == JTokenType.Null)
                    continue;

                string value = token.Type == JTokenType.String
                    ? token.Value<string>()
                    : token.ToString(Newtonsoft.Json.Formatting.None);

                if (!string.IsNullOrWhiteSpace(value))
                    return value.Length > 400 ? value.Substring(0, 400) : value;
            }

            return null;
        }

        private static bool HasVapidPublicKey(JObject body)
        {
            if (body == null) return false;

            var vapid = body["vapid"] as JObject;

            return !string.IsNullOrWhiteSpace((string)body["publicKey"]) ||
                   !string.IsNullOrWhiteSpace((string)body["vapidPublicKey"]) ||
                   !string.IsNullOrWhiteSpace((string)body["publicVapidKey"]) ||
                   (vapid != null &&
                    !string.IsNullOrWhiteSpace((string)vapid["publicKey"]));
        }

        // GET /api/slt-notifications/admin/guests?search=...
        [SltAdmin, HttpGet, Route("admin/guests")]
        public async Task<IHttpActionResult> Guests(string search = null)
        {
            return Ok(await service.GuestsForTargetAsync(search));
        }

        // POST /api/slt-notifications/admin/send
        [SltAdmin, HttpPost, Route("admin/send")]
        public async Task<IHttpActionResult> Send([FromBody] SltNotificationSendInput input, CancellationToken cancellationToken)
        {
            try { return Ok(await service.SendAsync(input, IdentityId("SLTAdminId"), AdminEmail, cancellationToken)); }
            catch (ArgumentException ex) { return BadRequest(ex.Message); }
            catch (UnauthorizedAccessException) { return Unauthorized(); }
        }

        // GET /api/slt-notifications/admin/sent?page=1&pageSize=20
        [SltAdmin, HttpGet, Route("admin/sent")]
        public async Task<IHttpActionResult> Sent(int page = 1, int pageSize = 20, bool unreadOnly = false)
        {
            try { return Ok(await service.AdminOutboxAsync(IdentityId("SLTAdminId"), page, pageSize, unreadOnly)); }
            catch (UnauthorizedAccessException) { return Unauthorized(); }
        }

        // POST /api/slt-notifications/admin/{id}/read
        [SltAdmin, HttpPost, Route("admin/{id:long}/read")]
        public async Task<IHttpActionResult> ReadAdmin(long id)
        {
            try { return await service.MarkAdminReadAsync(IdentityId("SLTAdminId"), id) ? (IHttpActionResult)Ok(new { IsRead = true }) : NotFound(); }
            catch (UnauthorizedAccessException) { return Unauthorized(); }
        }

        // GET /api/slt-notifications/guest/inbox
        [SltGuest, HttpGet, Route("guest/inbox")]
        public async Task<IHttpActionResult> Inbox(int page = 1, int pageSize = 20, bool unreadOnly = false)
        {
            try { return Ok(await service.GuestInboxAsync(IdentityId("SLTGuestId"), page, pageSize, unreadOnly)); }
            catch (UnauthorizedAccessException) { return Unauthorized(); }
        }

        // POST /api/slt-notifications/guest/{id}/read
        [SltGuest, HttpPost, Route("guest/{id:long}/read")]
        public async Task<IHttpActionResult> ReadGuest(long id)
        {
            try { return await service.MarkGuestReadAsync(IdentityId("SLTGuestId"), id) ? (IHttpActionResult)Ok(new { IsRead = true }) : NotFound(); }
            catch (UnauthorizedAccessException) { return Unauthorized(); }
        }

        // SLT-origin subscription proxy avoids direct browser calls to Global Push.
        // The authenticated SLT token determines the guest; the validated browser
        // Origin is forwarded to Global Push so its Allowed Origins policy can work.
        [SltGuest, HttpGet, Route("guest/push/config")]
        public Task<IHttpActionResult> PushConfig(CancellationToken cancellationToken)
        {
            return ProxyPush("config", null, cancellationToken);
        }

        [SltGuest, HttpPost, Route("guest/push/subscriptions")]
        public Task<IHttpActionResult> PushSubscribe(
            [FromBody] JObject input, CancellationToken cancellationToken)
        {
            return ProxyPush("subscriptions", input, cancellationToken);
        }

        [SltGuest, HttpPost, Route("guest/push/subscriptions/status")]
        public Task<IHttpActionResult> PushSubscriptionStatus(
            [FromBody] JObject input, CancellationToken cancellationToken)
        {
            return ProxyPush("subscriptions/status", input, cancellationToken);
        }

        [SltGuest, HttpPost, Route("guest/push/subscriptions/unsubscribe")]
        public Task<IHttpActionResult> PushUnsubscribe(
            [FromBody] JObject input, CancellationToken cancellationToken)
        {
            return ProxyPush("subscriptions/unsubscribe", input, cancellationToken);
        }

        // Diagnostic endpoint: verifies the guest identity, configured origin,
        // Global Push config endpoint and guest-scoped registration-token endpoint.
        // It never returns the application API key or the registration token.
        [SltGuest, HttpGet, Route("guest/push/diagnostics")]
        public async Task<IHttpActionResult> PushDiagnostics(
            CancellationToken cancellationToken)
        {
            long guestId;
            try
            {
                guestId = IdentityId("SLTGuestId");
            }
            catch (UnauthorizedAccessException)
            {
                return Unauthorized();
            }

            if (guestId > int.MaxValue)
                return BadRequest("Guest ID exceeds Global Push mapping limits.");

            string origin;
            try
            {
                origin = ResolvePushOrigin();
            }
            catch (UnauthorizedAccessException ex)
            {
                return Content(HttpStatusCode.Forbidden, new { Message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return Content(HttpStatusCode.ServiceUnavailable, new { Message = ex.Message });
            }

            try
            {
                var gateway = new GlobalPushV103Gateway();

                var configResult = await gateway.BrowserOperationAsync(
                    "config", null, null, cancellationToken, origin);

                var tokenResult = await gateway.SendAsync(
                    HttpMethod.Post,
                    "registration-token",
                    new JObject
                    {
                        ["userReference"] =
                            GlobalPushV103Gateway.GuestUserReference((int)guestId)
                    },
                    cancellationToken,
                    origin);

                string providerMessage =
                    ProviderMessage(configResult.Body) ??
                    ProviderMessage(tokenResult.Body);

                return Ok(new
                {
                    GuestId = guestId,
                    UserReference = GlobalPushV103Gateway.GuestUserReference((int)guestId),
                    Origin = origin,
                    OriginAllowed = true,
                    GlobalPushConfigHttpStatus = (int)configResult.Status,
                    GlobalPushConfigSucceeded = configResult.IsSuccess,
                    VapidPublicKeyReturned = HasVapidPublicKey(configResult.Body),
                    RegistrationTokenHttpStatus = (int)tokenResult.Status,
                    RegistrationTokenIssued = tokenResult.IsSuccess &&
                        !string.IsNullOrWhiteSpace((string)tokenResult.Body["token"]),
                    ProviderMessage = providerMessage
                });
            }
            catch (Exception ex) when (
                ex is HttpRequestException ||
                ex is TaskCanceledException ||
                ex is InvalidOperationException ||
                ex is ArgumentException ||
                ex is UriFormatException)
            {
                System.Diagnostics.Trace.TraceWarning(
                    "SLT push diagnostics failed: " + ex.GetType().Name);

                return Content(HttpStatusCode.ServiceUnavailable, new
                {
                    Message = "The SLT backend could not complete the Global Push diagnostics request.",
                    ErrorType = ex.GetType().Name
                });
            }
        }

        private async Task<IHttpActionResult> ProxyPush(
            string action, JObject input, CancellationToken cancellationToken)
        {
            long guestId;
            try
            {
                guestId = IdentityId("SLTGuestId");
            }
            catch (UnauthorizedAccessException)
            {
                return Unauthorized();
            }

            if (guestId > int.MaxValue)
                return BadRequest("Guest ID exceeds Global Push mapping limits.");

            if (action != "config" && input == null)
                return BadRequest("Subscription data is required.");

            if (input != null && input.ToString().Length > 16384)
                return BadRequest("Subscription data is too large.");

            string origin;
            try
            {
                origin = ResolvePushOrigin();
            }
            catch (UnauthorizedAccessException ex)
            {
                return Content(HttpStatusCode.Forbidden, new { Message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return Content(HttpStatusCode.ServiceUnavailable, new { Message = ex.Message });
            }

            try
            {
                var gateway = new GlobalPushV103Gateway();
                string registrationToken = null;

                if (action != "config")
                {
                    var issued = await gateway.SendAsync(
                        HttpMethod.Post,
                        "registration-token",
                        new JObject
                        {
                            ["userReference"] =
                                GlobalPushV103Gateway.GuestUserReference((int)guestId)
                        },
                        cancellationToken,
                        origin);

                    if (!issued.IsSuccess)
                    {
                        return Content(HttpStatusCode.BadGateway, new
                        {
                            Message = "Global Push could not issue a guest registration token.",
                            ProviderStatus = (int)issued.Status,
                            ProviderMessage = ProviderMessage(issued.Body)
                        });
                    }

                    registrationToken = (string)issued.Body["token"];

                    if (string.IsNullOrWhiteSpace(registrationToken))
                    {
                        return Content(HttpStatusCode.BadGateway, new
                        {
                            Message = "Global Push registration-token response did not contain a token.",
                            ProviderStatus = (int)issued.Status,
                            ProviderMessage = ProviderMessage(issued.Body)
                        });
                    }
                }

                var result = await gateway.BrowserOperationAsync(
                    action,
                    input,
                    registrationToken,
                    cancellationToken,
                    origin);

                if (!result.IsSuccess)
                {
                    return Content(HttpStatusCode.BadGateway, new
                    {
                        Message = "Global Push browser registration request failed.",
                        ProviderStatus = (int)result.Status,
                        ProviderMessage = ProviderMessage(result.Body),
                        Operation = action,
                        Origin = origin
                    });
                }

                // Keep the provider response, but guarantee a consistent success
                // flag for the Partner SDK when the provider returns an empty 2xx.
                JObject responseBody = result.Body ?? new JObject();
                if (action == "subscriptions" &&
                    responseBody["subscribed"] == null)
                {
                    responseBody["subscribed"] = true;
                }

                return Ok(responseBody);
            }
            catch (Exception ex) when (
                ex is HttpRequestException ||
                ex is TaskCanceledException ||
                ex is InvalidOperationException ||
                ex is ArgumentException ||
                ex is UriFormatException)
            {
                System.Diagnostics.Trace.TraceWarning(
                    "SLT push proxy " + action + " failed: " +
                    ex.GetType().Name);

                return Content(HttpStatusCode.ServiceUnavailable, new
                {
                    Message = "Global Push is currently unavailable.",
                    Operation = action,
                    ErrorType = ex.GetType().Name
                });
            }
        }

        // Compatibility endpoint for SDK configurations that obtain a short-lived
        // registration token directly. The token remains guest-scoped and is never
        // persisted by SLTProject.
        [SltGuest, HttpPost, Route("guest/registration-token")]
        public async Task<IHttpActionResult> RegistrationToken(CancellationToken cancellationToken)
        {
            long guestId;
            try
            {
                guestId = IdentityId("SLTGuestId");
            }
            catch (UnauthorizedAccessException)
            {
                return Unauthorized();
            }

            if (guestId > int.MaxValue)
                return BadRequest("Guest ID exceeds Global Push mapping limits.");

            string origin;
            try
            {
                origin = ResolvePushOrigin();
            }
            catch (UnauthorizedAccessException ex)
            {
                return Content(HttpStatusCode.Forbidden, new { Message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return Content(HttpStatusCode.ServiceUnavailable, new { Message = ex.Message });
            }

            try
            {
                var gateway = new GlobalPushV103Gateway();
                var response = await gateway.SendAsync(
                    HttpMethod.Post,
                    "registration-token",
                    new JObject
                    {
                        ["userReference"] =
                            GlobalPushV103Gateway.GuestUserReference((int)guestId)
                    },
                    cancellationToken,
                    origin);

                if (!response.IsSuccess)
                {
                    return Content(HttpStatusCode.BadGateway, new
                    {
                        Message = "Global Push registration service is unavailable.",
                        ProviderStatus = (int)response.Status,
                        ProviderMessage = ProviderMessage(response.Body)
                    });
                }

                var token = (string)response.Body["token"];
                if (string.IsNullOrWhiteSpace(token))
                {
                    return Content(HttpStatusCode.BadGateway, new
                    {
                        Message = "Global Push registration response did not contain a token.",
                        ProviderStatus = (int)response.Status,
                        ProviderMessage = ProviderMessage(response.Body)
                    });
                }

                return Ok(new { token = token, expiresInSeconds = 600 });
            }
            catch (Exception ex) when (
                ex is HttpRequestException ||
                ex is TaskCanceledException ||
                ex is InvalidOperationException ||
                ex is UriFormatException ||
                ex is ArgumentException)
            {
                System.Diagnostics.Trace.TraceWarning(
                    "SLT push registration failed: " + ex.GetType().Name);

                return Content(HttpStatusCode.ServiceUnavailable, new
                {
                    Message = "Push registration is not currently available.",
                    ErrorType = ex.GetType().Name
                });
            }
        }
    }
}
