# SLT — Local Static Admin Login + Active Directory + 24-hour JWT

This package includes the latest backend Controllers and Services folders, the full admin-tab-free frontend, the JWT admin authentication implementation, and the latest Day Schedules / Custom Responses fixes.

## What was added

- A local-only static NT account + password for development login when Active Directory is unreachable.
- The static account is accepted only when the backend request is both `HttpRequest.IsLocal` and `Request.Url.IsLoopback`.
- Static login is still gated by the configured `Auth_APIKeyName` / `Auth_ClientId` header.
- The static login maps to an existing active `dbo.Admins` row using `SLTAdminStaticTestAdminId`; the JWT receives the same claims as an AD login.
- No static credentials are sent to, embedded in, or prefilled by frontend JavaScript. The admin enters them in the existing NT Account and Network Password fields.
- The login page shows a local-test notice only when opened on `localhost`, `127.0.0.1` or `::1`.
- Normal non-local login continues to validate credentials against Active Directory and resolve the user's AD email.
- JWT lifetime remains 24 hours (1,440 minutes).
- The Administrators frontend tab remains removed.
- The previous Day Schedules icon/date and Custom Responses soft-delete fixes are included.

## Local test credentials

The included Web.config fragment uses these sample values:

- NT Account: `SLTLOCAL\admin`
- Password: `SltLocalTest#2026!`
- Static test enabled: `true`
- Admin ID: `1` (change this to an existing active row in your local database)

These are synthetic application credentials; they are not an actual Windows/Active Directory account. They bypass AD only for local loopback API requests. They still require the database and an active `dbo.Admins` row so the token has a valid AdminId and email.

Find a suitable Admin ID:

```sql
SELECT Id, FullName, Email, IsActive, IsDeleted
FROM dbo.Admins
WHERE IsActive = 1 AND IsDeleted = 0
ORDER BY Id;
```

Set `SLTAdminStaticTestAdminId` to the selected row's Id. Do not add a new admin row unless your existing provisioning process requires it.

## Backend files

The `Backend/Controllers` and `Backend/Services` folders are complete replacements based on the latest uploaded `Controllers(9).zip` and `Services(10).zip`, with the obsolete admin passcode controller/service removed. They also include the prior fixes for:

- `DaySchedulesService.cs`
- `ScheduleTransportExcel.cs`
- `CustomizedResponsesService.cs`
- `CustomizedGuestResponsesService.cs`
- `CustomizedResponsesController.cs`

Authentication files:

- `Backend/Controllers/AuthController.cs`
- `Backend/Services/ISharepointAuthService.cs`
- `Backend/Services/SharepointAuthService.cs`
- `Backend/Models/ShareAuthModel.cs`
- `Backend/Filters/SltAdminAttribute.cs`
- `Backend/Filters/SltAdminJwtAuthorization.cs`
- `Backend/Filters/SltAdminOrGuestAttribute.cs`

Obsolete files intentionally omitted:

- `Controllers/AdminsController.cs` and `Controllers/AdminsController .cs`
- `Services/AdminService.cs`
- `Services/AdminLocalRecovery.cs`

The `dbo.Admins` table remains an active-admin allow-list. Admin passcodes are not used. Guest passcode authentication remains unchanged.

## Frontend

The complete `Frontend` folder is included. It retains the current SLT frontend and PWA, removes the Administrators navigation/page, and updates:

- `admin-login.html`
- `assets/admin-login.js`
- `assets/config.js` (set your API key)
- `service-worker.js` (cache version bumped)

The login form uses the same NT Account and Network Password fields for both normal AD login and the local static test login. It does not send a `UseStaticTest` flag; the backend determines whether the request is local.

## Web.config

Merge `Deployment/WEB_CONFIG_LOCAL_STATIC_ADMIN_JWT.xml` into your existing `<appSettings>` section. Do not create duplicate keys or replace the entire Web.config.

Change at minimum:

- `Auth_ClientId`: use your own random value and copy the same value to `Frontend/assets/config.js` as `AUTH_CLIENT_ID`.
- `JwtSecretKey`: use at least 32 random UTF-8 bytes; keep it private.
- `SLTAdminStaticTestAdminId`: set to a real active local `dbo.Admins.Id`.
- `LDAP_Path`: set your AD DNS domain or reachable LDAP server for normal AD authentication.

The local static account is enabled in this development fragment. Before publishing to staging/production, set:

```xml
<add key="SLTAdminStaticTestEnabled" value="false" />
```

Also remove the static test password from the deployed Web.config. Never enable the local static account for a publicly reachable environment. The loopback check is an additional guard, not a replacement for disabling the feature outside local development.

## Frontend API key

In `Frontend/assets/config.js`:

```javascript
AUTH_API_KEY_NAME: "X-SLT-API-Key",
AUTH_CLIENT_ID: "SAME_VALUE_AS_WEB_CONFIG_AUTH_CLIENT_ID"
```

This key is visible in browser code and is not a confidential secret. The actual user authentication is the local test gate or AD credentials plus the signed JWT.

## Test locally

1. Run the backend locally using a loopback URL, e.g. `https://localhost:44384`.
2. Serve/open the frontend from localhost (or use the frontend's configured local host).
3. Merge the Web.config fragment and set `SLTAdminStaticTestAdminId` to an active local Admin row.
4. Set the matching API key in `Frontend/assets/config.js`.
5. Open `admin-login.html`.
6. Enter `SLTLOCAL\admin` and `SltLocalTest#2026!` (or your configured values).
7. Submit. The backend verifies the API key, verifies that the request is local, checks the configured static credentials, loads the active Admin row, and issues the usual 24-hour JWT.
8. Call `/api/admin-auth/me`; it should return the mapped AdminId, email and full name.
9. Call an existing `[SltAdmin]` endpoint to verify authorization.

If the frontend is opened from a hostname other than localhost/127.0.0.1/::1, the login page won't show the local-test hint. The backend still enforces its own loopback test and will reject the static account on a non-local request.

## Normal Active Directory login

For a non-static username, the same login form continues to use Active Directory. The backend must be able to reach a Domain Controller and the resolved AD email must match an active `dbo.Admins.Email` row.

## Build/project references

- Add the new auth `.cs` files to the `.csproj` if it uses explicit Compile entries.
- Remove the old AdminsController/AdminService/AdminLocalRecovery Compile entries.
- Ensure references/packages exist: `System.DirectoryServices.AccountManagement`, `System.IdentityModel.Tokens.Jwt`, `Microsoft.IdentityModel.Tokens`, and Entity Framework 6.
- Preserve your existing EDMX/Data folder; this package does not replace DB-first entities.

## Security notes

- Do not commit real API/JWT secrets or static test credentials.
- The sample static password is for local development only. Change it locally and disable the feature outside localhost development.
- The JWT is signed, not encrypted; do not place passwords or secrets in its claims.
- The static test login is still subject to current Admin allow-list checks on every protected request.
