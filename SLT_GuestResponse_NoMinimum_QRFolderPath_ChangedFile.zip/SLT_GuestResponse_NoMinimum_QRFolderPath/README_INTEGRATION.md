# SLT Guest Response – No Minimum Days/Events + QR Folder Path

## Changed file only

`Backend/Services/CustomizedGuestResponsesService.cs`

Replace the existing file with the included complete source file.

## Changes

1. The existing flat response shape is preserved:
   - `Day1Event1DriverName`
   - `Day1Event1DriverNumber`
   - and so on.
2. No minimum days are generated. The response creates DayN fields only for distinct active dates present in `dbo.DaySchedules`.
3. No minimum events are generated. Each day creates EventN fields only for active schedules on that date.
4. The chronological ordering remains:
   - Date ascending
   - StartTime ascending
   - Id ascending
5. `QRPath` is added. It contains the configured QR folder path and the matched image filename.
6. Folder lookup reuses `GuestsService.FolderQrFileName(email)`, matching:
   - `<normalized-email>.png`
   - `<normalized-email>.jpg`
   - `<normalized-email>.jpeg`
   - `<normalized-email>.webp`
7. `QRUrl` is retained for backward compatibility and continues to point to the existing `/{guestId}/qr` endpoint.
8. `HasQR` is true when either a folder QR or the existing database QR image exists.

## Web.config

Ensure this setting exists inside the existing `<appSettings>`:

```xml
<add key="SLTGuestQrFolder" value="~/App_Data/GuestQRCodes" />
```

If you use a different configured folder, `QRPath` will use that configured path. The IIS application-pool identity needs read permission to the folder and image files.

## Example response

```json
{
  "HasQR": true,
  "QRFileName": "guest@example.com.png",
  "QRPath": "~/App_Data/GuestQRCodes/guest@example.com.png",
  "QRUrl": "https://your-host/api/guests/25/qr",
  "Day1Event1DriverName": "Ahmed",
  "Day1Event1DriverNumber": "01000000000"
}
```

`QRPath` is a server-side configured folder path, not a public browser URL. Use `QRUrl` when a client needs to retrieve the image over HTTP. Do not expose a physical server path in a public response; keep the folder configured as a virtual application-relative path such as `~/App_Data/GuestQRCodes`.

## Validation note

The source is checked for the absence of `Math.Max(4, ...)` and `Math.Max(10, ...)`, and the ZIP archive is checked for integrity. A full .NET Framework build and database test must still be performed in the SLT solution.
