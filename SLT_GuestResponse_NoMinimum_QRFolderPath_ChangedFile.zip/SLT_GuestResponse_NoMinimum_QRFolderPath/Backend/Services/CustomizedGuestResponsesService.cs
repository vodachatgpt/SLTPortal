
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using SLTProject.Data;

namespace SLTProject.Services
{
    public class CustomizedGuestResponsesService
    {
        // ============================================================
        // EMAIL NORMALIZATION
        // ============================================================

        private static string NormalizeEmail(string email)
        {
            return (email ?? "")
                .Trim()
                .ToLowerInvariant();
        }

        // ============================================================
        // FULL NAME SPLITTING
        // ============================================================

        private static string GetFirstName(string fullName)
        {
            if (string.IsNullOrWhiteSpace(fullName))
                return null;

            string[] parts = fullName.Trim()
                .Split(
                    new[] { ' ' },
                    StringSplitOptions.RemoveEmptyEntries);

            return parts.Length > 0
                ? parts[0]
                : null;
        }

        private static string GetLastName(string fullName)
        {
            if (string.IsNullOrWhiteSpace(fullName))
                return null;

            string[] parts = fullName.Trim()
                .Split(
                    new[] { ' ' },
                    StringSplitOptions.RemoveEmptyEntries);

            if (parts.Length <= 1)
                return null;

            return string.Join(" ", parts.Skip(1));
        }

        // ============================================================
        // DATE FORMATTING
        //
        // Day / Month / Year
        //
        // Examples:
        // 05/11/2026
        // 05/11/2026 14:27
        //
        // These functions format output only.
        // They do not change stored SQL timestamps.
        // ============================================================

        private static string FormatDate(DateTime? value)
        {
            if (!value.HasValue)
                return null;

            return EgyptDateTimeService.FormatDate(value.Value);
        }

        private static string FormatDateTime(DateTime? value)
        {
            if (!value.HasValue)
                return null;

            return EgyptDateTimeService.FormatDateTime(value.Value);
        }

        // ============================================================
        // DATE + TIME COMBINATION
        // ============================================================

        private static DateTime? CombineDateTime(
            DateTime? date,
            TimeSpan? time)
        {
            if (!date.HasValue)
                return null;

            // Preserve the date when the time is missing.
            // Use midnight as the default time.
            return date.Value.Date.Add(
                time ?? TimeSpan.Zero);
        }

        // ============================================================
        // QR FOLDER PATH
        //
        // Uses the same email-based file matching as GuestsService:
        // <normalized-email>.png/.jpg/.jpeg/.webp
        //
        // Returns the configured folder path + filename, not image bytes.
        // QRUrl remains available for existing API consumers.
        // ============================================================

        private static string GetFolderQrPath(string email)
        {
            string fileName =
                GuestsService.FolderQrFileName(email);

            if (string.IsNullOrWhiteSpace(fileName))
                return null;

            string folder =
                ConfigurationManager.AppSettings["SLTGuestQrFolder"];

            if (string.IsNullOrWhiteSpace(folder))
                folder = "~/App_Data/GuestQRCodes";

            folder = folder.Trim().TrimEnd('/', '\\');

            return folder.Replace('\\', '/') + "/" + fileName;
        }

        // ============================================================
        // GET GUESTS WITH ALL DRIVER ASSIGNMENTS
        // ============================================================

        public async Task<List<Dictionary<string, object>>>
            GetGuestsAsync(
                string guestEmail,
                string qrUrlPrefix)
        {
            string email = NormalizeEmail(guestEmail);

            using (var db = new SLTEntities())
            {
                // ====================================================
                // 1. LOAD ACTIVE GUESTS
                // ====================================================

                var guestQuery = db.Guests
                    .AsNoTracking()
                    .Where(x => !x.IsDeleted);

                if (!string.IsNullOrWhiteSpace(email))
                {
                    guestQuery = guestQuery.Where(
                        x => x.Email == email);
                }

                // Select required fields only.
                // Do not load QR image binary data.

                var guests = await guestQuery
                    .OrderBy(x => x.FullName)
                    .ThenBy(x => x.Id)
                    .Select(x => new
                    {
                        x.Id,
                        x.FullName,
                        x.Email,

                        // Actual phone number from Guests.
                        x.PhoneNumber,

                        // First successful guest login.
                        x.FirstLoginAt,

                        // Hotel check-in/check-out.
                        x.CheckInDate,
                        x.CheckInTime,
                        x.CheckOutDate,
                        x.CheckOutTime,

                        // Tour registration status.
                        x.TourRegister,

                        // QR image availability in database.
                        HasQR = x.QRCodeImage != null,
                        x.QRFileName
                    })
                    .ToListAsync();

                if (guests.Count == 0)
                {
                    return new List<
                        Dictionary<string, object>>();
                }

                // ====================================================
                // 2. LOAD ACTIVE DAY SCHEDULES
                // ====================================================

                var schedules = await db.DaySchedules
                    .AsNoTracking()
                    .Where(x => !x.IsDeleted)
                    .OrderBy(x => x.Date)
                    .ThenBy(x => x.StartTime)
                    .ThenBy(x => x.Id)
                    .Select(x => new
                    {
                        x.Id,
                        x.Date,
                        x.StartTime
                    })
                    .ToListAsync();

                // ====================================================
                // 3. GROUP SCHEDULES BY DAY
                // ====================================================

                var days = schedules
                    .GroupBy(x => x.Date.Date)
                    .OrderBy(x => x.Key)
                    .Select(x => x.ToList())
                    .ToList();

                // ====================================================
                // 4. LOAD ACTIVE AIRPORT TRANSFERS
                // ====================================================

                var airportQuery = db.AirportTransfers
                    .AsNoTracking()
                    .Where(x => !x.IsDeleted);

                if (!string.IsNullOrWhiteSpace(email))
                {
                    airportQuery = airportQuery.Where(
                        x => x.Email == email);
                }

                var airportTransfers = await airportQuery
                    .ToListAsync();

                // ====================================================
                // 5. LOAD ACTIVE EVENT DRIVERS
                // ====================================================

                var eventDriversQuery = db.GuestEventDrivers
                    .AsNoTracking()
                    .Where(x => !x.IsDeleted &&
                        db.DaySchedules.Any(schedule =>
                            schedule.Id == x.DayScheduleId && !schedule.IsDeleted));

                if (!string.IsNullOrWhiteSpace(email))
                {
                    eventDriversQuery = eventDriversQuery.Where(
                        x => x.Email == email);
                }

                var eventDrivers = await eventDriversQuery
                    .ToListAsync();

                // ====================================================
                // 6. AIRPORT TRANSFER LOOKUP
                // ====================================================

                var airportLookup = airportTransfers
                    .GroupBy(x =>
                        NormalizeEmail(x.Email) + "|" +
                        (x.Type ?? "")
                            .Trim()
                            .ToLowerInvariant())
                    .ToDictionary(
                        x => x.Key,
                        x => x.OrderBy(y => y.Id).First());

                // ====================================================
                // 7. EVENT DRIVER LOOKUP
                // ====================================================

                var eventDriverLookup = eventDrivers
                    .GroupBy(x =>
                        NormalizeEmail(x.Email) + "|" +
                        x.DayScheduleId.ToString(
                            CultureInfo.InvariantCulture))
                    .ToDictionary(
                        x => x.Key,
                        x => x.OrderBy(y => y.Id).First());

                // ====================================================
                // 8. BUILD CUSTOMIZED RESPONSE
                // ====================================================

                var results =
                    new List<Dictionary<string, object>>();

                foreach (var guest in guests)
                {
                    string guestKey =
                        NormalizeEmail(guest.Email);

                    var row =
                        new Dictionary<string, object>();

                    // ================================================
                    // PERSONAL INFORMATION
                    // ================================================

                    row["FirstName"] =
                        GetFirstName(guest.FullName);

                    row["LastName"] =
                        GetLastName(guest.FullName);

                    row["FullName"] =
                        guest.FullName;

                    // FIX 1:
                    // Read PhoneNumber from Guests.
                    // Keep MobileNumber for frontend compatibility.

                    row["MobileNumber"] =
                        guest.PhoneNumber;

                    row["Email"] =
                        guest.Email;

                    // FIX 2:
                    // FirstLogin formatted Day/Month/Year.

                    row["FirstLogin"] =
                        FormatDateTime(
                            guest.FirstLoginAt);

                    // FIX 3:
                    // Check-in formatted Day/Month/Year.

                    row["CheckInDateTime"] =
                        FormatDateTime(
                            CombineDateTime(
                                guest.CheckInDate,
                                guest.CheckInTime));

                    // FIX 4:
                    // Check-out formatted Day/Month/Year.

                    row["CheckOutDateTime"] =
                        FormatDateTime(
                            CombineDateTime(
                                guest.CheckOutDate,
                                guest.CheckOutTime));

                    // FIX 5:
                    // Actual tour registration status.
                    // Returns true or false instead of null.

                    row["TourRegisteration"] =
                        guest.TourRegister;

                    // ================================================
                    // QR IMAGE
                    // ================================================

                    string folderQrPath =
                        GetFolderQrPath(guest.Email);

                    bool hasQr =
                        guest.HasQR ||
                        !string.IsNullOrWhiteSpace(folderQrPath);

                    // QRPath is the configured folder path + image filename.
                    // Example: ~/App_Data/GuestQRCodes/person@company.com.png
                    row["QRPath"] = folderQrPath;

                    // Preserve the existing database filename as a fallback.
                    row["QRFileName"] =
                        !string.IsNullOrWhiteSpace(folderQrPath)
                            ? Path.GetFileName(folderQrPath)
                            : guest.QRFileName;

                    row["HasQR"] = hasQr;

                    // Keep the existing image endpoint for compatibility.
                    row["QRUrl"] =
                        hasQr &&
                        !string.IsNullOrWhiteSpace(qrUrlPrefix)
                            ? qrUrlPrefix + guest.Id + "/qr"
                            : null;

                    // ================================================
                    // AIRPORT PICKUP
                    // ================================================

                    AirportTransfer pickup = null;

                    airportLookup.TryGetValue(
                        guestKey + "|pickup",
                        out pickup);

                    row["AirportPickupDriverName"] =
                        pickup == null
                            ? null
                            : pickup.DriverName;

                    row["AirportPickupDriverNumber"] =
                        pickup == null
                            ? null
                            : pickup.DriverPhone;

                    // ================================================
                    // AIRPORT DROP-OFF
                    // ================================================

                    AirportTransfer dropOff = null;

                    airportLookup.TryGetValue(
                        guestKey + "|drop-off",
                        out dropOff);

                    row["AirportDropOffDriverName"] =
                        dropOff == null
                            ? null
                            : dropOff.DriverName;

                    row["AirportDropOffDriverNumber"] =
                        dropOff == null
                            ? null
                            : dropOff.DriverPhone;

                    // ================================================
                    // DAILY EVENT DRIVERS
                    //
                    // Maintain the original API structure:
                    //
                    // Day1Event1DriverName
                    // Day1Event1DriverNumber
                    // ...
                    //
                    // Return only actual scheduled days and events.
                    // No minimum placeholders are generated.
                    // ================================================

                    int totalDays = days.Count;

                    for (int dayIndex = 0;
                         dayIndex < totalDays;
                         dayIndex++)
                    {
                        int totalEvents =
                            days[dayIndex].Count;

                        for (int eventIndex = 0;
                             eventIndex < totalEvents;
                             eventIndex++)
                        {
                            string prefix =
                                "Day" + (dayIndex + 1) +
                                "Event" + (eventIndex + 1);

                            string driverNameKey =
                                prefix + "DriverName";

                            string driverNumberKey =
                                prefix + "DriverNumber";

                            // Default to null when no assigned
                            // driver exists for the event.

                            row[driverNameKey] = null;

                            row[driverNumberKey] = null;

                            var schedule =
                                days[dayIndex][eventIndex];

                            string lookupKey =
                                guestKey + "|" +
                                schedule.Id.ToString(
                                    CultureInfo.InvariantCulture);

                            GuestEventDriver driver = null;

                            if (!eventDriverLookup.TryGetValue(
                                lookupKey,
                                out driver))
                            {
                                continue;
                            }

                            row[driverNameKey] =
                                driver.DriverName;

                            row[driverNumberKey] =
                                driver.DriverPhone;
                        }
                    }

                    results.Add(row);
                }

                return results;
            }
        }
    }
}
