# SLT Admin Portal — HTML/CSS/JavaScript PWA

Static frontend for the existing .NET Framework 4.7 / Web API 2 SLT backend. This package keeps the original frontend CRUD logic and adds the new admin home, redesigned navigation, mobile layout, installable PWA, email template management and weather list.

## Setup
1. Host `Frontend` in IIS (or serve with a local HTTP server; do not open as file://).
2. Edit `assets/config.js`: set `API_BASE` to the actual backend origin + `/api`.
3. If frontend and backend are on different origins, configure **restricted CORS** on the backend to allow only the frontend origin, Authorization and Content-Type headers, and the required HTTP methods.
4. Open `admin-login.html`, login using an admin account, then the page redirects to `dashboard.html`.
5. Deploy under HTTPS for installable PWA functionality; for development, http://localhost works.

## Pages
Dashboard (events carousel and live counts); guests (passcodes/QR/Excel/tour registration); phases; day schedules; airport transfers; guest event drivers; blur icons; help/support; email templates; admins; weather forecasts (create, update, delete with the backend daily-array input format). The guest login page remains in the package.

## Security
Service worker only caches static shell and assets. It does not cache API traffic. Existing admin bearer token remains in browser localStorage as in your frontend; review XSS/CSRF and token handling prior to production. No credentials are hard-coded.

## Note
Some APIs require the live backend (including `SLTEntities.edmx` and SQL Server) and cannot be tested in this environment. No Angular/Node dependencies are needed. SweetAlert2 CDN is optional because the existing dashboard.js provides an offline fallback.
