(async function () {
    "use strict";
    const $ = id => document.getElementById(id);
    if (!await sltRequireAdmin()) return;

    let phases = [];
    let editingId = null;
    const dateOnly = value => value ? String(value).slice(0, 10) : "";
    const preview = value => {
        const v = String(value || "").trim();
        return sltEscape(v.length > 120 ? v.slice(0, 120) + "…" : (v || "—"));
    };

    function resetForm() {
        editingId = null;
        $("phaseForm").reset();
        $("formTitle").textContent = "Create Phase";
    }

    async function load() {
        try {
            const response = await sltRequest("/phases");
            phases = Array.isArray(response) ? response : (response.Records || response.Result || []);
            $("phaseRows").innerHTML = phases.length
                ? phases.map(p => `<tr>
                    <td>${sltEscape(p.Title)}</td>
                    <td>${sltEscape(dateOnly(p.Date))}</td>
                    <td class="slt-phase-message">${preview(p.EventWelcomeMessage)}</td>
                    <td class="slt-phase-message">${preview(p.EventSloganMessage)}</td>
                    <td>${sltEscape(p.CreatedBy)}</td>
                    <td>${sltEscape(p.ModifiedBy)}</td>
                    <td><div class="slt-row-actions">
                        <button type="button" data-id="${p.Id}" data-action="edit">Edit</button>
                        <button type="button" data-id="${p.Id}" data-action="delete">Delete</button>
                    </div></td>
                </tr>`).join("")
                : '<tr><td colspan="7" class="slt-empty-state">No phases yet.</td></tr>';
        } catch (error) {
            sltNotify(error.message, "error");
        }
    }

    $("openPhaseModal").onclick = () => {
        resetForm();
        sltOpenModal("phaseModal");
    };
    $("clear").onclick = () => {
        resetForm();
        sltCloseModal("phaseModal");
    };

    $("phaseForm").onsubmit = async event => {
        event.preventDefault();
        const input = {
            Title: $("phaseTitle").value.trim(),
            Date: $("phaseDate").value,
            EventWelcomeMessage: $("eventWelcomeMessage").value.trim() || null,
            EventSloganMessage: $("eventSloganMessage").value.trim() || null
        };
        if (!input.Title || !input.Date) {
            sltNotify("Title and date are required.", "error");
            return;
        }
        const button = event.submitter || $("phaseForm").querySelector('[type="submit"]');
        if (button) button.disabled = true;
        try {
            await sltRequest(editingId ? "/phases/" + editingId : "/phases", {
                method: editingId ? "PUT" : "POST",
                body: JSON.stringify(input)
            });
            sltNotify(editingId ? "Phase updated." : "Phase created.");
            resetForm();
            sltCloseModal("phaseModal");
            await load();
        } catch (error) {
            sltNotify(error.message, "error");
        } finally {
            if (button) button.disabled = false;
        }
    };

    $("phaseRows").onclick = async event => {
        const button = event.target.closest("button[data-action]");
        if (!button) return;
        const id = Number(button.dataset.id);
        const phase = phases.find(p => Number(p.Id) === id);
        if (!phase) return;
        if (button.dataset.action === "edit") {
            editingId = id;
            $("formTitle").textContent = "Edit Phase";
            $("phaseTitle").value = phase.Title || "";
            $("phaseDate").value = dateOnly(phase.Date);
            $("eventWelcomeMessage").value = phase.EventWelcomeMessage || "";
            $("eventSloganMessage").value = phase.EventSloganMessage || "";
            sltOpenModal("phaseModal");
            return;
        }
        if (button.dataset.action === "delete") {
            if (!await sltConfirm("Soft delete phase " + phase.Title + "?")) return;
            try {
                await sltRequest("/phases/" + id, { method: "DELETE" });
                sltNotify("Phase deleted.");
                await load();
            } catch (error) {
                sltNotify(error.message, "error");
            }
        }
    };

    $("refresh").onclick = load;
    await load();
})();
