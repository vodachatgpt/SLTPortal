window.SLT_SCHEDULE_MODULE = {
  "title": "Day Schedule",
  "description": "Create shared activities for all guests, or import an Excel schedule.",
  "api": "day-schedules",
  "columns": [
    [
      "Date",
      "Date"
    ],
    [
      "ItemType",
      "Type"
    ],
    [
      "Title",
      "Title"
    ],
    [
      "StartTime",
      "Start"
    ],
    [
      "EndTime",
      "End"
    ],
    [
      "LocationName",
      "Location"
    ],
    [
      "BlurIconName",
      "Icon"
    ]
  ],
  "fields": [
    [
      "Date",
      "Date *",
      "date",
      true
    ],
    [
      "ItemType",
      "Item type *",
      "text",
      true
    ],
    [
      "Title",
      "Title *",
      "text",
      true
    ],
    [
      "StartTime",
      "Start time",
      "time",
      false
    ],
    [
      "EndTime",
      "End time",
      "time",
      false
    ],
    [
      "ShortNote",
      "Short note",
      "textarea",
      false
    ],
    [
      "DressCode",
      "Dress code",
      "text",
      false
    ],
    [
      "LocationName",
      "Location name",
      "text",
      false
    ],
    [
      "MapsLink",
      "Maps link",
      "url",
      false
    ],
    [
      "BlurIconName",
      "Blurb icon name",
      "blurb",
      false
    ]
  ],
  "search": "Title Date ItemType LocationName"
};
window.sltScheduleAdminInit();
