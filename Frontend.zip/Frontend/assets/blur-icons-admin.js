
(async function () {
    "use strict";

    // ============================================================
    // SLT BLURB ICONS MANAGEMENT
    // ============================================================

    const $ = id => document.getElementById(id);

    if (!await sltRequireAdmin()) {
        return;
    }

    let records = [];
    let editingId = null;
    let isLoading = false;

    const API_PATH = "/blur-icons";

    // ============================================================
    // HELPERS
    // ============================================================

    function notify(message, type = "success") {
        if (typeof window.sltNotify === "function") {
            window.sltNotify(message, type);
        } else {
            console.log("[SLT]", message);
        }
    }

    function getRecords(response) {
        if (Array.isArray(response)) {
            return response;
        }

        if (response && Array.isArray(response.Records)) {
            return response.Records;
        }

        if (response && Array.isArray(response.Result)) {
            return response.Result;
        }

        if (response && Array.isArray(response.Data)) {
            return response.Data;
        }

        return [];
    }

    function findRecord(id) {
        return records.find(function (item) {
            return String(item.Id) === String(id);
        });
    }

    function createCell(value, className) {
        const td = document.createElement("td");

        td.textContent =
            value == null || value === ""
                ? "—"
                : String(value);

        if (className) {
            td.className = className;
        }

        return td;
    }

    function setLoading(loading) {
        isLoading = loading;

        const refreshButton = $("refresh");

        if (refreshButton) {
            refreshButton.disabled = loading;
        }
    }

    // ============================================================
    // SVG PREVIEW
    // ============================================================

    function createPreview(svg, name) {
        const wrapper = document.createElement("div");

        wrapper.className = "slt-blurb-preview";

        if (!svg || !String(svg).trim()) {
            wrapper.textContent = "—";
            return wrapper;
        }

        const source = String(svg).trim();

        if (!/^<svg[\s>]/i.test(source)) {
            wrapper.textContent = "Invalid SVG";
            wrapper.classList.add("slt-blurb-preview-invalid");
            return wrapper;
        }

        const image = document.createElement("img");

        image.className = "slt-icon-preview";
        image.alt = (name || "Blurb icon") + " preview";
        image.loading = "lazy";
        image.decoding = "async";

        // SVG is loaded as an image, not inserted into
        // the page as executable HTML.
        image.src =
            "data:image/svg+xml;charset=utf-8," +
            encodeURIComponent(source);

        image.onerror = function () {
            wrapper.textContent = "Preview unavailable";
            wrapper.classList.add(
                "slt-blurb-preview-invalid"
            );
        };

        wrapper.appendChild(image);

        return wrapper;
    }

    // ============================================================
    // TABLE RENDERING
    // ============================================================

    function showTableMessage(message) {
        const tbody = $("records");

        if (!tbody) {
            return;
        }

        tbody.replaceChildren();

        const tr = document.createElement("tr");
        const td = document.createElement("td");

        // Only four columns:
        // Preview | Icon Name | Shape | Actions
        td.colSpan = 4;
        td.className = "slt-empty-state";
        td.textContent = message;

        tr.appendChild(td);
        tbody.appendChild(tr);
    }

    function createActionButton(
        action,
        label,
        id
    ) {
        const button = document.createElement("button");

        button.type = "button";
        button.dataset.action = action;
        button.dataset.id = String(id);
        button.textContent = label;

        if (action === "delete") {
            button.classList.add("slt-delete-action");
        }

        return button;
    }

    function paint() {
        const tbody = $("records");

        if (!tbody) {
            console.error(
                "[SLT Blurb Icons] Table body not found."
            );
            return;
        }

        tbody.replaceChildren();

        if (!records.length) {
            showTableMessage(
                "No blurb icons found. Add your first icon."
            );
            return;
        }

        const fragment = document.createDocumentFragment();

        records.forEach(function (item) {
            const tr = document.createElement("tr");

            // ------------------------------------
            // 1. PREVIEW
            // ------------------------------------

            const previewCell =
                document.createElement("td");

            previewCell.appendChild(
                createPreview(item.SVG, item.Name)
            );

            tr.appendChild(previewCell);

            // ------------------------------------
            // 2. ICON NAME
            // ------------------------------------

            tr.appendChild(
                createCell(
                    item.Name,
                    "slt-blurb-name-cell"
                )
            );

            // ------------------------------------
            // 3. SHAPE
            // ------------------------------------

            tr.appendChild(
                createCell(
                    item.Shape,
                    "slt-blurb-shape-cell"
                )
            );

            // ------------------------------------
            // 4. ACTIONS
            // ------------------------------------

            const actionsCell =
                document.createElement("td");

            const actions =
                document.createElement("div");

            actions.className = "slt-row-actions";

            actions.appendChild(
                createActionButton(
                    "edit",
                    "Edit",
                    item.Id
                )
            );

            actions.appendChild(
                createActionButton(
                    "delete",
                    "Delete",
                    item.Id
                )
            );

            actionsCell.appendChild(actions);

            tr.appendChild(actionsCell);

            fragment.appendChild(tr);
        });

        tbody.appendChild(fragment);
    }

    // ============================================================
    // LOAD BLURB ICONS
    // ============================================================

    async function load() {
        if (isLoading) {
            return;
        }

        setLoading(true);

        showTableMessage(
            "Loading blurb icons..."
        );

        try {
            const response = await sltRequest(
                API_PATH
            );

            records = getRecords(response);

            paint();

        } catch (error) {
            console.error(
                "[SLT Blurb Icons] Load failed:",
                error
            );

            showTableMessage(
                "Unable to load blurb icons."
            );

            notify(
                error.message ||
                "Failed to load blurb icons.",
                "error"
            );

        } finally {
            setLoading(false);
        }
    }

    // ============================================================
    // OPEN CREATE / EDIT MODAL
    // ============================================================

    function openRecord(item) {
        editingId = item ? item.Id : null;

        const form = $("recordForm");

        if (!form) {
            console.error(
                "[SLT Blurb Icons] Form not found."
            );
            return;
        }

        form.reset();

        $("formTitle").textContent = item
            ? "Edit Blurb Icon"
            : "Add Blurb Icon";

        const saveButton = $("saveRecord");

        if (saveButton) {
            saveButton.textContent = item
                ? "Save Changes"
                : "Save Blurb Icon";
        }

        if (item) {
            $("iconName").value =
                item.Name || "";

            $("iconShape").value =
                item.Shape || "";

            $("iconSvg").value =
                item.SVG || "";
        }

        sltOpenModal("recordModal");
    }

    // ============================================================
    // CREATE BUTTON
    // ============================================================

    $("openRecord").addEventListener(
        "click",
        function () {
            openRecord(null);
        }
    );

    // ============================================================
    // REFRESH BUTTON
    // ============================================================

    $("refresh").addEventListener(
        "click",
        load
    );

    // ============================================================
    // CREATE / UPDATE BLURB ICON
    // ============================================================

    $("recordForm").addEventListener(
        "submit",
        async function (event) {
            event.preventDefault();

            const button = $("saveRecord");

            if (button.disabled) {
                return;
            }

            const input = {
                Name: $("iconName").value.trim(),
                Shape: $("iconShape").value.trim(),
                SVG: $("iconSvg").value.trim()
            };

            if (!input.Name) {
                notify(
                    "Please enter the blurb icon name.",
                    "warning"
                );

                $("iconName").focus();
                return;
            }

            if (!input.SVG) {
                notify(
                    "Please enter the SVG markup.",
                    "warning"
                );

                $("iconSvg").focus();
                return;
            }

            if (!/^<svg[\s>]/i.test(input.SVG)) {
                notify(
                    "SVG markup must begin with an <svg> element.",
                    "warning"
                );

                $("iconSvg").focus();
                return;
            }

            const isEditing =
                editingId !== null &&
                editingId !== undefined;

            const path = isEditing
                ? API_PATH + "/" +
                    encodeURIComponent(editingId)
                : API_PATH;

            button.disabled = true;

            const originalLabel = button.textContent;

            button.textContent = isEditing
                ? "Updating..."
                : "Saving...";

            try {
                await sltRequest(
                    path,
                    {
                        method: isEditing
                            ? "PUT"
                            : "POST",

                        body: JSON.stringify(input)
                    }
                );

                sltCloseModal("recordModal");

                notify(
                    isEditing
                        ? "Blurb icon updated successfully."
                        : "Blurb icon created successfully."
                );

                editingId = null;

                await load();

            } catch (error) {
                console.error(
                    "[SLT Blurb Icons] Save failed:",
                    error
                );

                notify(
                    error.message ||
                    "Unable to save the blurb icon.",
                    "error"
                );

            } finally {
                button.disabled = false;
                button.textContent = originalLabel;
            }
        }
    );

    // ============================================================
    // TABLE ACTIONS
    // ============================================================

    $("records").addEventListener(
        "click",
        async function (event) {
            const button = event.target.closest(
                "button[data-action]"
            );

            if (!button) {
                return;
            }

            const id = button.dataset.id;
            const action = button.dataset.action;

            const item = findRecord(id);

            if (!item) {
                notify(
                    "Blurb icon record not found.",
                    "error"
                );
                return;
            }

            // ------------------------------------
            // EDIT
            // ------------------------------------

            if (action === "edit") {
                openRecord(item);
                return;
            }

            // ------------------------------------
            // DELETE
            // ------------------------------------

            if (action === "delete") {
                let confirmed = false;

                try {
                    confirmed = await sltConfirm(
                        'Delete blurb icon "' +
                        (item.Name || "Unnamed") +
                        '"?'
                    );
                } catch (error) {
                    console.error(
                        "[SLT Blurb Icons] Confirmation failed:",
                        error
                    );
                    return;
                }

                if (!confirmed) {
                    return;
                }

                if (button.disabled) {
                    return;
                }

                button.disabled = true;

                try {
                    await sltRequest(
                        API_PATH + "/" +
                        encodeURIComponent(item.Id),
                        {
                            method: "DELETE"
                        }
                    );

                    notify(
                        "Blurb icon deleted successfully."
                    );

                    await load();

                } catch (error) {
                    console.error(
                        "[SLT Blurb Icons] Delete failed:",
                        error
                    );

                    notify(
                        error.message ||
                        "Unable to delete the blurb icon.",
                        "error"
                    );

                } finally {
                    button.disabled = false;
                }
            }
        }
    );

    // ============================================================
    // INITIALIZE
    // ============================================================

    console.info(
        "[SLT Blurb Icons] Module initialized."
    );

    await load();

})();
