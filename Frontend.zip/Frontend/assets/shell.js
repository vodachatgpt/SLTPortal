
(function () {
    "use strict";

    // ============================================================
    // SLT ADMIN APPLICATION SHELL
    // Vodafone Dark Experience
    // ============================================================

    const CONFIG = {
        dashboard: "dashboard.html",
        login: "admin-login.html",

        themeFile: "assets/admin-dark-theme.css",
        themeVersion: "9",

        serviceWorker: "./service-worker.js",

        emailStorageKey: "slt_admin_email",

        enablePWA: true
    };

    const $ = id => document.getElementById(id);

    const nav = document.querySelector(
        ".slt-dashboard-nav"
    );

    const currentPage =
        window.location.pathname
            .split("/")
            .pop()
            .toLowerCase() || CONFIG.dashboard;

    // ============================================================
    // SIDEBAR NAVIGATION COLLECTIONS
    // ============================================================

    const groups = [
        {
            title: "WORKSPACE",
            items: [
                {
                    url: "dashboard.html",
                    label: "Overview",
                    icon: "⌂"
                },
                {
                    url: "admins-admin.html",
                    label: "Administrators",
                    icon: "♙"
                }
            ]
        },
        {
            title: "GUEST INFORMATION",
            items: [
                {
                    url: "guests-admin.html",
                    label: "Guests",
                    icon: "♟"
                },
                {
                    url: "airport-transfers-admin.html",
                    label: "Airport Transfers",
                    icon: "✈"
                },
                {
                    url: "guest-event-drivers-admin.html",
                    label: "Event Drivers",
                    icon: "♧"
                }
            ]
        },
        {
            title: "EVENT INFORMATION",
            items: [
                {
                    url: "phases-admin.html",
                    label: "Phases",
                    icon: "◇"
                },
                {
                    url: "day-schedules-admin.html",
                    label: "Day Schedules",
                    icon: "▦"
                },
                {
                    url: "weather-admin.html",
                    label: "Weather Forecast",
                    icon: "☀"
                }
            ]
        },
        {
            title: "SYSTEM INFORMATION",
            items: [
                {
                    url: "blur-icons-admin.html",
                    label: "Blurb Icons",
                    icon: "✧"
                },
                {
                    url: "help-support-admin.html",
                    label: "Help & Support",
                    icon: "♡"
                },
                {
                    url: "email-templates-admin.html",
                    label: "Email Templates",
                    icon: "✉"
                }
            ]
        }
    ];

    // ============================================================
    // GLOBAL DARK THEME
    // ============================================================

    function initializeTheme() {
        if (!nav) return;
        let saved;
        try { saved = localStorage.getItem('slt_admin_theme'); } catch (_) {}
        let dark = saved === 'dark';
        const link = document.getElementById('sltDarkTheme') || document.createElement('link');
        link.id='sltDarkTheme';link.rel='stylesheet';link.href=CONFIG.themeFile+'?v=12';
        if(!link.parentNode)document.head.appendChild(link);
        function applyTheme() {
            document.documentElement.classList.toggle('slt-dark-admin',dark);
            document.body.classList.toggle('slt-dark-admin',dark);
            link.disabled=!dark;
            const control=document.getElementById('sltThemeToggle');
            if(control) {
                control.textContent=dark?'☀ Light mode':'☾ Dark mode';
                control.setAttribute('aria-pressed',String(dark));
                control.setAttribute('aria-label',dark?'Switch to light mode':'Switch to dark mode');
            }
        }
        window.sltToggleAdminTheme=function(){
            dark=!dark;
            try {localStorage.setItem('slt_admin_theme',dark?'dark':'light');}catch(_){}
            applyTheme();
        };
        applyTheme();
    }

    function createThemeToggle() {
        if (!nav) return;
        const target = document.querySelector('.slt-topbar-actions');
        if (!target || document.getElementById('sltThemeToggle')) return;
        const button=document.createElement('button');button.id='sltThemeToggle';
        button.className='slt-theme-switch';button.type='button';
        button.onclick=function(){window.sltToggleAdminTheme();};
        target.insertBefore(button,target.firstChild);
        button.textContent=document.documentElement.classList.contains('slt-dark-admin')?'☀ Light mode':'☾ Dark mode';
    }

    // ============================================================
    // HELPER FUNCTIONS
    // ============================================================

    function escapeHtml(value) {

        return String(value == null ? "" : value)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#39;");
    }

    function getCurrentPage() {

        for (const group of groups) {

            const page = group.items.find(
                item =>
                    item.url.toLowerCase() === currentPage
            );

            if (page) return page;
        }

        return {
            label: "Workspace",
            url: CONFIG.dashboard
        };
    }

    function getAdminEmail() {

        try {
            return (
                localStorage.getItem(
                    CONFIG.emailStorageKey
                ) ||
                sessionStorage.getItem(
                    CONFIG.emailStorageKey
                ) ||
                ""
            );
        } catch (error) {
            return "";
        }
    }

    function getAdminFirstName() {

        const email = getAdminEmail();

        if (!email || !email.includes("@")) {
            return "Admin";
        }

        const localPart = email
            .split("@")[0]
            .trim();

        const firstPart = localPart
            .split(/[._-]/)[0]
            .replace(/[^a-zA-Z]/g, "");

        if (!firstPart) {
            return "Admin";
        }

        return firstPart.charAt(0).toUpperCase() +
            firstPart.slice(1).toLowerCase();
    }

    function getAdminInitials() {

        const name = getAdminFirstName();

        return name
            ? name.charAt(0).toUpperCase()
            : "A";
    }

    function getFormattedDate() {

        return new Intl.DateTimeFormat("en-GB", {
            weekday: "short",
            day: "numeric",
            month: "short",
            year: "numeric"
        }).format(new Date());
    }

    function getGreeting() {

        const hour = new Date().getHours();

        if (hour < 12) {
            return "Good morning";
        }

        if (hour < 17) {
            return "Good afternoon";
        }

        return "Good evening";
    }

    // Expose for existing dashboard scripts if needed.
    window.sltAdminDisplayName = getAdminFirstName;
    window.sltAdminGreeting = getGreeting;

    // ============================================================
    // SIDEBAR BRAND
    // ============================================================

    function renderBrand() {

        if (!nav) return;

        const brand = nav.querySelector(
            ".slt-brand"
        );

        if (!brand) return;

        brand.href = CONFIG.dashboard;

        brand.innerHTML = `
            <span class="slt-brand-mark">
                S
            </span>

            <span class="slt-brand-name">
                SLT Admin

                <small>
                    EVENT CONTROL CENTER
                </small>
            </span>
        `;
    }

    // ============================================================
    // SIDEBAR MENU
    // ============================================================

    function renderSidebar() {

        if (!nav) return;

        const links = nav.querySelector(
            ".slt-nav-links"
        );

        if (!links) return;

        const fragments = [];

        groups.forEach(function (group, groupIndex) {

            fragments.push(`
                <div class="slt-nav-caption
                    ${groupIndex > 0
                        ? "slt-nav-caption-secondary"
                        : ""}">
                    ${escapeHtml(group.title)}
                </div>
            `);

            group.items.forEach(function (item) {

                const isActive =
                    item.url.toLowerCase() === currentPage;

                fragments.push(`
                    <a
                        href="${escapeHtml(item.url)}"
                        class="${isActive
                            ? "slt-nav-active"
                            : ""}"
                        ${isActive
                            ? 'aria-current="page"'
                            : ""}>

                        <span
                            class="slt-nav-symbol"
                            aria-hidden="true">
                            ${item.icon}
                        </span>

                        <span class="slt-nav-label">
                            ${escapeHtml(item.label)}
                        </span>

                        ${isActive
                            ? '<span class="slt-nav-active-indicator" aria-hidden="true"></span>'
                            : ""}

                    </a>
                `);
            });
        });

        // Guest Portal removed permanently
        // from the sidebar collection.

        links.innerHTML = fragments.join("");
    }

    // ============================================================
    // MOBILE SIDEBAR
    // ============================================================

    function closeMobileMenu() {

        document.body.classList.remove(
            "slt-nav-open"
        );

        const button = document.querySelector(
            ".slt-mobile-menu"
        );

        if (button) {

            button.setAttribute(
                "aria-expanded",
                "false"
            );
        }
    }

    function toggleMobileMenu() {

        const isOpen =
            document.body.classList.toggle(
                "slt-nav-open"
            );

        const button = document.querySelector(
            ".slt-mobile-menu"
        );

        if (button) {

            button.setAttribute(
                "aria-expanded",
                String(isOpen)
            );
        }
    }

    // ============================================================
    // TOP BAR
    // ============================================================

    function renderTopbar() {

        if (!nav) return;

        const main = document.querySelector(
            "main.slt-root"
        );

        if (!main) return;

        let topbar = main.querySelector(
            ".slt-topbar"
        );

        if (!topbar) {

            topbar = document.createElement("div");

            topbar.className = "slt-topbar";

            nav.insertAdjacentElement(
                "afterend",
                topbar
            );
        }

        const page = getCurrentPage();

        const name = getAdminFirstName();

        topbar.innerHTML = `
            <button
                type="button"
                class="slt-mobile-menu"
                aria-label="Toggle navigation"
                aria-expanded="false">
                ☰
            </button>

            <div class="slt-breadcrumb">

                <span class="slt-breadcrumb-root">
                    SLT Admin
                </span>

                <span>/</span>

                <strong>
                    ${escapeHtml(page.label)}
                </strong>

            </div>

            <div class="slt-topbar-actions">

                <span class="slt-topbar-date">
                    ${escapeHtml(getFormattedDate())}
                </span>

                <span
                    class="slt-avatar"
                    title="${escapeHtml(name)}"
                    aria-label="Administrator: ${escapeHtml(name)}">
                    ${escapeHtml(getAdminInitials())}
                </span>

            </div>
        `;

        const menuButton = topbar.querySelector(
            ".slt-mobile-menu"
        );

        if (menuButton) {

            menuButton.addEventListener(
                "click",
                toggleMobileMenu
            );
        }
    }

    // ============================================================
    // MOBILE NAVIGATION EVENTS
    // ============================================================

    function initializeMobileNavigation() {

        if (!nav) return;

        document.addEventListener(
            "click",
            function (event) {

                if (
                    !document.body.classList.contains(
                        "slt-nav-open"
                    )
                ) {
                    return;
                }

                const menuButton =
                    document.querySelector(
                        ".slt-mobile-menu"
                    );

                const insideNav =
                    nav.contains(event.target);

                const insideButton =
                    menuButton &&
                    menuButton.contains(event.target);

                if (!insideNav && !insideButton) {
                    closeMobileMenu();
                }
            }
        );

        document.addEventListener(
            "keydown",
            function (event) {

                if (event.key === "Escape") {
                    closeMobileMenu();
                }
            }
        );

        nav.addEventListener(
            "click",
            function (event) {

                const link = event.target.closest(
                    ".slt-nav-links a"
                );

                if (link) {
                    closeMobileMenu();
                }
            }
        );

        window.addEventListener(
            "resize",
            function () {

                if (window.innerWidth > 820) {
                    closeMobileMenu();
                }
            }
        );
    }

    // ============================================================
    // LOGOUT
    // ============================================================

    function initializeLogout() {

        const logout = $("sltLogout");

        if (!logout) return;

        logout.addEventListener(
            "click",
            function (event) {

                event.preventDefault();

                try {

                    if (
                        typeof window.sltClearAdminToken ===
                        "function"
                    ) {

                        window.sltClearAdminToken();

                    } else {

                        localStorage.removeItem(
                            "slt_admin_token"
                        );
                    }

                    localStorage.removeItem(
                        CONFIG.emailStorageKey
                    );

                    sessionStorage.removeItem(
                        CONFIG.emailStorageKey
                    );

                } catch (error) {

                    console.warn(
                        "SLT logout storage cleanup:",
                        error
                    );
                }

                window.location.replace(
                    CONFIG.login
                );
            }
        );
    }

    // ============================================================
    // PWA INSTALLATION
    // ============================================================

    let deferredInstallPrompt = null;

    function initializePWAInstall() {

        if (!CONFIG.enablePWA) return;

        const installButton = $("sltInstall");

        window.addEventListener(
            "beforeinstallprompt",
            function (event) {

                event.preventDefault();

                deferredInstallPrompt = event;

                if (installButton) {
                    installButton.hidden = false;
                }
            }
        );

        if (!installButton) return;

        installButton.addEventListener(
            "click",
            async function () {

                if (!deferredInstallPrompt) {
                    return;
                }

                const prompt = deferredInstallPrompt;

                deferredInstallPrompt = null;

                try {

                    await prompt.prompt();

                    await prompt.userChoice;

                } catch (error) {

                    console.warn(
                        "SLT PWA installation:",
                        error
                    );

                } finally {

                    installButton.hidden = true;
                }
            }
        );

        window.addEventListener(
            "appinstalled",
            function () {

                deferredInstallPrompt = null;

                if (installButton) {
                    installButton.hidden = true;
                }
            }
        );
    }

    // ============================================================
    // SERVICE WORKER
    // ============================================================

    function initializeServiceWorker() {

        if (!CONFIG.enablePWA) return;

        if (
            !("serviceWorker" in navigator) ||
            !window.isSecureContext
        ) {
            return;
        }

        window.addEventListener(
            "load",
            async function () {

                try {

                    const registration =
                        await navigator.serviceWorker.register(
                            CONFIG.serviceWorker
                        );

                    console.info(
                        "[SLT PWA] Service worker ready:",
                        registration.scope
                    );

                } catch (error) {

                    console.warn(
                        "[SLT PWA] Registration failed:",
                        error
                    );
                }
            }
        );
    }

    // ============================================================
    // INITIALIZATION
    // ============================================================

    initializeTheme();

    if (nav) {

        renderBrand();

        renderSidebar();

        renderTopbar();
        createThemeToggle();

        initializeMobileNavigation();

        initializeLogout();
    }

    initializePWAInstall();

    initializeServiceWorker();

})();
