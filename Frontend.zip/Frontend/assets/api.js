
(function () {
    "use strict";

    // ============================================================
    // SLT GLOBAL API SERVICES
    // ============================================================

    const config = window.SLT_CONFIG || {};

    const base = String(
        config.API_BASE || "/api"
    ).replace(/\/+$/, "");

    const ADMIN_TOKEN_KEY = "slt_admin_token";
    const ADMIN_EMAIL_KEY = "slt_admin_email";

    const ADMIN_PATHS = [
        "guests",
        "phases",
        "admins",
        "blur-icons",
        "help-support",
        "day-schedules",
        "airport-transfers",
        "guest-event-drivers",
        "email-templates",
        "weather-forecasts"
    ];

    // ============================================================
    // GENERAL HELPERS
    // ============================================================

    function normalizePath(path) {
        const value = String(path || "");

        if (!value) {
            throw new Error("API path is required.");
        }

        return value.startsWith("/")
            ? value
            : "/" + value;
    }

    window.sltEscape = function (value) {
        return String(value == null ? "" : value)
            .replace(/[&<>"']/g, function (character) {
                return {
                    "&": "&amp;",
                    "<": "&lt;",
                    ">": "&gt;",
                    '"': "&quot;",
                    "'": "&#39;"
                }[character];
            });
    };

    // ============================================================
    // GLOBAL DATE / TIME FORMATTING
    // Display standard across SLT:
    //   Date:      dd/MM/yyyy
    //   Time:      HH:mm (24-hour)
    //   Date/time: dd/MM/yyyy HH:mm
    //
    // API values remain ISO 8601. Date-only strings are parsed
    // without using Date(string), avoiding browser timezone shifts.
    // ============================================================

    function sltDateParts(value, options) {
        if (value == null || value === "") return null;

        if (value instanceof Date) {
            if (Number.isNaN(value.getTime())) return null;
            return {
                day: value.getDate(),
                month: value.getMonth() + 1,
                year: value.getFullYear(),
                hour: value.getHours(),
                minute: value.getMinutes()
            };
        }

        var text = String(value).trim();
        if (!text) return null;

        // Date-only ISO or ISO DateTime.
        var iso = /^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2})(?::(\d{2})(?:\.\d+)?)?(Z|[+-]\d{2}:\d{2})?)?$/.exec(text);
        if (iso) {
            // Explicitly offset timestamps represent instants. Render them
            // in Egypt time unless caller explicitly requests UTC.
            if (iso[7]) {
                var instant = new Date(text);
                if (Number.isNaN(instant.getTime())) return null;
                var zone = options && options.utc === true ? "UTC" : "Africa/Cairo";
                var parts = new Intl.DateTimeFormat("en-GB", {
                    timeZone: zone,
                    day: "2-digit",
                    month: "2-digit",
                    year: "numeric",
                    hour: "2-digit",
                    minute: "2-digit",
                    hourCycle: "h23"
                }).formatToParts(instant);
                var values = {};
                parts.forEach(function (part) {
                    if (part.type !== "literal") values[part.type] = part.value;
                });
                return {
                    day: Number(values.day),
                    month: Number(values.month),
                    year: Number(values.year),
                    hour: Number(values.hour),
                    minute: Number(values.minute)
                };
            }

            if (options && options.utc === true && iso[4] != null) {
                var utcInstant = new Date(text + "Z");
                if (Number.isNaN(utcInstant.getTime())) return null;
                return {
                    day: utcInstant.getUTCDate(),
                    month: utcInstant.getUTCMonth() + 1,
                    year: utcInstant.getUTCFullYear(),
                    hour: utcInstant.getUTCHours(),
                    minute: utcInstant.getUTCMinutes()
                };
            }

            return {
                day: Number(iso[3]),
                month: Number(iso[2]),
                year: Number(iso[1]),
                hour: Number(iso[4] || 0),
                minute: Number(iso[5] || 0)
            };
        }

        // Already formatted dd/MM/yyyy [HH:mm].
        var dmy = /^(\d{1,2})\/(\d{1,2})\/(\d{4})(?:[ T](\d{1,2}):(\d{2})(?::\d{2})?)?$/.exec(text);
        if (dmy) {
            return {
                day: Number(dmy[1]),
                month: Number(dmy[2]),
                year: Number(dmy[3]),
                hour: Number(dmy[4] || 0),
                minute: Number(dmy[5] || 0)
            };
        }

        return null;
    }

    function sltPad2(value) {
        return String(value).padStart(2, "0");
    }

    function sltValidParts(parts) {
        if (!parts) return false;
        var check = new Date(Date.UTC(parts.year, parts.month - 1, parts.day));
        return check.getUTCFullYear() === parts.year &&
            check.getUTCMonth() === parts.month - 1 &&
            check.getUTCDate() === parts.day &&
            parts.hour >= 0 && parts.hour <= 23 &&
            parts.minute >= 0 && parts.minute <= 59;
    }

    window.sltFormatDateOnly = function (value) {
        var parts = sltDateParts(value);
        if (!sltValidParts(parts)) return "—";
        return sltPad2(parts.day) + "/" + sltPad2(parts.month) + "/" + parts.year;
    };

    window.sltFormatTimeOnly = function (value) {
        if (value == null || value === "") return "—";
        var text = String(value).trim();

        // ASP.NET TimeSpan serialization: HH:mm:ss or HH:mm:ss.fffffff.
        var timeSpan = /^(\d{1,2}):(\d{2})(?::\d{2}(?:\.\d+)?)?$/.exec(text);
        if (timeSpan) {
            var hour = Number(timeSpan[1]);
            var minute = Number(timeSpan[2]);
            if (hour > 23 || minute > 59) return "—";
            return sltPad2(hour) + ":" + sltPad2(minute);
        }

        var parts = sltDateParts(value);
        return sltValidParts(parts)
            ? sltPad2(parts.hour) + ":" + sltPad2(parts.minute)
            : "—";
    };

    window.sltFormatDateTime = function (value, options) {
        var parts = sltDateParts(value, options || {});
        if (!sltValidParts(parts)) return "—";
        return sltPad2(parts.day) + "/" + sltPad2(parts.month) + "/" +
            parts.year + " " + sltPad2(parts.hour) + ":" + sltPad2(parts.minute);
    };

    // Backward-compatible alias. DateTime values are displayed in Egypt
    // local time, except callers explicitly passing { utc: true }.
    window.sltFormatDate = function (value, options) {
        return window.sltFormatDateTime(value, options || {});
    };

    // Use these only to populate native HTML date/time input controls.
    // Their values must stay in the browser's required ISO input format.
    window.sltDateInputValue = function (value) {
        var parts = sltDateParts(value);
        if (!sltValidParts(parts)) return "";
        return parts.year + "-" + sltPad2(parts.month) + "-" + sltPad2(parts.day);
    };

    window.sltTimeInputValue = function (value) {
        var result = window.sltFormatTimeOnly(value);
        return result === "—" ? "" : result;
    };

    // ============================================================
    // ADMIN TOKEN MANAGEMENT
    // ============================================================

    window.sltGetAdminToken = function () {
        try {
            return localStorage.getItem(
                ADMIN_TOKEN_KEY
            );
        } catch (error) {
            return null;
        }
    };

    window.sltSetAdminToken = function (token) {
        if (!token) {
            throw new Error(
                "Administrator token is required."
            );
        }

        localStorage.setItem(
            ADMIN_TOKEN_KEY,
            String(token)
        );
    };

    window.sltClearAdminToken = function () {
        localStorage.removeItem(
            ADMIN_TOKEN_KEY
        );
    };

    window.sltClearAdminSession = function () {
        window.sltClearAdminToken();

        localStorage.removeItem(
            ADMIN_EMAIL_KEY
        );

        sessionStorage.removeItem(
            ADMIN_EMAIL_KEY
        );
    };

    // ============================================================
    // API REQUEST HANDLER
    // ============================================================

    window.sltRequest = async function (
        path,
        options
    ) {
        options = options || {};

        const requestPath = normalizePath(path);

        const headers = Object.assign(
            {},
            options.headers || {}
        );

        const firstSegment = requestPath
            .split("?")[0]
            .split("/")
            .filter(Boolean)[0] || "";

        const requiresAdmin =
            ADMIN_PATHS.includes(firstSegment) ||
            requestPath === "/admin-auth/me";

        if (
            requiresAdmin &&
            !headers.Authorization
        ) {
            const token = window.sltGetAdminToken();

            if (token) {
                headers.Authorization =
                    "Bearer " + token;
            }
        }

        const hasBody =
            options.body !== undefined &&
            options.body !== null;

        const isFormData =
            hasBody &&
            typeof FormData !== "undefined" &&
            options.body instanceof FormData;

        if (
            hasBody &&
            !isFormData &&
            !headers["Content-Type"] &&
            !headers["content-type"]
        ) {
            headers["Content-Type"] =
                "application/json";
        }

        const requestOptions = {
            method: options.method || "GET",
            headers: headers,
            credentials: "omit",
            cache: "no-store"
        };

        if (hasBody) {
            requestOptions.body = options.body;
        }

        if (options.signal) {
            requestOptions.signal = options.signal;
        }

        let response;

        try {
            response = await fetch(
                base + requestPath,
                requestOptions
            );
        } catch (networkError) {
            console.error(
                "[SLT API] Network error:",
                networkError
            );

            const error = new Error(
                "Cannot connect to the server. " +
                "Please check the connection and retry."
            );

            error.status = 0;
            error.isNetworkError = true;

            // Preserve the admin token on network errors.
            throw error;
        }

        // ========================================================
        // HTTP ERROR HANDLING
        // ========================================================

        if (!response.ok) {
            let message =
                "HTTP " + response.status;

            try {
                const contentType =
                    response.headers.get(
                        "content-type"
                    ) || "";

                if (
                    contentType.includes(
                        "application/json"
                    )
                ) {
                    const data = await response.json();

                    message =
                        data.errorMessage ||
                        data.ExceptionMessage ||
                        data.Message ||
                        data.message ||
                        (
                            data.ModelState
                                ? Object.values(
                                    data.ModelState
                                ).flat().join(" ")
                                : ""
                        ) ||
                        message;

                } else {
                    const text = await response.text();

                    if (
                        text &&
                        text.length < 500
                    ) {
                        message = text;
                    }
                }
            } catch (parseError) {
                console.warn(
                    "[SLT API] Error parsing failed:",
                    parseError
                );
            }

            const error = new Error(message);

            error.status = response.status;
            error.url = requestPath;
            error.isNetworkError = false;

            console.warn(
                "[SLT API] Request failed:",
                {
                    path: requestPath,
                    status: response.status,
                    message: message
                }
            );

            throw error;
        }

        // ========================================================
        // SUCCESS RESPONSE
        // ========================================================

        if (response.status === 204) {
            return null;
        }

        const contentType =
            response.headers.get(
                "content-type"
            ) || "";

        if (
            contentType.includes(
                "application/json"
            )
        ) {
            return response.json();
        }

        // Binary downloads. Excel's official MIME type is not
        // application/octet-stream, so it must be handled explicitly.
        const contentDisposition =
            response.headers.get("content-disposition") || "";

        const isExcel =
            contentType.includes(
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            ) ||
            contentType.includes("application/vnd.ms-excel") ||
            contentType.includes("application/vnd.openxmlformats-officedocument.spreadsheetml") ||
            /\.xlsx?(?:\s*;|$)/i.test(contentDisposition);

        if (
            isExcel ||
            contentType.includes("image/") ||
            contentType.includes("application/octet-stream") ||
            contentType.includes("application/pdf")
        ) {
            return response.blob();
        }

        return response.text();
    };

    // ============================================================
    // FILE DOWNLOAD
    // ============================================================

    window.sltDownload = function (
        data,
        filename,
        type
    ) {
        const blob = data instanceof Blob
            ? data
            : new Blob(
                [data],
                {
                    type: type ||
                        "application/octet-stream"
                }
            );

        const url = URL.createObjectURL(blob);

        const link = document.createElement("a");

        link.href = url;
        link.download = filename || "download";

        document.body.appendChild(link);

        link.click();
        link.remove();

        setTimeout(function () {
            URL.revokeObjectURL(url);
        }, 2000);
    };

    // ============================================================
    // SHARED EXCEL IMPORT ERROR REPORT
    // ============================================================

    window.sltShowImportReport = function (
        targetId,
        result,
        title,
        insertAfterSelector
    ) {
        result = result || {};

        var panel = document.getElementById(targetId);

        if (!panel) {
            panel = document.createElement("section");
            panel.id = targetId;
            panel.className = "slt-card slt-import-report";

            var anchor = insertAfterSelector
                ? document.querySelector(insertAfterSelector)
                : null;

            if (anchor && anchor.parentNode) {
                anchor.parentNode.insertBefore(panel, anchor.nextSibling);
            } else {
                (document.querySelector(".slt-root") || document.body)
                    .appendChild(panel);
            }
        }

        var details = Array.isArray(result.ErrorDetails)
            ? result.ErrorDetails
            : (Array.isArray(result.errorDetails) ? result.errorDetails : []);

        var rawErrors = Array.isArray(result.Errors)
            ? result.Errors
            : (Array.isArray(result.errors) ? result.errors : []);

        if (!details.length && rawErrors.length) {
            details = rawErrors.map(function (message) {
                var match = /^Row\s+(\d+)(?:,\s*([^:]+))?:\s*(.*)$/i.exec(String(message));
                return {
                    RowNumber: match ? Number(match[1]) : 0,
                    Column: match && match[2] ? match[2].trim() : "Record",
                    Value: "",
                    Reason: match ? match[3] : String(message)
                };
            });
        }

        function escape(value) {
            return window.sltEscape(value == null ? "" : String(value));
        }

        function field(item, pascalName, camelName, alternateName) {
            if (item && item[pascalName] != null) return item[pascalName];
            if (item && item[camelName] != null) return item[camelName];
            if (alternateName && item && item[alternateName] != null) return item[alternateName];
            return "";
        }

        var uniqueFailedRows = {};
        details.forEach(function (item) {
            var row = Number(field(item, "RowNumber", "rowNumber", "Row") || 0);
            uniqueFailedRows[row] = true;
        });

        var failed = Number(field(result, "Failed", "failed") || 0);
        if (!failed) failed = Object.keys(uniqueFailedRows).filter(function (x) {
            return x !== "0";
        }).length;

        var inserted = Number(field(result, "Inserted", "inserted") || 0) +
            Number(field(result, "Created", "created") || 0);
        var updated = Number(field(result, "Updated", "updated") || 0);
        var skipped = Number(field(result, "Skipped", "skipped") || 0);
        var softDeleted = Number(field(result, "SoftDeleted", "softDeleted") || 0);
        var total = Number(field(result, "TotalRows", "totalRows") || 0);

        // Backward-compatible fallback for older result DTOs.
        if (!total) total = inserted + updated + skipped;
        var reportTitle = title || "Excel import";

        var rowsHtml = details.length
            ? '<div class="slt-import-report-table-wrap">' +
                '<table class="slt-import-report-table">' +
                    '<thead><tr><th>Excel row</th><th>Column</th><th>Value</th><th>Reason</th></tr></thead>' +
                    '<tbody>' +
                    details.map(function (item) {
                        return '<tr>' +
                            '<td class="slt-import-row-number">' + escape(field(item, "RowNumber", "rowNumber", "Row") || "—") + '</td>' +
                            '<td><strong>' + escape(field(item, "Column", "column") || "Record") + '</strong></td>' +
                            '<td class="slt-import-value">' + escape(field(item, "Value", "value") || "—") + '</td>' +
                            '<td>' + escape(field(item, "Reason", "reason") || "Invalid value.") + '</td>' +
                        '</tr>';
                    }).join("") +
                    '</tbody></table></div>'
            : '<div class="slt-import-report-clean">All submitted rows were imported successfully. No row-level errors were found.</div>';

        panel.hidden = false;
        panel.innerHTML =
            '<div class="slt-import-report-heading">' +
                '<div>' +
                    '<span class="slt-kicker">IMPORT SUMMARY</span>' +
                    '<h2>' + escape(reportTitle) + '</h2>' +
                    '<p class="slt-muted">Valid rows were saved. Rows with errors were skipped and are listed below.</p>' +
                '</div>' +
                (details.length
                    ? '<button type="button" class="slt-btn slt-secondary" id="' + escape(targetId) + 'Download">Download error report</button>'
                    : '') +
            '</div>' +
            '<div class="slt-import-report-stats">' +
                '<div><strong>' + total + '</strong><span>Data rows</span></div>' +
                '<div><strong>' + inserted + '</strong><span>Inserted / created</span></div>' +
                '<div><strong>' + updated + '</strong><span>Updated</span></div>' +
                '<div><strong>' + skipped + '</strong><span>Skipped</span></div>' +
                (softDeleted ? '<div><strong>' + softDeleted + '</strong><span>Soft-deleted</span></div>' : '') +
                '<div class="' + (failed ? 'slt-import-has-errors' : '') + '"><strong>' + failed + '</strong><span>Rows with errors</span></div>' +
            '</div>' +
            rowsHtml +
            (details.length
                ? '<p class="slt-import-report-footnote">The report uses the actual Excel row number, including the header row. Correct the listed cells and upload the workbook again.</p>'
                : '');

        var downloadButton = document.getElementById(targetId + "Download");

        if (downloadButton) {
            downloadButton.addEventListener("click", function () {
                var csvRows = [
                    ["Excel row", "Column", "Value", "Reason"]
                ];

                details.forEach(function (item) {
                    csvRows.push([
                        field(item, "RowNumber", "rowNumber", "Row") || "",
                        field(item, "Column", "column") || "Record",
                        field(item, "Value", "value") || "",
                        field(item, "Reason", "reason") || "Invalid value."
                    ]);
                });

                function csvCell(value) {
                    var text = String(value == null ? "" : value);

                    // Prevent spreadsheet formula execution when the CSV is opened.
                    if (/^[\s]*[=+\-@]/.test(text))
                        text = "'" + text;

                    return '"' + text.replace(/"/g, '""') + '"';
                }

                var csv = "\uFEFF" + csvRows.map(function (row) {
                    return row.map(csvCell).join(",");
                }).join("\r\n");

                var safeName = reportTitle
                    .replace(/[^a-z0-9_-]+/gi, "_")
                    .replace(/^_+|_+$/g, "") || "Import";

                window.sltDownload(
                    csv,
                    safeName + "_Error_Report.csv",
                    "text/csv;charset=utf-8"
                );
            });
        }

        if (panel.scrollIntoView)
            panel.scrollIntoView({ behavior: "smooth", block: "start" });

        return panel;
    };

    // ============================================================
    // ADMIN SESSION VALIDATION
    // ============================================================

    window.sltRequireAdmin = async function () {
        const token = window.sltGetAdminToken();

        if (!token) {
            window.location.replace(
                "admin-login.html"
            );

            return false;
        }

        try {
            await window.sltRequest(
                "/admin-auth/me"
            );

            return true;

        } catch (error) {
            console.warn(
                "[SLT Admin] Session validation failed:",
                error
            );

            if (error.status === 401) {
                window.sltClearAdminSession();

                window.location.replace(
                    "admin-login.html"
                );

                return false;
            }

            window.sltNotify(
                "Unable to verify your administrator session. " +
                "Please check the connection and retry.",
                "error"
            );

            return false;
        }
    };

    // ============================================================
    // GLOBAL SWEETALERT NOTIFICATIONS
    // ============================================================

    window.sltNotify = function (
        message,
        type = "success"
    ) {
        const validTypes = [
            "success",
            "error",
            "warning",
            "info"
        ];

        const icon = validTypes.includes(type)
            ? type
            : "info";

        const text = String(
            message || ""
        );

        if (window.Swal) {
            return window.Swal.fire({
                target: document.body,
                heightAuto: false,
                toast: true,
                position: "top-end",
                icon: icon,
                title: text,
                showConfirmButton: false,
                timer: icon === "error"
                    ? 5000
                    : 3200,
                timerProgressBar: true,
                background: "#ffffff",
                color: "#252838",
                confirmButtonColor: "#c8102e"
            });
        }

        console[
            icon === "error" ? "error" : "log"
        ]("[SLT " + icon + "]", text);

        return Promise.resolve();
    };

    // ============================================================
    // GLOBAL CONFIRMATIONS
    // ============================================================

    window.sltConfirm = async function (message) {
        if (window.Swal) {
            const result = await window.Swal.fire({
                target: document.body,
                heightAuto: false,
                title: "Please confirm",
                text: String(message || ""),
                icon: "question",
                showCancelButton: true,
                confirmButtonText: "Yes, continue",
                cancelButtonText: "Cancel",
                confirmButtonColor: "#c8102e",
                cancelButtonColor: "#7b8290",
                background: "#ffffff",
                color: "#252838",
                reverseButtons: true
            });

            return result.isConfirmed;
        }

        return window.confirm(
            String(message || "")
        );
    };

    // ============================================================
    // GLOBAL MODAL MANAGEMENT
    // ============================================================

    function findModal(id) {
        const modal = document.getElementById(id);

        if (!modal) {
            console.error(
                "[SLT Modal] Modal not found:",
                id
            );
        }

        return modal;
    }

    window.sltOpenModal = function (id) {
        const modal = findModal(id);

        if (!modal) return false;

        // Close other open modals.
        document.querySelectorAll(
            ".slt-modal.slt-modal-open"
        ).forEach(function (other) {
            if (other !== modal) {
                other.classList.remove(
                    "slt-modal-open"
                );

                other.classList.add(
                    "slt-hidden"
                );

                other.setAttribute(
                    "aria-hidden",
                    "true"
                );
            }
        });

        modal.classList.remove("slt-hidden");
        modal.classList.add("slt-modal-open");

        modal.setAttribute(
            "aria-hidden",
            "false"
        );

        document.body.classList.add(
            "slt-modal-active"
        );

        const firstInput = modal.querySelector(
            'input:not([disabled]), ' +
            'select:not([disabled]), ' +
            'textarea:not([disabled]), ' +
            'button:not([disabled])'
        );

        if (firstInput) {
            requestAnimationFrame(function () {
                firstInput.focus();
            });
        }

        return true;
    };

    window.sltCloseModal = function (id) {
        const modal = findModal(id);

        if (!modal) return false;

        modal.classList.remove(
            "slt-modal-open"
        );

        modal.classList.add(
            "slt-hidden"
        );

        modal.setAttribute(
            "aria-hidden",
            "true"
        );

        if (
            !document.querySelector(
                ".slt-modal.slt-modal-open"
            )
        ) {
            document.body.classList.remove(
                "slt-modal-active"
            );
        }

        return true;
    };

    // ============================================================
    // CLOSE MODAL BUTTONS
    // ============================================================

    document.addEventListener(
        "click",
        function (event) {
            const button = event.target.closest(
                "[data-modal-close]"
            );

            if (!button) return;

            event.preventDefault();

            const modalId = button.getAttribute(
                "data-modal-close"
            );

            if (modalId) {
                window.sltCloseModal(modalId);
            }
        }
    );

    // ============================================================
    // ESCAPE CLOSE
    // ============================================================

    document.addEventListener(
        "keydown",
        function (event) {
            if (event.key !== "Escape") {
                return;
            }

            const modals = document.querySelectorAll(
                ".slt-modal.slt-modal-open"
            );

            if (!modals.length) return;

            window.sltCloseModal(
                modals[modals.length - 1].id
            );
        }
    );

    // ============================================================
    // CLOSE ON BACKDROP CLICK
    // ============================================================

    document.addEventListener(
        "click",
        function (event) {
            const target = event.target;

            if (
                target &&
                target.classList &&
                target.classList.contains(
                    "slt-modal"
                ) &&
                target.classList.contains(
                    "slt-modal-open"
                )
            ) {
                window.sltCloseModal(target.id);
            }
        }
    );

    console.info(
        "[SLT API] Global services initialized.",
        {
            apiBase: base,
            dateFormatting: true,
            modals: true,
            notifications: true,
            sessionValidation: true
        }
    );

})();
