
(function () {
    "use strict";

    // ============================================================
    // SLT GLOBAL API SERVICES
    // ============================================================

    const config = window.SLT_CONFIG || {};

    const base = String(
        config.API_BASE || "/api"
    ).replace(/\/+$/, "");

    const ADMIN_TOKEN_KEY = "slt_admin_token";
    const ADMIN_EMAIL_KEY = "slt_admin_email";

    const ADMIN_PATHS = [
        "guests",
        "phases",
        "admins",
        "blur-icons",
        "help-support",
        "day-schedules",
        "airport-transfers",
        "guest-event-drivers",
        "email-templates",
        "weather-forecasts"
    ];

    // ============================================================
    // GENERAL HELPERS
    // ============================================================

    function normalizePath(path) {
        const value = String(path || "");

        if (!value) {
            throw new Error("API path is required.");
        }

        return value.startsWith("/")
            ? value
            : "/" + value;
    }

    window.sltEscape = function (value) {
        return String(value == null ? "" : value)
            .replace(/[&<>"']/g, function (character) {
                return {
                    "&": "&amp;",
                    "<": "&lt;",
                    ">": "&gt;",
                    '"': "&quot;",
                    "'": "&#39;"
                }[character];
            });
    };

    // ============================================================
    // GLOBAL DATE FORMATTING
    // ============================================================

    window.sltFormatDate = function (
        value,
        options = {}
    ) {
        if (!value) return "—";

        try {
            let dateValue = String(value).trim();

            const useUtc = options.utc === true;

            // ASP.NET Web API can serialize UTC DateTime
            // values without a timezone suffix.
            //
            // Append Z only when explicitly formatting
            // a timestamp that is known to be UTC.

            if (
                useUtc &&
                /^\d{4}-\d{2}-\d{2}T/.test(dateValue) &&
                !/(Z|[+-]\d{2}:\d{2})$/i.test(dateValue)
            ) {
                dateValue += "Z";
            }

            const date = new Date(dateValue);

            if (Number.isNaN(date.getTime())) {
                return "—";
            }

            const formatter = new Intl.DateTimeFormat(
                "en-GB",
                {
                    day: "2-digit",
                    month: "short",
                    year: "numeric",
                    hour: "2-digit",
                    minute: "2-digit",
                    hour12: true,
                    timeZone: useUtc
                        ? "UTC"
                        : "Africa/Cairo"
                }
            );

            return formatter.format(date)
                .replace(/\bam\b/i, "AM")
                .replace(/\bpm\b/i, "PM");

        } catch (error) {
            console.warn(
                "[SLT Date] Formatting failed:",
                error
            );

            return "—";
        }
    };

    window.sltFormatDateOnly = function (value) {
        if (!value) return "—";

        try {
            const datePart = String(value).slice(0, 10);

            const match = /^(\d{4})-(\d{2})-(\d{2})$/
                .exec(datePart);

            if (!match) return "—";

            const year = Number(match[1]);
            const month = Number(match[2]);
            const day = Number(match[3]);

            const date = new Date(
                Date.UTC(year, month - 1, day)
            );

            // Reject invalid calendar dates.
            if (
                date.getUTCFullYear() !== year ||
                date.getUTCMonth() !== month - 1 ||
                date.getUTCDate() !== day
            ) {
                return "—";
            }

            return new Intl.DateTimeFormat(
                "en-GB",
                {
                    day: "2-digit",
                    month: "short",
                    year: "numeric",
                    timeZone: "UTC"
                }
            ).format(date);

        } catch (error) {
            console.warn(
                "[SLT Date] Date-only formatting failed:",
                error
            );

            return "—";
        }
    };

    // ============================================================
    // ADMIN TOKEN MANAGEMENT
    // ============================================================

    window.sltGetAdminToken = function () {
        try {
            return localStorage.getItem(
                ADMIN_TOKEN_KEY
            );
        } catch (error) {
            return null;
        }
    };

    window.sltSetAdminToken = function (token) {
        if (!token) {
            throw new Error(
                "Administrator token is required."
            );
        }

        localStorage.setItem(
            ADMIN_TOKEN_KEY,
            String(token)
        );
    };

    window.sltClearAdminToken = function () {
        localStorage.removeItem(
            ADMIN_TOKEN_KEY
        );
    };

    window.sltClearAdminSession = function () {
        window.sltClearAdminToken();

        localStorage.removeItem(
            ADMIN_EMAIL_KEY
        );

        sessionStorage.removeItem(
            ADMIN_EMAIL_KEY
        );
    };

    // ============================================================
    // API REQUEST HANDLER
    // ============================================================

    window.sltRequest = async function (
        path,
        options
    ) {
        options = options || {};

        const requestPath = normalizePath(path);

        const headers = Object.assign(
            {},
            options.headers || {}
        );

        const firstSegment = requestPath
            .split("?")[0]
            .split("/")
            .filter(Boolean)[0] || "";

        const requiresAdmin =
            ADMIN_PATHS.includes(firstSegment) ||
            requestPath === "/admin-auth/me";

        if (
            requiresAdmin &&
            !headers.Authorization
        ) {
            const token = window.sltGetAdminToken();

            if (token) {
                headers.Authorization =
                    "Bearer " + token;
            }
        }

        const hasBody =
            options.body !== undefined &&
            options.body !== null;

        const isFormData =
            hasBody &&
            typeof FormData !== "undefined" &&
            options.body instanceof FormData;

        if (
            hasBody &&
            !isFormData &&
            !headers["Content-Type"] &&
            !headers["content-type"]
        ) {
            headers["Content-Type"] =
                "application/json";
        }

        const requestOptions = {
            method: options.method || "GET",
            headers: headers,
            credentials: "omit",
            cache: "no-store"
        };

        if (hasBody) {
            requestOptions.body = options.body;
        }

        if (options.signal) {
            requestOptions.signal = options.signal;
        }

        let response;

        try {
            response = await fetch(
                base + requestPath,
                requestOptions
            );
        } catch (networkError) {
            console.error(
                "[SLT API] Network error:",
                networkError
            );

            const error = new Error(
                "Cannot connect to the server. " +
                "Please check the connection and retry."
            );

            error.status = 0;
            error.isNetworkError = true;

            // Preserve the admin token on network errors.
            throw error;
        }

        // ========================================================
        // HTTP ERROR HANDLING
        // ========================================================

        if (!response.ok) {
            let message =
                "HTTP " + response.status;

            try {
                const contentType =
                    response.headers.get(
                        "content-type"
                    ) || "";

                if (
                    contentType.includes(
                        "application/json"
                    )
                ) {
                    const data = await response.json();

                    message =
                        data.errorMessage ||
                        data.ExceptionMessage ||
                        data.Message ||
                        data.message ||
                        (
                            data.ModelState
                                ? Object.values(
                                    data.ModelState
                                ).flat().join(" ")
                                : ""
                        ) ||
                        message;

                } else {
                    const text = await response.text();

                    if (
                        text &&
                        text.length < 500
                    ) {
                        message = text;
                    }
                }
            } catch (parseError) {
                console.warn(
                    "[SLT API] Error parsing failed:",
                    parseError
                );
            }

            const error = new Error(message);

            error.status = response.status;
            error.url = requestPath;
            error.isNetworkError = false;

            console.warn(
                "[SLT API] Request failed:",
                {
                    path: requestPath,
                    status: response.status,
                    message: message
                }
            );

            throw error;
        }

        // ========================================================
        // SUCCESS RESPONSE
        // ========================================================

        if (response.status === 204) {
            return null;
        }

        const contentType =
            response.headers.get(
                "content-type"
            ) || "";

        if (
            contentType.includes(
                "application/json"
            )
        ) {
            return response.json();
        }

        if (
            contentType.includes("image/") ||
            contentType.includes(
                "application/octet-stream"
            ) ||
            contentType.includes(
                "application/pdf"
            )
        ) {
            return response.blob();
        }

        return response.text();
    };

    // ============================================================
    // FILE DOWNLOAD
    // ============================================================

    window.sltDownload = function (
        data,
        filename,
        type
    ) {
        const blob = data instanceof Blob
            ? data
            : new Blob(
                [data],
                {
                    type: type ||
                        "application/octet-stream"
                }
            );

        const url = URL.createObjectURL(blob);

        const link = document.createElement("a");

        link.href = url;
        link.download = filename || "download";

        document.body.appendChild(link);

        link.click();
        link.remove();

        setTimeout(function () {
            URL.revokeObjectURL(url);
        }, 2000);
    };

    // ============================================================
    // ADMIN SESSION VALIDATION
    // ============================================================

    window.sltRequireAdmin = async function () {
        const token = window.sltGetAdminToken();

        if (!token) {
            window.location.replace(
                "admin-login.html"
            );

            return false;
        }

        try {
            await window.sltRequest(
                "/admin-auth/me"
            );

            return true;

        } catch (error) {
            console.warn(
                "[SLT Admin] Session validation failed:",
                error
            );

            if (error.status === 401) {
                window.sltClearAdminSession();

                window.location.replace(
                    "admin-login.html"
                );

                return false;
            }

            window.sltNotify(
                "Unable to verify your administrator session. " +
                "Please check the connection and retry.",
                "error"
            );

            return false;
        }
    };

    // ============================================================
    // GLOBAL SWEETALERT NOTIFICATIONS
    // ============================================================

    window.sltNotify = function (
        message,
        type = "success"
    ) {
        const validTypes = [
            "success",
            "error",
            "warning",
            "info"
        ];

        const icon = validTypes.includes(type)
            ? type
            : "info";

        const text = String(
            message || ""
        );

        if (window.Swal) {
            return window.Swal.fire({
                toast: true,
                position: "top-end",
                icon: icon,
                title: text,
                showConfirmButton: false,
                timer: icon === "error"
                    ? 5000
                    : 3200,
                timerProgressBar: true,
                background: "#ffffff",
                color: "#252838",
                confirmButtonColor: "#c8102e"
            });
        }

        console[
            icon === "error" ? "error" : "log"
        ]("[SLT " + icon + "]", text);

        return Promise.resolve();
    };

    // ============================================================
    // GLOBAL CONFIRMATIONS
    // ============================================================

    window.sltConfirm = async function (message) {
        if (window.Swal) {
            const result = await window.Swal.fire({
                title: "Please confirm",
                text: String(message || ""),
                icon: "question",
                showCancelButton: true,
                confirmButtonText: "Yes, continue",
                cancelButtonText: "Cancel",
                confirmButtonColor: "#c8102e",
                cancelButtonColor: "#7b8290",
                background: "#ffffff",
                color: "#252838",
                reverseButtons: true
            });

            return result.isConfirmed;
        }

        return window.confirm(
            String(message || "")
        );
    };

    // ============================================================
    // GLOBAL MODAL MANAGEMENT
    // ============================================================

    function findModal(id) {
        const modal = document.getElementById(id);

        if (!modal) {
            console.error(
                "[SLT Modal] Modal not found:",
                id
            );
        }

        return modal;
    }

    window.sltOpenModal = function (id) {
        const modal = findModal(id);

        if (!modal) return false;

        // Close other open modals.
        document.querySelectorAll(
            ".slt-modal.slt-modal-open"
        ).forEach(function (other) {
            if (other !== modal) {
                other.classList.remove(
                    "slt-modal-open"
                );

                other.classList.add(
                    "slt-hidden"
                );

                other.setAttribute(
                    "aria-hidden",
                    "true"
                );
            }
        });

        modal.classList.remove("slt-hidden");
        modal.classList.add("slt-modal-open");

        modal.setAttribute(
            "aria-hidden",
            "false"
        );

        document.body.classList.add(
            "slt-modal-active"
        );

        const firstInput = modal.querySelector(
            'input:not([disabled]), ' +
            'select:not([disabled]), ' +
            'textarea:not([disabled]), ' +
            'button:not([disabled])'
        );

        if (firstInput) {
            requestAnimationFrame(function () {
                firstInput.focus();
            });
        }

        return true;
    };

    window.sltCloseModal = function (id) {
        const modal = findModal(id);

        if (!modal) return false;

        modal.classList.remove(
            "slt-modal-open"
        );

        modal.classList.add(
            "slt-hidden"
        );

        modal.setAttribute(
            "aria-hidden",
            "true"
        );

        if (
            !document.querySelector(
                ".slt-modal.slt-modal-open"
            )
        ) {
            document.body.classList.remove(
                "slt-modal-active"
            );
        }

        return true;
    };

    // ============================================================
    // CLOSE MODAL BUTTONS
    // ============================================================

    document.addEventListener(
        "click",
        function (event) {
            const button = event.target.closest(
                "[data-modal-close]"
            );

            if (!button) return;

            event.preventDefault();

            const modalId = button.getAttribute(
                "data-modal-close"
            );

            if (modalId) {
                window.sltCloseModal(modalId);
            }
        }
    );

    // ============================================================
    // ESCAPE CLOSE
    // ============================================================

    document.addEventListener(
        "keydown",
        function (event) {
            if (event.key !== "Escape") {
                return;
            }

            const modals = document.querySelectorAll(
                ".slt-modal.slt-modal-open"
            );

            if (!modals.length) return;

            window.sltCloseModal(
                modals[modals.length - 1].id
            );
        }
    );

    // ============================================================
    // CLOSE ON BACKDROP CLICK
    // ============================================================

    document.addEventListener(
        "click",
        function (event) {
            const target = event.target;

            if (
                target &&
                target.classList &&
                target.classList.contains(
                    "slt-modal"
                ) &&
                target.classList.contains(
                    "slt-modal-open"
                )
            ) {
                window.sltCloseModal(target.id);
            }
        }
    );

    console.info(
        "[SLT API] Global services initialized.",
        {
            apiBase: base,
            dateFormatting: true,
            modals: true,
            notifications: true,
            sessionValidation: true
        }
    );

})();
