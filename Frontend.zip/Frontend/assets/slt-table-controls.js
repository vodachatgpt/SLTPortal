/* Shared controls for Guests, Airport Transfers, Day Schedules and Event Drivers. */
(function () {
  'use strict';
  window.sltCreateTableControls = function (resource, toolbarSelector, tableSelector, onChange) {
    const toolbar = document.querySelector(toolbarSelector);
    const table = document.querySelector(tableSelector);
    if (!toolbar || !table) throw new Error('Missing table control target: ' + resource);
    let page = 1, total = 0, totalPages = 0;
    const filterSpecs = {
      'guests': [['Email','Email'],['Hotel','Hotel'],['Activated','Login', ['','true','false']],['TourRegister','Tour', ['','true','false']],['From','Arrival from','date'],['To','Arrival to','date']],
      'airport-transfers': [['Email','Email'],['Type','Type'],['Driver','Driver'],['From','From','date'],['To','To','date']],
      'day-schedules': [['Type','Type'],['From','From','date'],['To','To','date']],
      'guest-event-drivers': [['Email','Email'],['Driver','Driver'],['DayScheduleId','Schedule ID','number'],['From','From','date'],['To','To','date']]
    };
    const root = document.createElement('div');
    root.className = 'slt-data-filters';
    for (const spec of (filterSpecs[resource] || [])) {
      const label = document.createElement('label');
      label.textContent = spec[1];
      let input;
      if (Array.isArray(spec[2])) {
        input = document.createElement('select');
        for (const value of spec[2]) {
          const opt = document.createElement('option'); opt.value = value;
          opt.textContent = value === '' ? 'All' : value === 'true' ? 'Yes' : 'No';
          input.appendChild(opt);
        }
      } else { input = document.createElement('input'); input.type = spec[2] || 'search'; input.placeholder = spec[1]; }
      input.dataset.sltFilter = spec[0];
      label.appendChild(input); root.appendChild(label);
    }
    const pageSizeLabel = document.createElement('label');
    pageSizeLabel.textContent = 'Rows per page';
    const pageSizeSelect = document.createElement('select'); pageSizeSelect.dataset.sltFilter = 'PageSize';
    [10,20,50,100].forEach(n => {const opt=document.createElement('option');opt.value=n;opt.textContent=n;if(n===20)opt.selected=true;pageSizeSelect.appendChild(opt);});
    pageSizeLabel.appendChild(pageSizeSelect); root.appendChild(pageSizeLabel);
    const button = document.createElement('button'); button.type='button';button.className='slt-btn slt-secondary';
    button.textContent='Export filtered Excel'; button.addEventListener('click', exportFiltered);
    root.appendChild(button); toolbar.appendChild(root);
    const footer = document.createElement('div'); footer.className='slt-paging';
    const previous=document.createElement('button');previous.type='button';previous.textContent='Previous';previous.className='slt-btn slt-secondary';
    const next=document.createElement('button');next.type='button';next.textContent='Next';next.className='slt-btn slt-secondary';
    const label=document.createElement('span'); label.setAttribute('aria-live','polite');
    footer.append(previous,label,next);table.parentElement.insertAdjacentElement('afterend',footer);
    const searchInput = document.getElementById('search');
    function query(withPage=true) {
      const params=new URLSearchParams();
      if (withPage) params.set('Page',page);params.set('PageSize',pageSizeSelect.value);
      if(searchInput && searchInput.value.trim())params.set('Search',searchInput.value.trim());
      root.querySelectorAll('[data-slt-filter]').forEach(el=>{
        if(el.dataset.sltFilter!=='PageSize' && el.value.trim())params.set(el.dataset.sltFilter,el.value.trim());
      });
      return params.toString();
    }
    function notifyChanged(){page=1;onChange();}
    let debounce;
    root.addEventListener('input',()=>{clearTimeout(debounce);debounce=setTimeout(notifyChanged,350);});
    root.addEventListener('change',notifyChanged);
    if(searchInput) {
      searchInput.addEventListener('input',()=>{clearTimeout(debounce);debounce=setTimeout(notifyChanged,350);});
    }
    previous.addEventListener('click',()=>{if(page>1){page--;onChange();}});
    next.addEventListener('click',()=>{if(page<totalPages){page++;onChange();}});
    function setResult(data){
      total = Number(data.Total||0); totalPages = Number(data.TotalPages||0);
      page=Number(data.Page||page);
      label.textContent=`Page ${page} of ${Math.max(totalPages,1)} · ${total.toLocaleString()} records`;
      previous.disabled=page<=1;next.disabled=page>=totalPages;
    }
    async function exportFiltered(){
      button.disabled=true;
      try{
        const base=(window.SLT_CONFIG.API_BASE||'/api').replace(/\/+$/,'');
        const token=localStorage.getItem('slt_admin_token');
        const res=await fetch(`${base}/${resource}/export?${query(false)}`,{
          headers:token?{Authorization:'Bearer '+token}:{},cache:'no-store'});
        if(!res.ok){let d;try{d=await res.json();}catch(_){d={};}throw new Error(d.Message||'Export failed ('+res.status+')');}
        const blob=await res.blob();window.sltDownload(blob,`SLT_${resource}_filtered.xlsx`,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      }catch(err){window.sltNotify(err.message,'error');}finally{button.disabled=false;}
    }
    return {query,setResult,getTotal:()=>total};
  };
})();
