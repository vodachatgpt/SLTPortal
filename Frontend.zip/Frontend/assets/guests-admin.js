
(function () {
    "use strict";

    const $ = id => document.getElementById(id);

    const fields = [
        ["FullName", "Full Name", "text"],
        ["Email", "Email", "email"],
        ["PhoneNumber", "Phone number (+20...) ", "tel"],
        ["ArrivalDate", "Arrival Date", "date"],
        ["ArrivalFlight", "Arrival Flight", "text"],
        ["LandingTime", "Landing Time", "time"],
        ["DepartureDate", "Departure Date", "date"],
        ["DepartureFlight", "Departure Flight", "text"],
        ["DepartureTime", "Departure Time", "time"],
        ["HotelName", "Hotel Name", "text"],
        ["CheckInDate", "Check-in Date", "date"],
        ["CheckInTime", "Check-in Time", "time"],
        ["CheckOutDate", "Check-out Date", "date"],
        ["CheckOutTime", "Check-out Time", "time"],
        ["TourRegister", "Tour registered", "checkbox"]
    ];

    let guests = [];
    let tableControls = null;
    let editingId = null;
    let qrGuestId = null;
    let importedRows = [];
    let authorized = false;

    let panelTimer = null;
    let rowTimer = null;
    let revealedRowId = null;
    let revealRequestId = 0;
    let tableVersion = 0;

    function escape(value) {
        return sltEscape(
            value == null ? "" : String(value)
        );
    }

    function isSixDigits(value) {
        return typeof value === "string" &&
            /^[0-9]{6}$/.test(value);
    }

    function date(value) {
        return value
            ? String(value).slice(0, 10)
            : "";
    }

    function time(value) {
        return value
            ? String(value).slice(0, 5)
            : "";
    }

    function message(text, error) {
        if (text) sltNotify(text, error ? "error" : "success");
    }

    function emailStatus(result) {
        if (result && result.EmailSent === true) {
            return " Email accepted by Mail API.";
        }

        if (result && result.EmailSent === false) {
            return " Email delivery was not confirmed.";
        }

        return "";
    }

    // ==========================================
    // PASSCODE PANEL: CREATE / RESET
    // ==========================================

    function hidePasscodePanel() {
        if (panelTimer !== null) {
            clearTimeout(panelTimer);
            panelTimer = null;
        }

        $("passcodeValue").textContent = "";

        $("passcodePanel").classList.add(
            "slt-hidden"
        );
        sltCloseModal("passcodeModal");

        $("passcodeTitle").textContent =
            "Generated Guest Passcode";
    }

    function showPasscodePanel(passcode, fullName) {
        if (!isSixDigits(passcode)) {
            throw new Error(
                "Invalid six-digit passcode returned."
            );
        }

        hidePasscodePanel();

        $("passcodeValue").textContent = passcode;

        $("passcodeTitle").textContent =
            fullName
                ? "Passcode for " + fullName
                : "Generated Guest Passcode";

        $("passcodeDescription").textContent =
            "Copy the code securely. " +
            "It will be hidden automatically.";

        $("passcodePanel").classList.remove(
            "slt-hidden"
        );
        sltOpenModal("passcodeModal");

        panelTimer = setTimeout(
            hidePasscodePanel,
            30000
        );
    }

    // ==========================================
    // PASSCODE INSIDE EACH GUEST ROW
    // ==========================================

    function getPasscodeCell(id) {
        return $("guestRows").querySelector(
            '.slt-passcode-cell[data-guest-id="' +
            id + '"]'
        );
    }

    function hideRowPasscode() {
        if (rowTimer !== null) {
            clearTimeout(rowTimer);
            rowTimer = null;
        }

        if (revealedRowId === null) {
            return;
        }

        const cell = getPasscodeCell(
            revealedRowId
        );

        if (cell) {
            const code = cell.querySelector(
                "[data-passcode-value]"
            );

            const button = cell.querySelector(
                'button[data-action="hidepasscode"]'
            );

            if (code) {
                code.textContent = "••••••";

                code.classList.remove(
                    "is-visible"
                );

                code.setAttribute(
                    "aria-label",
                    "Passcode hidden"
                );
            }

            if (button) {
                button.dataset.action =
                    "showpasscode";

                button.textContent =
                    "Show Passcode";

                button.setAttribute(
                    "aria-pressed",
                    "false"
                );
            }
        }

        revealedRowId = null;
    }

    function invalidateReveals() {
        revealRequestId++;
        hideRowPasscode();
    }

    function showRowPasscode(id, passcode) {
        if (!isSixDigits(passcode)) {
            throw new Error(
                "The server returned an invalid passcode."
            );
        }

        hideRowPasscode();

        const cell = getPasscodeCell(id);

        if (!cell) {
            return;
        }

        const code = cell.querySelector(
            "[data-passcode-value]"
        );

        const button = cell.querySelector(
            'button[data-action="showpasscode"]'
        );

        if (!code || !button) {
            return;
        }

        code.textContent = passcode;

        code.classList.add("is-visible");

        code.setAttribute(
            "aria-label",
            "Passcode visible"
        );

        button.dataset.action =
            "hidepasscode";

        button.textContent =
            "Hide Passcode";

        button.setAttribute(
            "aria-pressed",
            "true"
        );

        revealedRowId = id;

        rowTimer = setTimeout(
            hideRowPasscode,
            30000
        );
    }

    async function revealGuestPasscode(id, guest) {
        invalidateReveals();

        const requestId = revealRequestId;
        const version = tableVersion;

        const result = await sltRequest(
            "/guests/" + id + "/passcode"
        );

        // Ignore responses that arrive after the
        // table changes or the page is hidden.
        if (
            requestId !== revealRequestId ||
            version !== tableVersion ||
            document.hidden
        ) {
            return;
        }

        if (!result || !isSixDigits(result.Passcode)) {
            throw new Error(
                "The full passcode could not be retrieved."
            );
        }

        showRowPasscode(
            id,
            result.Passcode
        );

        message(
            "Passcode shown for " +
            guest.FullName +
            ". This action was recorded in the audit log."
        );
    }

    // ==========================================
    // GENERATE FORM FIELDS
    // ==========================================

    $("guestFields").innerHTML = fields.map(
        function (field) {
            const name = field[0];
            const label = field[1];
            const type = field[2];

            const required =
                name === "FullName" ||
                name === "Email";

            return `
                <label class="${type === "checkbox" ? "slt-check-label" : ""}">
                    ${escape(label)}

                    <input
                        name="${name}"
                        type="${type}"
                        ${required ? "required" : ""}
                        autocomplete="off">
                </label>
            `;
        }
    ).join("");

    function clearForm() {
        editingId = null;

        $("guestForm").reset();

        $("formTitle").textContent =
            "Create Guest";

        $("saveGuestButton").textContent =
            "Create Guest";

        $("guestForm").elements
            .FullName.required = true;

        $("guestForm").elements
            .Email.required = true;
    }

    function getFormData() {
        const result = {};

        fields.forEach(function (field) {
            const name = field[0];

            const element = $("guestForm").elements[name];
            if (field[2] === "checkbox") {
                result[name] = element.checked;
                return;
            }
            const value = element.value.trim();

            if (value !== "") {
                result[name] = value;
            }
        });

        return result;
    }

    function editGuest(guest) {
        editingId = Number(guest.Id);

        $("formTitle").textContent =
            "Edit Guest #" + editingId;

        $("saveGuestButton").textContent =
            "Update Guest";

        $("guestForm").elements
            .FullName.required = false;

        $("guestForm").elements
            .Email.required = false;

        fields.forEach(function (field) {
            const name = field[0];
            const type = field[2];

            let value = guest[name] ?? "";

            if (type === "date") {
                value = date(value);
            }

            if (type === "time") {
                value = time(value);
            }

            if (type === "checkbox") {
                $("guestForm").elements[name].checked = value === true;
            } else {
                $("guestForm").elements[name].value = value;
            }
        });

        sltOpenModal("guestModal");
    }

    // ==========================================
    // TABLE HELPERS
    // ==========================================

    function statusBadge(
        isActive,
        positive,
        negative
    ) {
        const className = isActive
            ? "slt-status-success"
            : "slt-status-warning";

        return `
            <span class="slt-status ${className}">
                ${isActive ? positive : negative}
            </span>
        `;
    }

    function actionButton(
        id,
        action,
        text,
        disabled
    ) {
        return `
            <button
                type="button"
                data-id="${id}"
                data-action="${action}"
                ${disabled ? "disabled" : ""}>
                ${escape(text)}
            </button>
        `;
    }

    // ==========================================
    // RENDER GUESTS
    // ==========================================

    function render() {
        invalidateReveals();
        tableVersion++;

        const search =
            $("search").value
                .trim()
                .toLowerCase();

        const filtered = guests;

        $("guestCount").textContent =
            (tableControls ? tableControls.getTotal() : guests.length) +
            " matching guest(s)";

        if (filtered.length === 0) {
            $("guestRows").innerHTML = `
                <tr>
                    <td
                        colspan="10"
                        class="slt-empty-state">
                        No guests found.
                    </td>
                </tr>
            `;

            return;
        }

        $("guestRows").innerHTML =
            filtered.map(function (guest) {
                const id = Number(guest.Id);

                const canReveal =
                    guest.CanRevealPasscode === true;

                const passcodeCell = `
                    <div
                        class="slt-passcode-cell"
                        data-guest-id="${id}">

                        <code
                            data-passcode-value
                            aria-label="Passcode hidden"
                        >••••••</code>

                        <button
                            type="button"
                            data-id="${id}"
                            data-action="showpasscode"
                            aria-pressed="false"
                            ${canReveal ? "" : "disabled"}>
                            Show Passcode
                        </button>

                        ${!canReveal
                        ? `<small>
                                Reset required
                               </small>`
                        : ""}
                    </div>
                `;

                const actions = [
                    actionButton(
                        id,
                        "edit",
                        "Edit",
                        false
                    ),

                    actionButton(
                        id,
                        "uploadqr",
                        guest.HasQR
                            ? "Replace QR"
                            : "Upload QR",
                        false
                    ),

                    actionButton(
                        id,
                        "viewqr",
                        "View QR",
                        !guest.HasQR
                    ),

                    actionButton(
                        id,
                        "removeqr",
                        "Remove QR",
                        !guest.HasQR
                    ),

                    actionButton(
                        id,
                        "reset",
                        "Reset Passcode",
                        false
                    ),

                    actionButton(
                        id,
                        "delete",
                        "Delete",
                        false
                    )
                ].join("");

                return `
                    <tr>
                        <td>
                            <span class="slt-guest-name">
                                ${escape(guest.FullName)}
                            </span>
                        </td>

                        <td>
                            ${escape(guest.Email)}
                        </td>
                        <td>${escape(guest.PhoneNumber || "—")}</td>

                        <td>
                            ${escape(
                    date(guest.ArrivalDate) || "—"
                )}
                        </td>

                        <td>
                            ${escape(
                    guest.HotelName || "—"
                )}
                        </td>

                        <td>${statusBadge(guest.TourRegister === true, "Registered", "Not registered")}</td>

                        <!-- LOGIN STATUS -->
                        <td>
                            ${statusBadge(
                    guest.Activated,
                    "Activated",
                    "Not Activated"
                )}
                        </td>

                        <!-- FULL GUEST PASSCODE -->
                        <td>
                            ${passcodeCell}
                        </td>

                        <!-- QR STATUS -->
                        <td>
                            ${statusBadge(
                    guest.HasQR,
                    "Uploaded",
                    "Missing"
                )}
                        </td>

                        <!-- GUEST ACTIONS -->
                        <td>
                            <div class="slt-row-actions">
                                ${actions}
                            </div>
                        </td>
                    </tr>
                `;
            }).join("");
    }

    // ==========================================
    // LOAD GUEST RECORDS
    // ==========================================

    async function load() {
        invalidateReveals();

        try {
            const response = await sltRequest(
                "/guests/paged?" + tableControls.query()
            );

            // Supports the original array API.
            // Also tolerates a wrapped response.
            const records = Array.isArray(response?.Items)
                ? response.Items : null;
            tableControls.setResult(response);

            if (!records) {
                throw new Error(
                    "Unexpected /guests response format."
                );
            }

            guests = records;

            render();

        } catch (error) {
            message(
                "Unable to load guests: " +
                error.message,
                true
            );
        }
    }

    // ==========================================
    // CREATE / UPDATE
    // ==========================================

    $("guestForm").addEventListener(
        "submit",
        async function (event) {
            event.preventDefault();

            if (!authorized) {
                message(
                    "Admin authorization required.",
                    true
                );
                return;
            }

            const button = $("saveGuestButton");

            button.disabled = true;

            try {
                const input = getFormData();

                if (editingId !== null) {
                    await sltRequest(
                        "/guests/" + editingId,
                        {
                            method: "PUT",
                            body: JSON.stringify(input)
                        }
                    );

                    message(
                        "Guest updated successfully."
                    );

                } else {
                    const result = await sltRequest(
                        "/guests",
                        {
                            method: "POST",
                            body: JSON.stringify(input)
                        }
                    );

                    if (result.Passcode) {
                        showPasscodePanel(
                            result.Passcode,
                            result.Guest?.FullName ||
                            input.FullName
                        );
                    }

                    message(
                        "Guest created successfully." +
                        emailStatus(result),
                        result.EmailSent === false
                    );
                }

                clearForm();
                sltCloseModal("guestModal");
                await load();

            } catch (error) {
                message(error.message, true);

            } finally {
                button.disabled = false;
            }
        }
    );

    // ==========================================
    // GUEST TABLE ACTIONS
    // ==========================================

    $("guestRows").addEventListener(
        "click",
        async function (event) {
            const button = event.target.closest(
                "button[data-action]"
            );

            if (!button || button.disabled) {
                return;
            }

            const id = Number(
                button.dataset.id
            );

            const action =
                button.dataset.action;

            const guest = guests.find(
                g => Number(g.Id) === id
            );

            if (!guest) {
                return;
            }

            button.disabled = true;

            try {
                // --------------------------
                // SHOW PASSCODE
                // --------------------------
                if (action === "showpasscode") {
                    await revealGuestPasscode(
                        id,
                        guest
                    );
                    return;
                }

                // --------------------------
                // HIDE PASSCODE
                // --------------------------
                if (action === "hidepasscode") {
                    invalidateReveals();
                    return;
                }

                // --------------------------
                // EDIT GUEST
                // --------------------------
                if (action === "edit") {
                    editGuest(guest);
                    return;
                }

                // --------------------------
                // SELECT QR UPLOAD
                // --------------------------
                if (action === "uploadqr") {
                    qrGuestId = id;

                    $("qrGuestLabel").textContent =
                        "Upload business QR image for: " +
                        guest.FullName;

                    $("qrUploadButton").disabled =
                        false;

                    $("qrForm").scrollIntoView({
                        behavior: "smooth",
                        block: "center"
                    });

                    return;
                }

                // --------------------------
                // VIEW QR
                // --------------------------
                if (action === "viewqr") {
                    const blob = await sltRequest(
                        "/guests/" + id + "/qr"
                    );

                    const mime =
                        blob.type || "image/png";

                    const extension =
                        mime === "image/jpeg"
                            ? ".jpg"
                            : mime === "image/webp"
                                ? ".webp"
                                : ".png";

                    sltDownload(
                        blob,
                        "guest-" +
                        id +
                        "-qr" +
                        extension,
                        mime
                    );

                    return;
                }

                // --------------------------
                // REMOVE QR
                // --------------------------
                if (action === "removeqr") {
                    if (!await sltConfirm(
                        "Remove QR image for " +
                        guest.FullName +
                        "?"
                    )) { return; }

                    await sltRequest(
                        "/guests/" + id + "/qr",
                        {
                            method: "DELETE"
                        }
                    );

                    message(
                        "QR image removed successfully."
                    );

                    await load();
                    return;
                }

                // --------------------------
                // RESET PASSCODE
                // --------------------------
                if (action === "reset") {
                    if (!await sltConfirm(
                        "Generate a new six-digit passcode " +
                        "for " +
                        guest.FullName +
                        "? This revokes the existing session."
                    )) { return; }

                    invalidateReveals();
                    hidePasscodePanel();

                    const result = await sltRequest(
                        "/guests/" +
                        id +
                        "/reset-passcode",
                        {
                            method: "POST"
                        }
                    );

                    await load();

                    if (result.Passcode) {
                        showPasscodePanel(
                            result.Passcode,
                            guest.FullName
                        );
                    }

                    message(
                        "Passcode reset successfully." +
                        emailStatus(result),
                        result.EmailSent === false
                    );

                    return;
                }

                // --------------------------
                // SOFT DELETE
                // --------------------------
                if (action === "delete") {
                    if (!await sltConfirm(
                        "Soft delete guest " +
                        guest.FullName +
                        "?"
                    )) { return; }

                    invalidateReveals();

                    await sltRequest(
                        "/guests/" + id,
                        {
                            method: "DELETE"
                        }
                    );

                    message(
                        "Guest soft deleted."
                    );

                    await load();
                }

            } catch (error) {
                message(error.message, true);

            } finally {
                // Do not re-enable buttons
                // belonging to a replaced table.
                if (button.isConnected) {
                    button.disabled = false;
                }
            }
        }
    );

    // ==========================================
    // QR IMAGE UPLOAD
    // ==========================================

    $("qrForm").addEventListener(
        "submit",
        async function (event) {
            event.preventDefault();

            if (!qrGuestId) {
                message(
                    "Select a guest first.",
                    true
                );
                return;
            }

            const file =
                $("qrFile").files[0];

            if (!file) {
                message(
                    "Select a QR image.",
                    true
                );
                return;
            }

            if (!/\.(png|jpg|jpeg|webp)$/i.test(
                file.name
            )) {
                message(
                    "Only PNG, JPG, JPEG and WEBP are supported.",
                    true
                );
                return;
            }

            if (file.size > 2 * 1024 * 1024) {
                message(
                    "Maximum QR image size is 2 MB.",
                    true
                );
                return;
            }

            const guestId = qrGuestId;

            const body = new FormData();

            body.append("file", file);

            $("qrUploadButton").disabled = true;

            try {
                await sltRequest(
                    "/guests/" +
                    guestId +
                    "/qr",
                    {
                        method: "POST",
                        body: body
                    }
                );

                $("qrForm").reset();

                qrGuestId = null;

                $("qrGuestLabel").textContent =
                    "Select Upload QR beside a guest below.";

                message(
                    "QR image uploaded successfully."
                );

                await load();

            } catch (error) {
                message(error.message, true);

            } finally {
                $("qrUploadButton").disabled =
                    qrGuestId === null;
            }
        }
    );

    // ==========================================
    // BULK EXCEL UPLOAD
    // ==========================================

    $("excelForm").addEventListener(
        "submit",
        async function (event) {
            event.preventDefault();

            const file =
                $("excelFile").files[0];

            if (!file) {
                return;
            }

            if (!/\.xlsx$/i.test(file.name)) {
                message(
                    "Only XLSX files are supported.",
                    true
                );
                return;
            }

            if (file.size > 5 * 1024 * 1024) {
                message(
                    "Maximum Excel size is 5 MB.",
                    true
                );
                return;
            }

            const body = new FormData();

            body.append("file", file);

            $("excelButton").disabled = true;
            $("exportPasscodes").disabled = true;

            importedRows = [];

            try {
                const response = await sltRequest(
                    "/guests/bulk-upload",
                    {
                        method: "POST",
                        body: body
                    }
                );

                const result =
                    response.result || response;

                importedRows =
                    result.Rows || [];

                $("excelSummary").textContent =
                    "Created: " +
                    (result.Created || 0) +
                    " | Updated: " +
                    (result.Updated || 0);

                $("exportPasscodes").disabled =
                    !importedRows.some(
                        row => isSixDigits(
                            row.Passcode
                        )
                    );

                $("excelForm").reset();

                message(
                    "Excel import completed successfully."
                );

                await load();

            } catch (error) {
                message(
                    "Excel import failed: " +
                    error.message,
                    true
                );

            } finally {
                $("excelButton").disabled =
                    false;
            }
        }
    );

    // ==========================================
    // EXPORT NEW PASSCODES
    // ==========================================

    $("exportPasscodes").addEventListener(
        "click",
        async function () {
            const rows = importedRows.filter(
                row => isSixDigits(
                    row.Passcode
                )
            );

            if (rows.length === 0) {
                message(
                    "No passcodes available for export.",
                    true
                );
                return;
            }

            if (!await sltConfirm(
                "This file contains sensitive guest " +
                "passcodes. Export to a secure location?"
            )) { return; }

            function csvCell(value) {
                let text = String(
                    value == null ? "" : value
                );

                if (/^\s*[=+\-@\t\r]/.test(text)) {
                    text = "'" + text;
                }

                return '"' +
                    text.replace(/"/g, '""') +
                    '"';
            }

            const csv =
                "Email,Passcode\r\n" +
                rows.map(function (row) {
                    return (
                        csvCell(row.Email) +
                        "," +
                        csvCell("'" + row.Passcode)
                    );
                }).join("\r\n");

            sltDownload(
                "\uFEFF" + csv,
                "SLT_New_Guest_Passcodes.csv",
                "text/csv;charset=utf-8"
            );

            message(
                "Passcode export created. " +
                "Keep the file secure."
            );
        }
    );

    // ==========================================
    // COPY GENERATED PASSCODE
    // ==========================================

    $("copyPasscode").addEventListener(
        "click",
        async function () {
            const passcode =
                $("passcodeValue")
                    .textContent
                    .trim();

            if (!isSixDigits(passcode)) {
                message(
                    "No valid passcode to copy.",
                    true
                );
                return;
            }

            try {
                await navigator.clipboard.writeText(
                    passcode
                );

                message(
                    "Passcode copied."
                );

            } catch (error) {
                message(
                    "Clipboard unavailable. Copy manually.",
                    true
                );
            }
        }
    );

    $("closePasscode").addEventListener(
        "click",
        hidePasscodePanel
    );

    // ==========================================
    // OTHER CONTROLS
    // ==========================================

    $("clearForm").addEventListener(
        "click",
        function () { clearForm(); sltCloseModal("guestModal"); }
    );
    $("openGuestModal").addEventListener("click", function () {
        clearForm(); sltOpenModal("guestModal");
    });
    $("passcodeCloseX").addEventListener("click", hidePasscodePanel);

    $("refresh").addEventListener(
        "click",
        load
    );

    // Search/filter changes are handled by shared server-side table controls.

    // Hide credentials when admin switches tabs.
    document.addEventListener(
        "visibilitychange",
        function () {
            if (document.hidden) {
                invalidateReveals();
                hidePasscodePanel();
            }
        }
    );

    // Hide credentials when browser loses focus.
    window.addEventListener(
        "blur",
        function () {
            invalidateReveals();
            hidePasscodePanel();
        }
    );

    window.addEventListener(
        "pagehide",
        function () {
            invalidateReveals();
            hidePasscodePanel();
            importedRows = [];
        }
    );

    // ==========================================
    // INITIALIZATION
    // ==========================================

    async function initialize() {
        try {
            authorized =
                await sltRequireAdmin();

            if (!authorized) {
                return;
            }

            tableControls = window.sltCreateTableControls(
        'guests', '.slt-guest-toolbar', '.slt-table-scroll table', load);

    await load();

        } catch (error) {
            message(
                "Administrator authorization failed: " +
                error.message,
                true
            );
        }
    }

    initialize();

})();
