(function () {
  "use strict";
  var $ = id => document.getElementById(id), tokenKey = "slt_guest_token", qrUrl = null;
  function message(text, error) { $("message").textContent = text || ""; $("message").className = "slt-message" + (error ? " slt-error" : ""); }
  function date(value) { return value ? String(value).slice(0, 10) : "—"; }
  function time(value) { return value ? String(value).slice(0, 5) : "—"; }
  function renderGuest(guest) {
    $("welcomeName").textContent = "Welcome, " + guest.FullName;
    $("expiryText").textContent = "Access expires (UTC): " + (guest.SessionExpiresAt || "—");
    var values = [["Full Name", guest.FullName], ["Email", guest.Email], ["Arrival Date",date(guest.ArrivalDate)], ["Arrival Flight",guest.ArrivalFlight], ["Landing Time",time(guest.LandingTime)], ["Departure Date",date(guest.DepartureDate)], ["Departure Flight",guest.DepartureFlight], ["Departure Time",time(guest.DepartureTime)], ["Hotel",guest.HotelName], ["Check-in Date",date(guest.CheckInDate)], ["Check-in Time",time(guest.CheckInTime)], ["Check-out Date",date(guest.CheckOutDate)], ["Check-out Time",time(guest.CheckOutTime)]];
    $("guestDetails").innerHTML = values.map(function (entry) { return '<div class="slt-detail"><small>' + sltEscape(entry[0]) + '</small><strong>' + sltEscape(entry[1] || "—") + '</strong></div>'; }).join("");
  }
  async function loadGuest() {
    var token = localStorage.getItem(tokenKey); if (!token) return;
    var auth = {headers: {Authorization: "Bearer " + token}};
    try {
      var guest = await sltRequest("/guest-auth/me", auth);
      renderGuest(guest);
      $("loginSection").classList.add("slt-hidden"); $("profileSection").classList.remove("slt-hidden");
      if (qrUrl) { URL.revokeObjectURL(qrUrl); qrUrl = null; }
      $("guestQr").classList.add("slt-hidden"); $("qrMessage").textContent = "No QR image has been uploaded yet.";
      if (guest.HasQR) {
        try { var image = await sltRequest("/guest-auth/my-qr", auth); qrUrl = URL.createObjectURL(image); $("guestQr").src = qrUrl; $("guestQr").classList.remove("slt-hidden"); $("qrMessage").textContent = "QR image provided by the business team."; }
        catch (_) { $("qrMessage").textContent = "QR image is currently unavailable."; }
      }
      message("");
    } catch (_) { localStorage.removeItem(tokenKey); $("loginSection").classList.remove("slt-hidden"); $("profileSection").classList.add("slt-hidden"); message("Session unavailable. If your passcode was already used, contact an administrator.", true); }
  }
  $("loginForm").addEventListener("submit", async function (event) {
    event.preventDefault(); $("loginButton").disabled = true; message("");
    try { var result = await sltRequest("/guest-auth/login", {method:"POST", body:JSON.stringify({Passcode:$("passcode").value.trim()})}); localStorage.setItem(tokenKey, result.Token); $("passcode").value = ""; await loadGuest(); }
    catch (error) { message(error.message, true); }
    finally { $("loginButton").disabled = false; }
  });
  loadGuest();
})();
