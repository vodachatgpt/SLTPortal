
(async function () {
    "use strict";

    // ============================================================
    // SLT ADMINISTRATOR MANAGEMENT
    // ============================================================

    const $ = id => document.getElementById(id);

    if (!await sltRequireAdmin()) {
        return;
    }

    let admins = [];
    let editingId = null;
    let currentPassword = "";

    // ============================================================
    // FORM HELPERS
    // ============================================================

    function clear() {
        editingId = null;

        $("adminForm").reset();

        $("formTitle").textContent =
            "Create Administrator";
    }

    function showPassword(password) {
        if (!password) {
            return;
        }

        currentPassword = String(password);

        $("passcode").textContent = currentPassword;

        $("passcodePanel").classList.remove(
            "slt-hidden"
        );

        sltOpenModal("adminPasscodeModal");
    }

    function hidePassword() {
        currentPassword = "";

        $("passcode").textContent = "";

        $("passcodePanel").classList.add(
            "slt-hidden"
        );

        sltCloseModal("adminPasscodeModal");
    }

    // ============================================================
    // DATE FORMATTING
    // ============================================================

    function formatSessionExpiry(value) {
        if (!value) {
            return "—";
        }

        return sltFormatDate(value, {
            utc: true
        });
    }

    // ============================================================
    // ADMINISTRATORS TABLE
    // ============================================================

    async function load() {
        const rows = $("adminRows");

        try {
            const response = await sltRequest(
                "/admins"
            );

            admins = Array.isArray(response)
                ? response
                : (
                    response.Records ||
                    response.Result ||
                    response.Data ||
                    []
                );

            if (!admins.length) {
                rows.innerHTML = `
                    <tr>
                        <td colspan="5"
                            class="slt-empty-state">
                            No administrators found.
                        </td>
                    </tr>
                `;

                return;
            }

            rows.innerHTML = admins.map(function (admin) {

                const id = Number(admin.Id);

                const fullName = sltEscape(
                    admin.FullName || "—"
                );

                const email = sltEscape(
                    admin.Email || "—"
                );

                const activated =
                    admin.Activated === true;

                const expiry = sltEscape(
                    formatSessionExpiry(
                        admin.SessionExpiresAt
                    )
                );

                return `
                    <tr>

                        <td>
                            <span class="slt-guest-name">
                                ${fullName}
                            </span>
                        </td>

                        <td>
                            ${email}
                        </td>

                        <td>
                            <span class="slt-admin-status
                                ${activated
                                    ? "slt-status-active"
                                    : "slt-status-inactive"
                                }">
                                ${activated
                                    ? "Activated"
                                    : "Not Activated"
                                }
                            </span>
                        </td>

                        <td>
                            <span
                                class="slt-admin-expiry"
                                title="Session expiration in UTC">
                                ${expiry}
                            </span>
                        </td>

                        <td>
                            <div class="slt-row-actions">

                                <button
                                    type="button"
                                    data-id="${id}"
                                    data-action="edit">
                                    Edit
                                </button>

                                <button
                                    type="button"
                                    data-id="${id}"
                                    data-action="reset">
                                    Reset Password
                                </button>

                                <button
                                    type="button"
                                    data-id="${id}"
                                    data-action="delete">
                                    Delete
                                </button>

                            </div>
                        </td>

                    </tr>
                `;
            }).join("");

        } catch (error) {
            console.error(
                "[SLT Admins] Load failed:",
                error
            );

            sltNotify(
                error.message ||
                "Unable to load administrators.",
                "error"
            );
        }
    }

    // ============================================================
    // OPEN CREATE MODAL
    // ============================================================

    $("openAdminModal").onclick = function () {
        clear();

        sltOpenModal("adminModal");
    };

    // ============================================================
    // CANCEL CREATE / EDIT
    // ============================================================

    $("clear").onclick = function () {
        clear();

        sltCloseModal("adminModal");
    };

    // ============================================================
    // CREATE / UPDATE ADMINISTRATOR
    // ============================================================

    $("adminForm").onsubmit = async function (event) {
        event.preventDefault();

        const input = {
            FullName: $("fullName").value.trim(),
            Email: $("email").value.trim()
        };

        const submit = event.submitter;

        if (submit) {
            submit.disabled = true;
        }

        try {
            if (editingId !== null) {

                await sltRequest(
                    "/admins/" + editingId,
                    {
                        method: "PUT",
                        body: JSON.stringify(input)
                    }
                );

                sltNotify(
                    "Administrator updated successfully."
                );

            } else {

                const response = await sltRequest(
                    "/admins",
                    {
                        method: "POST",
                        body: JSON.stringify(input)
                    }
                );

                sltNotify(
                    "Administrator created successfully."
                );

                // Password is shown only after
                // successful creation.
                if (response && response.Passcode) {
                    showPassword(
                        response.Passcode
                    );
                }
            }

            clear();

            sltCloseModal("adminModal");

            await load();

        } catch (error) {
            console.error(
                "[SLT Admins] Save failed:",
                error
            );

            sltNotify(
                error.message ||
                "Unable to save administrator.",
                "error"
            );

        } finally {
            if (submit) {
                submit.disabled = false;
            }
        }
    };

    // ============================================================
    // TABLE ACTIONS
    // ============================================================

    $("adminRows").onclick = async function (event) {
        const button = event.target.closest(
            "button[data-action]"
        );

        if (!button) {
            return;
        }

        const id = Number(button.dataset.id);
        const action = button.dataset.action;

        // API IDs may be strings or numbers.
        const admin = admins.find(function (item) {
            return Number(item.Id) === id;
        });

        if (!admin) {
            sltNotify(
                "Administrator record not found.",
                "error"
            );

            return;
        }

        // ========================================================
        // EDIT
        // ========================================================

        if (action === "edit") {
            editingId = id;

            $("fullName").value =
                admin.FullName || "";

            $("email").value =
                admin.Email || "";

            $("formTitle").textContent =
                "Edit Administrator";

            sltOpenModal("adminModal");

            return;
        }

        // ========================================================
        // RESET PASSWORD
        // ========================================================

        if (action === "reset") {
            const confirmed = await sltConfirm(
                "Reset password for " +
                admin.FullName + "?"
            );

            if (!confirmed) {
                return;
            }

            button.disabled = true;

            try {
                const response = await sltRequest(
                    "/admins/" + id +
                    "/reset-passcode",
                    {
                        method: "POST"
                    }
                );

                if (
                    response &&
                    response.Passcode
                ) {
                    showPassword(
                        response.Passcode
                    );
                }

                sltNotify(
                    "Administrator password reset successfully."
                );

                await load();

            } catch (error) {
                console.error(
                    "[SLT Admins] Reset failed:",
                    error
                );

                sltNotify(
                    error.message ||
                    "Unable to reset password.",
                    "error"
                );

            } finally {
                button.disabled = false;
            }

            return;
        }

        // ========================================================
        // DELETE
        // ========================================================

        if (action === "delete") {
            const confirmed = await sltConfirm(
                "Delete administrator " +
                admin.FullName + "?"
            );

            if (!confirmed) {
                return;
            }

            button.disabled = true;

            try {
                await sltRequest(
                    "/admins/" + id,
                    {
                        method: "DELETE"
                    }
                );

                sltNotify(
                    "Administrator deleted successfully."
                );

                await load();

            } catch (error) {
                console.error(
                    "[SLT Admins] Delete failed:",
                    error
                );

                sltNotify(
                    error.message ||
                    "Unable to delete administrator.",
                    "error"
                );

            } finally {
                button.disabled = false;
            }
        }
    };

    // ============================================================
    // REFRESH
    // ============================================================

    $("refresh").onclick = load;

    // ============================================================
    // PASSWORD MODAL
    // ============================================================

    $("hide").onclick = hidePassword;

    $("adminPasscodeCloseX").onclick =
        hidePassword;

    // ============================================================
    // COPY PASSWORD
    // ============================================================

    $("copy").onclick = async function () {
        if (!currentPassword) {
            sltNotify(
                "There is no password to copy.",
                "warning"
            );

            return;
        }

        try {
            await navigator.clipboard.writeText(
                currentPassword
            );

            sltNotify(
                "Password copied successfully."
            );

        } catch (error) {
            sltNotify(
                "Copy failed. Please copy the password manually.",
                "error"
            );
        }
    };

    // ============================================================
    // INITIAL LOAD
    // ============================================================

    await load();

})();
