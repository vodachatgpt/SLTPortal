(function(){
"use strict";
window.sltScheduleAdminInit=async function(){
 const cfg=window.SLT_SCHEDULE_MODULE;
 const $=id=>document.getElementById(id);
 const esc=x=>sltEscape(x==null?'':x);
 const endpoint='/'+cfg.api;
 if(!await sltRequireAdmin()) return;
 let rows=[], editingId=null, scheduleOptions=[], blurbOptions=[];
 let tableControls;
 try { tableControls=window.sltCreateTableControls(cfg.api,'.slt-schedule-filters','.slt-table-scroll table',refresh); }
 catch(err){sltNotify(err.message,'error');return;}
 const formatDate=x=>x?String(x).slice(0,10):'';
 const formatTime=x=>{
   if(x==null)return '';
   if(typeof x==='string')return x.slice(0,5);
   // ASP.NET Web API2 commonly serializes TimeSpan as "HH:mm:ss".
   return '';
 };
 const showValue=(record,key)=>{
   let v=record[key];
   if(v==null || v==='')return '—';
   if(key==='Date')return formatDate(v);
   if(key==='StartTime'||key==='EndTime')return formatTime(v)||'—';
   if(key==='WhatsApp')return v?'Yes':'No';
   if(key==='DayScheduleId'){
     const opt=scheduleOptions.find(x=>String(x.Id)===String(v));
     return esc(String(v))+(opt?' · '+esc(opt.Title):'');
   }
   return esc(v);
 };
 function render(){
   // Results are already filtered and paged on the backend.
   const filtered=rows;
   $('count').textContent=tableControls.getTotal()+' matching records';
   $('recordRows').innerHTML=filtered.length
     ? filtered.map(r=>`<tr>${cfg.columns.map(c=>`<td><span class="slt-compact">${showValue(r,c[0])}</span></td>`).join('')}<td><div class="slt-row-actions"><button data-action="edit" data-id="${r.Id}" type="button">Edit</button><button data-action="delete" data-id="${r.Id}" type="button">Delete</button></div></td></tr>`).join('')
     : `<tr><td colspan="${cfg.columns.length+1}" class="slt-empty-state">No matching records.</td></tr>`;
 }
 async function refresh(){
   try{
     const results=await Promise.all([
       sltRequest('/'+cfg.api+'/paged?'+tableControls.query()),
       cfg.api==='guest-event-drivers'?sltRequest('/day-schedules'):Promise.resolve([]),
       cfg.api==='day-schedules'?sltRequest('/blur-icons'):Promise.resolve([])
     ]);
     const result=results[0];
     rows=Array.isArray(result.Items)?result.Items:[];
     tableControls.setResult(result);
     scheduleOptions=Array.isArray(results[1])?results[1]:[];
     blurbOptions=Array.isArray(results[2])?results[2]:[];
     render();
   }catch(e){sltNotify(e.message,'error');}
 }
 function fieldMarkup(f){
   const [name,label,type,required,choices]=f;
   const attr=required?' required':'';
   let inner='';
   if(type==='select')inner=`<select id="field_${name}"${attr}><option value="">Select…</option>${choices.map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join('')}</select>`;
   else if(type==='blurb')inner=`<select id="field_${name}"><option value="">No icon</option>${blurbOptions.map(x=>`<option value="${esc(x.Name)}">${esc(x.Name)}</option>`).join('')}</select>`;
   else if(type==='schedule') inner=`<select id="field_${name}"${attr}><option value="">Select schedule…</option>${scheduleOptions.map(x=>`<option value="${x.Id}">${esc(x.Id+' · '+formatDate(x.Date)+' · '+x.Title)}</option>`).join('')}</select>`;
   else if(type==='textarea')inner=`<textarea id="field_${name}" rows="3"></textarea>`;
   else if(type==='checkbox')inner=`<input id="field_${name}" type="checkbox">`;
   else inner=`<input id="field_${name}" type="${type}"${attr}${type==='tel'?' autocomplete="off"':''}${type==='email'?' maxlength="320"':''}>`;
   return `<label class="${type==='textarea'?'slt-field-wide':type==='checkbox'?'slt-check-label':''}">${esc(label)}${inner}</label>`;
 }
 function openEditor(record){
   editingId=record?Number(record.Id):null;
   $('editTitle').textContent=(record?'Edit':'Add')+' '+cfg.title;
   $('dynamicFields').innerHTML=cfg.fields.map(fieldMarkup).join('');
   cfg.fields.forEach(f=>{
     const input=$('field_'+f[0]);const value=record?record[f[0]]:null;
     if(f[2]==='checkbox') input.checked=Boolean(value);
     else if(f[2]==='date')input.value=formatDate(value);
     else if(f[2]==='time')input.value=formatTime(value);
     else input.value=value==null?'':String(value);
   });
   sltOpenModal('editModal');
 }
 $('openCreate').onclick=()=>openEditor(null);
 $('refresh').onclick=refresh;
 // Search and paging handled centrally by sltCreateTableControls.
 $('recordRows').addEventListener('click',async e=>{
   const b=e.target.closest('button[data-action]');if(!b)return;
   const record=rows.find(x=>Number(x.Id)===Number(b.dataset.id));if(!record)return;
   if(b.dataset.action==='edit'){openEditor(record);return;}
   if(!await sltConfirm('Soft delete this record? It will no longer appear in the active list.','Delete record'))return;
   b.disabled=true;
   try{await sltRequest(endpoint+'/'+record.Id,{method:'DELETE'});sltNotify('Record deleted.');await refresh();}
   catch(err){sltNotify(err.message,'error');}finally{b.disabled=false;}
 });
 $('recordForm').addEventListener('submit',async e=>{
   e.preventDefault();const submit=$('saveBtn');if(submit.disabled)return;
   const payload={};
   cfg.fields.forEach(f=>{
     const input=$('field_'+f[0]);
     let v=f[2]==='checkbox'?input.checked:input.value.trim();
     if(f[2]==='time')v=v?v+':00':null;
     if(f[2]==='date')v=v?v+'T00:00:00':null;
     if(f[2]==='schedule')v=v?Number(v):0;
     if(v==='' && !f[3])v=null;
     payload[f[0]]=v;
   });
   submit.disabled=true;
   try{
     await sltRequest(endpoint+(editingId?'/'+editingId:''),{method:editingId?'PUT':'POST',body:JSON.stringify(payload)});
     sltCloseModal('editModal');sltNotify(editingId?'Record updated.':'Record created.');await refresh();
   }catch(err){sltNotify(err.message,'error');}finally{submit.disabled=false;}
 });
 // Templates are XLSX binary; use native fetch rather than the shared JSON-only request helper.
 function authHeader(){const token=localStorage.getItem('slt_admin_token');return token?{'Authorization':'Bearer '+token}:{};}
 async function parseError(res){
   const fallback='HTTP '+res.status;
   try{
     const data=await res.json();
     if(data.Errors && data.Errors.length)return data.Errors.slice(0,8).join('\n');
     if(data.ModelState)return Object.values(data.ModelState).flat().join('\n');
     return data.Message||data.errorMessage||data.message||fallback;
   }catch(_){return fallback;}
 }
 async function fetchApi(suffix,options){
   const base=window.SLT_CONFIG.API_BASE.replace(/\/$/,'');
   const res=await fetch(base+endpoint+suffix,Object.assign({headers:authHeader(),credentials:'omit',cache:'no-store'},options||{}));
   if(!res.ok)throw new Error(await parseError(res));
   return res;
 }
 $('downloadTemplate').onclick=async()=>{
   const b=$('downloadTemplate');b.disabled=true;
   try{
     const res=await fetchApi('/template');
     const blob=await res.blob();
     sltDownload(blob,cfg.api+'_Template.xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
   }catch(err){sltNotify(err.message,'error');}finally{b.disabled=false;}
 };
 $('openImport').onclick=()=>{$('importForm').reset();sltOpenModal('importModal');};
 $('importForm').addEventListener('submit',async e=>{
   e.preventDefault();const file=$('excelFile').files[0];if(!file)return;
   if(!/\.xlsx$/i.test(file.name) || file.size>10*1024*1024){sltNotify('Choose an .xlsx file no larger than 10MB.','error');return;}
   const b=$('importBtn');b.disabled=true;
   try{
     const form=new FormData();form.append('file',file,file.name);
     const res=await fetchApi('/import',{method:'POST',body:form});
     const result=await res.json();
     sltCloseModal('importModal');
     sltNotify(`Imported successfully. Inserted: ${result.Inserted||0}, updated: ${result.Updated||0}, skipped: ${result.Skipped||0}.`);
     await refresh();
   }catch(err){sltNotify(err.message,'error');}finally{b.disabled=false;}
 });
 await refresh();
};
})();
