(function () {
'use strict';
const $=id=>document.getElementById(id), ui=window.SLTNotificationUI;
let page=1,totalPages=0,sendKey=null,loadCounter=0;
function auth(path,opts){const token=localStorage.getItem('slt_admin_token');if(!token)throw Error('Administrator login required.');return sltRequest('/slt-notifications/admin/'+path,Object.assign({},opts||{},{headers:Object.assign({},opts&&opts.headers,{Authorization:'Bearer '+token})}));}
function info(msg,err){const el=$('nFeedback');el.textContent=msg;el.dataset.state=err?'error':'success';}
function formatDate(v){if(!v)return '—';return String(v).replace('T',' ').slice(0,16)+' (Egypt time)';}
function formatSelection(prefix,suffix,bullets){const el=$('nMessage');const a=el.selectionStart,b=el.selectionEnd;const old=el.value;
 const selected=old.slice(a,b)||(bullets?'List item':'text');const replacement=bullets?'- '+selected.replace(/\n/g,'\n- '):prefix+selected+suffix;
 el.value=old.slice(0,a)+replacement+old.slice(b);el.focus();el.setSelectionRange(a,a+replacement.length);el.dispatchEvent(new Event('input',{bubbles:true}));}
$('nTarget').onchange=()=>{$('nGuestArea').hidden=$('nTarget').value!=='Guest';sendKey=null;};
function updatePreview(){ $('nPreview').innerHTML=ui.markdown($('nMessage').value||'Start typing to preview your message.');$('nPreviewTitle').textContent=$('nTitle').value.trim()||'Your title appears here';$('nTitleCount').textContent=$('nTitle').value.length+' / 120';$('nMessageCount').textContent=$('nMessage').value.length+' / 4000'; }
$('nTitle').addEventListener('input',updatePreview);
$('nClear').onclick=()=>{$('nSendForm').reset();$('nGuestArea').hidden=true;sendKey=null;updatePreview();info('Draft cleared.');};
let searchTimer;
async function guests(){try{$('nGuestSearchStatus').textContent='Searching guests…';const list=await auth('guests?search='+encodeURIComponent($('nGuestSearch').value.trim()));const prev=$('nGuestId').value;
$('nGuestId').innerHTML='<option value="">Select guest...</option>'+list.map(g=>'<option value="'+g.Id+'">'+ui.esc(g.FullName)+' — '+ui.esc(g.Email)+(g.Registered?'':' (not logged in)')+'</option>').join('');$('nGuestId').value=prev;$('nGuestSearchStatus').textContent=list.length+' guest(s) found';}catch(e){$('nGuestSearchStatus').textContent='Unable to load guests';info(e.message,true);}}
$('nGuestSearch').addEventListener('input',()=>{clearTimeout(searchTimer);searchTimer=setTimeout(guests,300);});
$('nMessage').addEventListener('input',()=>{updatePreview();sendKey=null;});
$('nSendForm').addEventListener('input',()=>{sendKey=null;});
document.querySelectorAll('[data-format]').forEach(b=>b.addEventListener('click',()=>{const f=b.dataset.format;if(f==='bold')formatSelection('**','**',false);else if(f==='italic')formatSelection('*','*',false);else if(f==='underline')formatSelection('__','__',false);else formatSelection('','',true);}));
$('nSendForm').addEventListener('submit',async e=>{e.preventDefault();const button=$('nSend');if(button.disabled)return;
 const target=$('nTarget').value;const title=$('nTitle').value.trim(),message=$('nMessage').value.trim();
 if(!title||!message){info('Enter both a title and a message.',true);return;}if(title.length>120||message.length>4000){info('Title or message is too long.',true);return;}const url=$('nUrl').value.trim();if(url && (!url.startsWith('/')||url.startsWith('//')||/[\\%#]/.test(url)||url.includes('..'))){info('Enter a safe root-relative guest destination.',true);return;}
 const guestId=Number($('nGuestId').value);if(target==='Guest'&&(!Number.isSafeInteger(guestId)||guestId<1)){info('Choose a guest.',true);return;}
 const confirmed=await sltConfirm(target==='All'?'Save and send this message to every registered guest?':'Save and send this message to the selected guest?');if(!confirmed)return;
 if(!sendKey)sendKey=((window.crypto&&crypto.randomUUID)?crypto.randomUUID():'slt-'+Date.now()+'-'+Math.random().toString(36).slice(2));
 button.disabled=true;info('Saving and sending…');try{const payload={TargetType:target,GuestId:target==='Guest'?guestId:null,Title:title,MessageText:message,ClickUrl:$('nUrl').value.trim(),IdempotencyKey:sendKey};
 const r=await auth('send',{method:'POST',body:JSON.stringify(payload)});info('Saved #'+r.NotificationId+' for '+r.RecipientCount+' guest(s). Browser push: '+r.PushStatus+'.');sendKey=null;$('nSendForm').reset();$('nGuestArea').hidden=true;updatePreview();page=1;await refresh();}
 catch(err){info(err.message,true);}finally{button.disabled=false;}});
async function refresh(){const id=++loadCounter;$('nList').innerHTML='<div class="slt-n-empty"><span class="slt-n-spinner"></span> Loading history…</div>';const args='?page='+page+'&pageSize=15&unreadOnly='+$('nUnreadOnly').checked;try{const r=await auth('sent'+args);if(id!==loadCounter)return;
 totalPages=r.TotalPages||0;$('nPage').textContent='Page '+r.Page+' of '+Math.max(totalPages,1)+' · '+r.Total+' messages';$('nUnread').textContent=r.UnreadCount+' unread';
 $('nTotal').textContent=Number(r.Total||0).toLocaleString(); const items=Array.isArray(r.Items)?r.Items:[];$('nList').innerHTML=items.length?items.map(x=>'<article class="slt-n-item '+(x.IsRead?'':'unread')+'"><div class="slt-n-item-head"><strong>'+ui.esc(x.Title)+'</strong><span class="slt-n-badge">'+ui.esc(x.TargetType)+'</span></div><p class="slt-n-muted">'+ui.esc(formatDate(x.CreatedAt))+' · '+ui.esc(x.PushStatus)+'</p><div class="slt-n-body">'+ui.markdown(x.MessageText)+'</div><p class="slt-n-stat">'+ui.esc(x.GuestReadCount)+' of '+ui.esc(x.RecipientCount)+' guests marked read · '+ui.esc(x.CreatedByEmail||'Admin')+'</p>'+(!x.IsRead?'<button type="button" class="slt-n-button" data-read="'+x.NotificationId+'">Mark as read</button>':'<span class="slt-n-muted">Read</span>')+'</article>').join(''):'<div class="slt-n-empty"><strong>Nothing to show yet</strong><p>No notifications match your filter.</p></div>';
 $('nPrev').disabled=page<=1;$('nNext').disabled=page>=totalPages;
 }catch(err){if(id!==loadCounter)return;$('nList').textContent='Unable to load notifications: '+err.message;}}
$('nList').addEventListener('click',async e=>{const b=e.target.closest('[data-read]');if(!b)return;b.disabled=true;try{await auth(b.dataset.read+'/read',{method:'POST'});await refresh();}catch(err){info(err.message,true);b.disabled=false;}});
$('nRefresh').onclick=refresh;$('nPrev').onclick=()=>{if(page>1){page--;refresh();}};$('nNext').onclick=()=>{if(page<totalPages){page++;refresh();}};$('nUnreadOnly').onchange=()=>{page=1;refresh();};
updatePreview();(async()=>{if(!await sltRequireAdmin())return;await guests();await refresh();})();
})();
