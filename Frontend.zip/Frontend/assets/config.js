window.SLT_CONFIG = {
    API_BASE: "https://localhost:44384/api"
};
