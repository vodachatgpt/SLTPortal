window.SLT_CONFIG = {
    API_BASE: "https://localhost:44384/api",
    GLOBAL_PUSH_BASE_URL: "https://pulse.vodafone.com.eg/SPPowers/webpushapi/", // Set to HTTPS Global Push V10.3 service base URL to enable browser alerts.
    GLOBAL_PUSH_APPLICATION_CODE: "SLT_APP"
};
