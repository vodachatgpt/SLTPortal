# SLT Admin — 2026 visual refresh

## What's included
- All administrator pages retain their existing forms and APIs but now use `assets/theme-2026.css` for a consistent premium design.
- Overview (`dashboard.html` + `assets/dashboard.js`) contains **only** 5 statistics and an event carousel. It includes the `FirstLoginAt`-based logged-in metric using `GET /api/guests/statistics/logged-in` (falls back to guest data when the field is present).
- Weather (`weather-admin.html` + `assets/weather-admin.js`) uses `GET /api/weather-forecasts` and is **read-only**. No create/edit/delete endpoints are called.
- The sidebar in `assets/shell.js` is grouped with Overview and Administrators first; Guest Portal is removed.
- Login stores the administrator email only after success so Overview can display a personalized time-based greeting. The login API request remains `Email` + `Passcode`.
- `service-worker.js` is v8 and now fetches updated JS/CSS from the network first, preventing stale page versions.

## Deployment
1. Unzip and replace the *entire* existing `Frontend` folder, including `service-worker.js`, CSS, JS and HTML. Keep `assets/config.js` pointed at your real API URL.
2. Serve the frontend over HTTPS or localhost. Reload the installed PWA. If older pages remain, unregister the old service worker once in DevTools > Application > Service Workers and reload.
3. Log out and sign in again if the greeting displays `Admin`; login now saves `slt_admin_email`.
4. Confirm `GET /api/guests/statistics/logged-in` is present. Otherwise the count can only be shown from guests when their API response contains `FirstLoginAt`.
5. No backend CRUD endpoints were modified.

## Important
This is a frontend-only package. Live API responses could not be tested against your local server here. The weather page describes the existing saved forecasts, not an external live-weather lookup.
