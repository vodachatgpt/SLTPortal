(function () {
    "use strict";

    const $ = id => document.getElementById(id);

    const fields = [
        ["FullName", "Full Name", "text"],
        ["Email", "Email", "email"],
        ["PhoneNumber", "Phone Number (+20...)", "tel"],
        ["ArrivalDate", "Arrival Date", "date"],
        ["ArrivalFlight", "Arrival Flight", "text"],
        ["LandingTime", "Landing Time", "time"],
        ["DepartureDate", "Departure Date", "date"],
        ["DepartureFlight", "Departure Flight", "text"],
        ["DepartureTime", "Departure Time", "time"],
        ["HotelName", "Hotel Name", "text"],
        ["CheckInDate", "Check-in Date", "date"],
        ["CheckInTime", "Check-in Time", "time"],
        ["CheckOutDate", "Check-out Date", "date"],
        ["CheckOutTime", "Check-out Time", "time"],
        ["TourRegister", "Tour Registered", "checkbox"],
        ["WalletUrl", "Wallet URL", "url"]
    ];

    let guests = [];
    let tableControls = null;
    let editingId = null;
    let qrGuestId = null;
    let importedRows = [];
    let authorized = false;

    let panelTimer = null;
    let rowTimer = null;
    let revealedRowId = null;
    let revealRequestId = 0;
    let tableVersion = 0;

    // ==========================================
    // HELPERS
    // ==========================================

    function escape(value) {
        return sltEscape(
            value == null ? "" : String(value)
        );
    }

    function isSixDigits(value) {
        return typeof value === "string" &&
            /^(?:(?=(?:.*[A-Z]){3})(?=(?:.*[0-9]){3})[A-Z0-9]{6}|[0-9]{6})$/i.test(value);
    }

    function dateInput(value) {
        return window.sltDateInputValue
            ? window.sltDateInputValue(value)
            : (value ? String(value).slice(0, 10) : "");
    }

    function dateDisplay(value) {
        if (!value) return "—";

        return window.sltFormatDateOnly
            ? window.sltFormatDateOnly(value)
            : String(value).slice(0, 10);
    }

    function dateTimeDisplay(value) {
        if (!value) return "—";

        return window.sltFormatDateTime
            ? window.sltFormatDateTime(value)
            : String(value).replace("T", " ").slice(0, 16);
    }

    function time(value) {
        if (!value) return "—";

        return window.sltTimeInputValue
            ? window.sltTimeInputValue(value)
            : String(value).slice(0, 5);
    }

    function displayValue(value) {
        if (
            value === null ||
            value === undefined ||
            value === ""
        ) {
            return "—";
        }

        return escape(value);
    }

    function message(text, error) {
        if (text) {
            sltNotify(
                text,
                error ? "error" : "success"
            );
        }
    }

    function emailStatus(result) {
        if (!result) return "";
        const email = result.EmailSent === true
            ? "Email: Sent" : result.EmailSent === false
                ? "Email: Not sent" : null;
        const sms = result.SmsSent === true
            ? "SMS: Sent" : result.SmsSent === false
                ? "SMS: Not sent" : null;
        const details = [email, sms].filter(Boolean);
        return details.length ? " · " + details.join(" · ") : "";
    }

    function walletLink(value) {
        const url = String(value || "").trim();

        if (!/^https?:\/\//i.test(url)) {
            return "—";
        }

        return `
            <a href="${escape(url)}"
               target="_blank"
               rel="noopener noreferrer">
                Open Wallet
            </a>
        `;
    }

    // ==========================================
    // PASSCODE MODAL
    // ==========================================

    function hidePasscodePanel() {
        if (panelTimer !== null) {
            clearTimeout(panelTimer);
            panelTimer = null;
        }

        $("passcodeValue").textContent = "";

        $("passcodePanel").classList.add("slt-hidden");

        sltCloseModal("passcodeModal");

        $("passcodeTitle").textContent =
            "Generated Guest Passcode";
    }

    function showPasscodePanel(passcode, fullName) {
        if (!isSixDigits(passcode)) {
            throw new Error(
                "Invalid passcode returned (3 letters + 3 digits)."
            );
        }

        hidePasscodePanel();

        $("passcodeValue").textContent = passcode;

        $("passcodeTitle").textContent =
            fullName
                ? "Passcode for " + fullName
                : "Generated Guest Passcode";

        $("passcodeDescription").textContent =
            "Copy the code securely. It will be hidden automatically.";

        $("passcodePanel").classList.remove("slt-hidden");

        sltOpenModal("passcodeModal");

        panelTimer = setTimeout(
            hidePasscodePanel,
            30000
        );
    }

    // ==========================================
    // PASSCODE IN TABLE
    // ==========================================

    function getPasscodeCell(id) {
        return $("guestRows").querySelector(
            '.slt-passcode-cell[data-guest-id="' + id + '"]'
        );
    }

    function hideRowPasscode() {
        if (rowTimer !== null) {
            clearTimeout(rowTimer);
            rowTimer = null;
        }

        if (revealedRowId === null) return;

        const cell = getPasscodeCell(revealedRowId);

        if (cell) {
            const code = cell.querySelector(
                "[data-passcode-value]"
            );

            const button = cell.querySelector(
                'button[data-action="hidepasscode"]'
            );

            if (code) {
                code.textContent = "••••••";
                code.classList.remove("is-visible");
                code.setAttribute(
                    "aria-label",
                    "Passcode hidden"
                );
            }

            if (button) {
                button.dataset.action = "showpasscode";
                button.textContent = "Show Passcode";
                button.setAttribute("aria-pressed", "false");
            }
        }

        revealedRowId = null;
    }

    function invalidateReveals() {
        revealRequestId++;
        hideRowPasscode();
    }

    function showRowPasscode(id, passcode) {
        if (!isSixDigits(passcode)) {
            throw new Error(
                "The server returned an invalid passcode."
            );
        }

        hideRowPasscode();

        const cell = getPasscodeCell(id);

        if (!cell) return;

        const code = cell.querySelector(
            "[data-passcode-value]"
        );

        const button = cell.querySelector(
            'button[data-action="showpasscode"]'
        );

        if (!code || !button) return;

        code.textContent = passcode;
        code.classList.add("is-visible");

        code.setAttribute(
            "aria-label",
            "Passcode visible"
        );

        button.dataset.action = "hidepasscode";
        button.textContent = "Hide Passcode";
        button.setAttribute("aria-pressed", "true");

        revealedRowId = id;

        rowTimer = setTimeout(
            hideRowPasscode,
            30000
        );
    }

    async function revealGuestPasscode(id, guest) {
        invalidateReveals();

        const requestId = revealRequestId;
        const version = tableVersion;

        const result = await sltRequest(
            "/guests/" + id + "/passcode"
        );

        if (
            requestId !== revealRequestId ||
            version !== tableVersion ||
            document.hidden
        ) {
            return;
        }

        if (!result || !isSixDigits(result.Passcode)) {
            throw new Error(
                "The full passcode could not be retrieved."
            );
        }

        showRowPasscode(id, result.Passcode);

        message(
            "Passcode shown for " +
            guest.FullName +
            ". This action was recorded in the audit log."
        );
    }

    // ==========================================
    // GUEST FORM
    // ==========================================

    $("guestFields").innerHTML = fields.map(function (field) {

        const name = field[0];
        const label = field[1];
        const type = field[2];

        const required =
            name === "FullName" ||
            name === "Email";

        if (type === "checkbox") {
            return `
                <label class="slt-check-label">
                    <input
                        name="${name}"
                        type="checkbox">
                    ${escape(label)}
                </label>
            `;
        }

        return `
            <label>
                ${escape(label)}

                <input
                    name="${name}"
                    type="${type}"
                    ${required ? "required" : ""}
                    autocomplete="off">
            </label>
        `;

    }).join("");

    function clearForm() {
        editingId = null;

        $("guestForm").reset();
    $("guestNotifyMode").value = "None";
    $("guestNotifyChannels").value = "Both";

        $("formTitle").textContent = "Create Guest";

        $("saveGuestButton").textContent = "Create Guest";

        $("guestForm").elements.FullName.required = true;
        $("guestForm").elements.Email.required = true;
    }

    function getFormData() {
        const result = {};

        fields.forEach(function (field) {

            const name = field[0];
            const type = field[2];

            const element = $("guestForm").elements[name];

            if (type === "checkbox") {
                result[name] = element.checked;
                return;
            }

            const value = element.value.trim();

            if (value !== "") {
                result[name] = value;
            }
        });

        return result;
    }

    function editGuest(guest) {
        editingId = Number(guest.Id);

        $("formTitle").textContent =
            "Edit Guest #" + editingId;

        $("saveGuestButton").textContent = "Update Guest";

        $("guestForm").elements.FullName.required = false;
        $("guestForm").elements.Email.required = false;

        fields.forEach(function (field) {

            const name = field[0];
            const type = field[2];

            let value = guest[name] ?? "";

            if (type === "date") {
                value = dateInput(value);
            }

            if (type === "time") {
                value = value ? String(value).slice(0, 5) : "";
            }

            if (type === "checkbox") {
                $("guestForm").elements[name].checked =
                    value === true;
            } else {
                $("guestForm").elements[name].value = value;
            }
        });

        sltOpenModal("guestModal");
    }

    // ==========================================
    // TABLE HELPERS
    // ==========================================

    function statusBadge(isActive, positive, negative) {
        const className = isActive
            ? "slt-status-success"
            : "slt-status-warning";

        return `
            <span class="slt-status ${className}">
                ${isActive ? positive : negative}
            </span>
        `;
    }

    function actionButton(id, action, text, disabled) {
        return `
            <button
                type="button"
                data-id="${id}"
                data-action="${action}"
                ${disabled ? "disabled" : ""}>
                ${escape(text)}
            </button>
        `;
    }

    // ==========================================
    // RENDER GUEST TABLE
    // ==========================================

    function render() {
        invalidateReveals();

        tableVersion++;

        const filtered = guests;

        $("guestCount").textContent =
            (tableControls
                ? tableControls.getTotal()
                : guests.length) +
            " matching guest(s)";

        if (!filtered.length) {
            $("guestRows").innerHTML = `
                <tr>
                    <td colspan="28" class="slt-empty-state">
                        No guests found.
                    </td>
                </tr>
            `;

            return;
        }

        $("guestRows").innerHTML = filtered.map(function (guest) {

            const id = Number(guest.Id);

            const canReveal =
                guest.CanRevealPasscode === true;

            const passcodeCell = `
                <div class="slt-passcode-cell"
                     data-guest-id="${id}">

                    <code data-passcode-value
                          aria-label="Passcode hidden">
                        ••••••
                    </code>

                    <button
                        type="button"
                        data-id="${id}"
                        data-action="showpasscode"
                        aria-pressed="false"
                        ${canReveal ? "" : "disabled"}>
                        Show Passcode
                    </button>

                    ${!canReveal
                        ? "<small>Reset required</small>"
                        : ""}
                </div>
            `;

            const actions = [
                actionButton(id, "edit", "Edit", false),

                actionButton(
                    id,
                    "uploadqr",
                    guest.HasQR ? "Replace QR" : "Upload QR",
                    false
                ),

                actionButton(
                    id,
                    "viewqr",
                    "View QR",
                    !guest.HasQR
                ),

                actionButton(
                    id,
                    "removeqr",
                    "Remove QR",
                    !guest.HasQR
                ),

                actionButton(
                    id,
                    "reset",
                    "Reset Passcode",
                    false
                ),

                actionButton(
                    id,
                    "delete",
                    "Delete",
                    false
                )
            ].join("");

            return `
                <tr>

                    <td class="col-select">
                        <input
                            type="checkbox"
                            class="slt-select-guest"
                            data-guest-id="${id}"
                            data-full-name="${escape(guest.FullName)}"
                            data-email="${escape(guest.Email)}"
                            aria-label="Select guest">
                    </td>

                    <td class="col-name">
                        <span class="slt-guest-name">
                            ${displayValue(guest.FullName)}
                        </span>
                    </td>

                    <td class="col-email">
                        ${displayValue(guest.Email)}
                    </td>

                    <td class="col-phone">
                        ${displayValue(guest.PhoneNumber)}
                    </td>

                    <td class="col-date">
                        ${escape(dateDisplay(guest.ArrivalDate))}
                    </td>

                    <td class="col-flight">
                        ${displayValue(guest.ArrivalFlight)}
                    </td>

                    <td class="col-time">
                        ${escape(time(guest.LandingTime))}
                    </td>

                    <td class="col-date">
                        ${escape(dateDisplay(guest.DepartureDate))}
                    </td>

                    <td class="col-flight">
                        ${displayValue(guest.DepartureFlight)}
                    </td>

                    <td class="col-time">
                        ${escape(time(guest.DepartureTime))}
                    </td>

                    <td class="col-hotel">
                        ${displayValue(guest.HotelName)}
                    </td>

                    <td class="col-date">
                        ${escape(dateDisplay(guest.CheckInDate))}
                    </td>

                    <td class="col-time">
                        ${escape(time(guest.CheckInTime))}
                    </td>

                    <td class="col-date">
                        ${escape(dateDisplay(guest.CheckOutDate))}
                    </td>

                    <td class="col-time">
                        ${escape(time(guest.CheckOutTime))}
                    </td>

                    <td class="col-status">
                        ${statusBadge(
                            guest.TourRegister === true,
                            "Registered",
                            "Not Registered"
                        )}
                    </td>

                    <td class="col-status">
                        ${statusBadge(
                            guest.Activated === true,
                            "Activated",
                            "Not Activated"
                        )}
                    </td>

                    <td class="col-passcode">
                        ${passcodeCell}
                    </td>

                    <td class="col-status">
                        ${statusBadge(
                            guest.HasQR === true,
                            "Uploaded",
                            "Missing"
                        )}
                    </td>

                    <td class="col-file">
                        ${displayValue(guest.QRFileName)}
                    </td>

                    <td class="col-status">
                        ${statusBadge(
                            guest.EmailSent === true,
                            "Sent",
                            "Pending"
                        )}
                    </td>

                    <td class="col-status">
                        ${statusBadge(
                            guest.SmsSent === true,
                            "Sent",
                            "Pending"
                        )}
                    </td>

                    <td class="col-wallet">
                        ${walletLink(guest.WalletUrl)}
                    </td>

                    <td class="col-audit">
                        ${displayValue(guest.CreatedBy)}
                    </td>

                    <td class="col-audit">
                        ${escape(dateTimeDisplay(guest.RetentionDateCreated))}
                    </td>

                    <td class="col-audit">
                        ${displayValue(guest.ModifiedBy)}
                    </td>

                    <td class="col-audit">
                        ${escape(dateTimeDisplay(guest.RetentionDateModified))}
                    </td>

                    <td class="col-actions">
                        <div class="slt-row-actions">
                            ${actions}
                        </div>
                    </td>

                </tr>
            `;

        }).join("");
    }

    // ==========================================
    // LOAD GUESTS
    // ==========================================

    async function load() {
        invalidateReveals();

        try {
            const response = await sltRequest(
                "/guests/paged?" + tableControls.query()
            );

            const records = Array.isArray(response?.Items)
                ? response.Items
                : null;

            tableControls.setResult(response);

            if (!records) {
                throw new Error(
                    "Unexpected /guests response format."
                );
            }

            guests = records;

            if (guests.length) {
                try {
                    const details = await sltRequest(
                        "/guests/row-details?ids=" +
                        guests.map(g => g.Id).join(",")
                    );

                    const detailRows = Array.isArray(details)
                        ? details
                        : (details && Array.isArray(details.Items)
                            ? details.Items
                            : []);

                    const map = new Map(
                        detailRows.map(row => [
                            Number(row.Id),
                            row
                        ])
                    );

                    guests.forEach(function (guest) {
                        Object.assign(
                            guest,
                            map.get(Number(guest.Id)) || {}
                        );
                    });

                } catch (detailError) {
                    console.warn(
                        "Unable to load guest audit/send fields.",
                        detailError
                    );
                }
            }

            render();

        } catch (error) {
            message(
                "Unable to load guests: " + error.message,
                true
            );
        }
    }

    // ==========================================
    // CREATE / UPDATE
    // ==========================================

    $("guestForm").addEventListener(
        "submit",
        async function (event) {

            event.preventDefault();

            if (!authorized) {
                message(
                    "Admin authorization required.",
                    true
                );
                return;
            }

            const button = $("saveGuestButton");

            button.disabled = true;

            try {
                const input = getFormData();

                if (editingId !== null) {

                    await sltRequest(
                        "/guests/" + editingId + "?notificationMode=" + encodeURIComponent($("guestNotifyMode").value) + "&notificationChannels=" + encodeURIComponent($("guestNotifyChannels").value),
                        {
                            method: "PUT",
                            body: JSON.stringify(input)
                        }
                    );

                    message("Guest updated successfully.");

                } else {

                    const result = await sltRequest(
                        "/guests",
                        {
                            method: "POST",
                            body: JSON.stringify(input)
                        }
                    );

                    if (result.Passcode) {
                        showPasscodePanel(
                            result.Passcode,
                            result.Guest?.FullName || input.FullName
                        );
                    }

                    message(
                        "Guest created successfully." +
                        emailStatus(result),
                        result.EmailSent === false || result.SmsSent === false
                    );
                }

                clearForm();

                sltCloseModal("guestModal");

                await load();

            } catch (error) {
                message(error.message, true);

            } finally {
                button.disabled = false;
            }
        }
    );

    // ==========================================
    // TABLE ACTIONS
    // ==========================================

    $("guestRows").addEventListener(
        "click",
        async function (event) {

            const button = event.target.closest(
                "button[data-action]"
            );

            if (!button || button.disabled) return;

            const id = Number(button.dataset.id);
            const action = button.dataset.action;

            const guest = guests.find(
                g => Number(g.Id) === id
            );

            if (!guest) return;

            button.disabled = true;

            try {

                if (action === "showpasscode") {
                    await revealGuestPasscode(id, guest);
                    return;
                }

                if (action === "hidepasscode") {
                    invalidateReveals();
                    return;
                }

                if (action === "edit") {
                    editGuest(guest);
                    return;
                }

                if (action === "uploadqr") {

                    qrGuestId = id;

                    if (window.sltGuestSwitchTab) {
                        window.sltGuestSwitchTab("qr");
                    }

                    $("qrGuestLabel").textContent =
                        "Selected guest: " + guest.FullName;

                    $("qrUploadButton").disabled = false;

                    $("qrForm").scrollIntoView({
                        behavior: "smooth",
                        block: "center"
                    });

                    return;
                }

                if (action === "viewqr") {

                    const blob = await sltRequest(
                        "/guests/" + id + "/qr"
                    );

                    const mime = blob.type || "image/png";

                    const extension =
                        mime === "image/jpeg"
                            ? ".jpg"
                            : mime === "image/webp"
                                ? ".webp"
                                : ".png";

                    const objectUrl = URL.createObjectURL(blob);
                    const filename = "guest-" + id + "-qr" + extension;
                    const overlay = document.createElement("div");
                    overlay.className = "slt-qr-preview-overlay";
                    overlay.setAttribute("role", "dialog");
                    overlay.setAttribute("aria-modal", "true");
                    overlay.setAttribute("aria-label", "Guest QR image preview");
                    overlay.innerHTML = `<div class="slt-qr-preview-card">
                        <div class="slt-qr-preview-header"><h2>Guest QR Image</h2><button type="button" data-qr-close aria-label="Close preview">×</button></div>
                        <img alt="Guest QR image" src="${objectUrl}" />
                        <div class="slt-qr-preview-actions"><button type="button" class="slt-btn slt-secondary" data-qr-close>Close</button><button type="button" class="slt-btn slt-primary" data-qr-download>Download QR</button></div>
                    </div>`;
                    const cleanup = () => { document.removeEventListener("keydown", onEscape); overlay.remove(); URL.revokeObjectURL(objectUrl); };
                    const onEscape = event => { if (event.key === "Escape") cleanup(); };
                    overlay.addEventListener("click", event => {
                        if (event.target === overlay || event.target.closest("[data-qr-close]")) cleanup();
                        if (event.target.closest("[data-qr-download]")) sltDownload(blob, filename, mime);
                    });
                    document.body.appendChild(overlay);
                    document.addEventListener("keydown", onEscape);
                    overlay.querySelector("[data-qr-close]").focus();
                    return;
                }

                if (action === "removeqr") {

                    if (!await sltConfirm(
                        "Remove QR image for " +
                        guest.FullName + "?"
                    )) return;

                    await sltRequest(
                        "/guests/" + id + "/qr",
                        { method: "DELETE" }
                    );

                    message("QR image removed successfully.");

                    await load();

                    return;
                }

                if (action === "reset") {

                    if (!await sltConfirm(
                        "Generate a new 3-letter / 3-number mixed passcode for " +
                        guest.FullName +
                        "? This revokes the existing session."
                    )) return;

                    invalidateReveals();
                    hidePasscodePanel();

                    const result = await sltRequest(
                        "/guests/" + id + "/reset-passcode",
                        { method: "POST" }
                    );

                    await load();

                    if (result.Passcode) {
                        showPasscodePanel(
                            result.Passcode,
                            guest.FullName
                        );
                    }

                    message(
                        "Passcode reset successfully." +
                        emailStatus(result),
                        result.EmailSent === false || result.SmsSent === false
                    );

                    return;
                }

                if (action === "delete") {

                    if (!await sltConfirm(
                        "Soft delete guest " +
                        guest.FullName + "?"
                    )) return;

                    invalidateReveals();

                    await sltRequest(
                        "/guests/" + id,
                        { method: "DELETE" }
                    );

                    message("Guest soft deleted.");

                    await load();
                }

            } catch (error) {
                message(error.message, true);

            } finally {
                if (button.isConnected) {
                    button.disabled = false;
                }
            }
        }
    );

    // ==========================================
    // QR UPLOAD
    // ==========================================

    $("qrForm").addEventListener(
        "submit",
        async function (event) {

            event.preventDefault();

            if (!qrGuestId) {
                message("Select a guest first.", true);
                return;
            }

            const file = $("qrFile").files[0];

            if (!file) {
                message("Select a QR image.", true);
                return;
            }

            if (!/\.(png|jpg|jpeg|webp)$/i.test(file.name)) {
                message(
                    "Only PNG, JPG, JPEG and WEBP are supported.",
                    true
                );
                return;
            }

            if (file.size > 2 * 1024 * 1024) {
                message("Maximum QR image size is 2 MB.", true);
                return;
            }

            const guestId = qrGuestId;

            const body = new FormData();
            body.append("file", file);

            $("qrUploadButton").disabled = true;

            try {
                await sltRequest(
                    "/guests/" + guestId + "/qr",
                    {
                        method: "POST",
                        body: body
                    }
                );

                $("qrForm").reset();

                qrGuestId = null;

                $("qrGuestLabel").textContent =
                    "Select a guest from Guest Records.";

                message("QR image uploaded successfully.");

                await load();

            } catch (error) {
                message(error.message, true);

            } finally {
                $("qrUploadButton").disabled =
                    qrGuestId === null;
            }
        }
    );

    // ==========================================
    // EXCEL FILE PICKER
    // ==========================================

    function updateExcelFileName() {
        const file = $("excelFile").files[0];

        $("excelFileName").textContent =
            file ? file.name : "No file selected";

        $("excelFileName").classList.toggle(
            "has-file",
            !!file
        );

        $("excelButton").disabled = !file;
    }

    $("excelFile").addEventListener(
        "change",
        updateExcelFileName
    );

    // ==========================================
    // EXCEL IMPORT
    // ==========================================

    $("excelForm").addEventListener(
        "submit",
        async function (event) {

            event.preventDefault();

            const file = $("excelFile").files[0];

            if (!file) {
                message("Please select an Excel file.", true);
                return;
            }

            if (!/\.xlsx$/i.test(file.name)) {
                message("Only XLSX files are supported.", true);
                return;
            }

            if (file.size > 10 * 1024 * 1024) {
                message("Maximum Excel size is 10 MB.", true);
                return;
            }

            const mode = $("importMode").value;

            if (
                mode === "ReplaceAll" &&
                !await sltConfirm(
                    "This will soft-delete ALL existing guests " +
                    "and revoke existing guest sessions. Continue?"
                )
            ) {
                return;
            }

            const body = new FormData();
            body.append("file", file);

            $("excelButton").disabled = true;
            $("exportPasscodes").disabled = true;
            $("exportPasscodes").hidden = true;

            $("guestImportReport").hidden = true;
            $("guestImportReport").innerHTML = "";

            $("excelSummary").textContent = "";

            importedRows = [];

            try {

                const response = await sltRequest(
                    "/guests/bulk-upload?mode=" +
                    encodeURIComponent(mode),
                    {
                        method: "POST",
                        body: body
                    }
                );

                const result = response.result || response;

                importedRows = result.Rows || [];

                const failed = Number(
                    result.Failed || result.failed || 0
                );

                const created = Number(
                    result.Created || result.created || 0
                );

                const updated = Number(
                    result.Updated || result.updated || 0
                );

                const skipped = Number(
                    result.Skipped || result.skipped || 0
                );

                const deleted = Number(
                    result.SoftDeleted || result.softDeleted || 0
                );

                $("excelSummary").textContent =
                    "Created: " + created +
                    " | Updated: " + updated +
                    " | Skipped: " + skipped +
                    " | Rows with errors: " + failed +
                    " | Soft-deleted: " + deleted;

                if (window.sltShowImportReport) {
                    window.sltShowImportReport(
                        "guestImportReport",
                        result,
                        "Guest import"
                    );
                }

                const hasPasscodes = importedRows.some(
                    row => isSixDigits(row.Passcode)
                );

                $("exportPasscodes").disabled = !hasPasscodes;
                $("exportPasscodes").hidden = !hasPasscodes;

                $("excelForm").reset();

                updateExcelFileName();

                message(
                    failed > 0
                        ? "Import completed with row errors. Valid rows were saved."
                        : "Excel import completed successfully.",
                    failed > 0
                );

                await load();

            } catch (error) {
                message(
                    "Excel import failed: " + error.message,
                    true
                );

            } finally {
                $("excelButton").disabled =
                    !$("excelFile").files.length;
            }
        }
    );

    // ==========================================
    // EXPORT NEW PASSCODES
    // ==========================================

    $("exportPasscodes").addEventListener(
        "click",
        async function () {

            const rows = importedRows.filter(
                row => isSixDigits(row.Passcode)
            );

            if (!rows.length) {
                message("No passcodes available for export.", true);
                return;
            }

            if (!await sltConfirm(
                "This file contains sensitive guest passcodes. " +
                "Export to a secure location?"
            )) return;

            function csvCell(value) {
                let text = String(
                    value == null ? "" : value
                );

                if (/^\s*[=+\-@\t\r]/.test(text)) {
                    text = "'" + text;
                }

                return '"' + text.replace(/"/g, '""') + '"';
            }

            const csv =
                "Email,Passcode\r\n" +
                rows.map(function (row) {
                    return (
                        csvCell(row.Email) +
                        "," +
                        csvCell("'" + row.Passcode)
                    );
                }).join("\r\n");

            sltDownload(
                "\uFEFF" + csv,
                "SLT_New_Guest_Passcodes.csv",
                "text/csv;charset=utf-8"
            );

            message("Passcode export created. Keep the file secure.");
        }
    );

    // ==========================================
    // COPY PASSCODE
    // ==========================================

    $("copyPasscode").addEventListener(
        "click",
        async function () {

            const passcode =
                $("passcodeValue").textContent.trim();

            if (!isSixDigits(passcode)) {
                message("No valid passcode to copy.", true);
                return;
            }

            try {
                await navigator.clipboard.writeText(passcode);
                message("Passcode copied.");

            } catch (_) {
                message(
                    "Clipboard unavailable. Copy manually.",
                    true
                );
            }
        }
    );

    // ==========================================
    // GENERAL CONTROLS
    // ==========================================

    $("clearForm").addEventListener(
        "click",
        function () {
            clearForm();
            sltCloseModal("guestModal");
        }
    );

    $("openGuestModal").addEventListener(
        "click",
        function () {
            clearForm();
            sltOpenModal("guestModal");
        }
    );

    $("passcodeCloseX").addEventListener(
        "click",
        hidePasscodePanel
    );

    $("closePasscode").addEventListener(
        "click",
        hidePasscodePanel
    );

    $("refresh").addEventListener(
        "click",
        load
    );

    // ==========================================
    // SECURITY: HIDE PASSCODES
    // ==========================================

    document.addEventListener(
        "visibilitychange",
        function () {
            if (document.hidden) {
                invalidateReveals();
                hidePasscodePanel();
            }
        }
    );

    window.addEventListener(
        "blur",
        function () {
            invalidateReveals();
            hidePasscodePanel();
        }
    );

    window.addEventListener(
        "pagehide",
        function () {
            invalidateReveals();
            hidePasscodePanel();
            importedRows = [];
        }
    );

    // ==========================================
    // INITIALIZATION
    // ==========================================

    async function initialize() {
        try {
            authorized = await sltRequireAdmin();

            if (!authorized) return false;

            if (!window.sltCreateTableControls) {
                throw new Error(
                    "Guest table controls script was not loaded."
                );
            }

            tableControls = window.sltCreateTableControls(
                "guests",
                ".slt-guest-toolbar",
                ".slt-table-scroll table",
                load
            );

            updateExcelFileName();

            await load();

            return true;

        } catch (error) {
            message(
                "Administrator authorization failed: " +
                error.message,
                true
            );

            return false;
        }
    }

    window.sltGuestAdminReady = initialize();

})();