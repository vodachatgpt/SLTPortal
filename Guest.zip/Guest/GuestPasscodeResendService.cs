
using System;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using SLTProject.Data;

namespace SLTProject.Services
{
    public class GuestPasscodeResendResult
    {
        public bool Eligible { get; set; }
        public bool EmailSent { get; set; }
    }

    public class GuestPasscodeResendService
    {
        private readonly GuestsService _guestsService;
        private readonly EmailTemplateService _emailService;

        public GuestPasscodeResendService()
        {
            _guestsService = new GuestsService();
            _emailService = new EmailTemplateService();
        }

        // ==========================================
        // MAIN RESEND METHOD
        // ==========================================

        public async Task<GuestPasscodeResendResult>
            ResendAsync(string email)
        {
            var result = new GuestPasscodeResendResult
            {
                Eligible = false,
                EmailSent = false
            };

            // STEP 1: Validate email.
            email = (email ?? "").Trim().ToLowerInvariant();

            if (string.IsNullOrWhiteSpace(email) ||
                email.Length > 254 ||
                !new EmailAddressAttribute().IsValid(email))
            {
                return result;
            }

            // Resend throttling removed as requested.

            // Find the guest by registered email.
            long guestId;

            using (var db = new SLTEntities())
            {
                var guest = await db.Guests
                    .AsNoTracking()
                    .Where(g => !g.IsDeleted && g.Email == email)
                    .Select(g => new { g.Id })
                    .FirstOrDefaultAsync();

                if (guest == null)
                    return result;

                guestId = guest.Id;
            }

            // Regenerate passcode.
            //
            // Existing ResetPasscodeAsync does:
            // - Generates unique 3-letter / 3-digit code
            // - Updates PasscodeHash
            // - Updates PasscodeLast4
            // - Updates PasscodeProtected
            // - Clears FirstLoginAt
            // - Revokes existing session
            // - Saves database changes

            string newPasscode =
                await _guestsService.ResetPasscodeAsync(
                    guestId,
                    "GuestSelfService");

            if (string.IsNullOrWhiteSpace(newPasscode))
                return result;

            result.Eligible = true;

            // Dispatch through the same delivery routine as admin resets.
            var delivery = await SendExistingPasscodeAsync(guestId, newPasscode);
            result.EmailSent = delivery.EmailSent;
            // Do not return the passcode or disclose delivery results publicly.
            return result;
        }

        // Admin-initiated reset calls this after resetting the code.
        // It does not reset the code a second time and does not consume
        // self-service request throttle counters.
        public async Task<GuestPasscodeResendResult> SendExistingPasscodeAsync(
            long guestId, string passcode)
        {
            var result = new GuestPasscodeResendResult();
            if (guestId <= 0 || string.IsNullOrWhiteSpace(passcode))
                return result;

            string guestEmail, guestName;
            using (var db = new SLTEntities())
            {
                var guest = await db.Guests.AsNoTracking()
                    .Where(g => g.Id == guestId && !g.IsDeleted)
                    .Select(g => new { g.Email, g.FullName })
                    .FirstOrDefaultAsync();
                if (guest == null) return result;
                guestEmail = guest.Email;
                guestName = guest.FullName;
            }
            result.Eligible = true;
            try
            {
                result.EmailSent = await _emailService.SendAsync(
                    "GUEST_PASSCODE_RESET", guestEmail, guestName, passcode);
                if (!result.EmailSent)
                    Trace.TraceWarning("Guest passcode email not accepted. GuestId: " + guestId);
            }
            catch (Exception ex)
            {
                Trace.TraceWarning("Guest passcode email failed: " + ex.GetType().Name);
            }
            return result;
        }

    }
}
