# SLT Scheduled Notifications — Minimal Integration Handoff

## Scope and baseline

Source reference: `SLTProject(1).zip` and `SLTAdmin.zip` previously supplied. **Do not overwrite newer branches wholesale.** Only the files below are provided. Existing `SltNotificationsService.SendAsync()`, guest notifications/inbox, Direct Web Push, VAPID keys and proxy implementation are unchanged.

## File-by-file instructions

| Project | Destination relative to project root | Action | What it does |
|---|---|---|---|
| SLTAPI | `Controllers/SltScheduledNotificationsController.cs` | **New** | Admin create/list; Hangfire process-due callback (reuses existing `SltAdmin` and scheduler IP allowlist) |
| SLTAPI | `Services/SltScheduledNotificationsService.cs` | **New** | Save/list schedules using existing EF6 connection (raw SQL, no EDMX update); atomically claim due records; call existing `SltNotificationsService.SendAsync()` |
| SLTAPI | `SLTProject.csproj` | **Merge two `<Compile Include>` entries only** | References two new C# files. Do not overwrite developer's newer csproj. |
| SLTAPI / SQL Server | `Database/03_Create_SltScheduledNotifications.sql` | **Run once** | One new table + due-time index, no updates to existing tables |
| SLTAdmin | `scheduled-notifications.html` | **New** | Schedule form and schedule list, independent of existing notification composer |
| SLTAdmin | `assets/slt-scheduled-notifications.js` | **New** | Calls SLTAPI create/list endpoints, uses current admin bearer session |
| SLTAdmin | `notifications-admin.html` | **Merge one link** | Adds navigation to scheduled notifications. All existing send/history behavior stays intact. |
| SLTUser | None | **No change** | Existing user PWA receives same messages |
| Global Hangfire | No code | **Register one recurring HTTP job** | `* * * * *` calls SLTAPI every minute |

### Required `.csproj` entries (only these two changes)

Insert into the current backend project `.csproj` in the matching `ItemGroup`:

```xml
<Compile Include="Controllers\SltScheduledNotificationsController.cs" />
<Compile Include="Services\SltScheduledNotificationsService.cs" />
```

### Admin navigation merge

Add this link in existing `notifications-admin.html`, near the Dashboard link:

```html
<a class="slt-n-button" href="scheduled-notifications.html">Scheduled notifications</a>
```

No existing `slt-notifications-admin.js` changes are needed.

## APIs (under the existing SLTAPI `/api` base)

**New:**

1. `POST /slt-notifications/admin/schedules` — existing admin bearer token. Body `{ "TargetType":"All", "Title":"Event reminder", "MessageText":"Starts soon", "ScheduledAt":"2026-11-15T07:00:00Z", "ClickUrl":"" }`. Accepts `GuestId` only for `TargetType: Guest`.
2. `GET /slt-notifications/admin/schedules` — existing admin bearer token; returns last 100 schedules, including `Status`, `PushStatus` and `NotificationId`.
3. `POST /slt-notifications/scheduler/process-due` — Global Hangfire HTTP callback, **no admin bearer**, gated by existing `SLTAlertsAllowedSchedulerIps` direct-peer IP list.

**Unchanged:** `POST /slt-notifications/admin/send` handles immediate sends and is called internally by the scheduling service. The scheduling service reuses `SltNotificationsService.SendAsync(...)` directly, not an HTTP call to `/admin/send`.

## One recurring job, not one job per message

Import the included Postman collection. Call your **existing** external Hangfire endpoint `POST {HangfireApiUrl}/api/jobs/AddScheduleJob` once with:

```json
{
  "key": "SLT_ScheduledNotifications_EveryMinute",
  "url": "https://pulse.vodafone.com.eg/SPPowers/sltapi/api/slt-notifications/scheduler/process-due",
  "jobIntervalInCronExpression": "* * * * *",
  "content": { "type": "application/json", "data": {} }
}
```

This matches the existing `SltOperationalAlertsSchedulerService.ScheduleAsync()` contract. Do not add any Hangfire NuGet packages to SLTAPI.

If Global Hangfire returns `409 Conflict`, first check whether the exact key is already registered; **do not remove unrelated recurring jobs**. Confirm the callback is reachable from Hangfire and the scheduler's **actual direct peer IP** is listed in existing `SLTAlertsAllowedSchedulerIps` on SLTAPI. Behind a reverse proxy, this may be the proxy IP, not the Hangfire machine. Do not rely on untrusted `X-Forwarded-For`.

No new `Web.config` setting is required when `SLTAlertsAllowedSchedulerIps` is already correctly configured. Confirm existing `ApiUrl` and `HangfireApiUrl` are real deployment URLs when registering the recurring job.

## Database and delivery

Run `SLTAPI/Database/03_Create_SltScheduledNotifications.sql` against the **SLT** database. No EF6 EDMX update is required.

Lifecycle: `Pending` -> `Processing` -> `Sent` or `Failed`.

- A callback selects at most **5** due messages; each is atomically claimed using `UPDATE ... WHERE Status='Pending'` before sending, preventing concurrent callback duplication.
- `SendAsync()` creates the usual SQL inbox/recipient records and invokes the **existing Direct Web Push** logic. An idempotency key `SLT-SCHEDULE-{Id}` is supplied.
- A successfully invoked sender yields `Status='Sent'`; `PushStatus='Accepted'`, `Partial`, `NoSubscribers` or `Failed` reports browser-delivery outcome independently. `Sent` does **not** guarantee a popup appeared.
- An exception yields `Status='Failed'` with a short error; no automatic resend of a `Failed` or stalled `Processing` record. This deliberately avoids duplicate browser popups after a partially successful send. Review these records manually.
- Broadcast uses the guest audience that exists **at execution time**, matching the existing immediate-send behavior.
- The job runs at minute granularity, not to-the-second. If more than 5 are due in one minute, remaining messages are processed on following ticks.

### Time zone

SLTAdmin selects a datetime in its **device local time** and posts ISO UTC (`Z`) to SLTAPI. SQL stores `ScheduledAtUtc` (UTC). The list displays `Africa/Cairo` time. For users/admins working outside Egypt, the page makes the distinction explicit.

### Cross-domain / PWA

The administrator uses existing `assets/config.js` to reach the deployed SLTAPI. The new page uses the same admin bearer token. No changes are required to SLTUser, `sw.js`, the subscription table, the VAPID keys, `SltWebPush.UseProxy` or the current notification-click fallback.

### Safe merge sequence

1. Run `03_Create_SltScheduledNotifications.sql` once on the SLT database.
2. Add the two new SLTAPI C# files; merge only their two compile entries into your **current** SLTProject.csproj.
3. Build/publish SLTAPI and test new admin Create/List APIs through Postman.
4. Copy the two new SLTAdmin files, merge only the Scheduled notifications link into current `notifications-admin.html`. Confirm the new page loads with the existing admin login.
5. Configure the single Global Hangfire recurring job and check its callback returns 200 with `Claimed`, `Sent`, `Failed`.
6. Schedule a test **2–3 minutes in the future** to one guest who has notifications enabled; verify SQL row -> existing SltNotifications row -> SLTUser inbox -> browser push.
7. Test `TargetType='All'`, then multiple schedules. Check the recurring job runs once per minute.

### Validation boundaries

Checks performed: source-file placement and diffs, project XML, JavaScript syntax, JSON/Postman schema, SQL object/column cross-references, package integrity, and a static assertion that no SLTUser files or existing Web Push business logic were changed. **Not performed**: Visual Studio/.NET Framework compilation, live SQL execution, Hangfire registration against your service, IIS publishing, or device push delivery. These must be tested in your environment.
