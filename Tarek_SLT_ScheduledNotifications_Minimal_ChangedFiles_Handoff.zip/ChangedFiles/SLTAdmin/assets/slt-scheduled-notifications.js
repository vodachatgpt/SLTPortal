(function () {
'use strict';
const $ = id => document.getElementById(id);
const base = '/slt-notifications/admin/';
function api(path, options) {
  const token = localStorage.getItem('slt_admin_token');
  if (!token) throw new Error('Administrator login required.');
  return window.sltRequest(base + path, Object.assign({}, options || {}, {
    headers: Object.assign({}, (options && options.headers) || {}, {Authorization: 'Bearer ' + token})
  }));
}
function feedback(message, isError) {
  const element = $('scheduleFeedback');
  element.textContent = message;
  element.dataset.state = isError ? 'error' : 'success';
}
function cairoDate(value) {
  if (!value) return '—';
  const dt = new Date(value);
  return Number.isNaN(dt.getTime()) ? value : new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Africa/Cairo', year: 'numeric', month: 'short', day: '2-digit',
    hour: '2-digit', minute: '2-digit', hour12: true
  }).format(dt);
}
async function refresh() {
  const body = $('scheduleRows');
  body.replaceChildren();
  try {
    const data = await api('schedules');
    const items = Array.isArray(data.Items) ? data.Items : [];
    if (!items.length) {
      const tr = body.insertRow();
      const td = tr.insertCell(); td.colSpan = 6; td.textContent = 'No scheduled messages yet.';
      return;
    }
    items.forEach(item => {
      const tr = body.insertRow();
      const cells = [
        item.Id,
        (item.Title || '') + (item.LastError ? ' — ' + item.LastError : ''),
        item.TargetType === 'All' ? 'All guests' : 'Guest #' + item.GuestId,
        cairoDate(item.ScheduledAtUtc),
        item.Status || '—',
        item.PushStatus || '—'
      ];
      cells.forEach(value => { const cell = tr.insertCell(); cell.textContent = String(value == null ? '' : value); });
    });
  } catch (error) {
    const tr = body.insertRow();
    const td = tr.insertCell(); td.colSpan = 6;
    td.textContent = 'Unable to load schedules: ' + error.message;
  }
}
async function loadGuests() {
  const dropdown = $('scheduleGuest');
  try {
    const result = await api('guests');
    const items = Array.isArray(result) ? result : result.Items || [];
    dropdown.replaceChildren(new Option('Choose guest...', ''));
    items.forEach(x => dropdown.add(new Option((x.FullName || 'Guest') + ' (#' + x.Id + ')', String(x.Id))));
  } catch (error) { feedback('Unable to load guests: ' + error.message, true); }
}
$('scheduleTarget').addEventListener('change', function () {
  $('scheduleGuestArea').hidden = this.value !== 'Guest';
});
$('scheduleRefresh').addEventListener('click', refresh);
$('scheduleForm').addEventListener('submit', async function (event) {
  event.preventDefault();
  const button = $('scheduleCreate');
  if (button.disabled) return;
  const localDate = $('scheduleDate').value;
  const due = new Date(localDate);
  if (!localDate || Number.isNaN(due.getTime()) || due.getTime() <= Date.now()) {
    feedback('Please choose a future scheduled time.', true); return;
  }
  const targetType = $('scheduleTarget').value;
  const guestId = Number($('scheduleGuest').value);
  if (targetType === 'Guest' && (!Number.isSafeInteger(guestId) || guestId < 1)) {
    feedback('Please select a guest.', true); return;
  }
  const url = $('scheduleClick').value.trim();
  if (url && (!url.startsWith('/') || url.startsWith('//') || /[\\%#]/.test(url) || url.includes('..'))) {
    feedback('Leave destination blank or enter a safe root-relative path.', true); return;
  }
  const payload = {
    TargetType: targetType,
    GuestId: targetType === 'Guest' ? guestId : null,
    Title: $('scheduleTitle').value.trim(),
    MessageText: $('scheduleMessage').value.trim(),
    ClickUrl: url,
    ScheduledAt: due.toISOString()
  };
  button.disabled = true;
  try {
    const result = await api('schedules', {method:'POST', body:JSON.stringify(payload)});
    feedback('Schedule #' + result.ScheduleId + ' saved for ' + cairoDate(result.ScheduledAtUtc) + '.');
    this.reset(); $('scheduleGuestArea').hidden = true;
    await refresh();
  } catch(error) { feedback(error.message || 'Unable to save schedule.', true); }
  finally { button.disabled = false; }
});
(async () => {
  if (!await window.sltRequireAdmin()) return;
  await Promise.all([loadGuests(), refresh()]);
})();
})();
