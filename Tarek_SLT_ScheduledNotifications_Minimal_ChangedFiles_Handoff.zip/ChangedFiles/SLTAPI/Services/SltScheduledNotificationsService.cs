using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using SLTProject.Data;

namespace SLTProject.Services
{
    public sealed class SltScheduledNotificationCreate
    {
        public string TargetType { get; set; } // All or Guest
        public long? GuestId { get; set; }
        public string Title { get; set; }
        public string MessageText { get; set; }
        public string ClickUrl { get; set; }
        public DateTimeOffset? ScheduledAt { get; set; } // Date with offset or UTC Z
    }

    // Plain SQL avoids modifying the existing EF6 Database-First EDMX.
    public sealed class SltScheduledNotificationRecord
    {
        public long Id { get; set; }
        public string Title { get; set; }
        public string MessageText { get; set; }
        public string TargetType { get; set; }
        public long? GuestId { get; set; }
        public string ClickUrl { get; set; }
        public DateTime ScheduledAtUtc { get; set; }
        public string Status { get; set; }
        public long? NotificationId { get; set; }
        public string PushStatus { get; set; }
        public string LastError { get; set; }
        public long CreatedByAdminId { get; set; }
        public string CreatedByEmail { get; set; }
        public DateTime CreatedAtUtc { get; set; }
        public DateTime? ExecutedAtUtc { get; set; }
    }

    public sealed class SltScheduledNotificationsService
    {
        // Intentionally bounded: each item may involve network I/O to several browser endpoints.
        private const int BatchSize = 5;

        private static SqlParameter P(string name, object value)
        {
            return new SqlParameter(name, value ?? DBNull.Value);
        }

        private static string Utc(DateTime value)
        {
            return DateTime.SpecifyKind(value, DateTimeKind.Utc)
                .ToString("yyyy-MM-ddTHH:mm:ss.fffZ", CultureInfo.InvariantCulture);
        }

        private static object View(SltScheduledNotificationRecord row)
        {
            return new
            {
                row.Id, row.Title, row.MessageText, row.TargetType, row.GuestId,
                row.ClickUrl, ScheduledAtUtc = Utc(row.ScheduledAtUtc), row.Status,
                row.NotificationId, row.PushStatus, row.LastError,
                row.CreatedByAdminId, row.CreatedByEmail,
                CreatedAtUtc = Utc(row.CreatedAtUtc),
                ExecutedAtUtc = row.ExecutedAtUtc.HasValue ? Utc(row.ExecutedAtUtc.Value) : null
            };
        }

        public async Task<object> CreateAsync(SltScheduledNotificationCreate input, long adminId, string adminEmail, CancellationToken ct)
        {
            if (input == null) throw new ArgumentException("Notification is required.");
            string target = (input.TargetType ?? "").Trim();
            if (target.Equals("broadcast", StringComparison.OrdinalIgnoreCase)) target = "All";
            if (target.Equals("all", StringComparison.OrdinalIgnoreCase)) target = "All";
            if (target.Equals("guest", StringComparison.OrdinalIgnoreCase)) target = "Guest";
            if (target != "All" && target != "Guest") throw new ArgumentException("TargetType must be All or Guest.");
            if (target == "Guest" && (!input.GuestId.HasValue || input.GuestId.Value <= 0))
                throw new ArgumentException("A valid GuestId is required for Guest targets.");
            string title = (input.Title ?? "").Trim();
            string message = (input.MessageText ?? "").Trim();
            string url = (input.ClickUrl ?? "").Trim();
            if (title.Length < 1 || title.Length > 120) throw new ArgumentException("Title must contain 1-120 characters.");
            if (message.Length < 1 || message.Length > 4000) throw new ArgumentException("Message must contain 1-4000 characters.");
            if (message.Contains("<") || message.Contains(">")) throw new ArgumentException("HTML is not supported.");
            if (url.Length > 500 || (url.Length > 0 &&
                (!url.StartsWith("/", StringComparison.Ordinal) || url.StartsWith("//", StringComparison.Ordinal) ||
                 url.Contains("\\") || url.Contains("\r") || url.Contains("\n"))))
                throw new ArgumentException("ClickUrl must be a safe root-relative path or empty.");
            if (!input.ScheduledAt.HasValue || input.ScheduledAt.Value.UtcDateTime <= DateTime.UtcNow)
                throw new ArgumentException("ScheduledAt must be a future ISO-8601 date/time with an offset or Z.");
            var scheduled = input.ScheduledAt.Value.UtcDateTime;

            using (var db = new SLTEntities())
            {
                // Existing guest validation; no new identity or authorization tables.
                if (target == "Guest" && !await db.Guests.AsNoTracking()
                    .AnyAsync(g => g.Id == input.GuestId.Value && !g.IsDeleted && g.FirstLoginAt.HasValue, ct))
                    throw new ArgumentException("The selected guest is not eligible.");
                var id = await db.Database.SqlQuery<long>(@"
INSERT INTO dbo.SltScheduledNotifications
 (Title, MessageText, TargetType, GuestId, ClickUrl, ScheduledAtUtc, Status,
  CreatedByAdminId, CreatedByEmail, CreatedAtUtc)
OUTPUT INSERTED.Id
VALUES (@title, @message, @target, @guest, @url, @scheduled, N'Pending',
        @adminId, @adminEmail, SYSUTCDATETIME());",
                    P("@title", title), P("@message", message), P("@target", target),
                    P("@guest", target == "Guest" ? (object)input.GuestId.Value : DBNull.Value),
                    P("@url", url.Length == 0 ? (object)DBNull.Value : url),
                    P("@scheduled", scheduled), P("@adminId", adminId),
                    P("@adminEmail", String.IsNullOrWhiteSpace(adminEmail) ? (object)DBNull.Value : adminEmail)
                ).SingleAsync(ct);
                return new { ScheduleId = id, Status = "Pending", ScheduledAtUtc = Utc(scheduled) };
            }
        }

        public async Task<object> ListAsync(CancellationToken ct)
        {
            using (var db = new SLTEntities())
            {
                var rows = await db.Database.SqlQuery<SltScheduledNotificationRecord>(@"
SELECT TOP (100) Id, Title, MessageText, TargetType, GuestId, ClickUrl,
       ScheduledAtUtc, Status, NotificationId, PushStatus, LastError,
       CreatedByAdminId, CreatedByEmail, CreatedAtUtc, ExecutedAtUtc
FROM dbo.SltScheduledNotifications ORDER BY Id DESC;").ToListAsync(ct);
                return new { Items = rows.Select(View).ToList(), TotalReturned = rows.Count };
            }
        }

        public async Task<object> ProcessDueAsync(CancellationToken ct)
        {
            int claimed = 0, sent = 0, failed = 0;
            using (var db = new SLTEntities())
            {
                // Snapshot candidates; the UPDATE below is the atomic per-row claim.
                var ids = await db.Database.SqlQuery<long>(@"
SELECT TOP (@batch) Id FROM dbo.SltScheduledNotifications
WHERE Status = N'Pending' AND ScheduledAtUtc <= SYSUTCDATETIME()
ORDER BY ScheduledAtUtc, Id;", P("@batch", BatchSize)).ToListAsync(ct);

                foreach (long id in ids)
                {
                    ct.ThrowIfCancellationRequested();
                    int changed = await db.Database.ExecuteSqlCommandAsync(ct, @"
UPDATE dbo.SltScheduledNotifications
SET Status = N'Processing'
WHERE Id = @id AND Status = N'Pending' AND ScheduledAtUtc <= SYSUTCDATETIME();", P("@id", id));
                    if (changed != 1) continue; // Another callback has already claimed it.
                    claimed++;

                    try
                    {
                        var item = await db.Database.SqlQuery<SltScheduledNotificationRecord>(@"
SELECT Id, Title, MessageText, TargetType, GuestId, ClickUrl,
       ScheduledAtUtc, Status, NotificationId, PushStatus, LastError,
       CreatedByAdminId, CreatedByEmail, CreatedAtUtc, ExecutedAtUtc
FROM dbo.SltScheduledNotifications WHERE Id = @id;", P("@id", id)).SingleAsync(ct);

                        // This is exactly the EXISTING admin sender's business and push logic.
                        var result = await new SltNotificationsService().SendAsync(
                            new SltNotificationSendInput
                            {
                                TargetType = item.TargetType,
                                GuestId = item.GuestId,
                                Title = item.Title,
                                MessageText = item.MessageText,
                                ClickUrl = item.ClickUrl,
                                IdempotencyKey = "SLT-SCHEDULE-" + item.Id
                            }, item.CreatedByAdminId, item.CreatedByEmail, ct);

                        // Sent means SLT inbox/send ran. PushStatus separately reports provider outcome.
                        await db.Database.ExecuteSqlCommandAsync(ct, @"
UPDATE dbo.SltScheduledNotifications
SET Status = N'Sent', NotificationId = @notificationId,
    PushStatus = @pushStatus, ExecutedAtUtc = SYSUTCDATETIME(), LastError = NULL
WHERE Id = @id AND Status = N'Processing';",
                            P("@notificationId", result.NotificationId), P("@pushStatus", result.PushStatus), P("@id", id));
                        sent++;
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Trace.TraceError("Scheduled SLT notification " + id + " failed: " + ex);
                        try
                        {
                            await db.Database.ExecuteSqlCommandAsync(CancellationToken.None, @"
UPDATE dbo.SltScheduledNotifications
SET Status = N'Failed', ExecutedAtUtc = SYSUTCDATETIME(), LastError = @error
WHERE Id = @id AND Status = N'Processing';",
                                P("@error", ex.GetType().Name + ": " + (ex.Message ?? "").Substring(0, Math.Min(900, (ex.Message ?? "").Length))),
                                P("@id", id));
                        }
                        catch (Exception saveEx)
                        {
                            System.Diagnostics.Trace.TraceError("Could not record failed schedule " + id + ": " + saveEx);
                        }
                        failed++;
                    }
                }
            }
            // No automatic resending of Failed/Processing items: it could duplicate browser popups.
            return new { Claimed = claimed, Sent = sent, Failed = failed, BatchSize = BatchSize,
                ExecutedAtUtc = DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture) };
        }
    }
}
