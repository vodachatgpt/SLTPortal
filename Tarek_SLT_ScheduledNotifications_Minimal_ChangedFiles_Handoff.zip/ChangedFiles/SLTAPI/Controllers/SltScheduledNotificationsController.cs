using System;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using SLTProject.Filters;
using SLTProject.Services;

namespace SLTProject.Controllers
{
    // New scheduling API only. Existing admin/send and Direct Web Push remain unchanged.
    [RoutePrefix("api/slt-notifications")]
    public sealed class SltScheduledNotificationsController : ApiController
    {
        private readonly SltScheduledNotificationsService schedules = new SltScheduledNotificationsService();

        private long AdminId()
        {
            object value;
            long id;
            if (Request.Properties.TryGetValue("SLTAdminId", out value) &&
                long.TryParse(Convert.ToString(value), out id) && id > 0) return id;
            throw new UnauthorizedAccessException("Administrator identity is unavailable.");
        }

        private string AdminEmail
        {
            get
            {
                object value;
                return Request.Properties.TryGetValue("SLTAdminEmail", out value)
                    ? Convert.ToString(value) : null;
            }
        }

        [SltAdmin, HttpPost, Route("admin/schedules")]
        public async Task<IHttpActionResult> Create([FromBody] SltScheduledNotificationCreate input, CancellationToken ct)
        {
            try { return Ok(await schedules.CreateAsync(input, AdminId(), AdminEmail, ct)); }
            catch (ArgumentException ex) { return BadRequest(ex.Message); }
            catch (UnauthorizedAccessException) { return Unauthorized(); }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError("Create scheduled notification failed: " + ex);
                return Content(HttpStatusCode.InternalServerError, new { Message = "Could not save scheduled notification. Check SLTAPI logs." });
            }
        }

        [SltAdmin, HttpGet, Route("admin/schedules")]
        public async Task<IHttpActionResult> List(CancellationToken ct)
        {
            try { return Ok(await schedules.ListAsync(ct)); }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError("List scheduled notifications failed: " + ex);
                return Content(HttpStatusCode.InternalServerError, new { Message = "Could not read scheduled notifications. Check SLTAPI logs." });
            }
        }

        // One recurring job in the EXISTING Global Hangfire service calls this endpoint every minute.
        // Reuses the same direct-peer IP allowlist as the existing operational-alert callback.
        [AllowAnonymous, HttpPost, Route("scheduler/process-due")]
        public async Task<IHttpActionResult> ProcessDue(CancellationToken ct)
        {
            if (!IsAllowedSchedulerPeer()) return StatusCode(HttpStatusCode.Forbidden);
            try { return Ok(await schedules.ProcessDueAsync(ct)); }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError("Scheduled notification callback failed: " + ex);
                return Content(HttpStatusCode.InternalServerError, new { Message = "Scheduled notification processing failed. Check SLTAPI logs." });
            }
        }

        private static bool IsAllowedSchedulerPeer()
        {
            var config = ConfigurationManager.AppSettings["SLTAlertsAllowedSchedulerIps"];
            var request = HttpContext.Current == null ? null : HttpContext.Current.Request;
            var raw = request == null ? null : request.UserHostAddress;
            IPAddress caller;
            if (String.IsNullOrWhiteSpace(config) || !IPAddress.TryParse(raw, out caller)) return false;
            if (caller.IsIPv4MappedToIPv6) caller = caller.MapToIPv4();
            return config.Split(new[] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(x => x.Trim()).Any(x =>
                {
                    IPAddress allowed;
                    if (!IPAddress.TryParse(x, out allowed)) return false;
                    if (allowed.IsIPv4MappedToIPv6) allowed = allowed.MapToIPv4();
                    return allowed.Equals(caller);
                });
        }
    }
}
