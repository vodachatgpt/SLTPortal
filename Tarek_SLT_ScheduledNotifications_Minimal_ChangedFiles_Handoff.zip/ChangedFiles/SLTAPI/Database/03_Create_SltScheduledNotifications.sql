-- SLT Direct Web Push: simple scheduled notification extension.
-- Run ONCE against the SAME SLT database used by the SLTAPI connection string.
-- Existing SltNotifications / SltNotificationRecipients / subscriptions are unchanged.
USE [SLT];
GO
IF OBJECT_ID(N'dbo.SltScheduledNotifications', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.SltScheduledNotifications
    (
        Id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        Title NVARCHAR(120) NOT NULL,
        MessageText NVARCHAR(MAX) NOT NULL,
        TargetType NVARCHAR(20) NOT NULL,
        GuestId BIGINT NULL,
        ClickUrl NVARCHAR(500) NULL,
        ScheduledAtUtc DATETIME2(3) NOT NULL,
        Status NVARCHAR(20) NOT NULL CONSTRAINT DF_SltScheduledNotifications_Status DEFAULT N'Pending',
        NotificationId BIGINT NULL,
        PushStatus NVARCHAR(64) NULL,
        LastError NVARCHAR(1000) NULL,
        CreatedByAdminId BIGINT NOT NULL,
        CreatedByEmail NVARCHAR(640) NULL,
        CreatedAtUtc DATETIME2(3) NOT NULL CONSTRAINT DF_SltScheduledNotifications_Created DEFAULT SYSUTCDATETIME(),
        ExecutedAtUtc DATETIME2(3) NULL,
        CONSTRAINT CK_SltScheduledNotifications_Target CHECK
            ((TargetType = N'All' AND GuestId IS NULL) OR
             (TargetType = N'Guest' AND GuestId IS NOT NULL)),
        CONSTRAINT CK_SltScheduledNotifications_Status CHECK
            (Status IN (N'Pending', N'Processing', N'Sent', N'Failed'))
    );
END;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'dbo.SltScheduledNotifications')
               AND name=N'IX_SltScheduledNotifications_Due')
BEGIN
    CREATE INDEX IX_SltScheduledNotifications_Due
    ON dbo.SltScheduledNotifications (Status, ScheduledAtUtc, Id);
END;
GO
-- Schedule audit query:
-- SELECT TOP 50 * FROM dbo.SltScheduledNotifications ORDER BY Id DESC;
