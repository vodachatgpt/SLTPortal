﻿using SLTProject.Data;
using SLTProject.Filters;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;

namespace SLTProject.Controllers
{
    [SltAdmin]
    [RoutePrefix("api/SLTLimits")]
    public class LimitsController : ApiController
    {
        [HttpPost]
        [Route("ClearAll")]
        public async Task<IHttpActionResult> ClearAll()
        {
            try
            {
                using (var db = new SLTEntities())
                {
                    var records = await db.SLTLoginRateLimits.ToListAsync();
                    int deletedCount = records.Count;

                    db.SLTLoginRateLimits.RemoveRange(records);
                    await db.SaveChangesAsync();

                    return Ok(new
                    {
                        Success = true,
                        DeletedRecords = deletedCount,
                        Message = "Login throttle records cleared successfully."
                    });
                }
            }
            catch (Exception)
            {
                return InternalServerError();
            }
        }
    }
}