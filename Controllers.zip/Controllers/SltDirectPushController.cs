using System;
using System.Configuration;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http;
using SLTProject.Filters;
using SLTProject.Services;

namespace SLTProject.Controllers
{
    // Existing SLT guest authentication is sufficient. No new tokens or external service.
    [RoutePrefix("api/slt-notifications/guest/push")]
    public sealed class SltDirectPushController : ApiController
    {
        public sealed class EndpointRequest { public string endpoint { get; set; } }

        private long GuestId()
        {
            object raw;
            long id;
            if (Request.Properties.TryGetValue("SLTGuestId", out raw) &&
                long.TryParse(Convert.ToString(raw), out id) && id > 0) return id;
            throw new UnauthorizedAccessException("Guest identity unavailable.");
        }

        [SltGuest, HttpGet, Route("config")]
        public IHttpActionResult Config()
        {
            try { return Ok(new { publicKey=SltDirectWebPushService.PublicKey, enabled=true }); }
            catch (ConfigurationErrorsException ex)
            {
                System.Diagnostics.Trace.TraceError("SLT Web Push config: " + ex.Message);
                return Content(HttpStatusCode.ServiceUnavailable,new { Message="Web Push configuration is missing." });
            }
        }

        [SltGuest, HttpPost, Route("subscriptions")]
        public async Task<IHttpActionResult> Subscribe([FromBody] SltDirectWebPushService.BrowserSubscription dto,CancellationToken ct)
        {
            try
            {
                var id = await new SltDirectWebPushService().SubscribeAsync(GuestId(),dto,ct);
                return Ok(new { subscriptionId=id, subscribed=true });
            }
            catch (ArgumentException ex) { return BadRequest(ex.Message); }
            catch (UnauthorizedAccessException) { return Unauthorized(); }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError("SLT Web Push subscribe: " + ex);
                return Content(HttpStatusCode.ServiceUnavailable,new { Message="Could not register this browser. Check SLTAPI logs." });
            }
        }

        [SltGuest, HttpPost, Route("subscriptions/status")]
        public async Task<IHttpActionResult> Status([FromBody] EndpointRequest dto,CancellationToken ct)
        {
            try { return Ok(new { subscribed=await new SltDirectWebPushService().StatusAsync(GuestId(),dto == null ? null : dto.endpoint,ct) }); }
            catch (UnauthorizedAccessException) { return Unauthorized(); }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError("SLT Web Push status: " + ex);
                return Content(HttpStatusCode.ServiceUnavailable,new { Message="Push status unavailable." });
            }
        }

        [SltGuest, HttpPost, Route("subscriptions/unsubscribe")]
        public async Task<IHttpActionResult> Unsubscribe([FromBody] EndpointRequest dto,CancellationToken ct)
        {
            try { return Ok(new { removed=await new SltDirectWebPushService().UnsubscribeAsync(GuestId(),dto == null ? null : dto.endpoint,ct) }); }
            catch (UnauthorizedAccessException) { return Unauthorized(); }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError("SLT Web Push unsubscribe: " + ex);
                return Content(HttpStatusCode.ServiceUnavailable,new { Message="Could not disable browser notifications." });
            }
        }
    }
}
