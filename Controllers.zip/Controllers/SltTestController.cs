using System;
using System.Configuration;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using SLTProject.Data;

namespace SLTProject.Controllers
{
    /// <summary>
    /// Lightweight health endpoints for deployment verification.
    /// Enable with SLTDiagnosticsEnabled=true in Web.config.
    /// These endpoints never return connection strings or exception details.
    /// </summary>
    [RoutePrefix("api/test")]
    public sealed class SltTestController : ApiController
    {
        private static bool IsEnabled
        {
            get
            {
                bool enabled;
                return true;
            }
        }

        // GET /api/test/app
        [AllowAnonymous]
        [HttpGet]
        [Route("app")]
        public IHttpActionResult App()
        {
            if (!IsEnabled)
                return NotFound();

            return Ok(new
            {
                Status = "Running",
                Application = ConfigurationManager.AppSettings["AppName"] ?? "SLTProject",
                CheckedAtUtc = DateTime.UtcNow
            });
        }

        // GET /api/test/database
        [AllowAnonymous]
        [HttpGet]
        [Route("database")]
        public async Task<IHttpActionResult> Database()
        {
            if (!IsEnabled)
                return NotFound();

            try
            {
                using (var db = new SLTEntities())
                {
                    int value = await db.Database
                        .SqlQuery<int>("SELECT CAST(1 AS INT)")
                        .SingleAsync();

                    if (value != 1)
                        throw new InvalidOperationException(
                            "Database health query returned an unexpected value.");
                }

                return Ok(new
                {
                    Status = "Connected",
                    Database = "Available",
                    CheckedAtUtc = DateTime.UtcNow
                });
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError(
                    "SLT database health check failed: " + ex);

                return Content(HttpStatusCode.ServiceUnavailable, new
                {
                    Status = "Unavailable",
                    Database = "Connection failed",
                    CheckedAtUtc = DateTime.UtcNow,
                    Message = "The application could not connect to its configured database."
                });
            }
        }
    }
}
