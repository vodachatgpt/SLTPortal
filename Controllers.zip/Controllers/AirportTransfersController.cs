
using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using SLTProject.Filters;
using SLTProject.Models.Dtos;
using SLTProject.Services;

namespace SLTProject.Controllers
{
    [RoutePrefix("api/airport-transfers")]
    public class AirportTransfersController : ApiController
    {
        private readonly AirportTransfersService _service =
            new AirportTransfersService();

        private const int MaxUploadBytes =
            10 * 1024 * 1024;

        // ====================================================
        // AUTHENTICATED USER TYPE
        // ====================================================

        private bool IsAdmin
        {
            get
            {
                return User != null &&
                       User.Identity != null &&
                       User.Identity.IsAuthenticated &&
                       User.IsInRole("Admin");
            }
        }

        private string GuestEmail
        {
            get
            {
                object value;

                if (Request != null &&
                    Request.Properties.TryGetValue(
                        "SLTGuestEmail", out value))
                {
                    string email = value as string;

                    if (!string.IsNullOrWhiteSpace(email))
                        return email;
                }

                return null;
            }
        }

        // ====================================================
        // ADMINISTRATOR AUDIT IDENTITY
        // ====================================================

        private string Actor
        {
            get
            {
                object value;

                if (Request != null &&
                    Request.Properties.TryGetValue(
                        "SLTAdminEmail", out value))
                {
                    string email = value as string;

                    if (!string.IsNullOrWhiteSpace(email))
                        return email;
                }

                throw new UnauthorizedAccessException(
                    "Authenticated administrator identity " +
                    "is unavailable.");
            }
        }

        // ====================================================
        // GET /api/airport-transfers
        //
        // Admin: all transfers or filter by email.
        // Guest: only transfers belonging to the guest.
        // ====================================================

        // ============================================================
        // GET /api/airport-transfers/paged
        // Admin only: filters and pagination run in SQL Server.
        // ============================================================
        [SltAdmin]
        [HttpGet]
        [Route("paged")]
        public async Task<IHttpActionResult> Paged([FromUri] SltTableQuery query)
        {
            try
            {
                var result = await _service.GetPagedAsync(query ?? new SltTableQuery());
                return Ok(result);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // ============================================================
        // GET /api/airport-transfers/export
        // Admin only: exports ALL filtered records, not only page 1.
        // ============================================================
        [SltAdmin]
        [HttpGet]
        [Route("export")]
        public async Task<HttpResponseMessage> Export([FromUri] SltTableQuery query)
        {
            byte[] content;
            try
            {
                content = await _service.ExportFilteredAsync(query ?? new SltTableQuery());
            }
            catch (ArgumentException ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }

            var response = Request.CreateResponse(HttpStatusCode.OK);
            response.Content = new ByteArrayContent(content);
            response.Content.Headers.ContentType = new MediaTypeHeaderValue(
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            response.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment")
            {
                FileName = "SLT_airport-transfers_Filtered.xlsx"
            };
            response.Headers.CacheControl = new CacheControlHeaderValue { NoStore = true };
            return response;
        }


        [SltAdminOrGuest]
        [HttpGet]
        [Route("")]
        public async Task<IHttpActionResult> GetAll(
            string email = null)
        {
            try
            {
                if (IsAdmin)
                {
                    return Ok(
                        await _service.GetAllAsync(email));
                }

                string guestEmail = GuestEmail;

                if (string.IsNullOrWhiteSpace(guestEmail))
                    return Unauthorized();

                // Ignore any caller-provided email when
                // authenticated as a guest.
                return Ok(
                    await _service.GetAllAsync(guestEmail));
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // ====================================================
        // GET /api/airport-transfers/{id}
        //
        // Admin: any active transfer.
        // Guest: own transfer only.
        // ====================================================

        [SltAdminOrGuest]
        [HttpGet]
        [Route("{id:long}")]
        public async Task<IHttpActionResult> Get(
            long id)
        {
            if (id <= 0)
                return BadRequest(
                    "Invalid airport transfer ID.");

            var transfer = await _service.GetAsync(id);

            if (transfer == null)
                return NotFound();

            if (!IsAdmin)
            {
                string guestEmail = GuestEmail;

                if (string.IsNullOrWhiteSpace(guestEmail))
                    return Unauthorized();

                if (!string.Equals(
                    transfer.Email,
                    guestEmail,
                    StringComparison.OrdinalIgnoreCase))
                {
                    // Do not reveal other guests' records.
                    return NotFound();
                }
            }

            return Ok(transfer);
        }

        // ====================================================
        // POST /api/airport-transfers
        // ADMIN ONLY
        // ====================================================

        [SltAdmin]
        [HttpPost]
        [Route("")]
        public async Task<IHttpActionResult> Create(
            [FromBody] AirportTransferInput input)
        {
            if (input == null)
                return BadRequest(
                    "Airport transfer details are required.");

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var result = await _service.CreateAsync(
                    input,
                    Actor);

                return Content(
                    HttpStatusCode.Created,
                    result);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // ====================================================
        // PUT /api/airport-transfers/{id}
        // ADMIN ONLY
        // ====================================================

        [SltAdmin]
        [HttpPut]
        [Route("{id:long}")]
        public async Task<IHttpActionResult> Update(
            long id,
            [FromBody] AirportTransferInput input)
        {
            if (id <= 0)
                return BadRequest(
                    "Invalid airport transfer ID.");

            if (input == null)
                return BadRequest(
                    "Airport transfer details are required.");

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var result = await _service.UpdateAsync(
                    id,
                    input,
                    Actor);

                return result == null
                    ? (IHttpActionResult)NotFound()
                    : Ok(result);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // ====================================================
        // DELETE /api/airport-transfers/{id}
        // ADMIN ONLY - SOFT DELETE
        // ====================================================

        [SltAdmin]
        [HttpDelete]
        [Route("{id:long}")]
        public async Task<IHttpActionResult> Delete(
            long id)
        {
            if (id <= 0)
                return BadRequest(
                    "Invalid airport transfer ID.");

            bool deleted = await _service.DeleteAsync(
                id,
                Actor);

            if (!deleted)
                return NotFound();

            return Ok(new
            {
                Message =
                    "Airport transfer soft-deleted successfully.",
                Id = id
            });
        }

        // ====================================================
        // GET /api/airport-transfers/template
        // ADMIN ONLY
        // ====================================================

        [SltAdmin]
        [HttpGet]
        [Route("template")]
        public HttpResponseMessage Template()
        {
            byte[] bytes = _service.GetTemplate();

            var response =
                new HttpResponseMessage(HttpStatusCode.OK);

            response.Content =
                new ByteArrayContent(bytes);

            response.Content.Headers.ContentType =
                new MediaTypeHeaderValue(
                    "application/vnd.openxmlformats-" +
                    "officedocument.spreadsheetml.sheet");

            response.Content.Headers.ContentDisposition =
                new ContentDispositionHeaderValue(
                    "attachment")
                {
                    FileName =
                        "AirportTransfers_Template.xlsx"
                };

            return response;
        }

        // ====================================================
        // POST /api/airport-transfers/import
        // ADMIN ONLY
        //
        // multipart/form-data
        // field name: file
        // ====================================================

        [SltAdmin]
        [HttpPost]
        [Route("import")]
        public async Task<IHttpActionResult> Import()
        {
            var httpRequest =
                HttpContext.Current != null
                    ? HttpContext.Current.Request
                    : null;

            if (httpRequest == null)
                return BadRequest(
                    "Upload request is unavailable.");

            var file = httpRequest.Files["file"];

            if (file == null || file.ContentLength == 0)
            {
                return BadRequest(
                    "Upload an .xlsx file using " +
                    "multipart/form-data field 'file'.");
            }

            if (httpRequest.Files.Count != 1)
            {
                return BadRequest(
                    "Upload exactly one Excel file.");
            }

            if (file.ContentLength > MaxUploadBytes)
            {
                return BadRequest(
                    "Maximum Excel file size is 10 MB.");
            }

            if (string.IsNullOrWhiteSpace(file.FileName) ||
                !file.FileName.EndsWith(
                    ".xlsx",
                    StringComparison.OrdinalIgnoreCase))
            {
                return BadRequest(
                    "Only .xlsx Excel files are supported.");
            }

            try
            {
                var result = await _service.ImportAsync(
                    file.InputStream,
                    Actor);

                if (result.Success)
                    return Ok(result);

                return Content(
                    HttpStatusCode.BadRequest,
                    result);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
