﻿
using System;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using SLTProject.Filters;
using SLTProject.Models.Dtos;
using SLTProject.Services;

namespace SLTProject.Controllers
{
    // ============================================================
    // SLT BLURB ICONS CONTROLLER
    //
    // GET     /api/blur-icons          Admin or Guest
    // GET     /api/blur-icons/{id}     Admin or Guest
    // POST    /api/blur-icons          Admin only
    // PUT     /api/blur-icons/{id}     Admin only
    // DELETE  /api/blur-icons/{id}     Admin only
    // ============================================================

    [RoutePrefix("api/blur-icons")]
    public class BlurIconsController : ApiController
    {
        private readonly BlurIconsService _service =
            new BlurIconsService();

        // ========================================================
        // CURRENT AUTHENTICATED ACTOR
        // ========================================================

        private string Actor
        {
            get
            {
                object value;

                if (Request != null &&
                    Request.Properties.TryGetValue(
                        "SLTAdminEmail",
                        out value))
                {
                    string email = value as string;

                    if (!string.IsNullOrWhiteSpace(email))
                    {
                        return email;
                    }
                }

                if (User != null &&
                    User.Identity != null &&
                    User.Identity.IsAuthenticated &&
                    !string.IsNullOrWhiteSpace(
                        User.Identity.Name))
                {
                    return User.Identity.Name;
                }

                throw new UnauthorizedAccessException(
                    "Administrator identity is unavailable.");
            }
        }

        // ========================================================
        // GET /api/blur-icons
        //
        // Admin or Guest can retrieve blurb icons.
        // ========================================================

        [SltAdminOrGuest]
        [HttpGet]
        [Route("")]
        public async Task<IHttpActionResult> GetAll()
        {
            var records =
                await _service.GetAllAsync();

            return Ok(records);
        }

        // ========================================================
        // GET /api/blur-icons/{id}
        //
        // Admin or Guest can retrieve a specific blurb icon.
        // ========================================================

        [SltAdminOrGuest]
        [HttpGet]
        [Route("{id:long}")]
        public async Task<IHttpActionResult> GetById(
            long id)
        {
            if (id <= 0)
            {
                return BadRequest(
                    "Invalid blurb icon ID.");
            }

            var record =
                await _service.GetByIdAsync(id);

            if (record == null)
            {
                return NotFound();
            }

            return Ok(record);
        }

        // ========================================================
        // POST /api/blur-icons
        //
        // Admin only.
        // Creates a new blurb icon.
        // ========================================================

        [SltAdmin]
        [HttpPost]
        [Route("")]
        public async Task<IHttpActionResult> Create(
            [FromBody] BlurIconInput input)
        {
            if (input == null)
            {
                return BadRequest(
                    "Blurb icon details are required.");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var record =
                    await _service.CreateAsync(
                        input,
                        Actor);

                return Content(
                    HttpStatusCode.Created,
                    record);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // ========================================================
        // PUT /api/blur-icons/{id}
        //
        // Admin only.
        // Updates an existing blurb icon.
        // ========================================================

        [SltAdmin]
        [HttpPut]
        [Route("{id:long}")]
        public async Task<IHttpActionResult> Update(
            long id,
            [FromBody] BlurIconInput input)
        {
            if (id <= 0)
            {
                return BadRequest(
                    "Invalid blurb icon ID.");
            }

            if (input == null)
            {
                return BadRequest(
                    "Blurb icon details are required.");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var record =
                    await _service.UpdateAsync(
                        id,
                        input,
                        Actor);

                if (record == null)
                {
                    return NotFound();
                }

                return Ok(new
                {
                    Message =
                        "Blurb icon updated successfully.",
                    Record = record
                });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // ========================================================
        // DELETE /api/blur-icons/{id}
        //
        // Admin only.
        // Soft deletes an existing blurb icon.
        // ========================================================

        [SltAdmin]
        [HttpDelete]
        [Route("{id:long}")]
        public async Task<IHttpActionResult> Delete(
            long id)
        {
            if (id <= 0)
            {
                return BadRequest(
                    "Invalid blurb icon ID.");
            }

            bool deleted =
                await _service.DeleteAsync(
                    id,
                    Actor);

            if (!deleted)
            {
                return NotFound();
            }

            return Ok(new
            {
                Message =
                    "Blurb icon deleted successfully.",
                DeletedId = id
            });
        }
    }
}
