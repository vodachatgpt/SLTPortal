﻿
using System;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using SLTProject.Services;

namespace SLTProject.Controllers
{
    public class GuestResendPasscodeDto
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }
    }

    [AllowAnonymous]
    [RoutePrefix("api/guest-auth")]
    public class GuestPasscodeResendController : ApiController
    {
        private readonly GuestPasscodeResendService _service =
            new GuestPasscodeResendService();

        private const string PublicMessage =
            "If your email is registered and eligible, " +
            "a new passcode will be sent to your email.";

        // ==========================================
        // POST api/guest-auth/resend-passcode
        // ==========================================

        [AllowAnonymous]
        [HttpPost]
        [Route("resend-passcode")]
        public async Task<IHttpActionResult> ResendPasscode(
            [FromBody] GuestResendPasscodeDto input)
        {
            // STEP 1: Validate input.
            if (input == null ||
                string.IsNullOrWhiteSpace(input.Email))
            {
                return BadRequest("Email is required.");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(
                    "Please enter a valid email address.");
            }

            try
            {
                // STEP 2: Get client IP.
                string clientIp =
                    HttpContext.Current?
                        .Request?
                        .UserHostAddress;

                // STEP 3: Regenerate and email passcode.
                await _service.ResendAsync(
                    input.Email,
                    clientIp);

                // STEP 4: Return generic response.
                //
                // Do not disclose:
                // - Whether email exists
                // - New passcode
                // - Guest ID
                // - Whether throttling blocked request
                return Ok(new
                {
                    Status = "Success",
                    Message = PublicMessage
                });
            }
            catch (Exception ex)
            {
                Trace.TraceError(
                    "Guest resend passcode failed. " +
                    "Error type: " +
                    ex.GetType().Name);

                // Keep the public response generic.
                return Ok(new
                {
                    Status = "Success",
                    Message = PublicMessage
                });
            }
        }
    }
}
