﻿
using System;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using SLTProject.Models;
using SLTProject.Models.Dtos;
using SLTProject.Services;

namespace SLTProject.Controllers
{
    [AllowAnonymous]
    [RoutePrefix("api/weather-forecasts")]
    public class WeatherForecastController : ApiController
    {
        private readonly WeatherForecastService _service =
            new WeatherForecastService();

        private readonly WeatherCleanupSchedulerService _scheduler =
            new WeatherCleanupSchedulerService();


        private string Actor
        {
            get
            {
                object value;

                if (Request.Properties.TryGetValue(
                    "SLTAdminEmail", out value))
                {
                    string email = value as string;

                    if (!string.IsNullOrWhiteSpace(email))
                        return email;
                }

                return "WeatherAPI";
            }
        }


        // =========================================
        // CREATE ONE-DAY FORECAST
        // POST api/weather-forecasts
        // =========================================


        [HttpPost]
        [Route("")]
        public async Task<IHttpActionResult> Create(
            [FromBody] WeatherForecastInput input)
        {
            if (input == null)
                return BadRequest(
                    "Weather forecast data is required.");

            try
            {
                var result = await _service.SaveAsync(
                    input,
                    Actor);

                return Content(
                    HttpStatusCode.Created,
                    result);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // =========================================
        // GET ALL FORECAST RECORDS (NO PAGINATION)
        // GET api/weather-forecasts
        // =========================================

        [HttpGet]
        [Route("")]
        public async Task<IHttpActionResult> GetAll(
            decimal? latitude = null,
            decimal? longitude = null)
        {
            try
            {
                var records = await _service.GetAllAsync(
                    latitude,
                    longitude);

                return Ok(records);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // =========================================
        // GET LATEST FORECAST BY LOCATION
        // GET api/weather-forecasts/latest
        // =========================================

        [HttpGet]
        [Route("latest")]
        public async Task<IHttpActionResult> GetLatest(
            [FromUri] decimal latitude,
            [FromUri] decimal longitude)
        {
            try
            {
                var records = await _service.GetLatestAsync(
                    latitude,
                    longitude);

                return Ok(new
                {
                    Count = records.Count,
                    Records = records
                });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // =========================================
        // GET FORECAST BY ID
        // GET api/weather-forecasts/{id}
        // =========================================


        [HttpGet]
        [Route("{id:long}")]
        public async Task<IHttpActionResult> GetById(
            long id)
        {
            var record = await _service.GetByIdAsync(id);

            if (record == null)
                return NotFound();

            return Ok(record);
        }

        // =========================================
        // UPDATE ONE FORECAST RECORD
        // PUT api/weather-forecasts/{id}
        // =========================================


        [HttpPut]
        [Route("{id:long}")]
        public async Task<IHttpActionResult> Update(
            long id,
            [FromBody] WeatherForecastUpdateInput input)
        {
            if (input == null)
                return BadRequest(
                    "Update data is required.");

            try
            {
                var record = await _service.UpdateAsync(
                    id,
                    input,
                    Actor);

                if (record == null)
                    return NotFound();

                return Ok(new
                {
                    Message =
                        "Weather forecast updated successfully.",
                    Record = record
                });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // =========================================
        // DELETE ONE FORECAST RECORD
        // DELETE api/weather-forecasts/{id}
        // =========================================


        [HttpDelete]
        [Route("{id:long}")]
        public async Task<IHttpActionResult> Delete(
            long id)
        {
            bool deleted = await _service.DeleteAsync(id);

            if (!deleted)
                return NotFound();

            return Ok(new
            {
                Message =
                    "Weather forecast deleted successfully.",
                DeletedId = id
            });
        }

        // =========================================
        // MANUALLY REMOVE EXPIRED FORECASTS
        // DELETE api/weather-forecasts/expired
        // =========================================


        [HttpDelete]
        [Route("expired")]
        public async Task<IHttpActionResult> DeleteExpired()
        {
            int deleted = await _service.DeleteExpiredAsync();

            return Ok(new
            {
                Status = "Success",
                DeletedRecords = deleted,
                Message =
                    "Expired forecasts deleted successfully."
            });
        }

        // =========================================
        // REGISTER GLOBAL HANGFIRE CLEANUP JOB
        // POST api/weather-forecasts/schedule-cleanup
        // =========================================


        [HttpPost]
        [Route("schedule-cleanup")]
        public async Task<IHttpActionResult> ScheduleCleanup()
        {
            try
            {
                string result = await _scheduler.ScheduleAsync();

                return Ok(new
                {
                    Status = "Scheduled",
                    JobKey =
                        WeatherCleanupSchedulerService.JobKey,
                    Cron =
                        WeatherCleanupSchedulerService.Cron,
                    Message = result
                });
            }
            catch (Exception)
            {
                // Add your standard audit/error logging here.
                // Do not expose internal Hangfire URLs.

                return Content(
                    HttpStatusCode.BadGateway,
                    new
                    {
                        Status = "Failed",
                        Message =
                            "Could not register weather cleanup " +
                            "with Global Hangfire. " +
                            "Check the Hangfire server logs."
                    });
            }
        }

        // =========================================
        // REMOVE GLOBAL HANGFIRE CLEANUP JOB
        // DELETE api/weather-forecasts/schedule-cleanup
        // =========================================


        [HttpDelete]
        [Route("schedule-cleanup")]
        public async Task<IHttpActionResult> RemoveSchedule()
        {
            try
            {
                string result = await _scheduler.RemoveAsync();

                return Ok(new
                {
                    Status = "Removed",
                    Message = result
                });
            }
            catch (Exception)
            {
                return Content(
                    HttpStatusCode.BadGateway,
                    new
                    {
                        Status = "Failed",
                        Message =
                            "Could not remove the Hangfire job."
                    });
            }
        }

        // =========================================
        // CALLED AUTOMATICALLY BY GLOBAL HANGFIRE
        // POST api/weather-forecasts/process-cleanup
        // =========================================

        [AllowAnonymous]
        [HttpPost]
        [Route("process-cleanup")]
        public async Task<IHttpActionResult> ProcessCleanup()
        {
            try
            {
                int deleted =
                    await _service.DeleteExpiredAsync();

                return Ok(new
                {
                    Status = "Success",
                    JobKey =
                        WeatherCleanupSchedulerService.JobKey,
                    DeletedRecords = deleted,
                    ExecutedAtUtc = DateTime.UtcNow,
                    Message =
                        "Hourly weather cleanup completed."
                });
            }
            catch (Exception)
            {
                // Log server-side with your audit service.

                return Content(
                    HttpStatusCode.InternalServerError,
                    new
                    {
                        Status = "Failed",
                        Message =
                            "Weather cleanup execution failed."
                    });
            }
        }


        [AllowAnonymous]
        [HttpPost]
        [Route("batch")]
        public async Task<IHttpActionResult> CreateBatch(
            [FromBody] WeatherForecastBatchInput input)
        {
            if (input == null)
            {
                return BadRequest(
                    "Weather forecast batch data is required.");
            }

            try
            {
                var result = await _service.SaveBatchAsync(
                    input,
                    Actor);

                return Content(
                    HttpStatusCode.Created,
                    result);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

    }
}
