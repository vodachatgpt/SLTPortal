using SLTProject.Filters;
using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using SLTProject.Models.Dtos;
using SLTProject.Services;

namespace SLTProject.Controllers
{
    [RoutePrefix("api/day-schedules")]
    public class DaySchedulesController : ApiController
    {
        private readonly DaySchedulesService _service = new DaySchedulesService();
        private string Actor
        {
            get
            {
                object value;
                if (Request != null && Request.Properties.TryGetValue("SLTAdminEmail",out value) &&
                    value is string && !string.IsNullOrWhiteSpace((string)value)) return (string)value;
                return User != null && User.Identity != null && User.Identity.IsAuthenticated
                    ? User.Identity.Name : "Unknown";
            }
        }

        // ============================================================
        // GET /api/day-schedules/paged
        // Admin only: filters and pagination run in SQL Server.
        // ============================================================
        [SltAdmin]
        [HttpGet]
        [Route("paged")]
        public async Task<IHttpActionResult> Paged([FromUri] SltTableQuery query)
        {
            try
            {
                var result = await _service.GetPagedAsync(query ?? new SltTableQuery());
                return Ok(result);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // ============================================================
        // GET /api/day-schedules/export
        // Admin only: exports ALL filtered records, not only page 1.
        // ============================================================
        [SltAdmin]
        [HttpGet]
        [Route("export")]
        public async Task<HttpResponseMessage> Export([FromUri] SltTableQuery query)
        {
            byte[] content;
            try
            {
                content = await _service.ExportFilteredAsync(query ?? new SltTableQuery());
            }
            catch (ArgumentException ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }

            var response = Request.CreateResponse(HttpStatusCode.OK);
            response.Content = new ByteArrayContent(content);
            response.Content.Headers.ContentType = new MediaTypeHeaderValue(
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            response.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment")
            {
                FileName = "SLT_day-schedules_Filtered.xlsx"
            };
            response.Headers.CacheControl = new CacheControlHeaderValue { NoStore = true };
            return response;
        }

        [SltAdminOrGuest]
        [HttpGet, Route("")]
        public async Task<IHttpActionResult> GetAll() { return Ok(await _service.GetAllAsync()); }
        [SltAdminOrGuest]
        [HttpGet, Route("{id:long}")]
        public async Task<IHttpActionResult> Get(long id)
        { var v=await _service.GetAsync(id);return v==null ? (IHttpActionResult)NotFound() : Ok(v); }
        [SltAdmin]
        [HttpPost, Route("")]
        public async Task<IHttpActionResult> Create([FromBody] DayScheduleInput input)
        { try { return Content(HttpStatusCode.Created,await _service.CreateAsync(input,Actor)); }
          catch(ArgumentException e) { return BadRequest(e.Message); } }
        [SltAdmin]
        [HttpPut, Route("{id:long}")]
        public async Task<IHttpActionResult> Update(long id,[FromBody] DayScheduleInput input)
        { try { var v=await _service.UpdateAsync(id,input,Actor);return v==null ? (IHttpActionResult)NotFound() : Ok(v); }
          catch(ArgumentException e) { return BadRequest(e.Message); } }
        [SltAdmin]
        [HttpDelete, Route("{id:long}")]
        public async Task<IHttpActionResult> Delete(long id)
        { return await _service.DeleteAsync(id,Actor) ? Ok(new {Message="Schedule soft-deleted.",Id=id}) : (IHttpActionResult)NotFound(); }
        [SltAdmin]
        [HttpGet, Route("template")]
        public System.Net.Http.HttpResponseMessage Template()
        {
            var response=new System.Net.Http.HttpResponseMessage(HttpStatusCode.OK);
            response.Content=new System.Net.Http.ByteArrayContent(_service.GetTemplate());
            response.Content.Headers.ContentType=new System.Net.Http.Headers.MediaTypeHeaderValue("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            response.Content.Headers.ContentDisposition=new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment") {FileName="DaySchedules_Template.xlsx"};
            return response;
        }
        [SltAdmin]
        [HttpPost, Route("import")]
        public async Task<IHttpActionResult> Import()
        {
            var file=HttpContext.Current != null && HttpContext.Current.Request.Files.Count>0
                ? HttpContext.Current.Request.Files[0] : null;
            if(file==null || file.ContentLength==0) return BadRequest("Upload an .xlsx file using multipart/form-data field 'file'.");
            if(file.ContentLength>10*1024*1024 || !file.FileName.EndsWith(".xlsx",StringComparison.OrdinalIgnoreCase))
                return BadRequest("Upload an .xlsx file up to 10 MB.");
            string mode = HttpContext.Current.Request.QueryString["mode"];
            try
            {
                var result = await _service.ImportAsync(file.InputStream, Actor, mode);
                // Row-level validation failures remain HTTP 200 so the UI can display the report.
                return Ok(result);
            }
            catch (ArgumentException e)
            {
                return BadRequest(e.Message);
            }
        }
    }
}
