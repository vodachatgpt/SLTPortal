﻿
using System;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using SLTProject.Filters;
using SLTProject.Services;

namespace SLTProject.Controllers
{
    // ============================================================
    // ADMIN AUTHENTICATION CONTROLLER
    // ============================================================

    [RoutePrefix("api/admin-auth")]
    public class AdminAuthController : ApiController
    {
        private readonly AdminService _service =
            new AdminService();

        // ========================================================
        // GET CURRENT BEARER TOKEN
        // ========================================================

        private string Token
        {
            get
            {
                var authorization =
                    Request.Headers.Authorization;

                if (authorization == null ||
                    !string.Equals(
                        authorization.Scheme,
                        "Bearer",
                        StringComparison.OrdinalIgnoreCase))
                {
                    return null;
                }

                var token = authorization.Parameter;

                if (string.IsNullOrWhiteSpace(token) ||
                    token.Length > 300)
                {
                    return null;
                }

                return token;
            }
        }

        // ========================================================
        // POST /api/admin-auth/login
        //
        // Public endpoint.
        // Existing passcode authentication is preserved.
        // ========================================================

        [AllowAnonymous]
        [HttpPost]
        [Route("login")]
        public async Task<IHttpActionResult> Login(
            AdminLoginInput input)
        {
            if (input == null)
            {
                return BadRequest(
                    "Credentials are required.");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (string.IsNullOrWhiteSpace(input.Email) ||
                string.IsNullOrWhiteSpace(input.Passcode))
            {
                return BadRequest(
                    "Email and passcode are required.");
            }

            string clientIp = null;

            if (HttpContext.Current != null &&
                HttpContext.Current.Request != null)
            {
                clientIp =
                    HttpContext.Current.Request.UserHostAddress;
            }

            var result = await _service.LoginAsync(
                input.Email,
                input.Passcode,
                clientIp);

            if (result == null)
            {
                return Content(
                    HttpStatusCode.Unauthorized,
                    new
                    {
                        Success = false,
                        Message =
                            "Invalid credentials, already used " +
                            "passcode, or login temporarily blocked."
                    });
            }

            return Ok(result);
        }

        // ========================================================
        // GET /api/admin-auth/me
        //
        // Validate current admin session.
        // Frontend sltRequireAdmin() calls this endpoint.
        // ========================================================

        [AllowAnonymous]
        [HttpGet]
        [Route("me")]
        public async Task<IHttpActionResult> Me()
        {
            if (string.IsNullOrWhiteSpace(Token))
            {
                return Unauthorized();
            }

            var admin = await _service.CurrentAsync(Token);

            if (admin == null)
            {
                return Unauthorized();
            }

            return Ok(admin);
        }
    }

    // ============================================================
    // ADMINISTRATOR MANAGEMENT CONTROLLER
    //
    // Requires authenticated administrator.
    //
    // GET     /api/admins
    // GET     /api/admins/{id}
    // POST    /api/admins
    // PUT     /api/admins/{id}
    // POST    /api/admins/{id}/reset-passcode
    // DELETE  /api/admins/{id}
    // ============================================================

    [SltAdmin]
    [RoutePrefix("api/admins")]
    public class AdminsController : ApiController
    {
        private readonly AdminService _service =
            new AdminService();

        private readonly EmailTemplateService _emailService =
            new EmailTemplateService();

        // ========================================================
        // AUTHENTICATED ADMINISTRATOR EMAIL
        // ========================================================

        private string Actor
        {
            get
            {
                object value;

                if (Request.Properties.TryGetValue(
                    "SLTAdminEmail",
                    out value))
                {
                    return value as string;
                }

                throw new UnauthorizedAccessException(
                    "Administrator email is unavailable.");
            }
        }

        // ========================================================
        // AUTHENTICATED ADMINISTRATOR ID
        // ========================================================

        private long ActorId
        {
            get
            {
                object value;

                if (Request.Properties.TryGetValue(
                    "SLTAdminId",
                    out value) &&
                    value != null)
                {
                    return Convert.ToInt64(value);
                }

                throw new UnauthorizedAccessException(
                    "Administrator identity is unavailable.");
            }
        }

        // ========================================================
        // GET /api/admins
        //
        // Get all administrator records.
        // ========================================================

        [HttpGet]
        [Route("")]
        public async Task<IHttpActionResult> GetAll()
        {
            var result = await _service.GetAllAsync();

            return Ok(result);
        }

        // ========================================================
        // GET /api/admins/{id}
        //
        // Get administrator by ID.
        // ========================================================

        [HttpGet]
        [Route("{id:long}")]
        public async Task<IHttpActionResult> Get(
            long id)
        {
            if (id <= 0)
            {
                return BadRequest(
                    "Invalid administrator ID.");
            }

            var admin = await _service.GetAsync(id);

            if (admin == null)
            {
                return NotFound();
            }

            return Ok(admin);
        }

        // ========================================================
        // POST /api/admins
        //
        // Create administrator.
        // Generate passcode through AdminService.
        // Send welcome email.
        // ========================================================

        [HttpPost]
        [Route("")]
        public async Task<IHttpActionResult> Create(
            AdminInput input)
        {
            if (input == null)
            {
                return BadRequest(
                    "Administrator details are required.");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var created =
                    await _service.CreateAsync(
                        input,
                        Actor);

                bool emailSent = false;

                try
                {
                    emailSent =
                        await _emailService.SendAsync(
                            "ADMIN_WELCOME",
                            created.Admin.Email,
                            created.Admin.FullName,
                            created.Passcode);
                }
                catch (Exception ex)
                {
                    // The administrator was already saved.
                    // Do not execute CreateAsync again.
                    // Never log the generated passcode.

                    System.Diagnostics.Trace.TraceWarning(
                        "SLT ADMIN_WELCOME email failed: {0}",
                        ex.Message);
                }

                return Content(
                    HttpStatusCode.Created,
                    new
                    {
                        created.Admin,
                        created.Passcode,
                        EmailSent = emailSent,

                        Message = emailSent
                            ? "Administrator created and " +
                              "email accepted."
                            : "Administrator created, but " +
                              "email delivery was not confirmed."
                    });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // ========================================================
        // PUT /api/admins/{id}
        //
        // Update administrator information.
        // ========================================================

        [HttpPut]
        [Route("{id:long}")]
        public async Task<IHttpActionResult> Update(
            long id,
            AdminInput input)
        {
            if (id <= 0)
            {
                return BadRequest(
                    "Invalid administrator ID.");
            }

            if (input == null)
            {
                return BadRequest(
                    "Administrator details are required.");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var result =
                    await _service.UpdateAsync(
                        id,
                        input,
                        Actor);

                if (result == null)
                {
                    return NotFound();
                }

                return Ok(result);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // ========================================================
        // POST /api/admins/{id}/reset-passcode
        //
        // Reset administrator passcode.
        // Send reset email.
        // ========================================================

        [HttpPost]
        [Route("{id:long}/reset-passcode")]
        public async Task<IHttpActionResult> ResetPasscode(
            long id)
        {
            if (id <= 0)
            {
                return BadRequest(
                    "Invalid administrator ID.");
            }

            string passcode =
                await _service.ResetPasscodeAsync(
                    id,
                    Actor);

            if (passcode == null)
            {
                return NotFound();
            }

            var admin =
                await _service.GetAsync(id);

            bool emailSent = false;

            try
            {
                if (admin != null)
                {
                    emailSent =
                        await _emailService.SendAsync(
                            "ADMIN_PASSCODE_RESET",
                            admin.Email,
                            admin.FullName,
                            passcode);
                }
            }
            catch (Exception ex)
            {
                // The reset was already committed.
                // Do not generate another passcode.

                System.Diagnostics.Trace.TraceWarning(
                    "SLT ADMIN_PASSCODE_RESET email failed: {0}",
                    ex.Message);
            }

            return Ok(new
            {
                Passcode = passcode,
                EmailSent = emailSent,

                Message = emailSent
                    ? "Passcode reset and Mail API " +
                      "accepted the email."
                    : "Passcode reset; email delivery " +
                      "was not confirmed."
            });
        }

        // ========================================================
        // DELETE /api/admins/{id}
        //
        // Soft delete administrator.
        // ========================================================

        [HttpDelete]
        [Route("{id:long}")]
        public async Task<IHttpActionResult> Delete(
            long id)
        {
            if (id <= 0)
            {
                return BadRequest(
                    "Invalid administrator ID.");
            }

            try
            {
                bool deleted =
                    await _service.DeleteAsync(
                        id,
                        ActorId,
                        Actor);

                if (!deleted)
                {
                    return NotFound();
                }

                return Ok(new
                {
                    Message =
                        "Administrator soft deleted."
                });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
