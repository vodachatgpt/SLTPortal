using SLTProject.Filters;
using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using SLTProject.Models.Dtos;
using SLTProject.Services;
using ExcelImportResult = SLTProject.Services.ExcelImportResult;

namespace SLTProject.Controllers
{
    [RoutePrefix("api/guest-event-drivers")]
    public class GuestEventDriversController : ApiController
    {
        private readonly GuestEventDriversService _service=new GuestEventDriversService();
        private string Actor
        {
            get
            {
                object value;
                if(Request!=null && Request.Properties.TryGetValue("SLTAdminEmail",out value) &&
                   value is string && !string.IsNullOrWhiteSpace((string)value)) return (string)value;
                return User!=null && User.Identity!=null && User.Identity.IsAuthenticated ? User.Identity.Name : "Unknown";
            }
        }

        // ============================================================
        // GET /api/guest-event-drivers/paged
        // Admin only: filters and pagination run in SQL Server.
        // ============================================================
        [SltAdmin]
        [HttpGet]
        [Route("paged")]
        public async Task<IHttpActionResult> Paged([FromUri] SltTableQuery query)
        {
            try
            {
                var result = await _service.GetPagedAsync(query ?? new SltTableQuery());
                return Ok(result);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // ============================================================
        // GET /api/guest-event-drivers/export
        // Admin only: exports ALL filtered records, not only page 1.
        // ============================================================
        [SltAdmin]
        [HttpGet]
        [Route("export")]
        public async Task<HttpResponseMessage> Export([FromUri] SltTableQuery query)
        {
            byte[] content;
            try
            {
                content = await _service.ExportFilteredAsync(query ?? new SltTableQuery());
            }
            catch (ArgumentException ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }

            var response = Request.CreateResponse(HttpStatusCode.OK);
            response.Content = new ByteArrayContent(content);
            response.Content.Headers.ContentType = new MediaTypeHeaderValue(
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            response.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment")
            {
                FileName = "SLT_guest-event-drivers_Filtered.xlsx"
            };
            response.Headers.CacheControl = new CacheControlHeaderValue { NoStore = true };
            return response;
        }

        [SltAdminOrGuest]
        [HttpGet,Route("")]
        public async Task<IHttpActionResult> GetAll(string email=null,long? dayScheduleId=null)
        {
            if (!User.IsInRole("Admin"))
            {
                object guestEmail;
                if (!Request.Properties.TryGetValue("SLTGuestEmail", out guestEmail) ||
                    string.IsNullOrWhiteSpace(guestEmail as string))
                    return Unauthorized();
                email = (string)guestEmail;
            }
            try { return Ok(await _service.GetAllAsync(email,dayScheduleId)); }
            catch (ArgumentException ex) { return BadRequest(ex.Message); }
        }
        [SltAdminOrGuest]
        [HttpGet,Route("{id:long}")]
        public async Task<IHttpActionResult> Get(long id)
        {
            if (id <= 0) return BadRequest("Invalid assignment ID.");
            var v = await _service.GetAsync(id);
            if (v == null) return NotFound();
            if (!User.IsInRole("Admin"))
            {
                object guestEmail;
                if (!Request.Properties.TryGetValue("SLTGuestEmail", out guestEmail) ||
                    string.IsNullOrWhiteSpace(guestEmail as string))
                    return Unauthorized();
                if (!string.Equals(v.Email, (string)guestEmail,
                    StringComparison.OrdinalIgnoreCase)) return NotFound();
            }
            return Ok(v);
        }
        [SltAdmin]
        [HttpPost,Route("")]
        public async Task<IHttpActionResult> Create([FromBody] GuestEventDriverInput input,
            [FromUri] string notificationMode = "None", [FromUri] string notificationChannels = "Both", [FromUri] bool reminder = false)
        {try{
            var result = await _service.CreateAsync(input,Actor);
            await SltAlertHookRunner.TryAsync(() => SltOperationalAlertHooks.EventAsync(result.Email,result.DayScheduleId,notificationMode,notificationChannels,reminder));
            return Content(HttpStatusCode.Created,result);}
         catch(ArgumentException e){return BadRequest(e.Message);}}
        [SltAdmin]
        [HttpPut,Route("{id:long}")]
        public async Task<IHttpActionResult> Update(long id,[FromBody] GuestEventDriverInput input,
            [FromUri] string notificationMode = "None", [FromUri] string notificationChannels = "Both", [FromUri] bool reminder = false)
        {try{var v=await _service.UpdateAsync(id,input,Actor);
          if(v!=null) await SltAlertHookRunner.TryAsync(() => SltOperationalAlertHooks.EventAsync(v.Email,v.DayScheduleId,notificationMode,notificationChannels,reminder));
          return v==null ? (IHttpActionResult)NotFound() : Ok(v);}
         catch(ArgumentException e){return BadRequest(e.Message);}}
        [SltAdmin]
        [HttpDelete,Route("{id:long}")]
        public async Task<IHttpActionResult> Delete(long id)
        {return await _service.DeleteAsync(id,Actor) ? Ok(new {Message="Event driver assignment soft-deleted.",Id=id}) : (IHttpActionResult)NotFound();}
        [SltAdmin]
        [HttpGet,Route("template")]
        public System.Net.Http.HttpResponseMessage Template()
        {
            var response=new System.Net.Http.HttpResponseMessage(HttpStatusCode.OK);
            response.Content=new System.Net.Http.ByteArrayContent(_service.GetTemplate());
            response.Content.Headers.ContentType=new System.Net.Http.Headers.MediaTypeHeaderValue("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            response.Content.Headers.ContentDisposition=new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment") {FileName="GuestEventDrivers_Template.xlsx"};
            return response;
        }
        [SltAdmin]
        [HttpPost,Route("import")]
        public async Task<IHttpActionResult> Import()
        {
            var file=HttpContext.Current!=null && HttpContext.Current.Request.Files.Count>0
                ? HttpContext.Current.Request.Files[0] : null;
            if(file==null || file.ContentLength==0)return BadRequest("Upload an .xlsx file using multipart/form-data field 'file'.");
            if(file.ContentLength>10*1024*1024 || !file.FileName.EndsWith(".xlsx",StringComparison.OrdinalIgnoreCase))
                return BadRequest("Upload an .xlsx file up to 10 MB.");
            string mode = HttpContext.Current.Request.QueryString["mode"];
            try
            {
                byte[] excel;
                using (var ms = new System.IO.MemoryStream())
                {
                    await file.InputStream.CopyToAsync(ms);
                    excel = ms.ToArray();
                }
                ExcelImportResult result;
                using (var ms = new System.IO.MemoryStream(excel))
                    result = await _service.ImportAsync(ms, Actor, mode);
                await SltAlertHookRunner.TryAsync(() => SltOperationalAlertHooks.QueueImportedAsync(
                    excel, "Event", new System.Collections.Generic.HashSet<int>(
                        result.ErrorDetails.Select(x => x.RowNumber)), null));
                // Keep row-level errors in the HTTP 200 report for partial-success imports.
                return Ok(result);
            }
            catch (ArgumentException e)
            {
                return BadRequest(e.Message);
            }
        }
    }
}
