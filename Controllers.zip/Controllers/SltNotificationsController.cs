using System;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http;
using SLTProject.Filters;
using SLTProject.Services;

namespace SLTProject.Controllers
{
    [RoutePrefix("api/slt-notifications")]
    public sealed class SltNotificationsController : ApiController
    {
        private readonly SltNotificationsService service = new SltNotificationsService();

        private long IdentityId(string key)
        {
            object value;
            if (Request.Properties.TryGetValue(key, out value) && value != null)
            {
                long result;
                if (long.TryParse(Convert.ToString(value), out result) && result > 0) return result;
            }
            throw new UnauthorizedAccessException("Authenticated identity was not resolved.");
        }
        private string AdminEmail
        {
            get { object value; return Request.Properties.TryGetValue("SLTAdminEmail", out value) ? Convert.ToString(value) : null; }
        }

        // GET /api/slt-notifications/admin/guests?search=...
        [SltAdmin, HttpGet, Route("admin/guests")]
        public async Task<IHttpActionResult> Guests(string search = null)
        {
            return Ok(await service.GuestsForTargetAsync(search));
        }

        // POST /api/slt-notifications/admin/send
        [SltAdmin, HttpPost, Route("admin/send")]
        public async Task<IHttpActionResult> Send([FromBody] SltNotificationSendInput input, CancellationToken cancellationToken)
        {
            try { return Ok(await service.SendAsync(input, IdentityId("SLTAdminId"), AdminEmail, cancellationToken)); }
            catch (ArgumentException ex) { return BadRequest(ex.Message); }
            catch (UnauthorizedAccessException) { return Unauthorized(); }
        }

        // GET /api/slt-notifications/admin/sent?page=1&pageSize=20
        [SltAdmin, HttpGet, Route("admin/sent")]
        public async Task<IHttpActionResult> Sent(int page = 1, int pageSize = 20, bool unreadOnly = false)
        {
            try { return Ok(await service.AdminOutboxAsync(IdentityId("SLTAdminId"), page, pageSize, unreadOnly)); }
            catch (UnauthorizedAccessException) { return Unauthorized(); }
        }

        // POST /api/slt-notifications/admin/{id}/read
        [SltAdmin, HttpPost, Route("admin/{id:long}/read")]
        public async Task<IHttpActionResult> ReadAdmin(long id)
        {
            try { return await service.MarkAdminReadAsync(IdentityId("SLTAdminId"), id) ? (IHttpActionResult)Ok(new { IsRead = true }) : NotFound(); }
            catch (UnauthorizedAccessException) { return Unauthorized(); }
        }

        // GET /api/slt-notifications/guest/inbox
        [SltGuest, HttpGet, Route("guest/inbox")]
        public async Task<IHttpActionResult> Inbox(int page = 1, int pageSize = 20, bool unreadOnly = false)
        {
            try { return Ok(await service.GuestInboxAsync(IdentityId("SLTGuestId"), page, pageSize, unreadOnly)); }
            catch (UnauthorizedAccessException) { return Unauthorized(); }
        }

        // POST /api/slt-notifications/guest/{id}/read
        [SltGuest, HttpPost, Route("guest/{id:long}/read")]
        public async Task<IHttpActionResult> ReadGuest(long id)
        {
            try { return await service.MarkGuestReadAsync(IdentityId("SLTGuestId"), id) ? (IHttpActionResult)Ok(new { IsRead = true }) : NotFound(); }
            catch (UnauthorizedAccessException) { return Unauthorized(); }
        }

    }
}
