using System;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http;
using SLTProject.Filters;
using SLTProject.Services;
using SltPushIntegration;
using Newtonsoft.Json.Linq;
using System.Net;
using System.Net.Http;

namespace SLTProject.Controllers
{
    [RoutePrefix("api/slt-notifications")]
    public sealed class SltNotificationsController : ApiController
    {
        private readonly SltNotificationsService service = new SltNotificationsService();

        private long IdentityId(string key)
        {
            object value;
            if (Request.Properties.TryGetValue(key, out value) && value != null)
            {
                long result;
                if (long.TryParse(Convert.ToString(value), out result) && result > 0) return result;
            }
            throw new UnauthorizedAccessException("Authenticated identity was not resolved.");
        }
        private string AdminEmail
        {
            get { object value; return Request.Properties.TryGetValue("SLTAdminEmail", out value) ? Convert.ToString(value) : null; }
        }

        // GET /api/slt-notifications/admin/guests?search=...
        [SltAdmin, HttpGet, Route("admin/guests")]
        public async Task<IHttpActionResult> Guests(string search = null)
        {
            return Ok(await service.GuestsForTargetAsync(search));
        }

        // POST /api/slt-notifications/admin/send
        [SltAdmin, HttpPost, Route("admin/send")]
        public async Task<IHttpActionResult> Send([FromBody] SltNotificationSendInput input, CancellationToken cancellationToken)
        {
            try { return Ok(await service.SendAsync(input, IdentityId("SLTAdminId"), AdminEmail, cancellationToken)); }
            catch (ArgumentException ex) { return BadRequest(ex.Message); }
            catch (UnauthorizedAccessException) { return Unauthorized(); }
        }

        // GET /api/slt-notifications/admin/sent?page=1&pageSize=20
        [SltAdmin, HttpGet, Route("admin/sent")]
        public async Task<IHttpActionResult> Sent(int page = 1, int pageSize = 20, bool unreadOnly = false)
        {
            try { return Ok(await service.AdminOutboxAsync(IdentityId("SLTAdminId"), page, pageSize, unreadOnly)); }
            catch (UnauthorizedAccessException) { return Unauthorized(); }
        }

        // POST /api/slt-notifications/admin/{id}/read
        [SltAdmin, HttpPost, Route("admin/{id:long}/read")]
        public async Task<IHttpActionResult> ReadAdmin(long id)
        {
            try { return await service.MarkAdminReadAsync(IdentityId("SLTAdminId"), id) ? (IHttpActionResult)Ok(new { IsRead = true }) : NotFound(); }
            catch (UnauthorizedAccessException) { return Unauthorized(); }
        }

        // GET /api/slt-notifications/guest/inbox
        [SltGuest, HttpGet, Route("guest/inbox")]
        public async Task<IHttpActionResult> Inbox(int page = 1, int pageSize = 20, bool unreadOnly = false)
        {
            try { return Ok(await service.GuestInboxAsync(IdentityId("SLTGuestId"), page, pageSize, unreadOnly)); }
            catch (UnauthorizedAccessException) { return Unauthorized(); }
        }

        // POST /api/slt-notifications/guest/{id}/read
        [SltGuest, HttpPost, Route("guest/{id:long}/read")]
        public async Task<IHttpActionResult> ReadGuest(long id)
        {
            try { return await service.MarkGuestReadAsync(IdentityId("SLTGuestId"), id) ? (IHttpActionResult)Ok(new { IsRead = true }) : NotFound(); }
            catch (UnauthorizedAccessException) { return Unauthorized(); }
        }

        // SLT-origin subscription proxy avoids cross-origin browser calls.
        // Guest identity is ALWAYS taken from the validated SLT bearer token.
        [SltGuest, HttpGet, Route("guest/push/config")]
        public Task<IHttpActionResult> PushConfig(CancellationToken cancellationToken)
        {
            return ProxyPush("config", null, cancellationToken);
        }

        [SltGuest, HttpPost, Route("guest/push/subscriptions")]
        public Task<IHttpActionResult> PushSubscribe(
            [FromBody] JObject input, CancellationToken cancellationToken)
        {
            return ProxyPush("subscriptions", input, cancellationToken);
        }

        [SltGuest, HttpPost, Route("guest/push/subscriptions/status")]
        public Task<IHttpActionResult> PushSubscriptionStatus(
            [FromBody] JObject input, CancellationToken cancellationToken)
        {
            return ProxyPush("subscriptions/status", input, cancellationToken);
        }

        [SltGuest, HttpPost, Route("guest/push/subscriptions/unsubscribe")]
        public Task<IHttpActionResult> PushUnsubscribe(
            [FromBody] JObject input, CancellationToken cancellationToken)
        {
            return ProxyPush("subscriptions/unsubscribe", input, cancellationToken);
        }

        private async Task<IHttpActionResult> ProxyPush(
            string action, JObject input, CancellationToken cancellationToken)
        {
            long guestId;
            try { guestId = IdentityId("SLTGuestId"); }
            catch (UnauthorizedAccessException) { return Unauthorized(); }
            if (guestId > int.MaxValue) return BadRequest("Guest ID exceeds push provider limits.");
            if (action != "config" && input == null)
                return BadRequest("Subscription data is required.");
            if (input != null && input.ToString().Length > 16384)
                return BadRequest("Subscription data is too large.");
            try
            {
                var gateway = new GlobalPushV103Gateway();
                string token = null;
                if (action != "config")
                {
                    var issued = await gateway.SendAsync(HttpMethod.Post,
                        "registration-token",
                        new JObject { ["userReference"] =
                            GlobalPushV103Gateway.GuestUserReference((int)guestId) },
                        cancellationToken);
                    if (!issued.IsSuccess)
                        return Content(HttpStatusCode.BadGateway, new {
                            Message = "Global Push could not issue a registration token.",
                            ProviderStatus = (int)issued.Status });
                    token = (string)issued.Body["token"];
                    if (string.IsNullOrWhiteSpace(token))
                        return Content(HttpStatusCode.BadGateway, new {
                            Message = "Global Push token response has no token field." });
                }
                var result = await gateway.BrowserOperationAsync(
                    action, input, token, cancellationToken);
                if (!result.IsSuccess)
                    return Content(HttpStatusCode.BadGateway, new {
                        Message = "Global Push browser registration request failed.",
                        ProviderStatus = (int)result.Status,
                        Operation = action });
                return Ok(result.Body);
            }
            catch (Exception ex) when (ex is HttpRequestException ||
                ex is TaskCanceledException || ex is InvalidOperationException ||
                ex is ArgumentException || ex is UriFormatException)
            {
                System.Diagnostics.Trace.TraceWarning("SLT push proxy " +
                    action + " failed: " + ex.GetType().Name);
                return Content(HttpStatusCode.ServiceUnavailable, new {
                    Message = "Global Push is currently unavailable.",
                    Operation = action });
            }
        }

        // Only a validated guest may obtain their own Global Push registration token.
        [SltGuest, HttpPost, Route("guest/registration-token")]
        public async Task<IHttpActionResult> RegistrationToken(CancellationToken cancellationToken)
        {
            long guestId;
            try { guestId = IdentityId("SLTGuestId"); }
            catch (UnauthorizedAccessException) { return Unauthorized(); }
            if (guestId > int.MaxValue) return BadRequest("Guest ID outside push provider limits.");
            try
            {
                var gateway = new GlobalPushV103Gateway();
                var response = await gateway.SendAsync(HttpMethod.Post, "registration-token",
                    new JObject { ["userReference"] = GlobalPushV103Gateway.GuestUserReference((int)guestId) }, cancellationToken);
                if (!response.IsSuccess) return Content(HttpStatusCode.BadGateway, new { Message = "Push registration service is unavailable.", ProviderStatus = (int)response.Status });
                var token = (string)response.Body["token"];
                if (String.IsNullOrWhiteSpace(token)) return Content(HttpStatusCode.BadGateway, new { Message = "Push registration response is invalid." });
                return Ok(new { token = token, expiresInSeconds = 600 });
            }
            catch (Exception ex) when (ex is HttpRequestException || ex is TaskCanceledException || ex is InvalidOperationException || ex is UriFormatException)
            {
                System.Diagnostics.Trace.TraceWarning("SLT push registration failed: " + ex.GetType().Name);
                return Content(HttpStatusCode.ServiceUnavailable, new { Message = "Push registration is not currently available." });
            }
        }
    }
}
