
using SLTProject.Filters;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.IO;
using System.Net;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Threading.Tasks;
using System.Web;
using System.Web.Hosting;
using System.Web.Http;
using System.Web.Security;
using SLTProject.Services;
using SLTProject.Models.Dtos;
using SLTProject.Data;

namespace SLTProject.Controllers
{
    [SltAdmin]
    [RoutePrefix("api/guests")]
    public class GuestsController : ApiController
    {
        private readonly GuestsService _service =
            new GuestsService();

        private readonly GuestOperationsService _operations =
            new GuestOperationsService();

        private string Actor
        {
            get
            {
                object value;

                if (Request.Properties.TryGetValue(
                    "SLTAdminEmail", out value))
                {
                    return value as string ?? "System";
                }

                return "System";
            }
        }

        // ============================================================
        // QR FOLDER CONFIGURATION
        // ============================================================

        private static readonly string[] QrExtensions =
        {
            ".png", ".jpg", ".jpeg", ".webp"
        };

        private static string ResolveQrFolderPath()
        {
            string configured =
                ConfigurationManager.AppSettings[
                    "SLTGuestQrFolder"];

            if (string.IsNullOrWhiteSpace(configured))
                configured = "~/App_Data/GuestQRCodes";

            configured = configured.Trim();

            if (Path.IsPathRooted(configured))
                return Path.GetFullPath(configured);

            string virtualPath;

            if (configured.StartsWith(
                    "~/", StringComparison.Ordinal) ||
                configured.StartsWith(
                    "~\\", StringComparison.Ordinal))
            {
                virtualPath = configured.Replace('\\', '/');
            }
            else
            {
                virtualPath = "~/" +
                    configured.TrimStart('/', '\\')
                        .Replace('\\', '/');
            }

            string mappedPath =
                HostingEnvironment.MapPath(virtualPath);

            if (string.IsNullOrWhiteSpace(mappedPath))
            {
                throw new InvalidOperationException(
                    "The guest QR folder path could not be mapped. " +
                    "Check SLTGuestQrFolder in Web.config.");
            }

            return Path.GetFullPath(mappedPath);
        }

        private static string GetQrMimeType(string extension)
        {
            switch ((extension ?? "").ToLowerInvariant())
            {
                case ".png":
                    return "image/png";

                case ".jpg":
                case ".jpeg":
                    return "image/jpeg";

                case ".webp":
                    return "image/webp";

                default:
                    return "application/octet-stream";
            }
        }

        // ============================================================
        // GET QR FROM FOLDER
        //
        // Folder QR has priority over database QR.
        // Filename must match the guest email.
        //
        // Returns:
        // Item1 = Image bytes
        // Item2 = MIME type
        // Item3 = Filename
        // ============================================================

        internal static Tuple<byte[], string, string> GetQrFromFolder(
            string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return null;

            string normalizedEmail =
                email.Trim().ToLowerInvariant();

            if (!string.Equals(
                    Path.GetFileName(normalizedEmail),
                    normalizedEmail,
                    StringComparison.OrdinalIgnoreCase) ||
                normalizedEmail.IndexOfAny(
                    Path.GetInvalidFileNameChars()) >= 0)
            {
                return null;
            }

            string folder = ResolveQrFolderPath();

            if (!Directory.Exists(folder))
                return null;

            var matchingFile = Directory.GetFiles(
                    folder,
                    "*",
                    SearchOption.TopDirectoryOnly)
                .FirstOrDefault(path =>
                    string.Equals(
                        Path.GetFileNameWithoutExtension(path).Trim(),
                        normalizedEmail,
                        StringComparison.OrdinalIgnoreCase) &&
                    QrExtensions.Contains(
                        Path.GetExtension(path),
                        StringComparer.OrdinalIgnoreCase));

            if (matchingFile == null)
                return null;

            string extension =
                Path.GetExtension(matchingFile);

            var fileInfo = new FileInfo(matchingFile);

            const long maxQrBytes =
                5L * 1024L * 1024L;

            if (fileInfo.Length <= 0 ||
                fileInfo.Length > maxQrBytes)
            {
                throw new InvalidOperationException(
                    "The QR image is empty or exceeds 5 MB.");
            }

            return Tuple.Create(
                File.ReadAllBytes(matchingFile),
                GetQrMimeType(extension),
                Path.GetFileName(matchingFile));
        }

        // ============================================================
        // QR FOLDER STATUS
        // GET api/guests/qr-folder/status
        // ============================================================

        [HttpGet]
        [Route("qr-folder/status")]
        public async Task<IHttpActionResult> QrFolderStatus()
        {
            try
            {
                string folder = ResolveQrFolderPath();

                bool folderExists =
                    Directory.Exists(folder);

                var files = folderExists
                    ? Directory.GetFiles(
                        folder,
                        "*",
                        SearchOption.TopDirectoryOnly)
                    : new string[0];

                var imageFiles = files
                    .Where(path => QrExtensions.Contains(
                        Path.GetExtension(path),
                        StringComparer.OrdinalIgnoreCase))
                    .ToList();

                var availableEmails =
                    new HashSet<string>(
                        imageFiles.Select(path =>
                            Path.GetFileNameWithoutExtension(path).Trim()),
                        StringComparer.OrdinalIgnoreCase);

                List<string> activeGuestEmails;

                using (var db = new SLTEntities())
                {
                    activeGuestEmails =
                        await db.Guests
                            .AsNoTracking()
                            .Where(x =>
                                !x.IsDeleted &&
                                x.Email != null &&
                                x.Email != "")
                            .Select(x => x.Email)
                            .ToListAsync();
                }

                int matchedGuests =
                    activeGuestEmails.Count(email =>
                        availableEmails.Contains(email.Trim()));

                return Ok(new
                {
                    Success = true,

                    FolderExists = folderExists,
                    FolderAccessible = folderExists,

                    FolderName = Path.GetFileName(
                        folder.TrimEnd(
                            Path.DirectorySeparatorChar,
                            Path.AltDirectorySeparatorChar)),

                    ImagesInFolder = imageFiles.Count,

                    ActiveGuests = activeGuestEmails.Count,

                    GuestsWithFolderQr = matchedGuests,

                    GuestsMissingQr =
                        activeGuestEmails.Count - matchedGuests,

                    SupportedExtensions = QrExtensions
                });
            }
            catch (UnauthorizedAccessException)
            {
                return Content(
                    HttpStatusCode.Forbidden,
                    new
                    {
                        Success = false,
                        FolderExists = false,
                        FolderAccessible = false,

                        Message =
                            "IIS does not have permission to read " +
                            "the guest QR folder."
                    });
            }
            catch (Exception ex)
            {
                return Content(
                    HttpStatusCode.InternalServerError,
                    new
                    {
                        Success = false,
                        FolderAccessible = false,
                        Message =
                            "Unable to inspect the guest QR folder.",
                        Detail = ex.Message
                    });
            }
        }

        // ============================================================
        // GET PAGED
        // GET /api/guests/paged
        // ============================================================

        [HttpGet]
        [Route("paged")]
        public async Task<IHttpActionResult> Paged(
            [FromUri] SltTableQuery query)
        {
            try
            {
                var result = await _service.GetPagedAsync(
                    query ?? new SltTableQuery());

                return Ok(result);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // ============================================================
        // EXPORT
        // GET /api/guests/export
        // ============================================================

        [HttpGet]
        [Route("export")]
        public async Task<HttpResponseMessage> Export(
            [FromUri] SltTableQuery query)
        {
            byte[] content;

            try
            {
                content = await _service.ExportFilteredAsync(
                    query ?? new SltTableQuery());
            }
            catch (ArgumentException ex)
            {
                return Request.CreateErrorResponse(
                    HttpStatusCode.BadRequest,
                    ex.Message);
            }

            var response =
                Request.CreateResponse(HttpStatusCode.OK);

            response.Content =
                new ByteArrayContent(content);

            response.Content.Headers.ContentType =
                new MediaTypeHeaderValue(
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

            response.Content.Headers.ContentDisposition =
                new ContentDispositionHeaderValue("attachment")
                {
                    FileName = "SLT_guests_Filtered.xlsx"
                };

            response.Headers.CacheControl =
                new CacheControlHeaderValue { NoStore = true };

            return response;
        }

        // ============================================================
        // GET ALL
        // ============================================================

        [HttpGet]
        [Route("")]
        public async Task<IHttpActionResult> GetAll()
        {
            return Ok(await _service.GetAllAsync());
        }

        // ============================================================
        // LOGGED-IN STATISTICS
        // ============================================================

        [HttpGet]
        [Route("statistics/logged-in")]
        public async Task<IHttpActionResult>
            GetLoggedInStatistics()
        {
            int loggedInGuests =
                await _service.GetLoggedInGuestsCountAsync();

            return Ok(new
            {
                Success = true,
                LoggedInGuests = loggedInGuests
            });
        }

        // ============================================================
        // GET BY ID
        // ============================================================

        [HttpGet]
        [Route("{id:long}")]
        public async Task<IHttpActionResult> Get(long id)
        {
            var guest = await _service.GetAsync(id);

            return guest == null
                ? (IHttpActionResult)NotFound()
                : Ok(guest);
        }

        // ============================================================
        // CREATE
        // ============================================================

        [HttpPost]
        [Route("")]
        public async Task<IHttpActionResult> Create(
            GuestInput input)
        {
            if (input == null)
                return BadRequest(
                    "Guest information is required.");

            try
            {
                var result = await _service.CreateAsync(
                    input,
                    Actor);

                return Content(
                    HttpStatusCode.Created,
                    new
                    {
                        result.Guest,
                        result.Passcode,
                        EmailSent = false,
                        SmsSent = false,
                        Message =
                            "Guest created. Select recipients in " +
                            "Send Invitations when ready."
                    });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // ============================================================
        // UPDATE
        // ============================================================

        [HttpPut]
        [Route("{id:long}")]
        public async Task<IHttpActionResult> Update(
            long id,
            GuestInput input)
        {
            if (input == null)
                return BadRequest(
                    "Guest information required.");

            try
            {
                var result = await _service.UpdateAsync(
                    id,
                    input,
                    Actor);

                return result == null
                    ? (IHttpActionResult)NotFound()
                    : Ok(result);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // ============================================================
        // SOFT DELETE
        // ============================================================

        [HttpDelete]
        [Route("{id:long}")]
        public async Task<IHttpActionResult> Delete(long id)
        {
            bool deleted = await _service.DeleteAsync(
                id,
                Actor);

            return deleted
                ? Ok(new
                {
                    Message = "Guest soft deleted."
                })
                : (IHttpActionResult)NotFound();
        }

        // ============================================================
        // RESET PASSCODE
        // ============================================================

        [HttpPost]
        [Route("{id:long}/reset-passcode")]
        public async Task<IHttpActionResult> ResetPasscode(
            long id)
        {
            string passcode =
                await _service.ResetPasscodeAsync(
                    id,
                    Actor);

            if (passcode == null)
                return NotFound();

            return Ok(new
            {
                Passcode = passcode,
                EmailSent = false,
                SmsSent = false,
                Message =
                    "Passcode reset. Send it later using " +
                    "the admin delivery panel."
            });
        }

        // ============================================================
        // GET PASSCODE
        // ============================================================

        [HttpGet]
        [Route("{id:long}/passcode")]
        public async Task<IHttpActionResult> GetPasscode(long id)
        {
            try
            {
                string passcode =
                    await _service.GetPasscodeForAdminAsync(
                        id,
                        Actor);

                if (passcode == null)
                    return NotFound();

                var response = Request.CreateResponse(
                    HttpStatusCode.OK,
                    new { Passcode = passcode });

                response.Headers.CacheControl =
                    new CacheControlHeaderValue
                    {
                        NoStore = true,
                        NoCache = true
                    };

                response.Headers.Pragma.Add(
                    new NameValueHeaderValue("no-cache"));

                return ResponseMessage(response);
            }
            catch (InvalidOperationException)
            {
                return Content(
                    HttpStatusCode.Conflict,
                    new
                    {
                        Message =
                            "The guest passcode cannot be decrypted " +
                            "using the current protection configuration. " +
                            "Check the original machineKey before " +
                            "resetting this guest's passcode."
                    });
            }
        }

        // ============================================================
        // ENCRYPTION DIAGNOSTIC
        // ============================================================

        [HttpGet]
        [Route("diagnostics/encryption")]
        public IHttpActionResult TestEncryption()
        {
            try
            {
                const string sample = "123456";

                byte[] protectedValue = MachineKey.Protect(
                    System.Text.Encoding.UTF8.GetBytes(sample),
                    "SLTProject",
                    "GuestPasscode",
                    "v1");

                byte[] clear = MachineKey.Unprotect(
                    protectedValue,
                    "SLTProject",
                    "GuestPasscode",
                    "v1");

                bool success = clear != null &&
                    System.Text.Encoding.UTF8.GetString(clear) == sample;

                return Ok(new
                {
                    EncryptionWorking = success,
                    CurrentApplicationRoundTrip =
                        success ? "Success" : "Failed"
                });
            }
            catch (CryptographicException)
            {
                return Content(
                    HttpStatusCode.InternalServerError,
                    new
                    {
                        EncryptionWorking = false,
                        Message =
                            "The current ASP.NET cryptographic " +
                            "round-trip failed."
                    });
            }
        }

        // ============================================================
        // UPLOAD QR
        // POST api/guests/{id}/qr
        // Existing manual upload route preserved.
        // ============================================================

        [HttpPost]
        [Route("{id:long}/qr")]
        public async Task<IHttpActionResult> UploadQr(long id)
        {
            if (!Request.Content.IsMimeMultipartContent())
                return BadRequest(
                    "Upload image as multipart/form-data.");

            var provider =
                new MultipartMemoryStreamProvider();

            await Request.Content.ReadAsMultipartAsync(provider);

            if (provider.Contents.Count != 1)
                return BadRequest(
                    "Upload exactly one image.");

            var file = provider.Contents[0];

            string fileName = file.Headers
                .ContentDisposition
                ?.FileName
                ?.Trim('"');

            if (string.IsNullOrWhiteSpace(fileName))
                return BadRequest(
                    "Image filename required.");

            byte[] bytes =
                await file.ReadAsByteArrayAsync();

            try
            {
                bool uploaded =
                    await _service.UploadQrAsync(
                        id,
                        bytes,
                        fileName,
                        file.Headers.ContentType?.MediaType,
                        Actor);

                return uploaded
                    ? Ok(new
                    {
                        Message = "QR image uploaded."
                    })
                    : (IHttpActionResult)NotFound();
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // ============================================================
        // GET QR
        // GET api/guests/{id}/qr
        //
        // Folder image first, database image second.
        //
        // Tuple:
        // Item1 = Image bytes
        // Item2 = MIME type
        // Item3 = Filename
        // ============================================================

        [HttpGet]
        [Route("{id:long}/qr")]
        public async Task<HttpResponseMessage> GetQr(long id)
        {
            var guest = await _service.GetAsync(id);

            if (guest == null)
                return Request.CreateResponse(
                    HttpStatusCode.NotFound);

            // Updated to match GuestsService.GetQrAsync().
            Tuple<byte[], string, string> qr = null;

            try
            {
                // First priority: automatic folder lookup.
                qr = GetQrFromFolder(guest.Email);
            }
            catch (InvalidOperationException)
            {
                return Request.CreateErrorResponse(
                    HttpStatusCode.InternalServerError,
                    "The guest QR image is invalid or exceeds 5 MB.");
            }

            // Second priority: database QR.
            if (qr == null)
                qr = await _service.GetQrAsync(id);

            if (qr == null)
                return Request.CreateResponse(
                    HttpStatusCode.NotFound);

            return ImageResponse(
                qr.Item1,
                qr.Item2);
        }

        // ============================================================
        // DELETE QR
        // Existing database QR deletion route preserved.
        // ============================================================

        [HttpDelete]
        [Route("{id:long}/qr")]
        public async Task<IHttpActionResult> RemoveQr(long id)
        {
            bool removed = await _service.RemoveQrAsync(
                id,
                Actor);

            return removed
                ? Ok(new
                {
                    Message = "QR image removed."
                })
                : (IHttpActionResult)NotFound();
        }

        // ============================================================
        // BULK UPLOAD
        // POST api/guests/bulk-upload
        // ============================================================

        [HttpPost]
        [Route("bulk-upload")]
        public async Task<IHttpActionResult> BulkUpload()
        {
            if (!Request.Content.IsMimeMultipartContent())
                return BadRequest(
                    "Excel file required.");

            var provider =
                new MultipartMemoryStreamProvider();

            await Request.Content.ReadAsMultipartAsync(provider);

            if (provider.Contents.Count != 1)
                return BadRequest(
                    "Upload one Excel file.");

            var file = provider.Contents[0];

            string fileName = file.Headers
                .ContentDisposition
                ?.FileName
                ?.Trim('"');

            if (string.IsNullOrWhiteSpace(fileName) ||
                !fileName.EndsWith(
                    ".xlsx",
                    StringComparison.OrdinalIgnoreCase))
            {
                return BadRequest(
                    "Only .xlsx files supported.");
            }

            byte[] bytes =
                await file.ReadAsByteArrayAsync();

            if (bytes.Length == 0 ||
                bytes.Length > 10 * 1024 * 1024)
            {
                return BadRequest(
                    "Excel file must be 10 MB or smaller.");
            }

            try
            {
                string mode = "Upsert";

                var modeValues = Request.GetQueryNameValuePairs()
                    .Where(x => string.Equals(
                        x.Key,
                        "mode",
                        StringComparison.OrdinalIgnoreCase))
                    .Select(x => x.Value)
                    .FirstOrDefault();

                if (!string.IsNullOrWhiteSpace(modeValues))
                    mode = modeValues;

                var result = await _operations.ImportAsync(
                    bytes,
                    mode,
                    Actor);

                return Ok(new
                {
                    statusCode = 200,
                    result = result
                });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception)
            {
                return Content(
                    HttpStatusCode.InternalServerError,
                    new
                    {
                        statusCode = 500,
                        errorMessage =
                            "Guest import failed. Check server logs."
                    });
            }
        }

        // ============================================================
        // ROW DETAILS
        // ============================================================

        [HttpGet]
        [Route("row-details")]
        public async Task<IHttpActionResult> RowDetails(
            [FromUri] string ids)
        {
            var parsed = new List<long>();

            foreach (string part in (ids ?? "").Split(','))
            {
                long id;

                if (!long.TryParse(part, out id) || id <= 0)
                    return BadRequest("Invalid guest IDs.");

                parsed.Add(id);
            }

            if (parsed.Count == 0 || parsed.Count > 200)
                return BadRequest(
                    "Provide 1 to 200 guest IDs.");

            return Ok(
                await _operations.RowDetailsAsync(
                    parsed.Distinct().ToList()));
        }

        // ============================================================
        // GUEST STATISTICS
        // ============================================================

        [HttpGet]
        [Route("statistics")]
        public async Task<IHttpActionResult> Statistics()
        {
            return Ok(await _operations.StatisticsAsync());
        }

        // ============================================================
        // EXPORT SEGMENT
        // ============================================================

        [HttpGet]
        [Route("export-segment")]
        public async Task<HttpResponseMessage> ExportSegment(
            [FromUri] string segment = "all")
        {
            try
            {
                byte[] bytes =
                    await _operations.ExportAsync(segment ?? "all");

                return ExcelResponse(
                    bytes,
                    "SLT_Guests_" + (segment ?? "all") + ".xlsx");
            }
            catch (ArgumentException ex)
            {
                return Request.CreateErrorResponse(
                    HttpStatusCode.BadRequest,
                    ex.Message);
            }
        }

        // ============================================================
        // EXCEL TEMPLATE
        // ============================================================

        [HttpGet]
        [Route("excel-template")]
        public HttpResponseMessage ExcelTemplate()
        {
            return ExcelResponse(
                _operations.BuildTemplate(),
                "SLT_Guests_Import_Template.xlsx");
        }

        // ============================================================
        // SEND INVITATIONS
        // ============================================================

        [HttpPost]
        [Route("send-invitations")]
        public async Task<IHttpActionResult> SendInvitations(
            GuestDistributionInput input)
        {
            try
            {
                return Ok(
                    await _operations.DistributeAsync(
                        input,
                        Actor));
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // ============================================================
        // SMS TEMPLATE DTO
        // ============================================================

        public sealed class SmsTemplateInput
        {
            public string TemplateKey { get; set; }
            public string TemplateBody { get; set; }
            public bool IsActive { get; set; }
        }

        // ============================================================
        // GET SMS TEMPLATES
        // ============================================================

        [HttpGet]
        [Route("sms-templates")]
        public async Task<IHttpActionResult> SmsTemplates()
        {
            return Ok(await _operations.GetTemplatesAsync());
        }

        // ============================================================
        // UPDATE SMS TEMPLATE
        // ============================================================

        [HttpPut]
        [Route("sms-templates")]
        public async Task<IHttpActionResult> UpdateSmsTemplate(
            SmsTemplateInput input)
        {
            if (input == null)
                return BadRequest("SMS template required.");

            try
            {
                await _operations.SaveTemplateAsync(
                    input.TemplateKey,
                    input.TemplateBody,
                    input.IsActive,
                    Actor);

                return Ok(new
                {
                    Message = "SMS template saved."
                });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // ============================================================
        // EXCEL RESPONSE
        // ============================================================

        private HttpResponseMessage ExcelResponse(
            byte[] bytes,
            string filename)
        {
            var response =
                Request.CreateResponse(HttpStatusCode.OK);

            response.Content =
                new ByteArrayContent(bytes);

            response.Content.Headers.ContentType =
                new MediaTypeHeaderValue(
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

            response.Content.Headers.ContentDisposition =
                new ContentDispositionHeaderValue("attachment")
                {
                    FileName = filename
                };

            response.Headers.CacheControl =
                new CacheControlHeaderValue { NoStore = true };

            return response;
        }

        // ============================================================
        // IMAGE RESPONSE
        // ============================================================

        internal static HttpResponseMessage ImageResponse(
            byte[] bytes,
            string mime)
        {
            var response =
                new HttpResponseMessage(HttpStatusCode.OK);

            response.Content =
                new ByteArrayContent(bytes);

            response.Content.Headers.ContentType =
                new MediaTypeHeaderValue(mime);

            response.Headers.CacheControl =
                new CacheControlHeaderValue
                {
                    NoStore = true
                };

            return response;
        }
    }

    // ================================================================
    // GUEST AUTHENTICATION CONTROLLER
    // ================================================================

    [AllowAnonymous]
    [RoutePrefix("api/guest-auth")]
    public class GuestAuthController : ApiController
    {
        private readonly GuestsService _service =
            new GuestsService();

        private string Token
        {
            get
            {
                var auth =
                    Request.Headers.Authorization;

                return auth != null &&
                    string.Equals(
                        auth.Scheme,
                        "Bearer",
                        StringComparison.OrdinalIgnoreCase)
                    ? auth.Parameter : null;
            }
        }

        // ============================================================
        // LOGIN
        // ============================================================

        [HttpPost]
        [Route("login")]
        public async Task<IHttpActionResult> Login(
            GuestLoginInput input)
        {
            if (input == null ||
                string.IsNullOrWhiteSpace(input.Passcode))
            {
                return BadRequest(
                    "Passcode is required.");
            }

            string clientIp =
                HttpContext.Current?.Request?.UserHostAddress;

            var result = await _service.LoginAsync(
                input.Passcode,
                clientIp);

            if (result == null)
            {
                return Content(
                    HttpStatusCode.Unauthorized,
                    new
                    {
                        Message =
                            "Invalid or used passcode, " +
                            "or login temporarily blocked."
                    });
            }

            return Ok(result);
        }

        // ============================================================
        // CURRENT GUEST
        // ============================================================

        [HttpGet]
        [Route("me")]
        public async Task<IHttpActionResult> Me()
        {
            var guest =
                await _service.CurrentAsync(Token);

            return guest == null
                ? (IHttpActionResult)Unauthorized()
                : Ok(guest);
        }

        // ============================================================
        // MY QR
        // GET api/guest-auth/my-qr
        //
        // Folder image first, database image second.
        //
        // Tuple:
        // Item1 = Image bytes
        // Item2 = MIME type
        // Item3 = Filename
        // ============================================================

        [HttpGet]
        [Route("my-qr")]
        public async Task<HttpResponseMessage> MyQr()
        {
            var guest =
                await _service.CurrentAsync(Token);

            if (guest == null)
                return Request.CreateResponse(
                    HttpStatusCode.Unauthorized);

            // Updated to match GuestsService.GetQrAsync().
            Tuple<byte[], string, string> qr = null;

            try
            {
                // First priority: automatic folder lookup.
                qr = GuestsController.GetQrFromFolder(
                    guest.Email);
            }
            catch (InvalidOperationException)
            {
                return Request.CreateErrorResponse(
                    HttpStatusCode.InternalServerError,
                    "Your QR image is invalid or exceeds 5 MB.");
            }

            // Second priority: database QR.
            if (qr == null)
                qr = await _service.GetQrAsync(guest.Id);

            if (qr == null)
                return Request.CreateResponse(
                    HttpStatusCode.NotFound);

            return GuestsController.ImageResponse(
                qr.Item1,
                qr.Item2);
        }

        // ============================================================
        // TOUR REGISTRATION
        // ============================================================

        [HttpPost]
        [Route("tour-register")]
        public async Task<IHttpActionResult> TourRegister()
        {
            string token = Token;

            if (string.IsNullOrWhiteSpace(token))
                return Unauthorized();

            bool registered =
                await _service.RegisterForTourAsync(token);

            if (!registered)
                return Unauthorized();

            return Ok(new
            {
                Success = true,
                TourRegister = true,
                Message =
                    "Successfully registered for the tour."
            });
        }
    }
}
