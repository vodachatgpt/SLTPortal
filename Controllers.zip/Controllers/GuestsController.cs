using SLTProject.Filters;

using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Security;
using SLTProject.Services;
using SLTProject.Models.Dtos;

namespace SLTProject.Controllers
{
    [SltAdmin]
    [RoutePrefix("api/guests")]
    public class GuestsController : ApiController
    {
        private readonly GuestsService _service =
            new GuestsService();

        private readonly EmailTemplateService _emailService =
            new EmailTemplateService();

        private string Actor
        {
            get
            {
                return (string)Request.Properties[
                    "SLTAdminEmail"];
            }
        }

        // ============================================================
        // GET /api/guests/paged
        // Admin only: filters and pagination run in SQL Server.
        // ============================================================
        [SltAdmin]
        [HttpGet]
        [Route("paged")]
        public async Task<IHttpActionResult> Paged([FromUri] SltTableQuery query)
        {
            try
            {
                var result = await _service.GetPagedAsync(query ?? new SltTableQuery());
                return Ok(result);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // ============================================================
        // GET /api/guests/export
        // Admin only: exports ALL filtered records, not only page 1.
        // ============================================================
        [SltAdmin]
        [HttpGet]
        [Route("export")]
        public async Task<HttpResponseMessage> Export([FromUri] SltTableQuery query)
        {
            byte[] content;
            try
            {
                content = await _service.ExportFilteredAsync(query ?? new SltTableQuery());
            }
            catch (ArgumentException ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }

            var response = Request.CreateResponse(HttpStatusCode.OK);
            response.Content = new ByteArrayContent(content);
            response.Content.Headers.ContentType = new MediaTypeHeaderValue(
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            response.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment")
            {
                FileName = "SLT_guests_Filtered.xlsx"
            };
            response.Headers.CacheControl = new CacheControlHeaderValue { NoStore = true };
            return response;
        }


        [HttpGet]
        [Route("")]
        public async Task<IHttpActionResult> GetAll()
        {
            return Ok(await _service.GetAllAsync());
        }

        // ============================================================
        // GET api/guests/statistics/logged-in
        //
        // Returns the number of guests who have logged in
        // at least once using Guests.FirstLoginAt.
        //
        // Requires administrator authentication.
        // ============================================================

        [HttpGet]
        [Route("statistics/logged-in")]
        public async Task<IHttpActionResult> GetLoggedInStatistics()
        {
            int loggedInGuests =
                await _service.GetLoggedInGuestsCountAsync();

            return Ok(new
            {
                Success = true,
                LoggedInGuests = loggedInGuests
            });
        }


        [HttpGet]
        [Route("{id:long}")]
        public async Task<IHttpActionResult> Get(long id)
        {
            var guest = await _service.GetAsync(id);

            return guest == null
                ? (IHttpActionResult)NotFound()
                : Ok(guest);
        }

        [HttpPost]
        [Route("")]
        public async Task<IHttpActionResult> Create(
            GuestInput input)
        {
            if (input == null)
                return BadRequest(
                    "Guest information is required.");

            try
            {
                var result = await _service.CreateAsync(
                    input, Actor);

                bool emailSent = false;

                try
                {
                    emailSent = await _emailService.SendAsync(
                        "GUEST_WELCOME",
                        result.Guest.Email,
                        result.Guest.FullName,
                        result.Passcode);
                }
                catch (Exception)
                {
                    // Guest is already saved.
                    // Do not create a duplicate guest.
                    // Log non-sensitive delivery diagnostics.
                }

                return Content(
                    HttpStatusCode.Created,
                    new
                    {
                        result.Guest,
                        result.Passcode,
                        EmailSent = emailSent,
                        Message = emailSent
                            ? "Guest created and email accepted."
                            : "Guest created; email delivery " +
                              "was not confirmed."
                    });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        [Route("{id:long}")]
        public async Task<IHttpActionResult> Update(
            long id,
            GuestInput input)
        {
            if (input == null)
                return BadRequest(
                    "Guest information required.");

            try
            {
                var result = await _service.UpdateAsync(
                    id, input, Actor);

                return result == null
                    ? (IHttpActionResult)NotFound()
                    : Ok(result);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete]
        [Route("{id:long}")]
        public async Task<IHttpActionResult> Delete(long id)
        {
            bool deleted = await _service.DeleteAsync(
                id, Actor);

            return deleted
                ? Ok(new
                {
                    Message = "Guest soft deleted."
                })
                : (IHttpActionResult)NotFound();
        }

        [HttpPost]
        [Route("{id:long}/reset-passcode")]
        public async Task<IHttpActionResult> ResetPasscode(
            long id)
        {
            string passcode =
                await _service.ResetPasscodeAsync(
                    id, Actor);

            if (passcode == null)
                return NotFound();

            var guest = await _service.GetAsync(id);

            bool emailSent = false;

            try
            {
                if (guest != null)
                {
                    emailSent = await _emailService.SendAsync(
                        "GUEST_PASSCODE_RESET",
                        guest.Email,
                        guest.FullName,
                        passcode);
                }
            }
            catch (Exception)
            {
                // The reset is already committed.
                // Do not perform another reset.
            }

            return Ok(new
            {
                Passcode = passcode,
                EmailSent = emailSent,
                Message = emailSent
                    ? "Passcode reset and email accepted."
                    : "Passcode reset; email delivery " +
                      "was not confirmed."
            });
        }

        [HttpGet]
        [Route("{id:long}/passcode")]
        public async Task<IHttpActionResult> GetPasscode(long id)
        {
            try
            {
                string passcode = await _service.GetPasscodeForAdminAsync(id, Actor);
                if (passcode == null)
                    return NotFound();

                var response = Request.CreateResponse(HttpStatusCode.OK,
                    new { Passcode = passcode });
                response.Headers.CacheControl = new CacheControlHeaderValue
                {
                    NoStore = true,
                    NoCache = true
                };
                response.Headers.Pragma.Add(new NameValueHeaderValue("no-cache"));
                return ResponseMessage(response);
            }
            catch (InvalidOperationException)
            {
                return Content(HttpStatusCode.Conflict, new
                {
                    Message = "The guest passcode cannot be decrypted using the current protection configuration. " +
                              "Check the original machineKey before resetting this guest's passcode."
                });
            }
        }

        // Temporary, admin-protected diagnostic. Remove after investigation.
        [HttpGet]
        [Route("diagnostics/encryption")]
        public IHttpActionResult TestEncryption()
        {
            try
            {
                const string sample = "123456";
                byte[] protectedValue = MachineKey.Protect(
                    System.Text.Encoding.UTF8.GetBytes(sample),
                    "SLTProject", "GuestPasscode", "v1");
                byte[] clear = MachineKey.Unprotect(
                    protectedValue, "SLTProject", "GuestPasscode", "v1");
                bool success = clear != null &&
                    System.Text.Encoding.UTF8.GetString(clear) == sample;
                return Ok(new
                {
                    EncryptionWorking = success,
                    CurrentApplicationRoundTrip = success ? "Success" : "Failed"
                });
            }
            catch (CryptographicException)
            {
                return Content(HttpStatusCode.InternalServerError, new
                {
                    EncryptionWorking = false,
                    Message = "The current ASP.NET cryptographic round-trip failed."
                });
            }
        }

        [HttpPost]
        [Route("{id:long}/qr")]
        public async Task<IHttpActionResult> UploadQr(
            long id)
        {
            if (!Request.Content.IsMimeMultipartContent())
                return BadRequest(
                    "Upload image as multipart/form-data.");

            var provider =
                new MultipartMemoryStreamProvider();

            await Request.Content
                .ReadAsMultipartAsync(provider);

            if (provider.Contents.Count != 1)
                return BadRequest(
                    "Upload exactly one image.");

            var file = provider.Contents[0];

            string fileName = file.Headers
                .ContentDisposition
                ?.FileName
                ?.Trim('"');

            if (string.IsNullOrWhiteSpace(fileName))
                return BadRequest(
                    "Image filename required.");

            byte[] bytes =
                await file.ReadAsByteArrayAsync();

            try
            {
                bool uploaded =
                    await _service.UploadQrAsync(
                        id,
                        bytes,
                        fileName,
                        file.Headers.ContentType?.MediaType,
                        Actor);

                return uploaded
                    ? Ok(new
                    {
                        Message = "QR image uploaded."
                    })
                    : (IHttpActionResult)NotFound();
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("{id:long}/qr")]
        public async Task<HttpResponseMessage> GetQr(
            long id)
        {
            var qr = await _service.GetQrAsync(id);

            if (qr == null)
                return Request.CreateResponse(
                    HttpStatusCode.NotFound);

            return ImageResponse(
                qr.Item1,
                qr.Item2);
        }

        [HttpDelete]
        [Route("{id:long}/qr")]
        public async Task<IHttpActionResult> RemoveQr(
            long id)
        {
            bool removed = await _service.RemoveQrAsync(
                id, Actor);

            return removed
                ? Ok(new
                {
                    Message = "QR image removed."
                })
                : (IHttpActionResult)NotFound();
        }

        [HttpPost]
        [Route("bulk-upload")]
        public async Task<IHttpActionResult> BulkUpload()
        {
            if (!Request.Content.IsMimeMultipartContent())
                return BadRequest(
                    "Excel file required.");

            var provider =
                new MultipartMemoryStreamProvider();

            await Request.Content
                .ReadAsMultipartAsync(provider);

            if (provider.Contents.Count != 1)
                return BadRequest(
                    "Upload one Excel file.");

            var file = provider.Contents[0];

            string fileName = file.Headers
                .ContentDisposition
                ?.FileName
                ?.Trim('"');

            if (string.IsNullOrWhiteSpace(fileName) ||
                !fileName.EndsWith(
                    ".xlsx",
                    StringComparison.OrdinalIgnoreCase))
            {
                return BadRequest(
                    "Only .xlsx files supported.");
            }

            byte[] bytes =
                await file.ReadAsByteArrayAsync();

            if (bytes.Length == 0 ||
                bytes.Length > 5 * 1024 * 1024)
            {
                return BadRequest(
                    "Excel file must be 5 MB or smaller.");
            }

            try
            {
                var result = await _service.ImportAsync(
                    bytes, Actor);

                // Import response preserves new passcodes.
                // Send their emails separately using an
                // approved protected delivery workflow.
                // Do not repeat import if delivery fails.

                return Ok(new
                {
                    statusCode = 200,
                    result = result
                });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception)
            {
                return Content(
                    HttpStatusCode.InternalServerError,
                    new
                    {
                        statusCode = 500,
                        errorMessage =
                            "Guest import failed. " +
                            "Check server logs."
                    });
            }
        }

        internal static HttpResponseMessage ImageResponse(
            byte[] bytes,
            string mime)
        {
            var response =
                new HttpResponseMessage(HttpStatusCode.OK);

            response.Content =
                new ByteArrayContent(bytes);

            response.Content.Headers.ContentType =
                new MediaTypeHeaderValue(mime);

            response.Headers.CacheControl =
                new CacheControlHeaderValue
                {
                    NoStore = true
                };

            return response;
        }
    }

    [AllowAnonymous]
    [RoutePrefix("api/guest-auth")]
    public class GuestAuthController : ApiController
    {
        private readonly GuestsService _service =
            new GuestsService();

        private string Token
        {
            get
            {
                var auth =
                    Request.Headers.Authorization;

                return auth != null &&
                    string.Equals(
                        auth.Scheme,
                        "Bearer",
                        StringComparison.OrdinalIgnoreCase)
                    ? auth.Parameter : null;
            }
        }

        [HttpPost]
        [Route("login")]
        public async Task<IHttpActionResult> Login(
            GuestLoginInput input)
        {
            if (input == null ||
                string.IsNullOrWhiteSpace(input.Passcode))
                return BadRequest(
                    "Passcode is required.");

            string clientIp =
                HttpContext.Current?.Request?.UserHostAddress;

            var result = await _service.LoginAsync(
                input.Passcode,
                clientIp);

            if (result == null)
            {
                return Content(
                    HttpStatusCode.Unauthorized,
                    new
                    {
                        Message =
                            "Invalid or used passcode, " +
                            "or login temporarily blocked."
                    });
            }

            return Ok(result);
        }

        [HttpGet]
        [Route("me")]
        public async Task<IHttpActionResult> Me()
        {
            var guest =
                await _service.CurrentAsync(Token);

            return guest == null
                ? (IHttpActionResult)Unauthorized()
                : Ok(guest);
        }

        [HttpGet]
        [Route("my-qr")]
        public async Task<HttpResponseMessage> MyQr()
        {
            var guest =
                await _service.CurrentAsync(Token);

            if (guest == null)
                return Request.CreateResponse(
                    HttpStatusCode.Unauthorized);

            var qr = await _service.GetQrAsync(
                guest.Id);

            if (qr == null)
                return Request.CreateResponse(
                    HttpStatusCode.NotFound);

            return GuestsController.ImageResponse(
                qr.Item1,
                qr.Item2);
        }


        [HttpPost]
        [Route("tour-register")]
        public async Task<IHttpActionResult> TourRegister()
        {
            string token = Token;

            if (string.IsNullOrWhiteSpace(token))
                return Unauthorized();

            bool registered =
                await _service.RegisterForTourAsync(token);

            if (!registered)
                return Unauthorized();

            return Ok(new
            {
                Success = true,
                TourRegister = true,
                Message = "Successfully registered for the tour."
            });
        }

    }
}
