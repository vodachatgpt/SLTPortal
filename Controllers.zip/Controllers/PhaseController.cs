﻿
using System;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using SLTProject.Filters;
using SLTProject.Services;

namespace SLTProject.Controllers
{
    // ============================================================
    // PHASE MANAGEMENT CONTROLLER
    //
    // GET     /api/phases           Admin or Guest
    // GET     /api/phases/{id}      Admin or Guest
    // POST    /api/phases           Admin only
    // PUT     /api/phases/{id}      Admin only
    // DELETE  /api/phases/{id}      Admin only
    // ============================================================

    [RoutePrefix("api/phases")]
    public class PhaseController : ApiController
    {
        private readonly PhaseService _service =
            new PhaseService();

        // ========================================================
        // CURRENT AUTHENTICATED ADMINISTRATOR
        // ========================================================

        private string Actor
        {
            get
            {
                object value;

                if (Request != null &&
                    Request.Properties.TryGetValue(
                        "SLTAdminEmail",
                        out value))
                {
                    string email = value as string;

                    if (!string.IsNullOrWhiteSpace(email))
                    {
                        return email;
                    }
                }

                // Never fall back to "System" for an
                // administrator-only write operation.
                throw new UnauthorizedAccessException(
                    "Authenticated administrator identity " +
                    "is unavailable.");
            }
        }

        // ========================================================
        // GET ALL PHASES
        // GET /api/phases
        //
        // Accessible by administrators and guests.
        // ========================================================

        [SltAdminOrGuest]
        [HttpGet]
        [Route("")]
        public async Task<IHttpActionResult> GetAll()
        {
            var phases = await _service.GetAllAsync();

            return Ok(phases);
        }

        // ========================================================
        // GET PHASE BY ID
        // GET /api/phases/{id}
        //
        // Accessible by administrators and guests.
        // ========================================================

        [SltAdminOrGuest]
        [HttpGet]
        [Route("{id:long}")]
        public async Task<IHttpActionResult> Get(
            long id)
        {
            if (id <= 0)
            {
                return BadRequest(
                    "Invalid phase ID.");
            }

            var phase = await _service.GetAsync(id);

            if (phase == null)
            {
                return NotFound();
            }

            return Ok(phase);
        }

        // ========================================================
        // CREATE PHASE
        // POST /api/phases
        //
        // Administrator only.
        // ========================================================

        [SltAdmin]
        [HttpPost]
        [Route("")]
        public async Task<IHttpActionResult> Create(
            [FromBody] PhaseInput input)
        {
            if (input == null)
            {
                return BadRequest(
                    "Phase data is required.");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var phase = await _service.CreateAsync(
                    input,
                    Actor);

                return Content(
                    HttpStatusCode.Created,
                    phase);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // ========================================================
        // UPDATE PHASE
        // PUT /api/phases/{id}
        //
        // Administrator only.
        // ========================================================

        [SltAdmin]
        [HttpPut]
        [Route("{id:long}")]
        public async Task<IHttpActionResult> Update(
            long id,
            [FromBody] PhaseInput input)
        {
            if (id <= 0)
            {
                return BadRequest(
                    "Invalid phase ID.");
            }

            if (input == null)
            {
                return BadRequest(
                    "Phase data is required.");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var phase = await _service.UpdateAsync(
                    id,
                    input,
                    Actor);

                if (phase == null)
                {
                    return NotFound();
                }

                return Ok(phase);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // ========================================================
        // SOFT DELETE PHASE
        // DELETE /api/phases/{id}
        //
        // Administrator only.
        // ========================================================

        [SltAdmin]
        [HttpDelete]
        [Route("{id:long}")]
        public async Task<IHttpActionResult> Delete(
            long id)
        {
            if (id <= 0)
            {
                return BadRequest(
                    "Invalid phase ID.");
            }

            bool deleted = await _service.DeleteAsync(
                id,
                Actor);

            if (!deleted)
            {
                return NotFound();
            }

            return Ok(new
            {
                Message =
                    "Phase soft deleted successfully."
            });
        }
    }
}
