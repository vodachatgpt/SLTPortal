﻿
using System;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using SLTProject.Filters;
using SLTProject.Models.Dtos;
using SLTProject.Services;

namespace SLTProject.Controllers
{
    // ============================================================
    // HELP & SUPPORT
    //
    // GET     /api/help-support         Admin or Guest
    // GET     /api/help-support/{id}    Admin or Guest
    // POST    /api/help-support         Admin only
    // PUT     /api/help-support/{id}    Admin only
    // DELETE  /api/help-support/{id}    Admin only
    // ============================================================

    [RoutePrefix("api/help-support")]
    public class HelpAndSupportController : ApiController
    {
        private readonly HelpAndSupportService _service =
            new HelpAndSupportService();

        // ========================================================
        // AUTHENTICATED ADMIN ACTOR
        // ========================================================

        private string Actor
        {
            get
            {
                object value;

                if (Request != null &&
                    Request.Properties.TryGetValue(
                        "SLTAdminEmail",
                        out value))
                {
                    var email = value as string;

                    if (!string.IsNullOrWhiteSpace(email))
                    {
                        return email;
                    }
                }

                // Administrative write operations must have
                // an identity established by [SltAdmin].
                throw new UnauthorizedAccessException(
                    "Administrator identity was not established.");
            }
        }

        // ========================================================
        // GET ALL
        // GET /api/help-support
        // ========================================================

        [SltAdminOrGuest]
        [HttpGet]
        [Route("")]
        public async Task<IHttpActionResult> GetAll()
        {
            var records = await _service.GetAllAsync();

            return Ok(records);
        }

        // ========================================================
        // GET BY ID
        // GET /api/help-support/{id}
        // ========================================================

        [SltAdminOrGuest]
        [HttpGet]
        [Route("{id:long}")]
        public async Task<IHttpActionResult> GetById(
            long id)
        {
            if (id <= 0)
            {
                return BadRequest(
                    "Invalid Help & Support record ID.");
            }

            var record =
                await _service.GetByIdAsync(id);

            if (record == null)
            {
                return NotFound();
            }

            return Ok(record);
        }

        // ========================================================
        // CREATE
        // POST /api/help-support
        // ========================================================

        [SltAdmin]
        [HttpPost]
        [Route("")]
        public async Task<IHttpActionResult> Create(
            [FromBody] HelpAndSupportInput input)
        {
            if (input == null)
            {
                return BadRequest(
                    "Help & Support details are required.");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var record =
                    await _service.CreateAsync(
                        input,
                        Actor);

                return Content(
                    HttpStatusCode.Created,
                    record);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // ========================================================
        // UPDATE
        // PUT /api/help-support/{id}
        // ========================================================

        [SltAdmin]
        [HttpPut]
        [Route("{id:long}")]
        public async Task<IHttpActionResult> Update(
            long id,
            [FromBody] HelpAndSupportInput input)
        {
            if (id <= 0)
            {
                return BadRequest(
                    "Invalid Help & Support record ID.");
            }

            if (input == null)
            {
                return BadRequest(
                    "Help & Support details are required.");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var record =
                    await _service.UpdateAsync(
                        id,
                        input,
                        Actor);

                if (record == null)
                {
                    return NotFound();
                }

                return Ok(new
                {
                    Message =
                        "Help and support updated successfully.",
                    Record = record
                });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // ========================================================
        // SOFT DELETE
        // DELETE /api/help-support/{id}
        // ========================================================

        [SltAdmin]
        [HttpDelete]
        [Route("{id:long}")]
        public async Task<IHttpActionResult> Delete(
            long id)
        {
            if (id <= 0)
            {
                return BadRequest(
                    "Invalid Help & Support record ID.");
            }

            bool deleted =
                await _service.DeleteAsync(
                    id,
                    Actor);

            if (!deleted)
            {
                return NotFound();
            }

            return Ok(new
            {
                Message =
                    "Help and support deleted successfully.",
                DeletedId = id
            });
        }
    }
}
