﻿using SLTProject.Filters;

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using SLTProject.Models;
using SLTProject.Services;
using SLTProject.Data;


namespace SLTProject.Controllers
{
    public class EmailTemplateInput
    {
        [Required]
        [StringLength(100)]
        public string TemplateKey { get; set; }

        [Required]
        [StringLength(200)]
        public string TemplateName { get; set; }

        [Required]
        [StringLength(500)]
        public string Subject { get; set; }

        [Required]
        public string BodyHtml { get; set; }

        public bool IsActive { get; set; } = true;
    }

    public class EmailTemplateView
    {
        public long Id { get; set; }
        public string TemplateKey { get; set; }
        public string TemplateName { get; set; }
        public string Subject { get; set; }
        public string BodyHtml { get; set; }
        public bool IsActive { get; set; }
        public bool IsSystemTemplate { get; set; }

        public DateTime RetentionDateCreated { get; set; }
        public DateTime? RetentionDateModified { get; set; }

        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
    }

    [SltAdmin]
    [RoutePrefix("api/email-templates")]
    public class EmailTemplatesController : ApiController
    {
        private readonly EmailTemplateService _emailService =
            new EmailTemplateService();

        private string Actor
        {
            get
            {
                object value;

                if (Request.Properties.TryGetValue(
                    "SLTAdminEmail", out value))
                    return Convert.ToString(value);

                throw new UnauthorizedAccessException(
                    "Administrator identity was not resolved.");
            }
        }

        private static string NormalizeKey(string key)
        {
            return (key ?? string.Empty)
                .Trim()
                .ToUpperInvariant();
        }

        private static bool IsValidKey(string key)
        {
            if (string.IsNullOrWhiteSpace(key) ||
                key.Length > 100)
                return false;

            return key.All(c =>
                (c >= 'A' && c <= 'Z') ||
                (c >= '0' && c <= '9') ||
                c == '_');
        }

        private static EmailTemplateView Map(EmailTemplate item)
        {
            return new EmailTemplateView
            {
                Id = item.Id,
                TemplateKey = item.TemplateKey,
                TemplateName = item.TemplateName,
                Subject = item.Subject,
                BodyHtml = item.BodyHtml,
                IsActive = item.IsActive,
                IsSystemTemplate =
                    EmailTemplateService.IsRequiredTemplate(
                        item.TemplateKey),

                RetentionDateCreated =
                    item.RetentionDateCreated,

                RetentionDateModified =
                    item.RetentionDateModified,

                CreatedBy = item.CreatedBy,
                ModifiedBy = item.ModifiedBy
            };
        }

        private IHttpActionResult ValidateInput(
            EmailTemplateInput input,
            out string normalizedKey)
        {
            normalizedKey = NormalizeKey(
                input == null ? null : input.TemplateKey);

            if (input == null)
                return BadRequest(
                    "Email template information is required.");

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            if (!IsValidKey(normalizedKey))
                return BadRequest(
                    "TemplateKey must contain only A-Z, " +
                    "0-9 and underscores.");

            if (string.IsNullOrWhiteSpace(input.TemplateName))
                return BadRequest(
                    "Template name is required.");

            if (string.IsNullOrWhiteSpace(input.Subject))
                return BadRequest(
                    "Email subject is required.");

            if (string.IsNullOrWhiteSpace(input.BodyHtml))
                return BadRequest(
                    "Email HTML body is required.");

            if (input.BodyHtml.Length > 500000)
                return BadRequest(
                    "HTML body exceeds the 500000-character limit.");

            return null;
        }

        // GET /api/email-templates
        // GET /api/email-templates?search=guest
        // GET /api/email-templates?isActive=true
        [HttpGet]
        [Route("")]
        public async Task<IHttpActionResult> GetAll(
            string search = null,
            bool? isActive = null)
        {
            using (var db = new SLTEntities())
            {
                var query = db.EmailTemplates
                    .AsNoTracking()
                    .Where(x => !x.IsDeleted);

                if (!string.IsNullOrWhiteSpace(search))
                {
                    string term = search.Trim();

                    query = query.Where(x =>
                        x.TemplateKey.Contains(term) ||
                        x.TemplateName.Contains(term) ||
                        x.Subject.Contains(term));
                }

                if (isActive.HasValue)
                {
                    bool active = isActive.Value;

                    query = query.Where(x =>
                        x.IsActive == active);
                }

                var templates = await query
                    .OrderBy(x => x.TemplateKey)
                    .ToListAsync();

                return Ok(templates.Select(Map).ToList());
            }
        }

        // GET /api/email-templates/1
        [HttpGet]
        [Route("{id:long}")]
        public async Task<IHttpActionResult> Get(long id)
        {
            using (var db = new SLTEntities())
            {
                var item = await db.EmailTemplates
                    .AsNoTracking()
                    .FirstOrDefaultAsync(x =>
                        x.Id == id &&
                        !x.IsDeleted);

                if (item == null)
                    return NotFound();

                return Ok(Map(item));
            }
        }

        // POST /api/email-templates
        [HttpPost]
        [Route("")]
        public async Task<IHttpActionResult> Create(
            EmailTemplateInput input)
        {
            string key;

            var validation = ValidateInput(input, out key);

            if (validation != null)
                return validation;

            using (var db = new SLTEntities())
            {
                // Includes soft-deleted records because
                // TemplateKey has a unique SQL index.
                bool exists = await db.EmailTemplates
                    .AnyAsync(x => x.TemplateKey == key);

                if (exists)
                {
                    return Content(
                        HttpStatusCode.Conflict,
                        new
                        {
                            Message =
                                "An email template with this " +
                                "key already exists."
                        });
                }

                var template = new EmailTemplate
                {
                    TemplateKey = key,
                    TemplateName = input.TemplateName.Trim(),
                    Subject = input.Subject.Trim(),
                    BodyHtml = input.BodyHtml,
                    IsActive = input.IsActive,
                    IsDeleted = false,

                    CreatedBy = Actor,
                    RetentionDateCreated = EgyptDateTimeService.Now
                };

                db.EmailTemplates.Add(template);

                await db.SaveChangesAsync();

                return Content(
                    HttpStatusCode.Created,
                    Map(template));
            }
        }

        // PUT /api/email-templates/1
        [HttpPut]
        [Route("{id:long}")]
        public async Task<IHttpActionResult> Update(
            long id,
            EmailTemplateInput input)
        {
            string key;

            var validation = ValidateInput(input, out key);

            if (validation != null)
                return validation;

            using (var db = new SLTEntities())
            {
                var template = await db.EmailTemplates
                    .FirstOrDefaultAsync(x =>
                        x.Id == id &&
                        !x.IsDeleted);

                if (template == null)
                    return NotFound();

                // Preserve the database key to avoid
                // breaking references in SendAsync().
                if (!string.Equals(
                    key,
                    template.TemplateKey,
                    StringComparison.OrdinalIgnoreCase))
                {
                    return BadRequest(
                        "TemplateKey cannot be changed. " +
                        "Create another template instead.");
                }

                // Required templates must remain active.
                if (EmailTemplateService.IsRequiredTemplate(
                    template.TemplateKey) &&
                    !input.IsActive)
                {
                    return BadRequest(
                        "Required system templates " +
                        "cannot be deactivated.");
                }

                template.TemplateName =
                    input.TemplateName.Trim();

                template.Subject =
                    input.Subject.Trim();

                template.BodyHtml =
                    input.BodyHtml;

                template.IsActive =
                    input.IsActive;

                template.ModifiedBy =
                    Actor;

                template.RetentionDateModified =
                    EgyptDateTimeService.Now;

                await db.SaveChangesAsync();

                return Ok(Map(template));
            }
        }

        // DELETE /api/email-templates/1
        [HttpDelete]
        [Route("{id:long}")]
        public async Task<IHttpActionResult> Delete(long id)
        {
            using (var db = new SLTEntities())
            {
                var template = await db.EmailTemplates
                    .FirstOrDefaultAsync(x =>
                        x.Id == id &&
                        !x.IsDeleted);

                if (template == null)
                    return NotFound();

                if (EmailTemplateService.IsRequiredTemplate(
                    template.TemplateKey))
                {
                    return BadRequest(
                        "This is a required system template. " +
                        "You may edit its content, " +
                        "but cannot delete it.");
                }

                template.IsDeleted = true;
                template.IsActive = false;

                template.DeletedBy = Actor;
                template.DeletedAt = EgyptDateTimeService.Now;

                template.ModifiedBy = Actor;
                template.RetentionDateModified =
                    EgyptDateTimeService.Now;

                await db.SaveChangesAsync();

                return Ok(new
                {
                    Message = "Email template soft deleted.",
                    Id = id
                });
            }
        }

        // GET /api/email-templates/1/preview
        [HttpGet]
        [Route("{id:long}/preview")]
        public async Task<IHttpActionResult> Preview(long id)
        {
            var preview = await _emailService
                .PreviewAsync(id);

            if (preview == null)
                return NotFound();

            return Ok(preview);
        }
    }
}
