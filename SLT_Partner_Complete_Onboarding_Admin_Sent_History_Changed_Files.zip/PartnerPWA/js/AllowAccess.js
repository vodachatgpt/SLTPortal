/* =========================================================
   Partner Allow Access: existing install/notification flow, now
   registering browser push through the SLT guest bearer token.
   ========================================================= */
const progressFill = document.getElementById('progressFill');
const installStep = document.getElementById('installStep');
const installBenefits = document.getElementById('installBenefits');
const iphoneSteps = document.getElementById('iphoneSteps');
const androidSteps = document.getElementById('androidSteps');
const installBtn = document.getElementById('installBtn');
const installSkipBtn = document.getElementById('installSkipBtn');
const notifyStep = document.getElementById('notifyStep');
const notifyBtn = document.getElementById('notifyBtn');
const notifySkipBtn = document.getElementById('notifySkipBtn');
const accessPushStatus = document.getElementById('accessPushStatus');
let installPrompt = null;
let installedApp = isInstalledApp();
let manualStepsShown = false;
let finishing = false;

function pushMessage(text){
  if(accessPushStatus) accessPushStatus.textContent=text||'';
}
function currentPermission(){
  return 'Notification' in window ? Notification.permission : 'unsupported';
}
function setProgress(widthClass){
  progressFill.classList.remove('w-50','w-75','w-100');
  progressFill.classList.add(widthClass);
}
function setLoading(value){
  [installBtn,installSkipBtn,notifyBtn,notifySkipBtn].forEach(btn=>btn.disabled=value);
  const spinner=notifyBtn.querySelector('.spinner-border');
  if(spinner)spinner.classList.toggle('d-none',!value);
}
function showManualSteps(list){
  installBenefits.classList.add('d-none');
  list.classList.remove('d-none');
  installBtn.textContent='Done, continue';
  manualStepsShown=true;
}
function showInstallStep(){
  installStep.classList.remove('d-none');
  notifyStep.classList.add('d-none');
  setProgress('w-75');
  if(isIphoneOrIpad())showManualSteps(iphoneSteps);
}
function showNotifyStep(){
  const supported='Notification' in window;
  const alreadyAnswered=supported && Notification.permission!=='default' && !CONFIG.testMode;
  if(!supported){pushMessage('Browser notifications are not available on this device. You can still read messages in your inbox.');finish(currentPermission());return;}
  // Even if browser permission is granted, still offer registration/rebind after login.
  if(alreadyAnswered && Notification.permission==='denied'){pushMessage('Notifications are blocked in this browser. Enable them in site settings to receive push alerts. Your inbox still works.');finish('denied');return;}
  installStep.classList.add('d-none');
  notifyStep.classList.remove('d-none');
  setProgress('w-100');
}
function afterInstallStep(){
  showNotifyStep(); // Always offer re-registration, even if permission was granted previously.
}
document.addEventListener('DOMContentLoaded',()=>{
  if(!getSession()){location.replace('InvitationCode.html');return;}
  if(installedApp)showNotifyStep();else showInstallStep();
});
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installPrompt=e;});
window.addEventListener('appinstalled',()=>{installedApp=true;pushMessage('SLT App installed successfully. You can now enable notifications.');});
installBtn.addEventListener('click',async()=>{
  if(manualStepsShown){afterInstallStep();return;}
  if(installPrompt){
    installPrompt.prompt();
    try{const choice=await installPrompt.userChoice;if(choice.outcome==='accepted')installedApp=true;}
    finally{installPrompt=null;afterInstallStep();}
    return;
  }
  showManualSteps(androidSteps);
});
installSkipBtn.addEventListener('click',afterInstallStep);

notifyBtn.addEventListener('click',async()=>{
  if(finishing)return;
  setLoading(true);
  let permission=currentPermission();
  let registered=false;
  try{
    // SDK handles Notification.requestPermission inside the direct user click.
    if(!window.PartnerGuestPush)throw Error('Push scripts did not load.');
    if(!getSession()||!guestToken())throw Error('You need a valid SLT guest login token. Sign in from InvitationCode.html first.');
    if(!PartnerGuestPush.supported())throw Error('Browser push requires HTTPS, service workers and a supported browser.');
    if(isIphoneOrIpad()&&!isInstalledApp())throw Error('On iPhone, add SLT App to Home Screen and open it there before enabling alerts.');
    const result=await PartnerGuestPush.enable();
    permission=currentPermission();
    registered=!!result.subscribed;
    if(!registered)throw Error('Push service did not confirm a subscription.');
    pushMessage('Browser push is enabled for this guest.');
  }catch(err){
    permission=currentPermission();
    pushMessage('Push setup was not completed: '+err.message+'. You can retry from Notifications later.');
    console.warn('[SLT AllowAccess push]',err.message);
  }finally{
    setLoading(false);
  }
  // Preserve original onboarding semantics: do not block app entry on provider/network failure.
  await finish(registered?'granted':permission);
});
notifySkipBtn.addEventListener('click',()=>finish('skipped'));

async function finish(notifications){
  if(finishing)return;
  finishing=true;
  setLoading(true);
  try{await saveAccess(installedApp,notifications);}
  catch(err){console.warn('[SLT AllowAccess] saveAccess failed:',err.message);}
  writeStorage(STORAGE.accessDone,'yes');
  location.href='Splash.html';
}
