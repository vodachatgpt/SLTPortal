/* SLT Partner PWA — email-first guest login on EXISTING InvitationCode.html.
 * No new HTML page. Existing app.js, config.js, api.js must load on this page.
 * Mounts a self-contained form because the original InvitationCode.html markup
 * was not included in the supplied integration overlay.
 */
(function(){
  'use strict';
  const launch=()=>{
    if(document.getElementById('sltPwaLogin'))return;
    if(typeof getSession==='function' && getSession() && typeof guestToken==='function' && guestToken()){location.replace(new URL('AllowAccess.html',location.href).href);return;}
    const main=document.querySelector('main')||document.body;
    const section=document.createElement('section');
    section.id='sltPwaLogin';
    section.className='slt-pwa-login';
    section.innerHTML=`
      <div class="slt-auth-step-label">STEP 1 OF 2 · ACCESS YOUR INVITATION</div><h2>Welcome to SLT</h2>
      <p>Enter the email address registered for your invitation. We'll send your passcode by email and SMS.</p>
      <form id="sltPwaRequestForm" novalidate>
        <label for="sltPwaEmail">Registered email</label>
        <input id="sltPwaEmail" type="email" autocomplete="email" inputmode="email" required placeholder="name@example.com">
        <button type="submit" id="sltPwaSendButton">Send passcode</button>
      </form>
      <form id="sltPwaCodeForm" novalidate hidden><div class="slt-auth-step-label">STEP 2 OF 2 · VERIFY YOUR PASSCODE</div><p>We sent a six-character passcode to your registered email and phone.</p>
        <label for="sltPwaPasscode">Six-character passcode</label>
        <input id="sltPwaPasscode" type="text" autocomplete="one-time-code" autocapitalize="characters" spellcheck="false" maxlength="6" pattern="[A-Za-z0-9]{6}" placeholder="A7B2C9" required>
        <button type="submit" id="sltPwaLoginButton">Continue to SLT App</button><button type="button" id="sltPwaBackButton" class="slt-auth-secondary">Use another email</button>
      </form>
      <p id="sltPwaLoginStatus" role="status" aria-live="polite"></p>`;
    main.insertBefore(section,main.firstChild);
    const $=id=>document.getElementById(id);
    const status=$('sltPwaLoginStatus');
    const email=$('sltPwaEmail');
    const code=$('sltPwaPasscode');
    const requestForm=$('sltPwaRequestForm'), codeForm=$('sltPwaCodeForm');
    $('sltPwaBackButton').addEventListener('click',()=>{codeForm.hidden=true;requestForm.hidden=false;code.value='';setStatus('');email.focus();});
    email.value=readStorage('slt.guestEmail')||'';
    const setStatus=(message,error)=>{status.textContent=message||'';status.classList.toggle('error',!!error)};
    $('sltPwaRequestForm').addEventListener('submit',async e=>{
      e.preventDefault();e.stopPropagation();
      const btn=$('sltPwaSendButton');btn.disabled=true;
      try{
        const clean=email.value.trim();
        await requestGuestPasscode(clean);
        writeStorage('slt.guestEmail',clean);
        setStatus('If your email is registered, your passcode has been sent. Check your email and SMS.');
        requestForm.hidden=true;codeForm.hidden=false;code.focus();
      }catch(err){setStatus(err.message||'Cannot request a passcode.',true)}
      finally{btn.disabled=false}
    });
    code.addEventListener('input',()=>{code.value=code.value.replace(/[^a-zA-Z0-9]/g,'').toUpperCase().slice(0,6)});
    $('sltPwaCodeForm').addEventListener('submit',async e=>{
      e.preventDefault();e.stopPropagation();
      const btn=$('sltPwaLoginButton');btn.disabled=true;
      try{
        const result=await guestLogin(code.value);
        saveGuestLoginResult(result);
        if(window.PartnerGuestPush&&typeof PartnerGuestPush.reset==='function')PartnerGuestPush.reset();
        code.value='';
        setStatus('Welcome to SLT. Opening your app…');
        location.assign(new URL('AllowAccess.html',location.href).href);
      }catch(err){setStatus(err.message||'Unable to sign in.',true)}
      finally{btn.disabled=false}
    });
  };
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',launch);
  else launch();
})();
