(function () {
'use strict';
const $ = id => document.getElementById(id);
const ui = window.SLTNotificationUI;
let page=1, totalPages=0, sendKey=null, loadCounter=0, cached=[];
const number = value => Number(value || 0);
function auth(path,opts){
  const token=localStorage.getItem('slt_admin_token');
  if(!token)throw Error('Administrator login required.');
  return sltRequest('/slt-notifications/admin/'+path,Object.assign({},opts||{}, {
    headers:Object.assign({},opts&&opts.headers,{Authorization:'Bearer '+token})
  }));
}
function info(msg,error){const el=$('nFeedback');el.textContent=msg;el.dataset.state=error?'error':'success';}
function formatDate(value){
  if(!value)return '—';
  if(window.sltFormatDateTime)return window.sltFormatDateTime(value)+' (Egypt time)';
  const date=new Date(value);
  return Number.isNaN(date.getTime())?String(value).replace('T',' ').slice(0,16):
    new Intl.DateTimeFormat('en-GB',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}).format(date);
}
function formatSelection(prefix,suffix,bullets){
  const el=$('nMessage'),a=el.selectionStart,b=el.selectionEnd,old=el.value;
  const selected=old.slice(a,b)||(bullets?'List item':'text');
  const replacement=bullets?'- '+selected.replace(/\n/g,'\n- '):prefix+selected+suffix;
  el.value=old.slice(0,a)+replacement+old.slice(b);
  el.focus();el.setSelectionRange(a,a+replacement.length);
  el.dispatchEvent(new Event('input',{bubbles:true}));
}
function updatePreview(){
  $('nPreview').innerHTML=ui.markdown($('nMessage').value||'Start typing to preview your message.');
  $('nPreviewTitle').textContent=$('nTitle').value.trim()||'Your title appears here';
  $('nTitleCount').textContent=$('nTitle').value.length+' / 120';
  $('nMessageCount').textContent=$('nMessage').value.length+' / 4000';
}
$('nTarget').addEventListener('change',()=>{$('nGuestArea').hidden=$('nTarget').value!=='Guest';sendKey=null;});
$('nTitle').addEventListener('input',updatePreview);
$('nClear').addEventListener('click',()=>{$('nSendForm').reset();$('nGuestArea').hidden=true;sendKey=null;updatePreview();info('Draft cleared.');});
let searchTimer;
async function guests(){
  try{
    $('nGuestSearchStatus').textContent='Searching guests…';
    const result=await auth('guests?search='+encodeURIComponent($('nGuestSearch').value.trim()));
    const list=Array.isArray(result)?result:(result.Items||[]);
    const select=$('nGuestId'), prev=select.value;
    select.replaceChildren(new Option('Select guest...',''));
    list.forEach(g=>select.add(new Option((g.FullName||'Guest')+' — '+(g.Email||'')+(g.Registered?'':' (not logged in)'),String(g.Id))));
    select.value=prev;$('nGuestSearchStatus').textContent=list.length+' guest(s) found';
  }catch(error){$('nGuestSearchStatus').textContent='Unable to load guests';info(error.message,true);}
}
$('nGuestSearch').addEventListener('input',()=>{clearTimeout(searchTimer);searchTimer=setTimeout(guests,300);});
$('nMessage').addEventListener('input',()=>{updatePreview();sendKey=null;});
$('nSendForm').addEventListener('input',()=>{sendKey=null;});
document.querySelectorAll('[data-format]').forEach(button=>button.addEventListener('click',()=>{
  const type=button.dataset.format;
  if(type==='bold')formatSelection('**','**',false);
  else if(type==='italic')formatSelection('*','*',false);
  else if(type==='underline')formatSelection('__','__',false);
  else formatSelection('','',true);
}));
$('nSendForm').addEventListener('submit',async e=>{
  e.preventDefault();const button=$('nSend');if(button.disabled)return;
  const target=$('nTarget').value,title=$('nTitle').value.trim(),message=$('nMessage').value.trim();
  if(!title||!message){info('Enter both a title and a message.',true);return;}
  const url=$('nUrl').value.trim();
  if(url&&(!url.startsWith('/')||url.startsWith('//')||/[\\%#]/.test(url)||url.includes('..'))){info('Enter a safe root-relative guest destination.',true);return;}
  const guestId=Number($('nGuestId').value);
  if(target==='Guest'&&(!Number.isSafeInteger(guestId)||guestId<1)){info('Choose a guest.',true);return;}
  const confirmed=await sltConfirm(target==='All'?'Send this notification to all registered guests?':'Send this notification to the selected guest?');
  if(!confirmed)return;
  if(!sendKey)sendKey=(window.crypto&&crypto.randomUUID)?crypto.randomUUID():'slt-'+Date.now()+'-'+Math.random().toString(36).slice(2);
  button.disabled=true;info('Sending your notification…');
  try{
    const response=await auth('send',{method:'POST',body:JSON.stringify({
      TargetType:target,GuestId:target==='Guest'?guestId:null,Title:title,
      MessageText:message,ClickUrl:url,IdempotencyKey:sendKey
    })});
    info('Notification #'+response.NotificationId+' saved for '+response.RecipientCount+' guest(s). Push status: '+response.PushStatus+'.');
    sendKey=null;$('nSendForm').reset();$('nGuestArea').hidden=true;updatePreview();
    page=1;await refresh();
  }catch(error){info(error.message,true);}finally{button.disabled=false;}
});
function renderHistory(){
  const query=$('nHistorySearch').value.toLocaleLowerCase().trim();
  const audience=$('nHistoryAudience').value;
  const items=cached.filter(x=>{
    if(audience&&String(x.TargetType||'').toLowerCase()!==audience.toLowerCase())return false;
    if(!query)return true;
    return [x.Title,x.MessageText,x.CreatedByEmail,x.TargetType].some(v=>String(v||'').toLocaleLowerCase().includes(query));
  });
  $('nHistorySummary').textContent=items.length+' notification(s) on this page · '+cached.length+' loaded from the server';
  const recipients=cached.reduce((sum,x)=>sum+number(x.RecipientCount),0);
  const read=cached.reduce((sum,x)=>sum+number(x.GuestReadCount),0);
  $('nReadRate').textContent=recipients?Math.round(read/recipients*100)+'%':'—';
  $('nList').innerHTML=items.length?items.map(x=>{
    const count=number(x.RecipientCount),readCount=number(x.GuestReadCount);
    const percent=count?Math.min(100,Math.max(0,Math.round(readCount/count*100))):0;
    const all=String(x.TargetType).toLowerCase()==='all';
    return '<article class="slt-n-item slt-n-history-item">'+
      '<div class="slt-n-item-head"><div class="slt-n-history-heading"><span class="slt-n-badge">'+(all?'Broadcast':'Individual')+'</span><strong>'+ui.esc(x.Title||'Untitled notification')+'</strong></div><span class="slt-n-delivery">'+ui.esc(x.PushStatus||'Not reported')+'</span></div>'+
      '<p class="slt-n-history-meta">'+ui.esc(formatDate(x.CreatedAt))+' · Sent by '+ui.esc(x.CreatedByEmail||'Admin')+' · #'+ui.esc(x.NotificationId)+'</p>'+
      '<div class="slt-n-history-message">'+ui.markdown(x.MessageText||'')+'</div>'+
      '<div class="slt-n-history-reads"><div><strong>'+readCount+' / '+count+'</strong><span>guest reads</span></div><div class="slt-n-read-track"><span style="width:'+percent+'%"></span></div><strong>'+percent+'%</strong></div>'+
      '<div class="slt-n-history-footer"><span>'+count+' recipient'+(count===1?'':'s')+' · '+(count-readCount>0?(count-readCount)+' not yet read':'All read')+'</span>'+
      (!x.IsRead?'<button type="button" class="slt-n-button" data-read="'+ui.esc(x.NotificationId)+'">Mark admin copy read</button>':'<span class="slt-n-muted">Admin copy read</span>')+'</div></article>';
  }).join(''):'<div class="slt-n-empty"><strong>No matching sent messages</strong><p>Try another search, audience, or page.</p></div>';
}
async function refresh(){
  const requestId=++loadCounter;
  $('nList').innerHTML='<div class="slt-n-empty"><span class="slt-n-spinner"></span> Loading history…</div>';
  try{
    const result=await auth('sent?page='+page+'&pageSize=15&unreadOnly='+$('nUnreadOnly').checked);
    if(requestId!==loadCounter)return;
    totalPages=number(result.TotalPages);
    cached=Array.isArray(result.Items)?result.Items:[];
    $('nPage').textContent='Page '+number(result.Page||page)+' of '+Math.max(1,totalPages)+' · '+number(result.Total)+' messages';
    $('nUnread').textContent=number(result.UnreadCount).toLocaleString();
    $('nTotal').textContent=number(result.Total).toLocaleString();
    $('nPrev').disabled=page<=1;$('nNext').disabled=page>=totalPages;
    renderHistory();
  }catch(error){if(requestId!==loadCounter)return;cached=[];$('nList').textContent='Unable to load sent notifications: '+error.message;}
}
$('nList').addEventListener('click',async e=>{
  const button=e.target.closest('[data-read]');if(!button)return;
  button.disabled=true;
  try{await auth(button.dataset.read+'/read',{method:'POST'});await refresh();}
  catch(error){info(error.message,true);button.disabled=false;}
});
$('nRefresh').addEventListener('click',refresh);
$('nPrev').addEventListener('click',()=>{if(page>1){page--;refresh();}});
$('nNext').addEventListener('click',()=>{if(page<totalPages){page++;refresh();}});
$('nUnreadOnly').addEventListener('change',()=>{page=1;refresh();});
$('nHistorySearch').addEventListener('input',renderHistory);
$('nHistoryAudience').addEventListener('change',renderHistory);
updatePreview();(async()=>{if(!await sltRequireAdmin())return;await guests();await refresh();})();
})();
