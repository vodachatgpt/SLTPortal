# SLT Partner PWA + Admin Notifications upgrade

## What changed

**Partner PWA** (existing pages only):
- `js/partner-slt-auth.js`: two-step invitation sign-in (email then alphanumeric passcode) on **existing** `InvitationCode.html`, with back-to-email action; a valid saved session continues to `AllowAccess.html`.
- `js/app.js`: updated asset revision for the mounted login adapter. Existing root service worker registration is preserved.
- `html/AllowAccess.html`, `js/AllowAccess.js`: installation instructions, followed by notification consent, with a safe skip path. Previously granted permission still triggers subscription registration; browser inbox does not depend on push permission.
- `css/notifications-integration.css`: scoped styles for these two steps.

**SLT Admin**:
- `Frontend/notifications-admin.html`: removed the **Delivery channel** summary tile and added a Guest reads tile, searchable sent-history toolbar, recipient filter and summary.
- `Frontend/assets/slt-notifications-admin.js`: improved history cards with targeted audience, timestamp, sender, push status, guest read count and read-progress bar. Search and audience filtering apply to the **currently fetched page**, not the entire server history. Kept admin read button separate from guest read count.
- `Frontend/assets/slt-notifications.css`: responsive light/dark styles for history cards and controls.

## Deployment

1. Back up your existing Partner PWA and SLT Admin frontend. Work on staging first.
2. Copy ZIP `PartnerPWA/js`, `PartnerPWA/css` and `PartnerPWA/html` files into their same relative paths inside the Partner PWA. **Do not create additional HTML pages** and do not overwrite `sw.js` or `manifest.webmanifest`.
3. **Your actual original `InvitationCode.html` was not provided.** It must already load `../js/config.js`, `../js/app.js`, `../js/api.js` in that order. `app.js` injects the two-step login form into the existing page. Hide/remove any original duplicate login form only after inspecting your own source.
4. Preserve the Partner PWA `push/` worker and SDK files from your previous integration. This ZIP contains *changed files only*, not the full previous integration. Check `js/config.js`: live backend API URL, push URL/app code, testMode=false.
5. Copy ZIP `SLTAdmin/Frontend` files into the SLTProject `Frontend` folder, preserving the `assets` subfolder. Publish and clear your static asset/PWA caches.
6. Use HTTPS (or localhost for browser testing), register the original PWA root worker with the original manifest scope and start_url, and configure CORS for the Partner origin.

## End-to-end user journey

1. Admin sends initial invitation email/SMS containing the existing PWA invitation link (no passcode).
2. Guest opens **existing `InvitationCode.html`**. Enter email -> `POST /api/guest-auth/request-passcode`.
3. Guest enters the new six-character mixed code -> `POST /api/guest-auth/login`. The session is saved in `slt.session`.
4. Existing **`AllowAccess.html`** offers PWA installation. Android browsers can show the install prompt; iOS provides Add to Home Screen instructions. Installation prompts are browser-controlled and cannot be forced. Skip remains possible.
5. AllowAccess then offers notification permission and Global Push registration. On supported iOS devices, install/open from the Home Screen before requesting push. Denial or failure does not block the in-app inbox.
6. Existing Splash/Home navigation continues unchanged.
7. Admin sends notification. Guest opens existing Notifications page; inbox and read/unread changes work independently of push delivery.
8. Admin reviews `Notification Center` sent-history cards and per-message guest read counts.

## Testing

- In Chrome DevTools > Network: verify POST `guest-auth/request-passcode`, POST `guest-auth/login`, GET `guest-auth/me`, guest inbox and registration endpoints.
- On a fresh browser profile: verify email -> code -> AllowAccess installation -> permission -> Splash/Home. On installed PWA: verify service worker and manifest status in Application tab and test re-entry after closing.
- Admin: verify history search, audience filter, guest read progress, pagination, and sending.
- Confirm the `Delivery channel` summary tile is gone. Actual push channel handling on the backend is unchanged.

## Limitations

- The full original Partner PWA (`InvitationCode.html`, `Home.html`, `sw.js`, manifest) was not supplied; no claims of full merge or end-to-end live test are made. Avoid replacing those files blindly.
- Admin sent-history API exposes per-notification `GuestReadCount` and `RecipientCount`, but **not an individual recipient read-status list** in this supplied frontend, so the UI reports aggregate reads only.
- Historical notification search filters the current fetched page of 15 messages, not the server-side history. A backend search endpoint would be needed for global search.
- Permission to show notifications and successful subscription registration are distinct. A successful send may not yield a visible system push if OS/browser restrictions or Global Push delivery fail.
