using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using ClosedXML.Excel;

namespace SLTProject.Services
{

    public sealed class ImportErrorDetail
    {
        public int RowNumber { get; set; }
        public string Column { get; set; }
        public string Value { get; set; }
        public string Reason { get; set; }
    }

    public sealed class ExcelImportResult
    {
        public int TotalRows { get; set; }
        public int Inserted { get; set; }
        public int Updated { get; set; }
        public int Skipped { get; set; }
        public int SoftDeleted { get; set; }
        public string Mode { get; set; }

        public int Failed
        {
            get
            {
                return ErrorDetails == null
                    ? 0
                    : ErrorDetails.Select(x => x.RowNumber).Distinct().Count();
            }
        }

        public bool Success { get { return Failed == 0; } }

        public List<string> Errors { get; set; } = new List<string>();
        public List<ImportErrorDetail> ErrorDetails { get; set; } =
            new List<ImportErrorDetail>();

        public void AddError(int row, string column, string value, string reason)
        {
            column = string.IsNullOrWhiteSpace(column) ? "Record" : column;
            reason = string.IsNullOrWhiteSpace(reason) ? "Invalid row." : reason;

            ErrorDetails.Add(new ImportErrorDetail
            {
                RowNumber = row,
                Column = column,
                Value = value,
                Reason = reason
            });

            Errors.Add("Row " + row + ", " + column + ": " + reason);
            Skipped++;
        }
    }

    internal static class ScheduleTransportExcel
    {
        public static XLWorkbook Open(Stream stream)
        {
            if (stream == null) throw new ArgumentException("Excel file is required.");
            return new XLWorkbook(stream);
        }
        private static string HeaderKey(string value)
        {
            return new string((value ?? "")
                .Where(char.IsLetterOrDigit)
                .ToArray())
                .ToLowerInvariant();
        }

        private static string CanonicalHeader(string value)
        {
            string key = HeaderKey(value);

            switch (key)
            {
                case "id": return "Id";
                case "date": return "Date";
                case "itemtype": return "ItemType";
                case "title": return "Title";
                case "bluriconname": return "BlurIconName";
                case "starttime": return "StartTime";
                case "endtime": return "EndTime";
                case "shortnote": return "ShortNote";
                case "dresscode": return "DressCode";
                case "locationname": return "LocationName";
                case "mapslink": return "MapsLink";
                case "email": return "Email";
                case "type": return "Type";
                case "drivername": return "DriverName";
                case "driverphone": return "DriverPhone";
                case "whatsapp":
                case "whatsappyn": return "WhatsApp";
                case "dayscheduleid": return "DayScheduleId";
                case "scheduletitle":
                case "dayscheduletitle": return "ScheduleTitle";
                case "scheduledate":
                case "dayscheduledate": return "ScheduleDate";
                default: return (value ?? "").Trim();
            }
        }

        public static Dictionary<string, int> Headers(IXLWorksheet sheet)
        {
            if (sheet == null || sheet.FirstRowUsed() == null)
                throw new ArgumentException("Excel sheet is empty.");

            var result = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

            foreach (var cell in sheet.Row(1).CellsUsed())
            {
                string original = cell.GetString().Trim();
                if (original.Length == 0) continue;

                string key = CanonicalHeader(original);
                if (result.ContainsKey(key))
                    throw new ArgumentException("Duplicate Excel header: " + original);

                result[key] = cell.Address.ColumnNumber;
            }

            return result;
        }
        public static void Require(Dictionary<string, int> headers, params string[] names)
        {
            foreach (var name in names)
                if (!headers.ContainsKey(name)) throw new ArgumentException("Missing Excel column: " + name);
        }
        public static string Text(IXLRow row, Dictionary<string, int> headers, string column)
        {
            int col;
            return headers.TryGetValue(column, out col)
                ? row.Cell(col).GetFormattedString().Trim()
                : "";
        }
        public static bool Empty(IXLRow row, Dictionary<string, int> headers)
        {
            return headers.Values.All(x => string.IsNullOrWhiteSpace(row.Cell(x).GetFormattedString()));
        }
        public static DateTime Date(string value, string field)
        {
            DateTime result;
            if (DateTime.TryParseExact(
                value.Trim(),
                new[] {
                    "dd/MM/yyyy", "d/M/yyyy",
                    "yyyy-MM-dd", "yyyy-M-d",
                },
                CultureInfo.InvariantCulture,
                DateTimeStyles.None,
                out result))
                return result.Date;

            throw new ArgumentException(
                field + " must be a date in dd/MM/yyyy format (for example 04/12/2026).");
        }
        public static TimeSpan? Time(string value, string field)
        {
            if (string.IsNullOrWhiteSpace(value)) return null;
            TimeSpan result;
            string[] formats = {
                @"h\:mm", @"hh\:mm",
                @"h\:mm\:ss", @"hh\:mm\:ss"
            };

            if (TimeSpan.TryParseExact(
                value.Trim(),
                formats,
                CultureInfo.InvariantCulture,
                out result) &&
                result >= TimeSpan.Zero &&
                result < TimeSpan.FromDays(1))
                return result;

            DateTime date;
            if (DateTime.TryParseExact(
                value.Trim(),
                new[] { "H:mm", "HH:mm", "H:mm:ss", "HH:mm:ss" },
                CultureInfo.InvariantCulture,
                DateTimeStyles.None,
                out date))
                return date.TimeOfDay;

            throw new ArgumentException(
                field + " must use 24-hour HH:mm format (for example 20:35).");
        }
        public static bool Bool(string value, string field)
        {
            if (string.IsNullOrWhiteSpace(value)) return false;
            switch (value.Trim().ToLowerInvariant())
            {
                case "y": case "yes": case "true": case "1": return true;
                case "n": case "no": case "false": case "0": return false;
                default: throw new ArgumentException(field + " must be Y or N.");
            }
        }
        public static string Limit(string value, int max, string field, bool required = false)
        {
            value = (value ?? "").Trim();
            if (required && value.Length == 0) throw new ArgumentException(field + " is required.");
            if (value.Length > max) throw new ArgumentException(field + " exceeds " + max + " characters.");
            return value.Length == 0 ? null : value;
        }

        public static string ErrorColumn(
            string message,
            IEnumerable<string> availableHeaders)
        {
            string text = (message ?? "").ToLowerInvariant();

            if (text.Contains("duplicate email + type"))
                return "Email + Type";
            if (text.Contains("duplicate email + dayscheduleid"))
                return "Email + DayScheduleId";
            if (text.Contains("duplicate email + scheduletitle"))
                return "Email + ScheduleTitle";
            if (text.Contains("scheduletitle") || text.Contains("schedule title"))
                return "ScheduleTitle";
            if (text.Contains("scheduledate"))
                return "ScheduleDate";
            if (text.Contains("duplicate date + title"))
                return "Date + Title";
            if (text.Contains("endtime must be after starttime"))
                return "EndTime";
            if (text.Contains("dayscheduleid"))
                return "DayScheduleId";
            if (text.Contains("duplicate id"))
                return "Id";

            var headers = (availableHeaders ?? Enumerable.Empty<string>())
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .OrderByDescending(x => x.Length);

            foreach (var header in headers)
            {
                string normalized = header.Replace("_", "").Replace(" ", "").ToLowerInvariant();
                if (normalized.Length > 0 && text.Replace("_", "").Replace(" ", "").Contains(normalized))
                    return header;
            }

            if (text.Contains("guest email") || text.Contains("email"))
                return "Email";
            if (text.Contains("schedule title"))
                return "ScheduleTitle";
            if (text.Contains("schedule id") || text.Contains("dayscheduleid"))
                return "DayScheduleId";
            if (text.Contains("starttime"))
                return "StartTime";
            if (text.Contains("endtime"))
                return "EndTime";
            if (text.Contains("drivername"))
                return "DriverName";
            if (text.Contains("driverphone"))
                return "DriverPhone";
            if (text.Contains("date"))
                return "Date";
            if (text.Contains("title"))
                return "Title";
            if (text.Contains("type"))
                return "Type";
            if (text.Contains("whatsapp"))
                return "WhatsApp";

            return "Record";
        }

        public static string ErrorValue(
            IXLRow row,
            Dictionary<string, int> headers,
            string column)
        {
            if (row == null || headers == null || string.IsNullOrWhiteSpace(column))
                return "";

            int index;
            if (headers.TryGetValue(column, out index))
                return row.Cell(index).GetFormattedString().Trim();

            if (column == "Email + Type")
                return Text(row, headers, "Email") + " | " + Text(row, headers, "Type");

            if (column == "Email + DayScheduleId")
                return Text(row, headers, "Email") + " | " + Text(row, headers, "DayScheduleId");

            if (column == "Email + ScheduleTitle")
                return Text(row, headers, "Email") + " | " + Text(row, headers, "ScheduleTitle");

            if (column == "Date + Title")
                return Text(row, headers, "Date") + " | " + Text(row, headers, "Title");

            return "";
        }

        public static string NormalizeImportMode(string mode)
        {
            if (string.IsNullOrWhiteSpace(mode))
                return "Upsert";

            if (string.Equals(mode, "UpdateOnly", StringComparison.OrdinalIgnoreCase))
                return "UpdateOnly";
            if (string.Equals(mode, "Upsert", StringComparison.OrdinalIgnoreCase))
                return "Upsert";
            if (string.Equals(mode, "ReplaceAll", StringComparison.OrdinalIgnoreCase))
                return "ReplaceAll";

            throw new ArgumentException(
                "Import mode must be UpdateOnly, Upsert or ReplaceAll.");
        }

        public static void WriteInstructions(IXLWorkbook workbook, params string[] instructions)
        {
            var sheet = workbook.Worksheets.Add("Instructions");
            sheet.Cell(1, 1).Value = "IMPORT GUIDANCE";
            sheet.Cell(1, 1).Style.Font.Bold = true;
            sheet.Cell(1, 1).Style.Font.FontColor = XLColor.White;
            sheet.Cell(1, 1).Style.Fill.BackgroundColor = XLColor.FromHtml("#C8102E");

            for (int i = 0; i < instructions.Length; i++)
            {
                sheet.Cell(i + 2, 1).Value = instructions[i];
                sheet.Cell(i + 2, 1).Style.Alignment.WrapText = true;
            }

            sheet.Column(1).Width = 105;
            sheet.SheetView.FreezeRows(1);
        }

        public static void WriteTemplateHeaders(IXLWorksheet sheet, params string[] headers)
        {
            for (int i = 0; i < headers.Length; i++)
            {
                sheet.Cell(1, i + 1).Value = headers[i];

                string header = headers[i] ?? "";
                if (string.Equals(header, "Date", StringComparison.OrdinalIgnoreCase) ||
                    header.EndsWith("Date", StringComparison.OrdinalIgnoreCase))
                    sheet.Column(i + 1).Style.DateFormat.Format = "dd/MM/yyyy";
                else if (header.EndsWith("Time", StringComparison.OrdinalIgnoreCase))
                    sheet.Column(i + 1).Style.DateFormat.Format = "HH:mm";
            }

            var range = sheet.Range(1, 1, 1, headers.Length);
            range.Style.Font.Bold = true;
            range.Style.Fill.BackgroundColor = XLColor.FromHtml("#B91C1C");
            range.Style.Font.FontColor = XLColor.White;
            sheet.SheetView.FreezeRows(1);
            sheet.Columns(1, headers.Length).Width = 23;
        }
        public static byte[] Template(params string[] headers)
        {
            using (var wb = new XLWorkbook())
            using (var stream = new MemoryStream())
            {
                WriteTemplateHeaders(wb.Worksheets.Add("Import"), headers);
                wb.SaveAs(stream);
                return stream.ToArray();
            }
        }
    }
}
