using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using ClosedXML.Excel;

namespace SLTProject.Services
{
    internal static class ScheduleTransportExcel
    {
        public static XLWorkbook Open(Stream stream)
        {
            if (stream == null) throw new ArgumentException("Excel file is required.");
            return new XLWorkbook(stream);
        }
        public static Dictionary<string, int> Headers(IXLWorksheet sheet)
        {
            if (sheet == null || sheet.FirstRowUsed() == null)
                throw new ArgumentException("Excel sheet is empty.");
            var result = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            foreach (var cell in sheet.Row(1).CellsUsed())
            {
                var key = cell.GetString().Trim();
                if (key.Length == 0) continue;
                if (result.ContainsKey(key)) throw new ArgumentException("Duplicate Excel header: " + key);
                result[key] = cell.Address.ColumnNumber;
            }
            return result;
        }
        public static void Require(Dictionary<string, int> headers, params string[] names)
        {
            foreach (var name in names)
                if (!headers.ContainsKey(name)) throw new ArgumentException("Missing Excel column: " + name);
        }
        public static string Text(IXLRow row, Dictionary<string, int> headers, string column)
        {
            int col;
            return headers.TryGetValue(column, out col)
                ? row.Cell(col).GetFormattedString().Trim()
                : "";
        }
        public static bool Empty(IXLRow row, Dictionary<string, int> headers)
        {
            return headers.Values.All(x => string.IsNullOrWhiteSpace(row.Cell(x).GetFormattedString()));
        }
        public static DateTime Date(string value, string field)
        {
            DateTime result;
            if (DateTime.TryParseExact(value, new[] { "yyyy-MM-dd", "dd/MM/yyyy", "M/d/yyyy", "MM/dd/yyyy" },
                CultureInfo.InvariantCulture, DateTimeStyles.None, out result)) return result.Date;
            throw new ArgumentException(field + " must be a date (yyyy-MM-dd recommended).");
        }
        public static TimeSpan? Time(string value, string field)
        {
            if (string.IsNullOrWhiteSpace(value)) return null;
            TimeSpan result;
            if (TimeSpan.TryParse(value, CultureInfo.InvariantCulture, out result) &&
                result >= TimeSpan.Zero && result < TimeSpan.FromDays(1)) return result;
            DateTime date;
            if (DateTime.TryParse(value, CultureInfo.InvariantCulture, DateTimeStyles.None, out date))
                return date.TimeOfDay;
            throw new ArgumentException(field + " must be HH:mm (24-hour time).");
        }
        public static bool Bool(string value, string field)
        {
            if (string.IsNullOrWhiteSpace(value)) return false;
            switch (value.Trim().ToLowerInvariant())
            {
                case "y": case "yes": case "true": case "1": return true;
                case "n": case "no": case "false": case "0": return false;
                default: throw new ArgumentException(field + " must be Y or N.");
            }
        }
        public static string Limit(string value, int max, string field, bool required = false)
        {
            value = (value ?? "").Trim();
            if (required && value.Length == 0) throw new ArgumentException(field + " is required.");
            if (value.Length > max) throw new ArgumentException(field + " exceeds " + max + " characters.");
            return value.Length == 0 ? null : value;
        }
        public static void WriteTemplateHeaders(IXLWorksheet sheet, params string[] headers)
        {
            for (int i = 0; i < headers.Length; i++) sheet.Cell(1, i + 1).Value = headers[i];
            var range = sheet.Range(1, 1, 1, headers.Length);
            range.Style.Font.Bold = true;
            range.Style.Fill.BackgroundColor = XLColor.FromHtml("#B91C1C");
            range.Style.Font.FontColor = XLColor.White;
            sheet.SheetView.FreezeRows(1);
            sheet.Columns(1, headers.Length).Width = 23;
        }
        public static byte[] Template(params string[] headers)
        {
            using (var wb = new XLWorkbook())
            using (var stream = new MemoryStream())
            {
                WriteTemplateHeaders(wb.Worksheets.Add("Import"), headers);
                wb.SaveAs(stream);
                return stream.ToArray();
            }
        }
    }
}
