using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Entity.Core.EntityClient;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using SLTProject.Data;
using WebPush;

namespace SLTProject.Services
{
    // One app-local Web Push implementation. No global service, application codes or token exchange.
    // Works with the existing database-first SLTEntities without regenerating the EDMX.
    public sealed class SltDirectWebPushService
    {
        public sealed class BrowserSubscription
        {
            public string endpoint { get; set; }
            public string p256dh { get; set; }
            public string auth { get; set; }
        }

        public sealed class DeliverySummary
        {
            public int Subscriptions { get; set; }
            public int Accepted { get; set; }
            public int Failed { get; set; }
            public string Status { get { return Subscriptions == 0 ? "NoSubscribers" :
                Failed == 0 ? "Accepted" : Accepted > 0 ? "Partial" : "Failed"; } }
        }

        private sealed class SubscriptionRow
        {
            public long Id;
            public string Endpoint, P256dh, Auth;
            public long? LastAcceptedNotificationId;
        }

        private static string Setting(string key) { return (ConfigurationManager.AppSettings[key] ?? "").Trim(); }
        private static string Required(string key)
        {
            var value = Setting(key);
            if (string.IsNullOrWhiteSpace(value) || value.StartsWith("REPLACE_", StringComparison.OrdinalIgnoreCase))
                throw new ConfigurationErrorsException("Missing SltWebPush setting: " + key);
            return value;
        }

        public static string PublicKey { get { return Required("SltWebPush.VapidPublicKey"); } }

        private static string SqlConnectionString()
        {
            using (var db = new SLTEntities())
            {
                var entity = db.Database.Connection as EntityConnection;
                return entity == null ? db.Database.Connection.ConnectionString : entity.StoreConnection.ConnectionString;
            }
        }

        private static SqlParameter Param(string key, object value) { return new SqlParameter(key, value ?? DBNull.Value); }

        private static byte[] Hash(string endpoint)
        {
            using (var sha = SHA256.Create()) return sha.ComputeHash(Encoding.UTF8.GetBytes(endpoint));
        }

        private static byte[] Base64Url(string value)
        {
            if (string.IsNullOrWhiteSpace(value) || value.Length > 350) throw new ArgumentException("Invalid browser subscription key.");
            string source = value.Replace('-', '+').Replace('_', '/');
            source = source.PadRight((source.Length + 3) / 4 * 4, '=');
            return Convert.FromBase64String(source);
        }

        // Keep the outbound destination restricted to standard Web Push providers (not arbitrary SSRF URLs).
        public static void Validate(BrowserSubscription dto)
        {
            if (dto == null || string.IsNullOrWhiteSpace(dto.endpoint) || dto.endpoint.Length > 2048)
                throw new ArgumentException("Browser endpoint is required.");
            Uri endpoint;
            if (!Uri.TryCreate(dto.endpoint, UriKind.Absolute, out endpoint) || endpoint.Scheme != Uri.UriSchemeHttps ||
                endpoint.Port != 443 || !string.IsNullOrEmpty(endpoint.UserInfo) || endpoint.HostNameType != UriHostNameType.Dns)
                throw new ArgumentException("Browser endpoint must use a supported HTTPS push provider.");
            var host = endpoint.Host.ToLowerInvariant();
            bool allowed = host == "fcm.googleapis.com" || (host.StartsWith("fcm") && host.EndsWith(".googleapis.com")) ||
                host == "updates.push.services.mozilla.com" || host == "push.services.mozilla.com" ||
                host == "web.push.apple.com" || host.EndsWith(".push.apple.com") ||
                host == "notify.windows.com" || host.EndsWith(".notify.windows.com");
            if (!allowed) throw new ArgumentException("Browser endpoint provider is unsupported.");
            try
            {
                if (Base64Url(dto.p256dh).Length != 65 || Base64Url(dto.auth).Length != 16)
                    throw new ArgumentException("Invalid browser Web Push encryption keys.");
            }
            catch (FormatException) { throw new ArgumentException("Invalid browser Web Push encryption keys."); }
        }

        // An existing endpoint is rebound to the currently authenticated guest; no separate device ID.
        public async Task<long> SubscribeAsync(long guestId, BrowserSubscription dto, CancellationToken ct)
        {
            Validate(dto);
            using (var connection = new SqlConnection(SqlConnectionString()))
            {
                await connection.OpenAsync(ct);
                using (var tx = connection.BeginTransaction(IsolationLevel.Serializable))
                using (var cmd = new SqlCommand(@"
DECLARE @id bigint;
SELECT @id=Id FROM dbo.SltGuestPushSubscriptions WITH (UPDLOCK,HOLDLOCK) WHERE EndpointHash=@hash;
IF @id IS NULL
BEGIN
 INSERT dbo.SltGuestPushSubscriptions(GuestId,Endpoint,EndpointHash,P256dh,Auth,IsActive,CreatedAtUtc,UpdatedAtUtc)
 VALUES (@guest,@endpoint,@hash,@p256dh,@auth,1,SYSUTCDATETIME(),SYSUTCDATETIME());
 SET @id=SCOPE_IDENTITY();
END
ELSE
 UPDATE dbo.SltGuestPushSubscriptions SET GuestId=@guest,Endpoint=@endpoint,P256dh=@p256dh,Auth=@auth,
 IsActive=1,UpdatedAtUtc=SYSUTCDATETIME(),LastError=NULL WHERE Id=@id;
SELECT @id;", connection, tx))
                {
                    cmd.Parameters.AddRange(new [] { Param("@guest",guestId), Param("@endpoint",dto.endpoint),
                        Param("@hash",Hash(dto.endpoint)), Param("@p256dh",dto.p256dh), Param("@auth",dto.auth) });
                    var id = Convert.ToInt64(await cmd.ExecuteScalarAsync(ct));
                    tx.Commit();
                    return id;
                }
            }
        }

        public async Task<bool> StatusAsync(long guestId, string endpoint, CancellationToken ct)
        {
            if (string.IsNullOrWhiteSpace(endpoint) || endpoint.Length > 2048) return false;
            using (var connection = new SqlConnection(SqlConnectionString()))
            using (var cmd = new SqlCommand(@"SELECT COUNT(1) FROM dbo.SltGuestPushSubscriptions
WHERE GuestId=@guest AND EndpointHash=@hash AND Endpoint=@endpoint AND IsActive=1", connection))
            {
                cmd.Parameters.AddRange(new [] { Param("@guest",guestId), Param("@hash",Hash(endpoint)), Param("@endpoint",endpoint) });
                await connection.OpenAsync(ct);
                return Convert.ToInt32(await cmd.ExecuteScalarAsync(ct)) > 0;
            }
        }

        public async Task<bool> UnsubscribeAsync(long guestId, string endpoint, CancellationToken ct)
        {
            if (string.IsNullOrWhiteSpace(endpoint) || endpoint.Length > 2048) return false;
            using (var connection = new SqlConnection(SqlConnectionString()))
            using (var cmd = new SqlCommand(@"UPDATE dbo.SltGuestPushSubscriptions SET IsActive=0,UpdatedAtUtc=SYSUTCDATETIME()
WHERE GuestId=@guest AND EndpointHash=@hash AND Endpoint=@endpoint AND IsActive=1", connection))
            {
                cmd.Parameters.AddRange(new [] { Param("@guest",guestId), Param("@hash",Hash(endpoint)), Param("@endpoint",endpoint) });
                await connection.OpenAsync(ct);
                return await cmd.ExecuteNonQueryAsync(ct) > 0;
            }
        }

        private static HttpClient CreateHttpClient()
        {
            var useProxy = string.Equals(Setting("SltWebPush.UseProxy"), "true", StringComparison.OrdinalIgnoreCase);
            var handler = new HttpClientHandler { UseProxy = useProxy, AllowAutoRedirect = false };
            if (useProxy)
            {
                Uri uri;
                if (!Uri.TryCreate(Required("SltWebPush.ProxyUrl"), UriKind.Absolute, out uri) ||
                    (uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps))
                    throw new ConfigurationErrorsException("SltWebPush.ProxyUrl must be a valid HTTP(S) proxy address.");
                var proxy = new WebProxy(uri) { BypassProxyOnLocal = false };
                if (string.Equals(Setting("SltWebPush.ProxyUseDefaultCredentials"), "true", StringComparison.OrdinalIgnoreCase))
                    proxy.Credentials = CredentialCache.DefaultNetworkCredentials;
                handler.Proxy = proxy;
            }
            var timeout = 25;
            int parsed;
            if (int.TryParse(Setting("SltWebPush.HttpTimeoutSeconds"), out parsed)) timeout = Math.Max(5, Math.Min(120, parsed));
            return new HttpClient(handler) { Timeout = TimeSpan.FromSeconds(timeout) };
        }

        // Reads the existing SLT notification recipient rows so admin broadcasts remain guest-only.
        private static async Task<List<SubscriptionRow>> ForNotificationAsync(long notificationId, CancellationToken ct)
        {
            var rows = new List<SubscriptionRow>();
            using (var connection = new SqlConnection(SqlConnectionString()))
            using (var cmd = new SqlCommand(@"
SELECT s.Id,s.Endpoint,s.P256dh,s.Auth,s.LastAcceptedNotificationId FROM dbo.SltGuestPushSubscriptions s
WHERE s.IsActive=1 AND EXISTS (
 SELECT 1 FROM dbo.SltNotificationRecipients r
 WHERE r.NotificationId=@notification AND r.GuestId=s.GuestId)
ORDER BY s.Id", connection))
            {
                cmd.Parameters.Add(Param("@notification", notificationId));
                await connection.OpenAsync(ct);
                using (var reader = await cmd.ExecuteReaderAsync(ct))
                    while (await reader.ReadAsync(ct))
                        rows.Add(new SubscriptionRow { Id=reader.GetInt64(0), Endpoint=reader.GetString(1),
                            P256dh=reader.GetString(2), Auth=reader.GetString(3),
                            LastAcceptedNotificationId=reader.IsDBNull(4)?(long?)null:reader.GetInt64(4) });
            }
            return rows;
        }

        private static async Task RecordAsync(long id, long notificationId, bool accepted, bool deactivate, string error)
        {
            using (var connection = new SqlConnection(SqlConnectionString()))
            using (var cmd = new SqlCommand(@"UPDATE dbo.SltGuestPushSubscriptions SET
IsActive=CASE WHEN @deactivate=1 THEN 0 ELSE IsActive END,
LastAcceptedAtUtc=CASE WHEN @accepted=1 THEN SYSUTCDATETIME() ELSE LastAcceptedAtUtc END,
LastAcceptedNotificationId=CASE WHEN @accepted=1 THEN @notification ELSE LastAcceptedNotificationId END,
LastError=@error,UpdatedAtUtc=SYSUTCDATETIME() WHERE Id=@id", connection))
            {
                cmd.Parameters.AddRange(new [] { Param("@id",id), Param("@accepted",accepted?1:0),
                    Param("@deactivate",deactivate?1:0), Param("@notification",notificationId), Param("@error",error) });
                await connection.OpenAsync();
                await cmd.ExecuteNonQueryAsync();
            }
        }

        public async Task<DeliverySummary> SendForNotificationAsync(long notificationId, string title, string body, string clickUrl, CancellationToken ct)
        {
            var rows = await ForNotificationAsync(notificationId, ct);
            var result = new DeliverySummary { Subscriptions = rows.Count };
            if (rows.Count == 0) return result;
            var vapid = new VapidDetails(Required("SltWebPush.VapidSubject"), PublicKey, Required("SltWebPush.VapidPrivateKey"));
            var fallback = Setting("SltWebPush.ClickPath");
            if (string.IsNullOrWhiteSpace(fallback)) fallback = "html/Notifications.html";
            // Push URLs must be same-origin relative paths. The user site's service worker resolves them.
            string url = string.IsNullOrWhiteSpace(clickUrl) ? fallback : clickUrl;
            var payload = JsonConvert.SerializeObject(new { title, body, url, id=notificationId });
            int configuredTtl;
            if (!int.TryParse(Setting("SltWebPush.TtlSeconds"), out configuredTtl)) configuredTtl = 3600;
            configuredTtl = Math.Max(60, Math.Min(86400, configuredTtl));
            var options = new Dictionary<string, object> { { "vapidDetails", vapid }, { "TTL", configuredTtl } };
            using (var http = CreateHttpClient())
            {
                var client = new WebPushClient(http);
                // Small bounded batches avoid one slow provider serializing a large admin broadcast.
                int acceptedCount = 0, failedCount = 0;
                const int parallelSends = 6;
                for (var offset = 0; offset < rows.Count; offset += parallelSends)
                {
                    var batch = rows.Skip(offset).Take(parallelSends).Select(async row =>
                    {
                        ct.ThrowIfCancellationRequested();
                        // A scheduled retry must not deliver twice to a browser that already accepted it.
                        if (row.LastAcceptedNotificationId == notificationId)
                        {
                            Interlocked.Increment(ref acceptedCount);
                            return;
                        }
                        try
                        {
                            await client.SendNotificationAsync(new PushSubscription(row.Endpoint,row.P256dh,row.Auth),payload,options,ct);
                            await RecordAsync(row.Id,notificationId,true,false,null);
                            Interlocked.Increment(ref acceptedCount);
                        }
                        catch (WebPushException ex)
                        {
                            var status = (int)ex.StatusCode;
                            Interlocked.Increment(ref failedCount);
                            await RecordAsync(row.Id,notificationId,false,status == 404 || status == 410,"Push provider HTTP " + status);
                            System.Diagnostics.Trace.TraceWarning("SLT Web Push notification " + notificationId + ": provider HTTP " + status);
                        }
                        catch (Exception ex) when (ex is HttpRequestException || ex is TaskCanceledException || ex is ArgumentException)
                        {
                            Interlocked.Increment(ref failedCount);
                            await RecordAsync(row.Id,notificationId,false,false,ex.GetType().Name);
                            System.Diagnostics.Trace.TraceWarning("SLT Web Push notification " + notificationId + ": " + ex.GetType().Name + " (proxy=" + Setting("SltWebPush.UseProxy") + ")");
                        }
                    }).ToArray();
                    await Task.WhenAll(batch);
                }
                result.Accepted = acceptedCount;
                result.Failed = failedCount;
            }
            return result;
        }
    }
}
