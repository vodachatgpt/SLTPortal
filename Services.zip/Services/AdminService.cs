﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Configuration;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using SLTProject.Data;

namespace SLTProject.Services
{
    // ============================================================
    // ADMIN INPUT DTO
    // ============================================================

    public class AdminInput
    {
        [Required]
        [StringLength(250)]
        public string FullName { get; set; }

        [Required]
        [EmailAddress]
        [StringLength(320)]
        public string Email { get; set; }
    }

    // ============================================================
    // ADMIN LOGIN INPUT
    // ============================================================

    public class AdminLoginInput
    {
        [Required]
        public string Email { get; set; }

        [Required]
        public string Passcode { get; set; }
    }

    // ============================================================
    // ADMIN VIEW DTO
    // ============================================================

    public class AdminView
    {
        public long Id { get; set; }

        public string FullName { get; set; }

        public string Email { get; set; }

        public string PasscodeLast4 { get; set; }

        public bool IsActive { get; set; }

        public bool Activated { get; set; }

        // Stored as Egypt-local time.
        public DateTime? SessionExpiresAt { get; set; }

        public DateTime RetentionDateCreated { get; set; }

        public DateTime? RetentionDateModified { get; set; }

        public string CreatedBy { get; set; }

        public string ModifiedBy { get; set; }
    }

    // ============================================================
    // ADMIN CREATED RESULT
    // ============================================================

    public class AdminCreatedResult
    {
        public AdminView Admin { get; set; }

        public string Passcode { get; set; }
    }

    // ============================================================
    // ADMIN LOGIN RESULT
    // ============================================================

    public class AdminLoginResult
    {
        public string Token { get; set; }

        // Egypt-local expiration timestamp.
        public DateTime ExpiresAt { get; set; }

        public AdminView Admin { get; set; }
    }

    // ============================================================
    // ADMIN SERVICE
    // ============================================================

    public class AdminService
    {
        private const int PasscodeLength = 6;

        private const int SessionDays = 30;

        private const int MaxFailedAttempts = 5;

        private const int LockMinutes = 15;

        // ========================================================
        // PASSCODE PEPPER
        // ========================================================

        private static string Pepper
        {
            get
            {
                string value = ConfigurationManager
                    .AppSettings["SLTPasscodePepper"];

                if (string.IsNullOrWhiteSpace(value) ||
                    value.StartsWith(
                        "REPLACE_WITH",
                        StringComparison.OrdinalIgnoreCase))
                {
                    throw new ConfigurationErrorsException(
                        "Configure SLTPasscodePepper.");
                }

                return value;
            }
        }

        // ========================================================
        // PASSWORD / PASSCODE HASH
        // ========================================================

        private static byte[] HashPasscode(
            string passcode)
        {
            using (var hmac = new HMACSHA256(
                Encoding.UTF8.GetBytes(Pepper)))
            {
                return hmac.ComputeHash(
                    Encoding.UTF8.GetBytes(
                        (passcode ?? string.Empty)
                            .Trim()
                            .ToUpperInvariant()));
            }
        }

        // ========================================================
        // SESSION TOKEN HASH
        // ========================================================

        private static byte[] HashToken(
            string token)
        {
            using (var sha = SHA256.Create())
            {
                return sha.ComputeHash(
                    Encoding.UTF8.GetBytes(
                        token ?? string.Empty));
            }
        }

        // ========================================================
        // CHECK SIX-DIGIT PASSCODE
        // ========================================================

        private static bool ValidPasscode(
            string value)
        {
            return value != null &&
                   value.Length == PasscodeLength &&
                   value.All(
                       c => c >= '0' && c <= '9');
        }

        // ========================================================
        // GENERATE SECURE SIX-DIGIT PASSCODE
        // ========================================================

        private static string GeneratePasscode()
        {
            const ulong range = 1000000UL;

            const ulong limit =
                (4294967296UL / range) * range;

            byte[] bytes = new byte[4];

            using (var rng =
                RandomNumberGenerator.Create())
            {
                while (true)
                {
                    rng.GetBytes(bytes);

                    uint value =
                        BitConverter.ToUInt32(
                            bytes,
                            0);

                    if ((ulong)value >= limit)
                        continue;

                    return ((ulong)value % range)
                        .ToString("D6");
                }
            }
        }

        // ========================================================
        // GENERATE SECURE SESSION TOKEN
        // ========================================================

        private static string GenerateToken()
        {
            byte[] bytes = new byte[32];

            using (var rng =
                RandomNumberGenerator.Create())
            {
                rng.GetBytes(bytes);
            }

            return Convert.ToBase64String(bytes)
                .TrimEnd('=')
                .Replace('+', '-')
                .Replace('/', '_');
        }

        // ========================================================
        // NORMALIZE EMAIL
        // ========================================================

        private static string NormalizeEmail(
            string email)
        {
            return (email ?? string.Empty)
                .Trim()
                .ToLowerInvariant();
        }

        // ========================================================
        // EGYPT DATE/TIME HELPERS
        // ========================================================

        private static DateTime EgyptNow
        {
            get
            {
                return EgyptDateTimeService.Now;
            }
        }

        // Add an elapsed duration to the current instant
        // before converting it to Egypt local time.
        // This avoids DST duration calculation errors.

        private static DateTime EgyptAfterMinutes(
            DateTime utcInstant,
            int minutes)
        {
            return EgyptDateTimeService.FromUtc(
                utcInstant.AddMinutes(minutes));
        }

        private static DateTime EgyptAfterDays(
            DateTime utcInstant,
            int days)
        {
            return EgyptDateTimeService.FromUtc(
                utcInstant.AddDays(days));
        }

        // ========================================================
        // ENTITY TO DTO MAPPING
        // ========================================================

        private static AdminView Map(
            Admin admin)
        {
            if (admin == null)
                return null;

            return new AdminView
            {
                Id = admin.Id,

                FullName = admin.FullName,

                Email = admin.Email,

                PasscodeLast4 =
                    admin.PasscodeLast4,

                IsActive = admin.IsActive,

                Activated =
                    admin.FirstLoginAt.HasValue,

                SessionExpiresAt =
                    admin.SessionExpiresAt,

                RetentionDateCreated =
                    admin.RetentionDateCreated,

                RetentionDateModified =
                    admin.RetentionDateModified,

                CreatedBy = admin.CreatedBy,

                ModifiedBy = admin.ModifiedBy
            };
        }

        // ========================================================
        // ISSUE UNIQUE ADMIN PASSCODE
        // ========================================================

        private static string IssuePasscode(
            SLTEntities db,
            Admin admin)
        {
            for (
                int attempt = 0;
                attempt < 100;
                attempt++)
            {
                string passcode =
                    GeneratePasscode();

                byte[] hash =
                    HashPasscode(passcode);

                // Preserve existing DB-side uniqueness check.
                // VARBINARY matching must be exact.

                int count = db.Database
                    .SqlQuery<int>(@"
SELECT COUNT(1)
FROM dbo.Admins
WHERE PasscodeHash = @hash
  AND Id <> @id",
                        new SqlParameter(
                            "@hash",
                            SqlDbType.VarBinary,
                            32)
                        {
                            Value = hash
                        },
                        new SqlParameter(
                            "@id",
                            SqlDbType.BigInt)
                        {
                            Value = admin.Id
                        })
                    .Single();

                bool localDuplicate =
                    db.Admins.Local.Any(
                        x =>
                            x != admin &&
                            x.PasscodeHash != null &&
                            x.PasscodeHash
                                .SequenceEqual(hash));

                if (count > 0 || localDuplicate)
                    continue;

                admin.PasscodeHash = hash;

                admin.PasscodeLast4 =
                    passcode.Substring(2);

                return passcode;
            }

            throw new InvalidOperationException(
                "Unable to generate a unique passcode.");
        }

        // ========================================================
        // GET ADMIN BY ID
        // ========================================================

        public async Task<AdminView> GetAsync(
            long id)
        {
            if (id <= 0)
                return null;

            using (var db = new SLTEntities())
            {
                var admin = await db.Admins
                    .AsNoTracking()
                    .FirstOrDefaultAsync(
                        x =>
                            x.Id == id &&
                            !x.IsDeleted);

                return Map(admin);
            }
        }

        // ========================================================
        // GET ALL ADMINS
        // ========================================================

        public async Task<List<AdminView>>
            GetAllAsync()
        {
            using (var db = new SLTEntities())
            {
                var admins = await db.Admins
                    .AsNoTracking()
                    .Where(
                        x => !x.IsDeleted)
                    .OrderBy(
                        x => x.FullName)
                    .ToListAsync();

                return admins
                    .Select(Map)
                    .ToList();
            }
        }

        // ========================================================
        // CREATE ADMIN
        // ========================================================

        public async Task<AdminCreatedResult>
            CreateAsync(
                AdminInput input,
                string createdBy)
        {
            if (input == null ||
                string.IsNullOrWhiteSpace(
                    input.FullName))
            {
                throw new ArgumentException(
                    "FullName is required.");
            }

            string email =
                NormalizeEmail(input.Email);

            if (!new EmailAddressAttribute()
                .IsValid(email))
            {
                throw new ArgumentException(
                    "Invalid email.");
            }

            using (var db = new SLTEntities())
            {
                bool exists = await db.Admins
                    .AnyAsync(
                        x =>
                            !x.IsDeleted &&
                            x.Email == email);

                if (exists)
                {
                    throw new ArgumentException(
                        "This admin email already exists.");
                }

                DateTime nowEgypt =
                    EgyptNow;

                var admin = new Admin
                {
                    FullName =
                        input.FullName.Trim(),

                    Email = email,

                    CreatedBy = createdBy,

                    RetentionDateCreated =
                        nowEgypt,

                    IsActive = true,

                    IsDeleted = false,

                    FailedLoginAttempts = 0
                };

                string passcode =
                    IssuePasscode(
                        db,
                        admin);

                db.Admins.Add(admin);

                await db.SaveChangesAsync();

                return new AdminCreatedResult
                {
                    Admin = Map(admin),

                    Passcode = passcode
                };
            }
        }

        // ========================================================
        // UPDATE ADMIN
        // ========================================================

        public async Task<AdminView> UpdateAsync(
            long id,
            AdminInput input,
            string actor)
        {
            if (id <= 0)
                return null;

            if (input == null ||
                string.IsNullOrWhiteSpace(
                    input.FullName))
            {
                throw new ArgumentException(
                    "FullName is required.");
            }

            string email =
                NormalizeEmail(input.Email);

            if (!new EmailAddressAttribute()
                .IsValid(email))
            {
                throw new ArgumentException(
                    "Invalid email.");
            }

            using (var db = new SLTEntities())
            {
                var admin = await db.Admins
                    .FirstOrDefaultAsync(
                        x =>
                            x.Id == id &&
                            !x.IsDeleted);

                if (admin == null)
                    return null;

                bool duplicate =
                    await db.Admins.AnyAsync(
                        x =>
                            x.Id != id &&
                            !x.IsDeleted &&
                            x.Email == email);

                if (duplicate)
                {
                    throw new ArgumentException(
                        "Another admin uses this email.");
                }

                admin.FullName =
                    input.FullName.Trim();

                admin.Email = email;

                admin.ModifiedBy = actor;

                admin.RetentionDateModified =
                    EgyptNow;

                await db.SaveChangesAsync();

                return Map(admin);
            }
        }

        // ========================================================
        // RESET ADMIN PASSCODE
        // ========================================================

        public async Task<string>
            ResetPasscodeAsync(
                long id,
                string actor)
        {
            if (id <= 0)
                return null;

            using (var db = new SLTEntities())
            {
                var admin = await db.Admins
                    .FirstOrDefaultAsync(
                        x =>
                            x.Id == id &&
                            !x.IsDeleted &&
                            x.IsActive);

                if (admin == null)
                    return null;

                string passcode =
                    IssuePasscode(
                        db,
                        admin);

                // Require fresh activation.
                admin.FirstLoginAt = null;

                // Invalidate existing session.
                admin.SessionTokenHash = null;

                admin.SessionExpiresAt = null;

                admin.FailedLoginAttempts = 0;

                admin.LockedUntil = null;

                admin.ModifiedBy = actor;

                admin.RetentionDateModified =
                    EgyptNow;

                await db.SaveChangesAsync();

                return passcode;
            }
        }

        // ========================================================
        // SOFT DELETE ADMIN
        // ========================================================

        public async Task<bool> DeleteAsync(
            long id,
            long actorId,
            string actor)
        {
            if (id <= 0)
                return false;

            if (id == actorId)
            {
                throw new ArgumentException(
                    "You cannot delete your own account.");
            }

            using (var db = new SLTEntities())
            {
                var admin = await db.Admins
                    .FirstOrDefaultAsync(
                        x =>
                            x.Id == id &&
                            !x.IsDeleted);

                if (admin == null)
                    return false;

                DateTime nowEgypt =
                    EgyptNow;

                admin.IsDeleted = true;

                admin.IsActive = false;

                admin.DeletedBy = actor;

                admin.DeletedAt = nowEgypt;

                admin.ModifiedBy = actor;

                admin.RetentionDateModified =
                    nowEgypt;

                admin.FirstLoginAt = null;

                admin.SessionTokenHash = null;

                admin.SessionExpiresAt = null;

                admin.LockedUntil = null;

                await db.SaveChangesAsync();

                return true;
            }
        }

        // ========================================================
        // ADMIN LOGIN
        //
        // POST /api/admin-auth/login
        //
        // Existing behavior:
        // - Six-digit passcode
        // - One-time activation
        // - 30-day session
        // - Login throttling
        // - Account lockout
        //
        // All persisted timestamps use Egypt time.
        // ========================================================

        public async Task<AdminLoginResult>
            LoginAsync(
                string email,
                string passcode,
                string clientIp = null)
        {
            email =
                NormalizeEmail(email);

            passcode =
                (passcode ?? string.Empty)
                    .Trim();

            // ----------------------------------------------------
            // 1. EMAIL RATE LIMIT
            // ----------------------------------------------------

            if (!await SltLoginThrottle
                .TryConsumeAsync(
                    "admin-email",
                    email.Length == 0
                        ? "unknown"
                        : email,
                    5,
                    15))
            {
                return null;
            }

            // ----------------------------------------------------
            // 2. IP RATE LIMIT
            // ----------------------------------------------------

            if (!await SltLoginThrottle
                .TryConsumeAsync(
                    "admin-ip",
                    clientIp ?? "unknown",
                    20,
                    15))
            {
                return null;
            }

            // ----------------------------------------------------
            // 3. INPUT VALIDATION
            // ----------------------------------------------------

            if (email.Length == 0 ||
                !ValidPasscode(passcode))
            {
                return null;
            }

            byte[] passcodeHash =
                HashPasscode(passcode);

            // ----------------------------------------------------
            // 4. SERIALIZABLE LOGIN TRANSACTION
            // ----------------------------------------------------

            using (var db = new SLTEntities())
            using (var transaction =
                db.Database.BeginTransaction(
                    IsolationLevel.Serializable))
            {
                // Lock row to prevent simultaneous
                // activation of the same passcode.

                var admin = await db.Admins
                    .SqlQuery(@"
SELECT *
FROM dbo.Admins WITH (UPDLOCK, HOLDLOCK)
WHERE Email = @email
  AND IsDeleted = 0
  AND IsActive = 1",
                        new SqlParameter(
                            "@email",
                            SqlDbType.NVarChar,
                            320)
                        {
                            Value = email
                        })
                    .FirstOrDefaultAsync();

                if (admin == null)
                    return null;

                // Capture a single UTC instant.
                // Convert before storing or comparing.

                DateTime nowUtc =
                    DateTime.UtcNow;

                DateTime nowEgypt =
                    EgyptDateTimeService
                        .FromUtc(nowUtc);

                // ------------------------------------------------
                // 5. ACCOUNT LOCKOUT
                // ------------------------------------------------

                if (admin.LockedUntil.HasValue &&
                    admin.LockedUntil.Value > nowEgypt)
                {
                    return null;
                }

                if (admin.LockedUntil.HasValue &&
                    admin.LockedUntil.Value <= nowEgypt)
                {
                    admin.LockedUntil = null;

                    admin.FailedLoginAttempts = 0;
                }

                // ------------------------------------------------
                // 6. ONE-TIME ACTIVATION
                // ------------------------------------------------

                if (admin.FirstLoginAt.HasValue)
                {
                    return null;
                }

                // ------------------------------------------------
                // 7. INVALID PASSCODE
                // ------------------------------------------------

                if (admin.PasscodeHash == null ||
                    !CryptographicOperationsEqual(
                        admin.PasscodeHash,
                        passcodeHash))
                {
                    admin.FailedLoginAttempts++;

                    if (admin.FailedLoginAttempts >=
                        MaxFailedAttempts)
                    {
                        admin.LockedUntil =
                            EgyptAfterMinutes(
                                nowUtc,
                                LockMinutes);

                        admin.FailedLoginAttempts = 0;
                    }

                    await db.SaveChangesAsync();

                    transaction.Commit();

                    return null;
                }

                // ------------------------------------------------
                // 8. SUCCESSFUL FIRST LOGIN
                // ------------------------------------------------

                string token =
                    GenerateToken();

                admin.FirstLoginAt =
                    nowEgypt;

                admin.SessionExpiresAt =
                    EgyptAfterDays(
                        nowUtc,
                        SessionDays);

                admin.SessionTokenHash =
                    HashToken(token);

                admin.FailedLoginAttempts = 0;

                admin.LockedUntil = null;

                await db.SaveChangesAsync();

                transaction.Commit();

                return new AdminLoginResult
                {
                    Token = token,

                    ExpiresAt =
                        admin.SessionExpiresAt.Value,

                    Admin = Map(admin)
                };
            }
        }

        // ========================================================
        // CONSTANT-TIME HASH COMPARISON
        //
        // Compatible with .NET Framework 4.7.
        // ========================================================

        private static bool CryptographicOperationsEqual(
            byte[] left,
            byte[] right)
        {
            if (left == null ||
                right == null ||
                left.Length != right.Length)
            {
                return false;
            }

            int difference = 0;

            for (int i = 0; i < left.Length; i++)
            {
                difference |= left[i] ^ right[i];
            }

            return difference == 0;
        }

        // ========================================================
        // GET CURRENT AUTHENTICATED ADMIN
        //
        // GET /api/admin-auth/me
        //
        // Compare session expiration using Egypt time.
        // ========================================================

        public async Task<AdminView>
            CurrentAsync(string token)
        {
            if (string.IsNullOrWhiteSpace(token) ||
                token.Length > 300)
            {
                return null;
            }

            byte[] tokenHash =
                HashToken(token);

            DateTime nowEgypt =
                EgyptNow;

            using (var db = new SLTEntities())
            {
                var admin = await db.Admins
                    .SqlQuery(@"
SELECT *
FROM dbo.Admins
WHERE SessionTokenHash = @hash
  AND IsActive = 1
  AND IsDeleted = 0
  AND SessionExpiresAt > @nowEgypt",
                        new SqlParameter(
                            "@hash",
                            SqlDbType.VarBinary,
                            32)
                        {
                            Value = tokenHash
                        },
                        new SqlParameter(
                            "@nowEgypt",
                            SqlDbType.DateTime2)
                        {
                            Value = nowEgypt
                        })
                    .FirstOrDefaultAsync();

                return Map(admin);
            }
        }
    }
}
