﻿
using System;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using SLTProject.Data;

namespace SLTProject.Services
{
    internal static class SltLoginThrottle
    {
        // ============================================
        // HASH IDENTIFIER
        // ============================================

        private static byte[] HashKey(string value)
        {
            using (var sha = SHA256.Create())
            {
                return sha.ComputeHash(
                    Encoding.UTF8.GetBytes(
                        value ?? "unknown"));
            }
        }

        // ============================================
        // CHECK TRANSIENT DATABASE CONFLICTS
        // ============================================

        private static bool IsRetryable(Exception ex)
        {
            while (ex != null)
            {
                var sql = ex as SqlException;

                if (sql != null)
                {
                    foreach (SqlError error in sql.Errors)
                    {
                        // Deadlock or duplicate insert
                        if (error.Number == 1205 ||
                            error.Number == 2601 ||
                            error.Number == 2627)
                        {
                            return true;
                        }
                    }
                }

                ex = ex.InnerException;
            }

            return false;
        }

        // ============================================
        // RATE LIMITER
        // ============================================

        public static async Task<bool> TryConsumeAsync(
            string scope,
            string identifier,
            int limit,
            int windowMinutes)
        {
            if (string.IsNullOrWhiteSpace(scope) ||
                scope.Length > 32 ||
                limit <= 0 ||
                windowMinutes <= 0)
            {
                throw new ArgumentException(
                    "Invalid rate limiter configuration.");
            }

            scope = scope.Trim();

            byte[] identifierHash =
                HashKey(identifier);

            // Retry transient concurrency conflicts.
            const int maxAttempts = 3;

            for (int attempt = 0;
                 attempt < maxAttempts;
                 attempt++)
            {
                try
                {
                    using (var db = new SLTEntities())
                    using (var transaction =
                        db.Database.BeginTransaction(
                            IsolationLevel.Serializable))
                    {
                        DateTime now = EgyptDateTimeService.Now;

                        // EF6 translates byte-array equality
                        // to a SQL binary-value comparison.
                        var record =
                            await db.SLTLoginRateLimits
                                .FirstOrDefaultAsync(x =>
                                    x.Scope == scope &&
                                    x.IdentifierHash ==
                                        identifierHash);

                        // ====================================
                        // FIRST REQUEST
                        // ====================================

                        if (record == null)
                        {
                            var newRecord =
                                new SLTLoginRateLimit
                                {
                                    Scope = scope,

                                    IdentifierHash =
                                        identifierHash,

                                    Attempts = 1,

                                    WindowExpiresAt =
                                        EgyptDateTimeService.AddMinutes(
                                            windowMinutes)
                                };

                            db.SLTLoginRateLimits.Add(
                                newRecord);

                            await db.SaveChangesAsync();

                            transaction.Commit();

                            return true;
                        }

                        // ====================================
                        // EXISTING WINDOW HAS EXPIRED
                        // ====================================

                        if (record.WindowExpiresAt <= now)
                        {
                            record.Attempts = 1;

                            record.WindowExpiresAt =
                                EgyptDateTimeService.AddMinutes(
                                    windowMinutes);

                            await db.SaveChangesAsync();

                            transaction.Commit();

                            return true;
                        }

                        // ====================================
                        // REQUEST LIMIT REACHED
                        // ====================================

                        if (record.Attempts >= limit)
                        {
                            transaction.Commit();

                            return false;
                        }

                        // ====================================
                        // CONSUME ONE REQUEST
                        // ====================================

                        record.Attempts++;

                        await db.SaveChangesAsync();

                        transaction.Commit();

                        return true;
                    }
                }
                catch (Exception ex)
                {
                    if (!IsRetryable(ex))
                        throw;

                    // Avoid unlimited retries.
                    if (attempt == maxAttempts - 1)
                    {
                        throw;
                    }

                    await Task.Delay(
                        50 * (attempt + 1));
                }
            }

            // Fail closed if a request cannot be
            // processed safely.
            return false;
        }
    }
}
