using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using SLTProject.Data;
using SLTProject.Models;
using SltPushIntegration;
using System.Net;
using System.Net.Http;

namespace SLTProject.Services
{
    public sealed class SltNotificationSendInput
    {
        public string TargetType { get; set; } // All or Guest
        public long? GuestId { get; set; }
        public string Title { get; set; }
        public string MessageText { get; set; } // Limited Markdown, no HTML
        public string ClickUrl { get; set; }
        public string IdempotencyKey { get; set; }
    }

    public sealed class SltNotificationPage
    {
        public object Items { get; set; }
        public int Total { get; set; }
        public int Page { get; set; }
        public int PageSize { get; set; }
        public int TotalPages { get; set; }
        public int UnreadCount { get; set; }
    }

    public sealed class SltNotificationsService
    {
        private static DateTime Now { get { return EgyptDateTimeService.Now; } }

        private static string PushText(string markdown)
        {
            // Push notifications are plain text. Rich formatting stays in the inbox.
            var text = Regex.Replace(markdown ?? "", @"\[([^\]]+)\]\(https?://[^)]+\)", "$1");
            text = Regex.Replace(text, @"(?m)^\s*[-*]\s+", "• ");
            text = text.Replace("**", "").Replace("__", "").Replace("*", "");
            text = Regex.Replace(text, @"\s+", " ").Trim();
            return text.Length > 500 ? text.Substring(0, 497) + "..." : text;
        }

        public async Task<object> SendAsync(SltNotificationSendInput input, long adminId, string adminEmail, CancellationToken ct)
        {
            if (input == null) throw new ArgumentException("Message is required.");
            var target = (input.TargetType ?? "").Trim();
            if (target.Equals("broadcast", StringComparison.OrdinalIgnoreCase)) target = "All";
            if (target.Equals("guest", StringComparison.OrdinalIgnoreCase)) target = "Guest";
            if (target.Equals("all", StringComparison.OrdinalIgnoreCase)) target = "All";
            if (target != "All" && target != "Guest") throw new ArgumentException("TargetType must be All or Guest.");
            if (target == "Guest" && (!input.GuestId.HasValue || input.GuestId.Value <= 0))
                throw new ArgumentException("Select a guest.");
            var title = (input.Title ?? "").Trim();
            var text = (input.MessageText ?? "").Trim();
            if (title.Length == 0 || title.Length > 120) throw new ArgumentException("Title must have 1–120 characters.");
            if (text.Length == 0 || text.Length > 4000) throw new ArgumentException("Message must have 1–4000 characters.");
            if (text.IndexOf('<') >= 0 || text.IndexOf('>') >= 0)
                throw new ArgumentException("HTML is not supported. Use the editor formatting controls.");
            var key = (input.IdempotencyKey ?? "").Trim();
            if (key.Length > 100) throw new ArgumentException("Idempotency key too long.");
            var url = (input.ClickUrl ?? "").Trim();
            if (url.Length > 500 || (url.Length > 0 && (!url.StartsWith("/", StringComparison.Ordinal) || url.StartsWith("//", StringComparison.Ordinal) || url.Contains("\\") || url.Contains("\r") || url.Contains("\n"))))
                throw new ArgumentException("Click URL must be a safe root-relative path.");

            // Save to SQL inbox before attempting external push. Database remains source of truth.
            List<long> guestIds;
            using (var main = new SLTEntities())
            {
                var guests = main.Guests.AsNoTracking().Where(g => !g.IsDeleted && g.FirstLoginAt.HasValue);
                if (target == "Guest")
                    guests = guests.Where(g => g.Id == input.GuestId.Value);
                guestIds = await guests.Select(g => g.Id).ToListAsync();
            }
            if (guestIds.Count == 0) throw new ArgumentException("No eligible guests found.");
            long id;
            using (var db = new SLTEntities())
            {
                // Key prevents accidental double-send; unique index handles concurrent submissions.
                if (key.Length > 0)
                {
                    var existing = await db.Set<SltNotification>().AsNoTracking()
                        .Where(n => n.IdempotencyKey == key)
                        .Select(n => new { n.Id, n.PushStatus }).FirstOrDefaultAsync();
                    if (existing != null) return new { NotificationId = existing.Id, RecipientCount = guestIds.Count, PushStatus = existing.PushStatus, Duplicate = true };
                }
                using (var tx = db.Database.BeginTransaction())
                {
                    var n = new SltNotification
                    {
                        Title = title,
                        MessageText = text,
                        TargetType = target,
                        TargetGuestId = target == "Guest" ? input.GuestId : null,
                        ClickUrl = url.Length == 0 ? null : url,
                        CreatedByAdminId = adminId,
                        CreatedByEmail = adminEmail,
                        CreatedAt = Now,
                        PushStatus = "Pending",
                        IdempotencyKey = key.Length == 0 ? null : key
                    };
                    db.Set<SltNotification>().Add(n);
                    await db.SaveChangesAsync();
                    foreach (var guestId in guestIds)
                        db.Set<SltNotificationRecipient>().Add(new SltNotificationRecipient { NotificationId = n.Id, GuestId = guestId, IsRead = false });
                    await db.SaveChangesAsync();
                    tx.Commit();
                    id = n.Id;
                }
            }

            var pushStatus = "NotConfigured";
            long? providerId = null;
            string pushError = null;
            try
            {
                var gateway = new GlobalPushV103Gateway();
                var dest = GlobalPushV103Gateway.GuestLaunchPath;
                if (!GlobalPushV103Gateway.ValidGuestUrl(url, dest)) throw new ArgumentException("Destination is outside the guest site.");
                var payload = new JObject
                {
                    ["targetType"] = target == "All" ? "broadcast" : "user",
                    ["title"] = title,
                    ["body"] = PushText(text),
                    ["url"] = url.Length == 0 ? dest : url,
                    ["idempotencyKey"] = key.Length == 0 ? "slt-inbox-" + id.ToString(CultureInfo.InvariantCulture) : key
                };
                if (target == "Guest")
                {
                    if (input.GuestId.Value > int.MaxValue) throw new InvalidOperationException("Guest identifier exceeds Global Push mapping limits.");
                    payload["userReference"] = GlobalPushV103Gateway.GuestUserReference((int)input.GuestId.Value);
                }
                var result = await gateway.SendAsync(HttpMethod.Post, "notifications", payload, ct);
                if (result.Status == HttpStatusCode.Accepted)
                {
                    pushStatus = "Queued";
                    providerId = (long?)result.Body["notificationId"];
                }
                else
                {
                    pushStatus = "Failed";
                    pushError = "Push gateway returned HTTP " + (int)result.Status;
                }
            }
            catch (Exception ex) when (ex is HttpRequestException || ex is TaskCanceledException || ex is InvalidOperationException || ex is UriFormatException || ex is ArgumentException)
            {
                pushStatus = "Failed";
                pushError = "Push delivery unavailable: " + ex.GetType().Name;
                System.Diagnostics.Trace.TraceWarning("SLT notification " + id + ": " + ex.GetType().Name);
            }
            // Never roll back inbox delivery if optional browser push is unavailable.
            using (var db = new SLTEntities())
            {
                var n = await db.Set<SltNotification>().FindAsync(id);
                if (n != null)
                {
                    n.PushStatus = pushStatus;
                    n.ProviderNotificationId = providerId;
                    n.PushError = pushError;
                    await db.SaveChangesAsync();
                }
            }
            return new { NotificationId = id, RecipientCount = guestIds.Count, PushStatus = pushStatus, ProviderNotificationId = providerId, Duplicate = false };
        }

        public async Task<SltNotificationPage> GuestInboxAsync(long guestId, int page, int pageSize, bool unreadOnly)
        {
            page = Math.Max(1, page); pageSize = Math.Max(1, Math.Min(100, pageSize));
            using (var db = new SLTEntities())
            {
                var baseQuery = db.Set<SltNotificationRecipient>().AsNoTracking().Where(r => r.GuestId == guestId);
                var unread = await baseQuery.CountAsync(r => !r.IsRead);
                var query = from r in baseQuery
                            join n in db.Set<SltNotification>().AsNoTracking() on r.NotificationId equals n.Id
                            where !unreadOnly || !r.IsRead
                            select new { r.IsRead, r.ReadAt, n.Title, n.MessageText, n.CreatedAt, n.ClickUrl, n.CreatedByEmail, n.Id, n.TargetType };
                var total = await query.CountAsync();
                var items = await query.OrderByDescending(x => x.Id).Skip((page - 1) * pageSize).Take(pageSize)
                    .ToListAsync();
                return new SltNotificationPage
                {
                    Items = items.Select(x => new { NotificationId = x.Id, x.Title, x.MessageText, x.CreatedAt, x.ClickUrl, x.IsRead, x.ReadAt, x.CreatedByEmail, x.TargetType }).ToList(),
                    Page = page,
                    PageSize = pageSize,
                    Total = total,
                    TotalPages = (total + pageSize - 1) / pageSize,
                    UnreadCount = unread
                };
            }
        }

        public async Task<bool> MarkGuestReadAsync(long guestId, long notificationId)
        {
            using (var db = new SLTEntities())
            {
                var row = await db.Set<SltNotificationRecipient>().FirstOrDefaultAsync(x => x.GuestId == guestId && x.NotificationId == notificationId);
                if (row == null) return false;
                if (!row.IsRead) { row.IsRead = true; row.ReadAt = Now; await db.SaveChangesAsync(); }
                return true;
            }
        }

        public async Task<SltNotificationPage> AdminOutboxAsync(long adminId, int page, int pageSize, bool unreadOnly)
        {
            page = Math.Max(1, page); pageSize = Math.Max(1, Math.Min(100, pageSize));
            using (var db = new SLTEntities())
            {
                var readIds = db.Set<SltNotificationAdminRead>().AsNoTracking().Where(r => r.AdminId == adminId).Select(r => r.NotificationId);
                var all = db.Set<SltNotification>().AsNoTracking();
                var unread = await all.CountAsync(n => !readIds.Contains(n.Id));
                var query = all.Where(n => !unreadOnly || !readIds.Contains(n.Id));
                var total = await query.CountAsync();
                var items = await query.OrderByDescending(n => n.Id).Skip((page - 1) * pageSize).Take(pageSize)
                    .Select(n => new {
                        n.Id,
                        n.Title,
                        n.MessageText,
                        n.CreatedAt,
                        n.TargetType,
                        n.TargetGuestId,
                        n.CreatedByEmail,
                        n.PushStatus,
                        n.ProviderNotificationId,
                        n.ClickUrl,
                        IsRead = readIds.Contains(n.Id)
                    }).ToListAsync();
                var ids = items.Select(x => x.Id).ToArray();
                var counts = await db.Set<SltNotificationRecipient>().AsNoTracking().Where(x => ids.Contains(x.NotificationId))
                    .GroupBy(x => x.NotificationId).Select(g => new { Id = g.Key, Count = g.Count(), Read = g.Count(r => r.IsRead) }).ToListAsync();
                return new SltNotificationPage
                {
                    Items = items.Select(x => new {
                        NotificationId = x.Id,
                        x.Title,
                        x.MessageText,
                        x.CreatedAt,
                        x.TargetType,
                        x.TargetGuestId,
                        x.CreatedByEmail,
                        x.PushStatus,
                        x.ProviderNotificationId,
                        x.ClickUrl,
                        x.IsRead,
                        RecipientCount = counts.Where(c => c.Id == x.Id).Select(c => c.Count).FirstOrDefault(),
                        GuestReadCount = counts.Where(c => c.Id == x.Id).Select(c => c.Read).FirstOrDefault()
                    }).ToList(),
                    Page = page,
                    PageSize = pageSize,
                    Total = total,
                    TotalPages = (total + pageSize - 1) / pageSize,
                    UnreadCount = unread
                };
            }
        }

        public async Task<bool> MarkAdminReadAsync(long adminId, long notificationId)
        {
            using (var db = new SLTEntities())
            {
                if (!await db.Set<SltNotification>().AnyAsync(n => n.Id == notificationId)) return false;
                if (!await db.Set<SltNotificationAdminRead>().AnyAsync(r => r.NotificationId == notificationId && r.AdminId == adminId))
                {
                    db.Set<SltNotificationAdminRead>().Add(new SltNotificationAdminRead { AdminId = adminId, NotificationId = notificationId, ReadAt = Now });
                    try { await db.SaveChangesAsync(); }
                    catch (System.Data.Entity.Infrastructure.DbUpdateException)
                    {
                        // Another tab may have marked this item read concurrently.
                        if (!await db.Set<SltNotificationAdminRead>().AsNoTracking().AnyAsync(r => r.NotificationId == notificationId && r.AdminId == adminId)) throw;
                    }
                }
                return true;
            }
        }

        public async Task<object> GuestsForTargetAsync(string search)
        {
            using (var db = new SLTEntities())
            {
                var query = db.Guests.AsNoTracking().Where(g => !g.IsDeleted && g.FirstLoginAt.HasValue);
                var term = (search ?? "").Trim();
                if (term.Length > 0) query = query.Where(g => g.FullName.Contains(term) || g.Email.Contains(term));
                return await query.OrderBy(g => g.FullName).Take(50)
                    .Select(g => new { g.Id, g.FullName, g.Email, Registered = g.FirstLoginAt.HasValue }).ToListAsync();
            }
        }
    }
}
