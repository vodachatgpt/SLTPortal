
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Threading.Tasks;
using SLTProject.Data;
using SLTProject.Models.Dtos;

namespace SLTProject.Services
{
    public class AirportTransfersService
    {
        private const int MaximumExcelRows = 10000;

        // ====================================================
        // EGYPT LOCAL TIME
        // ====================================================

        private static DateTime NowEgypt
        {
            get
            {
                return EgyptDateTimeService.Now;
            }
        }

        // ====================================================
        // EMAIL VALIDATION
        // ====================================================

        private static string Email(string email)
        {
            email = ScheduleTransportExcel.Limit(
                email,
                320,
                "Email",
                true).ToLowerInvariant();

            try
            {
                var address = new MailAddress(email);

                if (!string.Equals(
                    address.Address,
                    email,
                    StringComparison.OrdinalIgnoreCase))
                {
                    throw new ArgumentException(
                        "Invalid guest email.");
                }
            }
            catch (FormatException)
            {
                throw new ArgumentException(
                    "Invalid guest email.");
            }

            return email;
        }

        // ====================================================
        // TRANSFER TYPE VALIDATION
        // ====================================================

        private static string Type(string type)
        {
            type = ScheduleTransportExcel.Limit(
                type,
                20,
                "Type",
                true);

            if (type.Equals(
                "pickup",
                StringComparison.OrdinalIgnoreCase))
            {
                return "Pickup";
            }

            if (type.Equals(
                "drop-off",
                StringComparison.OrdinalIgnoreCase))
            {
                return "Drop-off";
            }

            throw new ArgumentException(
                "Type must be Pickup or Drop-off.");
        }

        // ====================================================
        // INPUT VALIDATION
        // ====================================================

        private static void Validate(
            AirportTransferInput input)
        {
            if (input == null)
            {
                throw new ArgumentException(
                    "Transfer data is required.");
            }

            Email(input.Email);
            Type(input.Type);

            if (input.Date == default(DateTime))
            {
                throw new ArgumentException(
                    "Transfer date is required.");
            }

            // SQL datetime compatibility.
            if (input.Date.Date <
                new DateTime(1753, 1, 1))
            {
                throw new ArgumentException(
                    "Transfer date is invalid.");
            }

            ScheduleTransportExcel.Limit(
                input.DriverName,
                250,
                "DriverName",
                true);

            ScheduleTransportExcel.Limit(
                input.DriverPhone,
                50,
                "DriverPhone",
                true);
        }

        // ====================================================
        // APPLY INPUT TO ENTITY
        // ====================================================

        private static void Apply(
            AirportTransfer entity,
            AirportTransferInput input)
        {
            entity.Email = Email(input.Email);

            entity.Type = Type(input.Type);

            // Preserve administrator-selected calendar date.
            // No UTC conversion is applied.
            entity.Date = input.Date.Date;

            entity.DriverName =
                input.DriverName.Trim();

            entity.DriverPhone =
                input.DriverPhone.Trim();

            entity.WhatsApp = input.WhatsApp;
        }

        // ====================================================
        // ENTITY TO DTO MAPPING
        // ====================================================

        public static AirportTransferDto Map(
            AirportTransfer entity)
        {
            if (entity == null)
                return null;

            return new AirportTransferDto
            {
                Id = entity.Id,

                Email = entity.Email,

                Type = entity.Type,

                Date = entity.Date,

                DriverName =
                    entity.DriverName,

                DriverPhone =
                    entity.DriverPhone,

                WhatsApp =
                    entity.WhatsApp,

                CreatedAt =
                    entity.CreatedAt,

                CreatedBy =
                    entity.CreatedBy,

                ModifiedAt =
                    entity.ModifiedAt,

                ModifiedBy =
                    entity.ModifiedBy,

                IsDeleted =
                    entity.IsDeleted,

                DeletedAt =
                    entity.DeletedAt,

                DeletedBy =
                    entity.DeletedBy,

                RetentionDateCreated =
                    entity.RetentionDateCreated,

                RetentionDateModified =
                    entity.RetentionDateModified
            };
        }

        // ====================================================
        // VERIFY GUEST EXISTS
        // ====================================================

        private static async Task CheckGuest(
            SLTEntities db,
            string email)
        {
            bool exists = await db.Guests
                .AsNoTracking()
                .AnyAsync(x =>
                    x.Email == email &&
                    !x.IsDeleted);

            if (!exists)
            {
                throw new ArgumentException(
                    "Guest email does not exist: " +
                    email);
            }
        }

        // ====================================================
        // GET ALL
        //
        // No pagination.
        // Optional guest email filter.
        // ====================================================

        public async Task<List<AirportTransferDto>>
            GetAllAsync(string email = null)
        {
            using (var db = new SLTEntities())
            {
                var query = db.AirportTransfers
                    .AsNoTracking()
                    .Where(x => !x.IsDeleted);

                if (!string.IsNullOrWhiteSpace(email))
                {
                    string normalized = Email(email);

                    query = query.Where(
                        x => x.Email == normalized);
                }

                var records = await query
                    .OrderBy(x => x.Date)
                    .ThenBy(x => x.Email)
                    .ThenBy(x => x.Type)
                    .ThenBy(x => x.Id)
                    .ToListAsync();

                return records
                    .Select(Map)
                    .ToList();
            }
        }

        // ====================================================
        // GET BY ID
        // ====================================================

        public async Task<AirportTransferDto>
            GetAsync(long id)
        {
            if (id <= 0)
                return null;

            using (var db = new SLTEntities())
            {
                var entity = await db.AirportTransfers
                    .AsNoTracking()
                    .FirstOrDefaultAsync(x =>
                        x.Id == id &&
                        !x.IsDeleted);

                return Map(entity);
            }
        }

        // ====================================================
        // CREATE AIRPORT TRANSFER
        // ====================================================

        public async Task<AirportTransferDto>
            CreateAsync(
                AirportTransferInput input,
                string actor)
        {
            Validate(input);

            string email = Email(input.Email);
            string type = Type(input.Type);

            using (var db = new SLTEntities())
            {
                await CheckGuest(db, email);

                bool duplicate =
                    await db.AirportTransfers
                        .AnyAsync(x =>
                            !x.IsDeleted &&
                            x.Email == email &&
                            x.Type == type);

                if (duplicate)
                {
                    throw new ArgumentException(
                        "An active " + type +
                        " transfer already exists " +
                        "for this email.");
                }

                DateTime nowEgypt = NowEgypt;

                var entity = new AirportTransfer
                {
                    CreatedAt = nowEgypt,

                    CreatedBy = actor,

                    RetentionDateCreated =
                        nowEgypt,

                    IsDeleted = false
                };

                Apply(entity, input);

                db.AirportTransfers.Add(entity);

                await db.SaveChangesAsync();

                return Map(entity);
            }
        }

        // ====================================================
        // UPDATE AIRPORT TRANSFER
        // ====================================================

        public async Task<AirportTransferDto>
            UpdateAsync(
                long id,
                AirportTransferInput input,
                string actor)
        {
            if (id <= 0)
                return null;

            Validate(input);

            string email = Email(input.Email);
            string type = Type(input.Type);

            using (var db = new SLTEntities())
            {
                var entity =
                    await db.AirportTransfers
                        .FirstOrDefaultAsync(x =>
                            x.Id == id &&
                            !x.IsDeleted);

                if (entity == null)
                    return null;

                await CheckGuest(db, email);

                bool duplicate =
                    await db.AirportTransfers
                        .AnyAsync(x =>
                            x.Id != id &&
                            !x.IsDeleted &&
                            x.Email == email &&
                            x.Type == type);

                if (duplicate)
                {
                    throw new ArgumentException(
                        "An active transfer with this " +
                        "Email + Type already exists.");
                }

                Apply(entity, input);

                DateTime nowEgypt = NowEgypt;

                entity.ModifiedAt = nowEgypt;

                entity.ModifiedBy = actor;

                entity.RetentionDateModified =
                    nowEgypt;

                await db.SaveChangesAsync();

                return Map(entity);
            }
        }

        // ====================================================
        // SOFT DELETE AIRPORT TRANSFER
        // ====================================================

        public async Task<bool> DeleteAsync(
            long id,
            string actor)
        {
            if (id <= 0)
                return false;

            using (var db = new SLTEntities())
            {
                var entity =
                    await db.AirportTransfers
                        .FirstOrDefaultAsync(x =>
                            x.Id == id &&
                            !x.IsDeleted);

                if (entity == null)
                    return false;

                DateTime nowEgypt = NowEgypt;

                entity.IsDeleted = true;

                entity.DeletedAt = nowEgypt;

                entity.DeletedBy = actor;

                entity.ModifiedAt = nowEgypt;

                entity.ModifiedBy = actor;

                entity.RetentionDateModified =
                    nowEgypt;

                await db.SaveChangesAsync();

                return true;
            }
        }

        // ====================================================
        // EXCEL TEMPLATE
        //
        // Keep existing column names and order.
        // ====================================================

        public byte[] GetTemplate()
        {
            return ScheduleTransportExcel.Template(
                "Email",
                "Type",
                "Date",
                "DriverName",
                "DriverPhone",
                "WhatsApp");
        }

        // ====================================================
        // IMPORT EXCEL
        //
        // Rules:
        // - Maximum 10,000 data rows
        // - Email + Type identifies a transfer
        // - Existing record is updated
        // - Blank cells preserve existing values
        // - Duplicate keys in file are rejected
        // - Any row error rolls back the entire upload
        // - All audit timestamps use Egypt local time
        // ====================================================

        public async Task<ExcelImportResult>
            ImportAsync(
                Stream stream,
                string actor)
        {
            if (stream == null ||
                !stream.CanRead)
            {
                throw new ArgumentException(
                    "A valid Excel file stream is required.");
            }

            var report = new ExcelImportResult();

            using (var workbook =
                ScheduleTransportExcel.Open(stream))
            {
                var sheet = workbook.Worksheet(1);

                var headers =
                    ScheduleTransportExcel.Headers(sheet);

                ScheduleTransportExcel.Require(
                    headers,
                    "Email",
                    "Type",
                    "Date",
                    "DriverName",
                    "DriverPhone",
                    "WhatsApp");

                var lastRow = sheet.LastRowUsed();

                if (lastRow == null ||
                    lastRow.RowNumber() < 2)
                {
                    return report;
                }

                if (lastRow.RowNumber() - 1 >
                    MaximumExcelRows)
                {
                    throw new ArgumentException(
                        "Maximum 10000 data rows " +
                        "per Excel upload.");
                }

                var seen =
                    new HashSet<string>(
                        StringComparer.OrdinalIgnoreCase);

                using (var db = new SLTEntities())
                using (var transaction =
                    db.Database.BeginTransaction())
                {
                    // One timestamp for the entire import.
                    DateTime nowEgypt = NowEgypt;

                    for (
                        int rowNumber = 2;
                        rowNumber <= lastRow.RowNumber();
                        rowNumber++)
                    {
                        var row = sheet.Row(rowNumber);

                        if (ScheduleTransportExcel.Empty(
                            row,
                            headers))
                        {
                            report.Skipped++;
                            continue;
                        }

                        try
                        {
                            // --------------------------------
                            // 1. READ IDENTIFIER
                            // --------------------------------

                            string email = Email(
                                ScheduleTransportExcel.Text(
                                    row,
                                    headers,
                                    "Email"));

                            string type = Type(
                                ScheduleTransportExcel.Text(
                                    row,
                                    headers,
                                    "Type"));

                            string key =
                                email + "|" + type;

                            if (!seen.Add(key))
                            {
                                throw new ArgumentException(
                                    "Duplicate Email + Type " +
                                    "in the Excel file.");
                            }

                            // --------------------------------
                            // 2. VALIDATE GUEST
                            // --------------------------------

                            await CheckGuest(
                                db,
                                email);

                            // --------------------------------
                            // 3. FIND EXISTING TRANSFER
                            // --------------------------------

                            var entity =
                                await db.AirportTransfers
                                    .FirstOrDefaultAsync(x =>
                                        !x.IsDeleted &&
                                        x.Email == email &&
                                        x.Type == type);

                            // --------------------------------
                            // 4. READ EXCEL VALUES
                            // --------------------------------

                            string dateText =
                                ScheduleTransportExcel.Text(
                                    row,
                                    headers,
                                    "Date");

                            string driverName =
                                ScheduleTransportExcel.Text(
                                    row,
                                    headers,
                                    "DriverName");

                            string driverPhone =
                                ScheduleTransportExcel.Text(
                                    row,
                                    headers,
                                    "DriverPhone");

                            string whatsAppText =
                                ScheduleTransportExcel.Text(
                                    row,
                                    headers,
                                    "WhatsApp");

                            // --------------------------------
                            // 5. PRESERVE EXISTING VALUES
                            //    WHEN CELLS ARE BLANK
                            // --------------------------------

                            var input =
                                new AirportTransferInput
                                {
                                    Email = email,

                                    Type = type,

                                    Date =
                                        dateText.Length > 0
                                        ? ScheduleTransportExcel.Date(
                                            dateText,
                                            "Date")
                                        : entity == null
                                            ? default(DateTime)
                                            : entity.Date,

                                    DriverName =
                                        driverName.Length > 0
                                        ? driverName
                                        : entity == null
                                            ? null
                                            : entity.DriverName,

                                    DriverPhone =
                                        driverPhone.Length > 0
                                        ? driverPhone
                                        : entity == null
                                            ? null
                                            : entity.DriverPhone,

                                    WhatsApp =
                                        whatsAppText.Length > 0
                                        ? ScheduleTransportExcel.Bool(
                                            whatsAppText,
                                            "WhatsApp")
                                        : entity != null &&
                                          entity.WhatsApp
                                };

                            // --------------------------------
                            // 6. VALIDATE MERGED RECORD
                            // --------------------------------

                            Validate(input);

                            // --------------------------------
                            // 7. CREATE OR UPDATE
                            // --------------------------------

                            if (entity == null)
                            {
                                entity = new AirportTransfer
                                {
                                    CreatedAt = nowEgypt,

                                    CreatedBy = actor,

                                    RetentionDateCreated =
                                        nowEgypt,

                                    IsDeleted = false
                                };

                                Apply(entity, input);

                                db.AirportTransfers.Add(entity);

                                report.Inserted++;
                            }
                            else
                            {
                                Apply(entity, input);

                                entity.ModifiedAt =
                                    nowEgypt;

                                entity.ModifiedBy =
                                    actor;

                                entity.RetentionDateModified =
                                    nowEgypt;

                                report.Updated++;
                            }
                        }
                        catch (Exception ex)
                            when (
                                ex is ArgumentException ||
                                ex is FormatException ||
                                ex is OverflowException)
                        {
                            report.Errors.Add(
                                "Row " +
                                rowNumber +
                                ": " +
                                ex.Message);
                        }
                    }

                    // ----------------------------------------
                    // 8. ROLLBACK IF ANY ROW FAILED
                    // ----------------------------------------

                    if (report.Errors.Count > 0)
                    {
                        transaction.Rollback();

                        report.Inserted = 0;
                        report.Updated = 0;

                        return report;
                    }

                    // ----------------------------------------
                    // 9. SAVE ALL RECORDS AT ONCE
                    // ----------------------------------------

                    await db.SaveChangesAsync();

                    transaction.Commit();
                }
            }

            return report;
        }
        // ============================================================
        // ADMIN TABLE: DATABASE-SIDE PAGING AND FILTERED XLSX EXPORT
        // The public unpaged GetAllAsync API remains unchanged.
        // ============================================================
        public Task<SltTablePage<AirportTransferDto>> GetPagedAsync(SltTableQuery filter)
        {
            return SltTableDataService.TransfersAsync(filter ?? new SltTableQuery());
        }

        public Task<byte[]> ExportFilteredAsync(SltTableQuery filter)
        {
            return SltTableDataService.ExportXlsxAsync<AirportTransferDto>(
                f => SltTableDataService.TransfersAsync(f),
                filter ?? new SltTableQuery(),
                new[] { "Id", "Email", "Type", "Date", "DriverName", "DriverPhone", "WhatsApp" });
        }

    }
}
