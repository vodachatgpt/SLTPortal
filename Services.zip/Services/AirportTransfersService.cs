
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Threading.Tasks;
using SLTProject.Data;
using SLTProject.Models.Dtos;

namespace SLTProject.Services
{
    public class AirportTransfersService
    {
        private const int MaximumExcelRows = 10000;

        // ====================================================
        // EGYPT LOCAL TIME
        // ====================================================

        private static DateTime NowEgypt
        {
            get
            {
                return EgyptDateTimeService.Now;
            }
        }

        // ====================================================
        // EMAIL VALIDATION
        // ====================================================

        private static string Email(string email)
        {
            email = ScheduleTransportExcel.Limit(
                email,
                320,
                "Email",
                true).ToLowerInvariant();

            try
            {
                var address = new MailAddress(email);

                if (!string.Equals(
                    address.Address,
                    email,
                    StringComparison.OrdinalIgnoreCase))
                {
                    throw new ArgumentException(
                        "Invalid guest email.");
                }
            }
            catch (FormatException)
            {
                throw new ArgumentException(
                    "Invalid guest email.");
            }

            return email;
        }

        // ====================================================
        // TRANSFER TYPE VALIDATION
        // ====================================================

        private static string Type(string type)
        {
            type = ScheduleTransportExcel.Limit(
                type,
                20,
                "Type",
                true);

            if (type.Equals(
                "pickup",
                StringComparison.OrdinalIgnoreCase))
            {
                return "Pickup";
            }

            if (type.Equals(
                "drop-off",
                StringComparison.OrdinalIgnoreCase))
            {
                return "Drop-off";
            }

            throw new ArgumentException(
                "Type must be Pickup or Drop-off.");
        }

        // ====================================================
        // INPUT VALIDATION
        // ====================================================

        private static void Validate(
            AirportTransferInput input)
        {
            if (input == null)
            {
                throw new ArgumentException(
                    "Transfer data is required.");
            }

            Email(input.Email);
            Type(input.Type);

            if (input.Date == default(DateTime))
            {
                throw new ArgumentException(
                    "Transfer date is required.");
            }

            // SQL datetime compatibility.
            if (input.Date.Date <
                new DateTime(1753, 1, 1))
            {
                throw new ArgumentException(
                    "Transfer date is invalid.");
            }

            ScheduleTransportExcel.Limit(
                input.DriverName,
                250,
                "DriverName",
                true);

            ScheduleTransportExcel.Limit(
                input.DriverPhone,
                50,
                "DriverPhone",
                true);
        }

        // ====================================================
        // APPLY INPUT TO ENTITY
        // ====================================================

        private static void Apply(
            AirportTransfer entity,
            AirportTransferInput input)
        {
            entity.Email = Email(input.Email);

            entity.Type = Type(input.Type);

            // Preserve administrator-selected calendar date.
            // No UTC conversion is applied.
            entity.Date = input.Date.Date;

            entity.DriverName =
                input.DriverName.Trim();

            entity.DriverPhone =
                input.DriverPhone.Trim();

            entity.WhatsApp = input.WhatsApp;
        }

        // ====================================================
        // ENTITY TO DTO MAPPING
        // ====================================================

        public static AirportTransferDto Map(
            AirportTransfer entity)
        {
            if (entity == null)
                return null;

            return new AirportTransferDto
            {
                Id = entity.Id,

                Email = entity.Email,

                Type = entity.Type,

                Date = entity.Date,

                DriverName =
                    entity.DriverName,

                DriverPhone =
                    entity.DriverPhone,

                WhatsApp =
                    entity.WhatsApp,

                CreatedAt =
                    entity.CreatedAt,

                CreatedBy =
                    entity.CreatedBy,

                ModifiedAt =
                    entity.ModifiedAt,

                ModifiedBy =
                    entity.ModifiedBy,

                IsDeleted =
                    entity.IsDeleted,

                DeletedAt =
                    entity.DeletedAt,

                DeletedBy =
                    entity.DeletedBy,

                RetentionDateCreated =
                    entity.RetentionDateCreated,

                RetentionDateModified =
                    entity.RetentionDateModified
            };
        }

        // ====================================================
        // VERIFY GUEST EXISTS
        // ====================================================

        private static async Task CheckGuest(
            SLTEntities db,
            string email)
        {
            bool exists = await db.Guests
                .AsNoTracking()
                .AnyAsync(x =>
                    x.Email == email &&
                    !x.IsDeleted);

            if (!exists)
            {
                throw new ArgumentException(
                    "Guest email does not exist: " +
                    email);
            }
        }

        // ====================================================
        // GET ALL
        //
        // No pagination.
        // Optional guest email filter.
        // ====================================================

        public async Task<List<AirportTransferDto>>
            GetAllAsync(string email = null)
        {
            using (var db = new SLTEntities())
            {
                var query = db.AirportTransfers
                    .AsNoTracking()
                    .Where(x => !x.IsDeleted);

                if (!string.IsNullOrWhiteSpace(email))
                {
                    string normalized = Email(email);

                    query = query.Where(
                        x => x.Email == normalized);
                }

                var records = await query
                    .OrderBy(x => x.Date)
                    .ThenBy(x => x.Email)
                    .ThenBy(x => x.Type)
                    .ThenBy(x => x.Id)
                    .ToListAsync();

                return records
                    .Select(Map)
                    .ToList();
            }
        }

        // ====================================================
        // GET BY ID
        // ====================================================

        public async Task<AirportTransferDto>
            GetAsync(long id)
        {
            if (id <= 0)
                return null;

            using (var db = new SLTEntities())
            {
                var entity = await db.AirportTransfers
                    .AsNoTracking()
                    .FirstOrDefaultAsync(x =>
                        x.Id == id &&
                        !x.IsDeleted);

                return Map(entity);
            }
        }

        // ====================================================
        // CREATE AIRPORT TRANSFER
        // ====================================================

        public async Task<AirportTransferDto>
            CreateAsync(
                AirportTransferInput input,
                string actor)
        {
            Validate(input);

            string email = Email(input.Email);
            string type = Type(input.Type);

            using (var db = new SLTEntities())
            {
                await CheckGuest(db, email);

                bool duplicate =
                    await db.AirportTransfers
                        .AnyAsync(x =>
                            !x.IsDeleted &&
                            x.Email == email &&
                            x.Type == type);

                if (duplicate)
                {
                    throw new ArgumentException(
                        "An active " + type +
                        " transfer already exists " +
                        "for this email.");
                }

                DateTime nowEgypt = NowEgypt;

                var entity = new AirportTransfer
                {
                    CreatedAt = nowEgypt,

                    CreatedBy = actor,

                    RetentionDateCreated =
                        nowEgypt,

                    IsDeleted = false
                };

                Apply(entity, input);

                db.AirportTransfers.Add(entity);

                await db.SaveChangesAsync();

                return Map(entity);
            }
        }

        // ====================================================
        // UPDATE AIRPORT TRANSFER
        // ====================================================

        public async Task<AirportTransferDto>
            UpdateAsync(
                long id,
                AirportTransferInput input,
                string actor)
        {
            if (id <= 0)
                return null;

            Validate(input);

            string email = Email(input.Email);
            string type = Type(input.Type);

            using (var db = new SLTEntities())
            {
                var entity =
                    await db.AirportTransfers
                        .FirstOrDefaultAsync(x =>
                            x.Id == id &&
                            !x.IsDeleted);

                if (entity == null)
                    return null;

                await CheckGuest(db, email);

                bool duplicate =
                    await db.AirportTransfers
                        .AnyAsync(x =>
                            x.Id != id &&
                            !x.IsDeleted &&
                            x.Email == email &&
                            x.Type == type);

                if (duplicate)
                {
                    throw new ArgumentException(
                        "An active transfer with this " +
                        "Email + Type already exists.");
                }

                Apply(entity, input);

                DateTime nowEgypt = NowEgypt;

                entity.ModifiedAt = nowEgypt;

                entity.ModifiedBy = actor;

                entity.RetentionDateModified =
                    nowEgypt;

                await db.SaveChangesAsync();

                return Map(entity);
            }
        }

        // ====================================================
        // SOFT DELETE AIRPORT TRANSFER
        // ====================================================

        public async Task<bool> DeleteAsync(
            long id,
            string actor)
        {
            if (id <= 0)
                return false;

            using (var db = new SLTEntities())
            {
                var entity =
                    await db.AirportTransfers
                        .FirstOrDefaultAsync(x =>
                            x.Id == id &&
                            !x.IsDeleted);

                if (entity == null)
                    return false;

                DateTime nowEgypt = NowEgypt;

                entity.IsDeleted = true;

                entity.DeletedAt = nowEgypt;

                entity.DeletedBy = actor;

                entity.ModifiedAt = nowEgypt;

                entity.ModifiedBy = actor;

                entity.RetentionDateModified =
                    nowEgypt;

                await db.SaveChangesAsync();

                return true;
            }
        }

        // ====================================================
        // EXCEL TEMPLATE
        //
        // Keep existing column names and order.
        // ====================================================

        public byte[] GetTemplate()
        {
            return ScheduleTransportExcel.Template(
                "Email",
                "Type",
                "Date",
                "DriverName",
                "DriverPhone",
                "WhatsApp",
                "NotificationMode",
                "NotificationChannels");
        }

        // ====================================================
        // GUEST-STYLE EXCEL IMPORT
        // UpdateOnly / Upsert / ReplaceAll
        // Email + Type = natural key. Blank cells preserve data.
        // ReplaceAll is atomic: prevalidate EVERY row before soft delete.
        // ====================================================

        private sealed class PreparedTransfer
        {
            public int RowNumber { get; set; }
            public AirportTransferInput Input { get; set; }
        }

        public Task<ExcelImportResult> ImportAsync(Stream stream, string actor)
        {
            // Backward compatibility with existing callers.
            return ImportAsync(stream, actor, "Upsert");
        }

        public async Task<ExcelImportResult> ImportAsync(
            Stream stream, string actor, string mode)
        {
            mode = ScheduleTransportExcel.NormalizeImportMode(mode);

            if (stream == null || !stream.CanRead)
                throw new ArgumentException("A valid Excel file stream is required.");

            var report = new ExcelImportResult { Mode = mode };

            using (var workbook = ScheduleTransportExcel.Open(stream))
            {
                var sheet = workbook.Worksheet(1);
                var headers = ScheduleTransportExcel.Headers(sheet);

                // Partial update requires ONLY its natural key columns;
                // missing optional columns preserve existing values.
                ScheduleTransportExcel.Require(headers, "Email", "Type");

                var last = sheet.LastRowUsed();
                if (last == null || last.RowNumber() < 2)
                    return report;

                if (last.RowNumber() - 1 > MaximumExcelRows)
                    throw new ArgumentException("Maximum 10000 data rows per Excel upload.");

                report.TotalRows = last.RowNumber() - 1;
                var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

                using (var db = new SLTEntities())
                {
                    var prepared = new List<PreparedTransfer>();

                    for (int rowNumber = 2; rowNumber <= last.RowNumber(); rowNumber++)
                    {
                        var row = sheet.Row(rowNumber);
                        if (ScheduleTransportExcel.Empty(row, headers))
                        {
                            report.Skipped++;
                            continue;
                        }

                        string emailText = ScheduleTransportExcel.Text(row, headers, "Email");
                        string typeText = ScheduleTransportExcel.Text(row, headers, "Type");

                        try
                        {
                            string email = Email(emailText);
                            string type = Type(typeText);
                            string key = email + "|" + type;

                            if (!seen.Add(key))
                                throw new ArgumentException(
                                    "Duplicate Email + Type in Excel file.");

                            await CheckGuest(db, email);

                            AirportTransfer entity = null;
                            if (mode != "ReplaceAll")
                            {
                                entity = await db.AirportTransfers
                                    .AsNoTracking()
                                    .FirstOrDefaultAsync(x =>
                                        !x.IsDeleted && x.Email == email && x.Type == type);
                            }

                            if (mode == "UpdateOnly" && entity == null)
                                throw new ArgumentException(
                                    "No active transfer exists for Email + Type (UpdateOnly). ");

                            string dateText = ScheduleTransportExcel.Text(row, headers, "Date");
                            string nameText = ScheduleTransportExcel.Text(row, headers, "DriverName");
                            string phoneText = ScheduleTransportExcel.Text(row, headers, "DriverPhone");
                            string whatsappText = ScheduleTransportExcel.Text(row, headers, "WhatsApp");

                            var input = new AirportTransferInput
                            {
                                Email = email,
                                Type = type,
                                Date = dateText.Length > 0
                                    ? ScheduleTransportExcel.Date(dateText, "Date")
                                    : (entity == null ? default(DateTime) : entity.Date),
                                DriverName = nameText.Length > 0
                                    ? nameText : (entity == null ? null : entity.DriverName),
                                DriverPhone = phoneText.Length > 0
                                    ? phoneText : (entity == null ? null : entity.DriverPhone),
                                WhatsApp = whatsappText.Length > 0
                                    ? ScheduleTransportExcel.Bool(whatsappText, "WhatsApp")
                                    : (entity != null && entity.WhatsApp)
                            };

                            Validate(input);
                            prepared.Add(new PreparedTransfer
                            {
                                RowNumber = rowNumber,
                                Input = input
                            });
                        }
                        catch (Exception ex)
                        {
                            string column = ScheduleTransportExcel.ErrorColumn(
                                ex.Message, headers.Keys);
                            string value = ScheduleTransportExcel.ErrorValue(row, headers, column);
                            if (column == "Email" && string.IsNullOrWhiteSpace(value))
                                value = emailText;
                            else if (column == "Type" && string.IsNullOrWhiteSpace(value))
                                value = typeText;
                            report.AddError(rowNumber, column, value, ex.Message);
                        }
                    }

                    if (mode == "ReplaceAll")
                    {
                        // Never modify active data on a partially invalid upload.
                        // This prevents silent loss of unrelated airport transfers.
                        if (report.Failed > 0 || prepared.Count == 0)
                            return report;

                        using (var tx = db.Database.BeginTransaction())
                        {
                            try
                            {
                                DateTime now = NowEgypt;
                                var current = await db.AirportTransfers
                                    .Where(x => !x.IsDeleted)
                                    .ToListAsync();

                                foreach (var transfer in current)
                                {
                                    transfer.IsDeleted = true;
                                    transfer.DeletedAt = now;
                                    transfer.DeletedBy = actor;
                                    transfer.ModifiedAt = now;
                                    transfer.ModifiedBy = actor;
                                    transfer.RetentionDateModified = now;
                                }
                                await db.SaveChangesAsync();

                                foreach (var item in prepared)
                                {
                                    var entity = new AirportTransfer
                                    {
                                        CreatedAt = now,
                                        CreatedBy = actor,
                                        RetentionDateCreated = now,
                                        IsDeleted = false
                                    };
                                    Apply(entity, item.Input);
                                    db.AirportTransfers.Add(entity);
                                }

                                await db.SaveChangesAsync();
                                tx.Commit();
                                report.SoftDeleted = current.Count;
                                report.Inserted = prepared.Count;
                            }
                            catch
                            {
                                tx.Rollback();
                                throw;
                            }
                        }
                        return report;
                    }

                    // UpdateOnly and Upsert accept valid rows independently.
                    foreach (var item in prepared)
                    {
                        var input = item.Input;
                        try
                        {
                            var entity = await db.AirportTransfers
                                .FirstOrDefaultAsync(x =>
                                    !x.IsDeleted &&
                                    x.Email == input.Email &&
                                    x.Type == input.Type);

                            if (entity == null && mode == "UpdateOnly")
                            {
                                report.AddError(item.RowNumber, "Email + Type",
                                    input.Email + " | " + input.Type,
                                    "Transfer no longer exists.");
                                continue;
                            }

                            bool inserted = entity == null;
                            DateTime now = NowEgypt;
                            if (inserted)
                            {
                                entity = new AirportTransfer
                                {
                                    CreatedAt = now,
                                    CreatedBy = actor,
                                    RetentionDateCreated = now,
                                    IsDeleted = false
                                };
                                Apply(entity, input);
                                db.AirportTransfers.Add(entity);
                            }
                            else
                            {
                                Apply(entity, input);
                                entity.ModifiedAt = now;
                                entity.ModifiedBy = actor;
                                entity.RetentionDateModified = now;
                            }

                            await db.SaveChangesAsync();
                            if (inserted) report.Inserted++;
                            else report.Updated++;
                        }
                        catch (Exception ex)
                        {
                            var pending = db.ChangeTracker.Entries()
                                .Where(x => x.State == System.Data.Entity.EntityState.Added ||
                                            x.State == System.Data.Entity.EntityState.Modified ||
                                            x.State == System.Data.Entity.EntityState.Deleted)
                                .ToList();
                            foreach (var entry in pending)
                                entry.State = System.Data.Entity.EntityState.Detached;

                            report.AddError(item.RowNumber, "Record", input.Email + " | " + input.Type,
                                ex.Message);
                        }
                    }
                }
            }
            return report;
        }

        // ============================================================
        // ADMIN TABLE: DATABASE-SIDE PAGING AND FILTERED XLSX EXPORT
        // The public unpaged GetAllAsync API remains unchanged.
        // ============================================================
        public Task<SltTablePage<AirportTransferDto>> GetPagedAsync(SltTableQuery filter)
        {
            return SltTableDataService.TransfersAsync(filter ?? new SltTableQuery());
        }

        public Task<byte[]> ExportFilteredAsync(SltTableQuery filter)
        {
            return SltTableDataService.ExportXlsxAsync<AirportTransferDto>(
                f => SltTableDataService.TransfersAsync(f),
                filter ?? new SltTableQuery(),
                new[] { "Id", "Email", "Type", "Date", "DriverName", "DriverPhone", "WhatsApp" });
        }

    }
}
