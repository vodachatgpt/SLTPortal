
using System;
using System.Globalization;

namespace SLTProject.Services
{
    public static class EgyptDateTimeService
    {
        private const string WindowsTimeZoneId =
            "Egypt Standard Time";

        private const string IanaTimeZoneId =
            "Africa/Cairo";

        private static readonly Lazy<TimeZoneInfo> EgyptZone =
            new Lazy<TimeZoneInfo>(LoadEgyptTimeZone);

        // ===================================================
        // GET EGYPT TIME ZONE
        // ===================================================

        public static TimeZoneInfo TimeZone
        {
            get { return EgyptZone.Value; }
        }

        private static TimeZoneInfo LoadEgyptTimeZone()
        {
            try
            {
                return TimeZoneInfo.FindSystemTimeZoneById(
                    WindowsTimeZoneId);
            }
            catch (TimeZoneNotFoundException)
            {
                return TimeZoneInfo.FindSystemTimeZoneById(
                    IanaTimeZoneId);
            }
            catch (InvalidTimeZoneException)
            {
                return TimeZoneInfo.FindSystemTimeZoneById(
                    IanaTimeZoneId);
            }
        }

        // ===================================================
        // CURRENT EGYPT DATE AND TIME
        // ===================================================

        public static DateTime Now
        {
            get
            {
                return TimeZoneInfo.ConvertTimeFromUtc(
                    DateTime.UtcNow,
                    TimeZone);
            }
        }

        // ===================================================
        // CURRENT EGYPT DATE ONLY
        // ===================================================

        public static DateTime Today
        {
            get { return Now.Date; }
        }

        // ===================================================
        // CURRENT EGYPT TIME WITH UTC OFFSET
        // ===================================================

        public static DateTimeOffset NowWithOffset
        {
            get
            {
                return TimeZoneInfo.ConvertTime(
                    DateTimeOffset.UtcNow,
                    TimeZone);
            }
        }

        // ===================================================
        // CONVERT UTC TO EGYPT TIME
        // ===================================================

        public static DateTime FromUtc(DateTime utcDate)
        {
            var normalized = DateTime.SpecifyKind(
                utcDate,
                DateTimeKind.Utc);

            return TimeZoneInfo.ConvertTimeFromUtc(
                normalized,
                TimeZone);
        }

        // ===================================================
        // CONVERT EGYPT TIME TO UTC
        // ===================================================

        public static DateTime ToUtc(DateTime egyptDate)
        {
            var normalized = DateTime.SpecifyKind(
                egyptDate,
                DateTimeKind.Unspecified);

            return TimeZoneInfo.ConvertTimeToUtc(
                normalized,
                TimeZone);
        }

        // ===================================================
        // ADD DURATION IN REAL ELAPSED TIME
        // ===================================================

        public static DateTime AddMinutes(int minutes)
        {
            return FromUtc(
                DateTime.UtcNow.AddMinutes(minutes));
        }

        public static DateTime AddHours(int hours)
        {
            return FromUtc(
                DateTime.UtcNow.AddHours(hours));
        }

        public static DateTime AddDays(int days)
        {
            return FromUtc(
                DateTime.UtcNow.AddDays(days));
        }

        // ===================================================
        // DISPLAY FORMATTING
        // All display dates use day/month/year.
        // All display times use the 24-hour clock.
        // These methods only format output; they do not change
        // database storage or API input date semantics.
        // ===================================================

        public static string FormatDate(DateTime date)
        {
            return date.ToString(
                "dd/MM/yyyy",
                CultureInfo.InvariantCulture);
        }

        public static string FormatTime(TimeSpan time)
        {
            if (time < TimeSpan.Zero || time >= TimeSpan.FromDays(1))
                throw new ArgumentOutOfRangeException("time");

            return time.ToString(
                @"hh\:mm",
                CultureInfo.InvariantCulture);
        }

        public static string FormatDateTime(DateTime date)
        {
            return date.ToString(
                "dd/MM/yyyy HH:mm",
                CultureInfo.InvariantCulture);
        }

        public static string FormatDateTimeWithSeconds(DateTime date)
        {
            return date.ToString(
                "dd/MM/yyyy HH:mm:ss",
                CultureInfo.InvariantCulture);
        }

        // ===================================================
        // ISO STYLE WITHOUT UTC SUFFIX
        // ===================================================

        public static string FormatIso(DateTime date)
        {
            return date.ToString(
                "yyyy-MM-ddTHH:mm:ss.fff",
                CultureInfo.InvariantCulture);
        }
    }
}
