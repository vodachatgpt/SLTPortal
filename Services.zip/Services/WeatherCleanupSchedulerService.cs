﻿
using System;
using System.Configuration;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace SLTProject.Services
{
    public class WeatherCleanupSchedulerService
    {
        public const string JobKey =
            "SLT_WeatherForecast_HourlyCleanup";

        public const string Cron =
            "0 * * * *";

        private static string Setting(string key)
        {
            string value =
                ConfigurationManager.AppSettings[key];

            if (string.IsNullOrWhiteSpace(value))
            {
                throw new ConfigurationErrorsException(
                    "Missing Web.config setting: " + key);
            }

            return value.Trim().TrimEnd('/');
        }

        private static StringContent MakeContent(object value)
        {
            return new StringContent(
                JsonConvert.SerializeObject(value),
                Encoding.UTF8,
                "application/json");
        }

        public async Task<string> ScheduleAsync()
        {
            string hangfireUrl =
                Setting("HangfireApiUrl");

            string apiUrl =
                Setting("ApiUrl");

            string scheduleUrl =
                hangfireUrl +
                "/api/jobs/AddScheduleJob";

            string removeUrl =
                hangfireUrl +
                "/api/jobs/RemoveJob?key=" +
                Uri.EscapeDataString(JobKey);

            var job = new
            {
                key = JobKey,

                url = apiUrl +
                    "/api/weather-forecasts/process-cleanup",

                jobIntervalInCronExpression = Cron,

                content = new
                {
                    type = "application/json",
                    data = new { }
                }
            };

            using (var client = new HttpClient())
            {
                client.Timeout =
                    TimeSpan.FromSeconds(60);

                HttpStatusCode scheduleStatus;

                using (var body = MakeContent(job))
                using (var response =
                    await client.PostAsync(
                        scheduleUrl,
                        body))
                {
                    if (response.IsSuccessStatusCode)
                    {
                        return
                            "Hourly weather cleanup scheduled.";
                    }

                    scheduleStatus = response.StatusCode;
                }

                // If the job already exists, replace it.
                // This assumes the global scheduler reports
                // an existing-key collision as HTTP 409.
                if (scheduleStatus != HttpStatusCode.Conflict)
                {
                    throw new InvalidOperationException(
                        "Global Hangfire registration failed. " +
                        "HTTP " + (int)scheduleStatus);
                }

                using (var response =
                    await client.DeleteAsync(removeUrl))
                {
                    if (!response.IsSuccessStatusCode)
                    {
                        throw new InvalidOperationException(
                            "Unable to remove existing job. " +
                            "HTTP " + (int)response.StatusCode);
                    }
                }

                using (var body = MakeContent(job))
                using (var response =
                    await client.PostAsync(
                        scheduleUrl,
                        body))
                {
                    if (!response.IsSuccessStatusCode)
                    {
                        throw new InvalidOperationException(
                            "Unable to reschedule job. " +
                            "HTTP " + (int)response.StatusCode);
                    }
                }

                return
                    "Hourly weather cleanup rescheduled.";
            }
        }

        public async Task<string> RemoveAsync()
        {
            string url =
                Setting("HangfireApiUrl") +
                "/api/jobs/RemoveJob?key=" +
                Uri.EscapeDataString(JobKey);

            using (var client = new HttpClient())
            {
                client.Timeout =
                    TimeSpan.FromSeconds(60);

                using (var response =
                    await client.DeleteAsync(url))
                {
                    if (!response.IsSuccessStatusCode)
                    {
                        throw new InvalidOperationException(
                            "Unable to remove the Hangfire job. " +
                            "HTTP " + (int)response.StatusCode);
                    }
                }
            }

            return "Weather cleanup schedule removed.";
        }
    }
}
