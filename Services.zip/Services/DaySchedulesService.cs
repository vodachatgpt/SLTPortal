
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using ClosedXML.Excel;
using SLTProject.Data;
using SLTProject.Models.Dtos;

namespace SLTProject.Services
{
    public class DaySchedulesService
    {
        // ==========================================
        // VALIDATION HELPERS
        // ==========================================

        private static string Required(
            string value,
            int max,
            string field)
        {
            return ScheduleTransportExcel.Limit(
                value, max, field, true);
        }

        private static string Optional(
            string value,
            int max,
            string field)
        {
            return ScheduleTransportExcel.Limit(
                value, max, field);
        }

        private static string ItemType(string value)
        {
            return Required(value, 100, "ItemType");
        }

        private static async Task ValidateIconAsync(SLTEntities db, string name)
        {
            if (string.IsNullOrWhiteSpace(name)) return;
            string normalized = name.Trim();
            bool exists = await db.BlurIcons.AsNoTracking().AnyAsync(x =>
                !x.IsDeleted && x.Name == normalized);
            if (!exists) throw new ArgumentException(
                "Blurb icon '" + normalized + "' not found. Select an existing Blurb Icon name.");
        }

        private static void Validate(DayScheduleInput input)
        {
            if (input == null)
            {
                throw new ArgumentException(
                    "Day schedule is required.");
            }

            if (input.Date == default(DateTime))
            {
                throw new ArgumentException(
                    "Date is required.");
            }

            ItemType(input.ItemType);

            Required(input.Title, 250, "Title");

            Optional(
                input.BlurIconName,
                150,
                "BlurIconName");

            Optional(
                input.DressCode,
                150,
                "DressCode");

            Optional(
                input.LocationName,
                250,
                "LocationName");

            Optional(
                input.MapsLink,
                1000,
                "MapsLink");

            if (input.StartTime.HasValue &&
                (input.StartTime.Value < TimeSpan.Zero ||
                 input.StartTime.Value >= TimeSpan.FromDays(1)))
            {
                throw new ArgumentException(
                    "Invalid StartTime.");
            }

            if (input.EndTime.HasValue &&
                (input.EndTime.Value < TimeSpan.Zero ||
                 input.EndTime.Value >= TimeSpan.FromDays(1)))
            {
                throw new ArgumentException(
                    "Invalid EndTime.");
            }

            if (input.StartTime.HasValue &&
                input.EndTime.HasValue &&
                input.EndTime.Value <= input.StartTime.Value)
            {
                throw new ArgumentException(
                    "EndTime must be after StartTime.");
            }
        }

        // ==========================================
        // APPLY INPUT TO ENTITY
        // ==========================================

        private static void Apply(
            DaySchedule entity,
            DayScheduleInput input)
        {
            entity.Date = input.Date.Date;

            entity.ItemType = ItemType(input.ItemType);

            entity.Title = Required(
                input.Title, 250, "Title");

            entity.BlurIconName = Optional(
                input.BlurIconName,
                150,
                "BlurIconName");

            entity.StartTime = input.StartTime;

            entity.EndTime = input.EndTime;

            entity.ShortNote = Optional(
                input.ShortNote,
                100000,
                "ShortNote");

            entity.DressCode = Optional(
                input.DressCode,
                150,
                "DressCode");

            entity.LocationName = Optional(
                input.LocationName,
                250,
                "LocationName");

            entity.MapsLink = Optional(
                input.MapsLink,
                1000,
                "MapsLink");
        }

        // ==========================================
        // MAP ENTITY TO DTO
        // ==========================================

        public static DayScheduleDto Map(DaySchedule entity)
        {
            if (entity == null)
                return null;

            return new DayScheduleDto
            {
                Id = entity.Id,

                Date = entity.Date,

                ItemType = entity.ItemType,

                Title = entity.Title,

                BlurIconName = entity.BlurIconName,

                StartTime = entity.StartTime,

                EndTime = entity.EndTime,

                ShortNote = entity.ShortNote,

                DressCode = entity.DressCode,

                LocationName = entity.LocationName,

                MapsLink = entity.MapsLink,

                CreatedAt = entity.CreatedAt,

                CreatedBy = entity.CreatedBy,

                ModifiedAt = entity.ModifiedAt,

                ModifiedBy = entity.ModifiedBy,

                IsDeleted = entity.IsDeleted,

                DeletedAt = entity.DeletedAt,

                DeletedBy = entity.DeletedBy,

                RetentionDateCreated =
                    entity.RetentionDateCreated,

                RetentionDateModified =
                    entity.RetentionDateModified
            };
        }

        // ==========================================
        // GET ALL
        // ==========================================

        public async Task<List<DayScheduleDto>> GetAllAsync()
        {
            using (var db = new SLTEntities())
            {
                var items = await db.DaySchedules
                    .AsNoTracking()
                    .Where(x => !x.IsDeleted)
                    .OrderBy(x => x.Date)
                    .ThenBy(x => x.StartTime)
                    .ThenBy(x => x.Id)
                    .ToListAsync();

                return items.Select(Map).ToList();
            }
        }

        // ==========================================
        // GET BY ID
        // ==========================================

        public async Task<DayScheduleDto> GetAsync(long id)
        {
            using (var db = new SLTEntities())
            {
                var item = await db.DaySchedules
                    .AsNoTracking()
                    .FirstOrDefaultAsync(x =>
                        x.Id == id &&
                        !x.IsDeleted);

                return Map(item);
            }
        }

        // ==========================================
        // CREATE
        // ==========================================

        public async Task<DayScheduleDto> CreateAsync(
            DayScheduleInput input,
            string actor)
        {
            Validate(input);

            using (var db = new SLTEntities())
            {
                var now = EgyptDateTimeService.Now;

                var entity = new DaySchedule
                {
                    CreatedAt = now,
                    CreatedBy = actor,
                    RetentionDateCreated = now,
                    IsDeleted = false
                };

                await ValidateIconAsync(db, input.BlurIconName);
                Apply(entity, input);

                db.DaySchedules.Add(entity);

                await db.SaveChangesAsync();

                return Map(entity);
            }
        }

        // ==========================================
        // UPDATE
        // ==========================================

        public async Task<DayScheduleDto> UpdateAsync(
            long id,
            DayScheduleInput input,
            string actor)
        {
            Validate(input);

            using (var db = new SLTEntities())
            {
                var entity = await db.DaySchedules
                    .FirstOrDefaultAsync(x =>
                        x.Id == id &&
                        !x.IsDeleted);

                if (entity == null)
                    return null;

                await ValidateIconAsync(db, input.BlurIconName);
                Apply(entity, input);

                var now = EgyptDateTimeService.Now;

                entity.ModifiedAt = now;
                entity.ModifiedBy = actor;
                entity.RetentionDateModified = now;

                await db.SaveChangesAsync();

                return Map(entity);
            }
        }

        // ==========================================
        // SOFT DELETE
        // ==========================================

        public async Task<bool> DeleteAsync(
            long id,
            string actor)
        {
            using (var db = new SLTEntities())
            {
                var entity = await db.DaySchedules
                    .FirstOrDefaultAsync(x =>
                        x.Id == id &&
                        !x.IsDeleted);

                if (entity == null)
                    return false;

                var now = EgyptDateTimeService.Now;

                entity.IsDeleted = true;
                entity.DeletedAt = now;
                entity.DeletedBy = actor;
                entity.ModifiedAt = now;
                entity.ModifiedBy = actor;
                entity.RetentionDateModified = now;

                await db.SaveChangesAsync();

                return true;
            }
        }

        // ==========================================
        // EXCEL TEMPLATE
        // ==========================================

        public byte[] GetTemplate()
        {
            return ScheduleTransportExcel.Template(
                "Id",
                "Date",
                "ItemType",
                "Title",
                "BlurIconName",
                "StartTime",
                "EndTime",
                "ShortNote",
                "DressCode",
                "LocationName",
                "MapsLink"
            );
        }

        // ==========================================
        // EXCEL BULK IMPORT
        // ==========================================

        public async Task<ExcelImportResult> ImportAsync(
            Stream stream,
            string actor)
        {
            var report = new ExcelImportResult();

            using (var workbook =
                ScheduleTransportExcel.Open(stream))
            {
                var sheet = workbook.Worksheet(1);

                var headers =
                    ScheduleTransportExcel.Headers(sheet);

                ScheduleTransportExcel.Require(
                    headers,
                    "Date",
                    "ItemType",
                    "Title");

                var last = sheet.LastRowUsed();

                if (last == null)
                    return report;

                if (last.RowNumber() > 10001)
                {
                    throw new ArgumentException(
                        "Maximum 10000 rows per upload.");
                }

                var seenIds = new HashSet<long>();

                using (var db = new SLTEntities())
                using (var transaction =
                    db.Database.BeginTransaction())
                {
                    for (int rowNumber = 2;
                         rowNumber <= last.RowNumber();
                         rowNumber++)
                    {
                        var row = sheet.Row(rowNumber);

                        if (ScheduleTransportExcel.Empty(
                            row, headers))
                        {
                            report.Skipped++;
                            continue;
                        }

                        try
                        {
                            // --------------------------
                            // READ ID
                            // --------------------------

                            string rawId =
                                ScheduleTransportExcel.Text(
                                    row,
                                    headers,
                                    "Id");

                            long id = 0;

                            if (rawId.Length > 0 &&
                                (!long.TryParse(rawId, out id) ||
                                 id <= 0))
                            {
                                throw new ArgumentException(
                                    "Id must be a positive integer.");
                            }

                            if (id > 0 && !seenIds.Add(id))
                            {
                                throw new ArgumentException(
                                    "Duplicate Id in Excel file.");
                            }

                            // --------------------------
                            // LOAD EXISTING ENTITY
                            // --------------------------

                            DaySchedule entity = null;

                            if (id > 0)
                            {
                                entity = await db.DaySchedules
                                    .FirstOrDefaultAsync(x =>
                                        x.Id == id &&
                                        !x.IsDeleted);

                                if (entity == null)
                                {
                                    throw new ArgumentException(
                                        "Active schedule Id " +
                                        id + " not found.");
                                }
                            }

                            // --------------------------
                            // READ EXCEL VALUES
                            // --------------------------

                            string dateText =
                                ScheduleTransportExcel.Text(
                                    row, headers, "Date");

                            string typeText =
                                ScheduleTransportExcel.Text(
                                    row, headers, "ItemType");

                            string titleText =
                                ScheduleTransportExcel.Text(
                                    row, headers, "Title");

                            var input = new DayScheduleInput
                            {
                                Date = dateText.Length > 0
                                    ? ScheduleTransportExcel.Date(
                                        dateText, "Date")
                                    : (entity == null
                                        ? default(DateTime)
                                        : entity.Date),

                                ItemType = typeText.Length > 0
                                    ? typeText
                                    : (entity == null
                                        ? null
                                        : entity.ItemType),

                                Title = titleText.Length > 0
                                    ? titleText
                                    : (entity == null
                                        ? null
                                        : entity.Title),

                                BlurIconName = ValueText(
                                    row,
                                    headers,
                                    "BlurIconName",
                                    entity == null
                                        ? null
                                        : entity.BlurIconName),

                                StartTime = ValueTime(
                                    row,
                                    headers,
                                    "StartTime",
                                    entity == null
                                        ? (TimeSpan?)null
                                        : entity.StartTime),

                                EndTime = ValueTime(
                                    row,
                                    headers,
                                    "EndTime",
                                    entity == null
                                        ? (TimeSpan?)null
                                        : entity.EndTime),

                                ShortNote = ValueText(
                                    row,
                                    headers,
                                    "ShortNote",
                                    entity == null
                                        ? null
                                        : entity.ShortNote),

                                DressCode = ValueText(
                                    row,
                                    headers,
                                    "DressCode",
                                    entity == null
                                        ? null
                                        : entity.DressCode),

                                LocationName = ValueText(
                                    row,
                                    headers,
                                    "LocationName",
                                    entity == null
                                        ? null
                                        : entity.LocationName),

                                MapsLink = ValueText(
                                    row,
                                    headers,
                                    "MapsLink",
                                    entity == null
                                        ? null
                                        : entity.MapsLink)
                            };

                            Validate(input);
                            await ValidateIconAsync(db, input.BlurIconName);

                            var now = EgyptDateTimeService.Now;

                            // --------------------------
                            // INSERT
                            // --------------------------

                            if (entity == null)
                            {
                                entity = new DaySchedule
                                {
                                    CreatedAt = now,
                                    CreatedBy = actor,
                                    RetentionDateCreated = now,
                                    IsDeleted = false
                                };

                                Apply(entity, input);

                                db.DaySchedules.Add(entity);

                                report.Inserted++;
                            }
                            else
                            {
                                // ----------------------
                                // UPDATE
                                // ----------------------

                                Apply(entity, input);

                                entity.ModifiedAt = now;
                                entity.ModifiedBy = actor;
                                entity.RetentionDateModified = now;

                                report.Updated++;
                            }
                        }
                        catch (Exception ex) when (
                            ex is ArgumentException ||
                            ex is FormatException ||
                            ex is OverflowException)
                        {
                            report.Errors.Add(
                                "Row " + rowNumber +
                                ": " + ex.Message);
                        }
                    }

                    // --------------------------
                    // ROLLBACK ON VALIDATION ERROR
                    // --------------------------

                    if (report.Errors.Count > 0)
                    {
                        transaction.Rollback();

                        report.Inserted = 0;
                        report.Updated = 0;

                        return report;
                    }

                    await db.SaveChangesAsync();

                    transaction.Commit();
                }
            }

            return report;
        }

        // ==========================================
        // EXCEL HELPERS
        // ==========================================

        private static string ValueText(
            IXLRow row,
            Dictionary<string, int> headers,
            string key,
            string existing)
        {
            var value = ScheduleTransportExcel.Text(
                row, headers, key);

            return value.Length > 0
                ? value
                : existing;
        }

        private static TimeSpan? ValueTime(
            IXLRow row,
            Dictionary<string, int> headers,
            string key,
            TimeSpan? existing)
        {
            var value = ScheduleTransportExcel.Text(
                row, headers, key);

            return value.Length > 0
                ? ScheduleTransportExcel.Time(value, key)
                : existing;
        }
        // ============================================================
        // ADMIN TABLE: DATABASE-SIDE PAGING AND FILTERED XLSX EXPORT
        // The public unpaged GetAllAsync API remains unchanged.
        // ============================================================
        public Task<SltTablePage<DayScheduleDto>> GetPagedAsync(SltTableQuery filter)
        {
            return SltTableDataService.SchedulesAsync(filter ?? new SltTableQuery());
        }

        public Task<byte[]> ExportFilteredAsync(SltTableQuery filter)
        {
            return SltTableDataService.ExportXlsxAsync<DayScheduleDto>(
                SltTableDataService.SchedulesAsync,
                filter ?? new SltTableQuery(),
                new[] { "Id", "Date", "ItemType", "Title", "StartTime", "EndTime", "LocationName", "BlurIconName" });
        }

    }
}
