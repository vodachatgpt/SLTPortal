using System;
using System.Configuration;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace SLTProject.Services
{
    // Uses the same external Global Hangfire API contract as WeatherCleanupSchedulerService.
    // No Hangfire packages or BackgroundJobServer are installed in SLTProject.
    public sealed class SltOperationalAlertsSchedulerService
    {
        public const string JobKey = "SLT_OperationalAlerts_EveryMinute";
        public const string Cron = "* * * * *";

        private static string Setting(string key)
        {
            var value = ConfigurationManager.AppSettings[key];
            if (string.IsNullOrWhiteSpace(value))
                throw new ConfigurationErrorsException("Missing Web.config setting: " + key);
            return value.Trim().TrimEnd('/');
        }

        private static StringContent JsonBody(object value)
        {
            return new StringContent(JsonConvert.SerializeObject(value), Encoding.UTF8, "application/json");
        }

        public async Task<string> ScheduleAsync()
        {
            string baseUrl = Setting("HangfireApiUrl");
            string callbackUrl = Setting("ApiUrl") + "/api/operational-alerts/process-due";
            string addUrl = baseUrl + "/api/jobs/AddScheduleJob";
            string deleteUrl = baseUrl + "/api/jobs/RemoveJob?key=" + Uri.EscapeDataString(JobKey);

            var job = new
            {
                key = JobKey,
                url = callbackUrl,
                jobIntervalInCronExpression = Cron,
                content = new { type = "application/json", data = new { } }
            };

            using (var client = new HttpClient { Timeout = TimeSpan.FromSeconds(60) })
            {
                HttpStatusCode status;
                using (var payload = JsonBody(job))
                using (var response = await client.PostAsync(addUrl, payload).ConfigureAwait(false))
                {
                    if (response.IsSuccessStatusCode) return "Operational alerts registered in Global Hangfire (every minute).";
                    status = response.StatusCode;
                }

                if (status != HttpStatusCode.Conflict)
                    throw new InvalidOperationException("Global Hangfire registration failed (HTTP " + (int)status + ").");

                // Same collision handling as the existing Weather cleanup registration.
                using (var response = await client.DeleteAsync(deleteUrl).ConfigureAwait(false))
                {
                    if (!response.IsSuccessStatusCode)
                        throw new InvalidOperationException("Could not remove previous alert job (HTTP " + (int)response.StatusCode + ").");
                }
                using (var payload = JsonBody(job))
                using (var response = await client.PostAsync(addUrl, payload).ConfigureAwait(false))
                {
                    if (!response.IsSuccessStatusCode)
                        throw new InvalidOperationException("Could not reschedule alert job (HTTP " + (int)response.StatusCode + ").");
                }
                return "Operational alerts rescheduled in Global Hangfire (every minute).";
            }
        }

        public async Task<string> RemoveAsync()
        {
            string url = Setting("HangfireApiUrl") + "/api/jobs/RemoveJob?key=" + Uri.EscapeDataString(JobKey);
            using (var client = new HttpClient { Timeout = TimeSpan.FromSeconds(60) })
            using (var response = await client.DeleteAsync(url).ConfigureAwait(false))
            {
                if (!response.IsSuccessStatusCode)
                    throw new InvalidOperationException("Global Hangfire job removal failed (HTTP " + (int)response.StatusCode + ").");
            }
            return "Operational alerts recurring job removed.";
        }
    }
}
