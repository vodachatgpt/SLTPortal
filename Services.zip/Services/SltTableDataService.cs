using System;
using System.Collections.Generic;
using System.IO;
using ClosedXML.Excel;
using System.Data.Entity;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SLTProject.Data;
using SLTProject.Models.Dtos;

namespace SLTProject.Services
{
    // Reusable, database-side filters and paging for four large admin tables.
    // Existing unpaged routes remain intact for legacy consumers.
    public sealed class SltTableQuery
    {
        public int Page { get; set; } = 1;
        public int PageSize { get; set; } = 20;
        public string Search { get; set; }
        public string Email { get; set; }
        public string Type { get; set; }
        public string Hotel { get; set; }
        public string Driver { get; set; }
        public DateTime? From { get; set; }
        public DateTime? To { get; set; }
        public bool? Activated { get; set; }
        public bool? TourRegister { get; set; }
        public long? DayScheduleId { get; set; }
        public void Validate()
        {
            if (Page < 1) throw new ArgumentException("Page must be at least 1.");
            if (PageSize < 1 || PageSize > 100) throw new ArgumentException("PageSize must be between 1 and 100.");
            if (From.HasValue && To.HasValue && From.Value.Date > To.Value.Date)
                throw new ArgumentException("From must be on or before To.");
            foreach (string term in new[] { Search, Email, Type, Hotel, Driver })
                if (term != null && term.Length > 250) throw new ArgumentException("Filter exceeds 250 characters.");
        }
    }

    public sealed class SltTablePage<T>
    {
        public List<T> Items { get; set; }
        public int Total { get; set; }
        public int Page { get; set; }
        public int PageSize { get; set; }
        public int TotalPages { get { return (Total + PageSize - 1) / PageSize; } }
    }

    public static class SltTableDataService
    {
        private static string Norm(string s) { return string.IsNullOrWhiteSpace(s) ? null : s.Trim(); }
        private static DateTime? ToExclusive(DateTime? date) { return date.HasValue ? (date.Value.Date == DateTime.MaxValue.Date ? DateTime.MaxValue : date.Value.Date.AddDays(1)) : (DateTime?)null; }
        private static async Task<SltTablePage<TResult>> PageAsync<TModel, TResult>(
            IQueryable<TModel> q, SltTableQuery filter, Func<TModel, TResult> map) where TModel : class
        {
            filter.Validate();
            int total = await q.CountAsync();
            var items = await q.Skip((filter.Page - 1) * filter.PageSize)
                .Take(filter.PageSize).ToListAsync();
            return new SltTablePage<TResult> { Items = items.Select(map).ToList(), Total = total,
                Page = filter.Page, PageSize = filter.PageSize };
        }

        public static async Task<SltTablePage<GuestView>> GuestsAsync(SltTableQuery f)
        {
            f.Validate();
            using (var db = new SLTEntities())
            {
                var q = db.Guests.AsNoTracking().Where(x => !x.IsDeleted);
                string s = Norm(f.Search), email = Norm(f.Email), hotel = Norm(f.Hotel);
                if (s != null) q = q.Where(x => x.FullName.Contains(s) || x.Email.Contains(s) ||
                    x.HotelName.Contains(s) || x.ArrivalFlight.Contains(s) || x.DepartureFlight.Contains(s) || x.PhoneNumber.Contains(s));
                if (email != null) q = q.Where(x => x.Email.Contains(email));
                if (hotel != null) q = q.Where(x => x.HotelName.Contains(hotel));
                if (f.Activated.HasValue) q = f.Activated.Value ? q.Where(x => x.FirstLoginAt != null) : q.Where(x => x.FirstLoginAt == null);
                if (f.TourRegister.HasValue) { bool tour = f.TourRegister.Value; q = q.Where(x => x.TourRegister == tour); }
                DateTime? end = ToExclusive(f.To);
                if (f.From.HasValue) { DateTime from = f.From.Value.Date; q = q.Where(x => x.ArrivalDate >= from); }
                if (end.HasValue) { DateTime until = end.Value; q = q.Where(x => x.ArrivalDate < until); }
                // Project only scalar values: avoid fetching QRCodeImage and
                // PasscodeProtected varbinary(max) for large tables/exports.
                int total = await q.CountAsync();
                var items = await q.OrderBy(x => x.FullName).ThenBy(x => x.Id)
                    .Skip((f.Page - 1) * f.PageSize).Take(f.PageSize)
                    .Select(g => new GuestView
                    {
                        Id = g.Id,
                        FullName = g.FullName,
                        Email = g.Email,
                        PhoneNumber = g.PhoneNumber,
                        ArrivalDate = g.ArrivalDate,
                        ArrivalFlight = g.ArrivalFlight,
                        LandingTime = g.LandingTime,
                        DepartureDate = g.DepartureDate,
                        DepartureFlight = g.DepartureFlight,
                        DepartureTime = g.DepartureTime,
                        HotelName = g.HotelName,
                        CheckInDate = g.CheckInDate,
                        CheckInTime = g.CheckInTime,
                        CheckOutDate = g.CheckOutDate,
                        CheckOutTime = g.CheckOutTime,
                        TourRegister = g.TourRegister,
                        PasscodeLast4 = g.PasscodeLast4,
                        CanRevealPasscode = g.PasscodeProtected != null,
                        Activated = g.FirstLoginAt != null,
                        SessionExpiresAt = g.SessionExpiresAt,
                        HasQR = g.QRCodeImage != null,
                        QRFileName = g.QRFileName,
                        RetentionDateCreated = g.RetentionDateCreated,
                        RetentionDateModified = g.RetentionDateModified,
                        CreatedBy = g.CreatedBy,
                        ModifiedBy = g.ModifiedBy
                    }).ToListAsync();
                foreach (var guest in items)
                {
                    string fileName = GuestsService.FolderQrFileName(guest.Email);
                    if (fileName != null)
                    {
                        guest.HasQR = true;
                        guest.QRFileName = fileName;
                    }
                }
                return new SltTablePage<GuestView>
                {
                    Items = items,
                    Total = total,
                    Page = f.Page,
                    PageSize = f.PageSize
                };
            }
        }

        public static async Task<SltTablePage<DayScheduleDto>> SchedulesAsync(SltTableQuery f)
        {
            f.Validate();
            using (var db = new SLTEntities())
            {
                var q = db.DaySchedules.AsNoTracking().Where(x => !x.IsDeleted);
                string s = Norm(f.Search), type = Norm(f.Type);
                if (s != null) q = q.Where(x => x.Title.Contains(s) || x.ItemType.Contains(s) || x.LocationName.Contains(s) || x.BlurIconName.Contains(s));
                if (type != null) q = q.Where(x => x.ItemType.Contains(type));
                DateTime? end = ToExclusive(f.To);
                if (f.From.HasValue) { DateTime from = f.From.Value.Date; q = q.Where(x => x.Date >= from); }
                if (end.HasValue) { DateTime until = end.Value; q = q.Where(x => x.Date < until); }
                return await PageAsync(q.OrderBy(x => x.Date).ThenBy(x => x.StartTime).ThenBy(x => x.Id), f, DaySchedulesService.Map);
            }
        }

        public static async Task<SltTablePage<AirportTransferDto>> TransfersAsync(SltTableQuery f, string restrictEmail = null)
        {
            f.Validate();
            using (var db = new SLTEntities())
            {
                var q = db.AirportTransfers.AsNoTracking().Where(x => !x.IsDeleted);
                string s = Norm(f.Search), email = Norm(restrictEmail) ?? Norm(f.Email),
                    type = Norm(f.Type), driver = Norm(f.Driver);
                if (restrictEmail != null) q = q.Where(x => x.Email == email);
                else if (email != null) q = q.Where(x => x.Email.Contains(email));
                if (s != null) q = q.Where(x => x.Email.Contains(s) || x.Type.Contains(s) || x.DriverName.Contains(s) || x.DriverPhone.Contains(s));
                if (type != null) q = q.Where(x => x.Type.Contains(type));
                if (driver != null) q = q.Where(x => x.DriverName.Contains(driver));
                DateTime? end = ToExclusive(f.To);
                if (f.From.HasValue) { DateTime from = f.From.Value.Date; q = q.Where(x => x.Date >= from); }
                if (end.HasValue) { DateTime until = end.Value; q = q.Where(x => x.Date < until); }
                return await PageAsync(q.OrderBy(x => x.Date).ThenBy(x => x.Email).ThenBy(x => x.Id), f, AirportTransfersService.Map);
            }
        }

        public static async Task<SltTablePage<GuestEventDriverDto>> DriversAsync(SltTableQuery f, string restrictEmail = null)
        {
            f.Validate();
            using (var db = new SLTEntities())
            {
                var activeSchedules = db.DaySchedules.Where(x => !x.IsDeleted).Select(x => x.Id);
                var q = db.GuestEventDrivers.AsNoTracking().Where(x => !x.IsDeleted && activeSchedules.Contains(x.DayScheduleId));
                string s = Norm(f.Search), email = Norm(restrictEmail) ?? Norm(f.Email), driver = Norm(f.Driver);
                if (restrictEmail != null) q = q.Where(x => x.Email == email);
                else if (email != null) q = q.Where(x => x.Email.Contains(email));
                if (s != null) q = q.Where(x =>
                    x.Email.Contains(s) ||
                    x.DriverName.Contains(s) ||
                    x.DriverPhone.Contains(s) ||
                    db.DaySchedules.Any(ds =>
                        !ds.IsDeleted &&
                        ds.Id == x.DayScheduleId &&
                        ds.Title.Contains(s)));
                if (driver != null) q = q.Where(x => x.DriverName.Contains(driver));
                if (f.DayScheduleId.HasValue) { long id = f.DayScheduleId.Value; q = q.Where(x => x.DayScheduleId == id); }
                DateTime? end = ToExclusive(f.To);
                if (f.From.HasValue) { DateTime from = f.From.Value.Date;
                    var dates = db.DaySchedules.Where(x => x.Date >= from).Select(x => x.Id);
                    q = q.Where(x => dates.Contains(x.DayScheduleId)); }
                if (end.HasValue) { DateTime until = end.Value;
                    var dates = db.DaySchedules.Where(x => x.Date < until).Select(x => x.Id);
                    q = q.Where(x => dates.Contains(x.DayScheduleId)); }
                return await PageAsync(q.OrderBy(x => x.DayScheduleId).ThenBy(x => x.Email).ThenBy(x => x.Id), f, GuestEventDriversService.Map);
            }
        }

        private static bool IsDateOnlyColumn(string columnName)
        {
            return string.Equals(columnName, "Date", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(columnName, "ArrivalDate", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(columnName, "DepartureDate", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(columnName, "CheckInDate", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(columnName, "CheckOutDate", StringComparison.OrdinalIgnoreCase);
        }

        private static string FormatExportValue(object value, string columnName)
        {
            if (value == null) return "";

            if (value is DateTime)
            {
                var date = (DateTime)value;
                return IsDateOnlyColumn(columnName)
                    ? EgyptDateTimeService.FormatDate(date)
                    : EgyptDateTimeService.FormatDateTime(date);
            }

            if (value is DateTimeOffset)
            {
                var date = ((DateTimeOffset)value).DateTime;
                return IsDateOnlyColumn(columnName)
                    ? EgyptDateTimeService.FormatDate(date)
                    : EgyptDateTimeService.FormatDateTime(date);
            }

            if (value is TimeSpan)
            {
                return EgyptDateTimeService.FormatTime((TimeSpan)value);
            }

            return Convert.ToString(value, CultureInfo.InvariantCulture) ?? "";
        }

        public static async Task<byte[]> ExportXlsxAsync<T>(Func<SltTableQuery, Task<SltTablePage<T>>> fetch,
            SltTableQuery filter, string[] columns)
        {
            filter.Validate(); filter.Page = 1; filter.PageSize = 100;
            using (var workbook = new XLWorkbook())
            {
                var sheet = workbook.Worksheets.Add("Filtered Records");
                for (int c = 0; c < columns.Length; c++)
                {
                    sheet.Cell(1, c + 1).Value = columns[c];
                    sheet.Column(c + 1).Width = columns[c].IndexOf("Email", StringComparison.OrdinalIgnoreCase) >= 0 ? 38 : 23;
                }
                sheet.Range(1, 1, 1, columns.Length).Style.Fill.BackgroundColor = XLColor.FromHtml("#C8102E");
                sheet.Range(1, 1, 1, columns.Length).Style.Font.FontColor = XLColor.White;
                sheet.Range(1, 1, 1, columns.Length).Style.Font.Bold = true;
                sheet.SheetView.FreezeRows(1);
                int outputRow = 2;
                while (true)
                {
                    var data = await fetch(filter);
                    if (data.Total > 50000) throw new ArgumentException("Export exceeds 50,000 rows. Narrow the filters.");
                    foreach (var record in data.Items)
                    {
                        for (int c = 0; c < columns.Length; c++)
                        {
                            var property = typeof(T).GetProperty(columns[c]);
                            var value = property == null ? null : property.GetValue(record, null);
                            // Export all columns as text, preserving leading '+' and zeroes.
                            // Prevent spreadsheet formula execution from user-provided strings.
                            string text = FormatExportValue(value, columns[c]);
                            if (text.Length > 0 && (text[0] == '=' || text[0] == '-' ||
                                text[0] == '@' || text[0] == '\t' || text[0] == '\r'))
                                text = "'" + text;
                            sheet.Cell(outputRow, c + 1).Style.NumberFormat.Format = "@";
                            sheet.Cell(outputRow, c + 1).Value = text;
                        }
                        outputRow++;
                    }
                    if (filter.Page >= data.TotalPages || data.Items.Count == 0) break;
                    filter.Page++;
                }
                if (outputRow > 2) sheet.Range(1, 1, outputRow - 1, columns.Length).SetAutoFilter();
                using (var stream = new MemoryStream())
                {
                    workbook.SaveAs(stream);
                    return stream.ToArray();
                }
            }
        }

    }
}
