﻿
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using SLTProject.Data;

namespace SLTProject.Services
{
    public class CustomizedResponsesService
    {
        // ==========================================
        // FORMATTING
        // ==========================================

        private static string FormatTime(object value)
        {
            if (value == null)
                return null;

            if (value is TimeSpan)
            {
                return ((TimeSpan)value).ToString(
                    @"hh\:mm",
                    CultureInfo.InvariantCulture);
            }

            if (value is DateTime)
            {
                return ((DateTime)value).ToString(
                    "HH:mm",
                    CultureInfo.InvariantCulture);
            }

            return Convert.ToString(
                value,
                CultureInfo.InvariantCulture);
        }

        private static string NormalizeEmail(
            string email)
        {
            return (email ?? "")
                .Trim()
                .ToLowerInvariant();
        }

        // ==========================================
        // GET COMBINED EVENTS BY DATE
        // ==========================================

        public async Task<
            List<Dictionary<string, object>>>
            GetCombinedEventsAsync(string guestEmail)
        {
            string email = NormalizeEmail(guestEmail);

            using (var db = new SLTEntities())
            {
                // ----------------------------------
                // 1. GET ACTIVE PHASES
                // ----------------------------------

                var phases = await db.Phases
                    .AsNoTracking()
                    .Where(x => !x.IsDeleted)
                    .OrderBy(x => x.Date)
                    .ThenBy(x => x.Id)
                    .ToListAsync();

                // ----------------------------------
                // 2. GET ACTIVE EVENTS
                // ----------------------------------

                var events = await db.DaySchedules
                    .AsNoTracking()
                    .Where(x => !x.IsDeleted)
                    .OrderBy(x => x.Date)
                    .ThenBy(x => x.StartTime)
                    .ThenBy(x => x.Id)
                    .ToListAsync();

                // ----------------------------------
                // 3. GET GUEST EVENT DRIVERS
                // ----------------------------------

                var guestDrivers =
                    new List<GuestEventDriver>();

                if (!string.IsNullOrWhiteSpace(email))
                {
                    guestDrivers =
                        await db.GuestEventDrivers
                            .AsNoTracking()
                            .Where(x =>
                                !x.IsDeleted &&
                                x.Email == email)
                            .ToListAsync();
                }

                // ----------------------------------
                // 4. GET AVAILABLE ICONS
                // ----------------------------------

                var icons = await db.BlurIcons
                    .AsNoTracking()
                    .Where(x => !x.IsDeleted)
                    .Select(x => x.Name)
                    .ToListAsync();

                var iconNames = new HashSet<string>(
                    icons.Where(x =>
                        !string.IsNullOrWhiteSpace(x)),
                    StringComparer.OrdinalIgnoreCase);

                // ----------------------------------
                // 5. PREPARE LOOKUPS
                // ----------------------------------

                var phaseByDate = phases
                    .GroupBy(x => x.Date.Date)
                    .ToDictionary(
                        x => x.Key,
                        x => x.First());

                var driverByEventId = guestDrivers
                    .GroupBy(x => x.DayScheduleId)
                    .ToDictionary(
                        x => x.Key,
                        x => x.First());

                var eventsByDate = events
                    .GroupBy(x => x.Date.Date)
                    .ToDictionary(
                        x => x.Key,
                        x => x.ToList());

                // Include dates having a phase
                // or at least one schedule event.
                var allDates = phaseByDate.Keys
                    .Union(eventsByDate.Keys)
                    .OrderBy(x => x)
                    .ToList();

                var results =
                    new List<Dictionary<string, object>>();

                // ----------------------------------
                // 6. BUILD ONE RESULT PER DATE
                // ----------------------------------

                foreach (var eventDate in allDates)
                {
                    Phase phase = null;

                    phaseByDate.TryGetValue(
                        eventDate,
                        out phase);

                    var row =
                        new Dictionary<string, object>();

                    row["EventDate"] =
                        eventDate.ToString(
                            "yyyy-MM-dd",
                            CultureInfo.InvariantCulture);

                    row["EventDay"] =
                        eventDate.ToString(
                            "dddd",
                            CultureInfo.InvariantCulture);

                    row["PhaseTitle"] =
                        phase == null
                            ? null
                            : phase.Title;

                    row["EventWelcomeMessage"] =
                        phase == null
                            ? null
                            : phase.EventWelcomeMessage;

                    row["EventSloganMessage"] =
                        phase == null
                            ? null
                            : phase.EventSloganMessage;

                    List<DaySchedule> dailyEvents;

                    if (!eventsByDate.TryGetValue(
                        eventDate,
                        out dailyEvents))
                    {
                        dailyEvents =
                            new List<DaySchedule>();
                    }

                    // ----------------------------------
                    // 7. LOOP THROUGH ALL DAILY EVENTS
                    // ----------------------------------

                    int eventNumber = 1;

                    foreach (var item in dailyEvents)
                    {
                        string prefix =
                            "Event" + eventNumber;

                        GuestEventDriver driver = null;

                        driverByEventId.TryGetValue(
                            item.Id,
                            out driver);

                        bool hasPhone =
                            driver != null &&
                            !string.IsNullOrWhiteSpace(
                                driver.DriverPhone);

                        bool hasWhatsApp =
                            hasPhone &&
                            driver.WhatsApp;

                        string iconName = null;

                        if (!string.IsNullOrWhiteSpace(
                            item.ItemType))
                        {
                            string candidate =
                                item.ItemType.Trim();

                            if (iconNames.Contains(candidate))
                            {
                                iconName = candidate;
                            }
                        }

                        row[prefix] = item.Title;

                        row[prefix + "BlurbIconName"] =
                            iconName;

                        row[prefix + "HasPhone"] =
                            hasPhone;

                        row[prefix + "HasWhatsApp"] =
                            hasWhatsApp;

                        row[prefix + "StartTime"] =
                            FormatTime(item.StartTime);

                        row[prefix + "EndTime"] =
                            FormatTime(item.EndTime);

                        row[prefix + "Description"] =
                            item.ShortNote;

                        row[prefix + "LocationName"] =
                            item.LocationName;

                        row[prefix + "LocationURL"] =
                            item.MapsLink;

                        eventNumber++;
                    }

                    results.Add(row);
                }

                return results;
            }
        }
    }
}
