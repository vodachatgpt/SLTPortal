using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Core.EntityClient;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using SLTProject.Data;

namespace SLTProject.Services
{
    // DB-first friendly outbox. SQL table in Database/20261109_OperationalAlerts.sql;
    // no EDMX regeneration required for this new table.
    public sealed class SltOperationalAlertsService
    {
        private static string ConnectionString()
        {
            using (var db = new SLTEntities())
            {
                var entity = db.Database.Connection as EntityConnection;
                if (entity != null) return entity.StoreConnection.ConnectionString;
                return db.Database.Connection.ConnectionString;
            }
        }

        private static SqlParameter P(string name, object value)
        {
            return new SqlParameter(name, value ?? DBNull.Value);
        }

        public static string Mode(string value)
        {
            string v = (value ?? "None").Trim();
            if (v.Equals("Automated", StringComparison.OrdinalIgnoreCase) || v.Equals("Immediate", StringComparison.OrdinalIgnoreCase)) return "Immediate";
            if (v.Equals("Scheduled", StringComparison.OrdinalIgnoreCase)) return "Scheduled";
            if (v.Equals("None", StringComparison.OrdinalIgnoreCase) || v.Equals("No", StringComparison.OrdinalIgnoreCase)) return "None";
            throw new ArgumentException("NotificationMode must be None, Immediate/Automated or Scheduled.");
        }

        public static string Channels(string value)
        {
            string v = (value ?? "Both").Trim();
            if (v.Equals("Push", StringComparison.OrdinalIgnoreCase)) return "Push";
            if (v.Equals("Sms", StringComparison.OrdinalIgnoreCase)) return "Sms";
            if (v.Equals("Both", StringComparison.OrdinalIgnoreCase)) return "Both";
            throw new ArgumentException("NotificationChannels must be Push, Sms or Both.");
        }

        public static bool Reminder(string value)
        {
            string v = (value ?? "No").Trim();
            return v.Equals("Yes", StringComparison.OrdinalIgnoreCase) || v.Equals("True", StringComparison.OrdinalIgnoreCase) || v == "1";
        }

        public static async Task EnqueueChangeAsync(string email, string category, string reference,
            string title, string text, string notificationMode, string channels)
        {
            string mode = Mode(notificationMode);
            if (mode == "None") return;
            await QueueAsync(email, category, reference + ":change", title, text,
                DateTime.UtcNow.AddMinutes(mode == "Scheduled" ? 15 : 0), Channels(channels));
            if (mode == "Immediate")
                await new SltOperationalAlertsService().ProcessDueAsync(CancellationToken.None);
        }

        public static async Task EnqueueReminderAsync(string email, long scheduleId,
            string title, DateTime eventLocalDate, TimeSpan? eventLocalStart, bool reminder, string channels)
        {
            string reference = "event:" + scheduleId + ":" + (email ?? "").Trim().ToLowerInvariant() + ":reminder";
            if (!reminder)
            {
                await CancelAsync(reference);
                return;
            }
            if (!eventLocalStart.HasValue)
                throw new ArgumentException("A schedule StartTime is required when Reminder is Yes.");
            var egypt = EgyptDateTimeService.TimeZone;
            DateTime local = DateTime.SpecifyKind(eventLocalDate.Date.Add(eventLocalStart.Value), DateTimeKind.Unspecified);
            if (egypt.IsInvalidTime(local)) throw new ArgumentException("Schedule StartTime falls in an invalid daylight-saving transition.");
            DateTime due = TimeZoneInfo.ConvertTimeToUtc(local, egypt).AddMinutes(-15);
            if (due <= DateTime.UtcNow) throw new ArgumentException("A reminder must be scheduled more than 15 minutes before the event.");
            await QueueAsync(email, "EVENT_REMINDER", reference,
                "Upcoming: " + title, "Reminder: " + title + " starts in 15 minutes.", due, Channels(channels));
        }

        private static async Task QueueAsync(string email, string category, string reference,
            string title, string text, DateTime dueUtc, string channels)
        {
            if (string.IsNullOrWhiteSpace(email)) throw new ArgumentException("Guest email is required.");
            if (reference.Length > 250) throw new ArgumentException("Notification reference is too long.");
            using (var connection = new SqlConnection(ConnectionString()))
            {
                await connection.OpenAsync();
                // Lock the key while superseding pending notifications. A sent notification is not recalled.
                using (var tx = connection.BeginTransaction(IsolationLevel.Serializable))
                {
                    using (var cmd = new SqlCommand(@"
UPDATE dbo.SltOperationalAlerts SET Status='Cancelled'
WHERE ReferenceKey=@ref AND Status='Pending';
INSERT dbo.SltOperationalAlerts
 (ReferenceKey, GuestEmail, Category, Channels, Title, MessageText, DueAtUtc, Status, CreatedAtUtc)
VALUES (@ref,@email,@category,@channels,@title,@text,@due,'Pending',SYSUTCDATETIME());", connection, tx))
                    {
                        cmd.Parameters.AddRange(new[] { P("@ref", reference), P("@email", email.Trim().ToLowerInvariant()),
                            P("@category", category), P("@channels", channels), P("@title", title),
                            P("@text", text), P("@due", dueUtc) });
                        await cmd.ExecuteNonQueryAsync();
                    }
                    tx.Commit();
                }
            }
        }

        private static async Task CancelAsync(string reference)
        {
            using (var connection = new SqlConnection(ConnectionString()))
            using (var cmd = new SqlCommand("UPDATE dbo.SltOperationalAlerts SET Status='Cancelled' WHERE ReferenceKey=@ref AND Status='Pending'", connection))
            {
                cmd.Parameters.Add(P("@ref", reference));
                await connection.OpenAsync();
                await cmd.ExecuteNonQueryAsync();
            }
        }

        private sealed class WorkItem
        {
            public long Id;
            public string Email, Category, Channels, Title, Message;
            public bool SmsAccepted, PushAccepted;
        }

        // Invoked by the IP-restricted SLT callback endpoint, called every minute by Global Hangfire.
        // Claiming the database queue remains atomic to prevent concurrent duplicate delivery.
        public async Task<object> ProcessDueAsync(CancellationToken token)
        {
            var work = new List<WorkItem>();
            using (var connection = new SqlConnection(ConnectionString()))
            {
                await connection.OpenAsync(token);
                using (var cmd = new SqlCommand(@"
;WITH due AS (
 SELECT TOP (25) * FROM dbo.SltOperationalAlerts WITH (UPDLOCK, READPAST, ROWLOCK)
 WHERE ((Status='Pending' AND DueAtUtc <= SYSUTCDATETIME())
     OR (Status='Processing' AND LastAttemptAtUtc < DATEADD(minute,-10,SYSUTCDATETIME())))
   AND Attempts < 4
 ORDER BY DueAtUtc, Id
)
UPDATE due SET Status='Processing', Attempts=Attempts+1, LastAttemptAtUtc=SYSUTCDATETIME()
OUTPUT inserted.Id,inserted.GuestEmail,inserted.Category,inserted.Channels,
       inserted.Title,inserted.MessageText,inserted.SmsAccepted,inserted.PushAccepted;", connection))
                using (var reader = await cmd.ExecuteReaderAsync(token))
                    while (await reader.ReadAsync(token))
                        work.Add(new WorkItem { Id = reader.GetInt64(0), Email = reader.GetString(1),
                            Category = reader.GetString(2), Channels = reader.GetString(3),
                            Title = reader.GetString(4), Message = reader.GetString(5),
                            SmsAccepted = reader.GetBoolean(6), PushAccepted = reader.GetBoolean(7) });
            }
            int sent = 0, retry = 0;
            foreach (var item in work)
            {
                string error = null;
                bool sms = item.SmsAccepted, push = item.PushAccepted;
                try
                {
                    using (var db = new SLTEntities())
                    {
                        var guest = await db.Guests.AsNoTracking().FirstOrDefaultAsync(
                            x => x.Email == item.Email && !x.IsDeleted, token);
                        if (guest == null) throw new InvalidOperationException("Guest is no longer active.");
                        if ((item.Channels == "Sms" || item.Channels == "Both") && !sms)
                        {
                            if (string.IsNullOrWhiteSpace(guest.PhoneNumber)) throw new InvalidOperationException("Guest phone number is missing.");
                            string templateKey = item.Category + "_SMS";
                            var template = await db.Set<SmsTemplate>().AsNoTracking()
                                .FirstOrDefaultAsync(x => x.TemplateKey == templateKey && x.IsActive, token);
                            if (template == null) throw new InvalidOperationException("SMS template missing: " + templateKey);
                            string body = template.TemplateBody.Replace("{FullName}", guest.FullName ?? "")
                                .Replace("{Title}", item.Title).Replace("{Message}", item.Message);
                            sms = await new SmsService().SendSmsAsync(guest.PhoneNumber, body);
                            if (!sms) throw new InvalidOperationException("SMS provider did not accept the message.");
                            await SetChannelAsync(item.Id, "SmsAccepted", token);
                        }
                        if ((item.Channels == "Push" || item.Channels == "Both") && !push)
                        {
                            if (!guest.FirstLoginAt.HasValue)
                                throw new InvalidOperationException("Guest has no active push identity yet.");
                            long adminId;
                            if (!long.TryParse(ConfigurationManager.AppSettings["SLTAutomationAdminId"], out adminId) || adminId <= 0)
                                throw new ConfigurationErrorsException("Configure SLTAutomationAdminId for the existing automation admin.");
                            var answer = await new SltNotificationsService().SendAsync(new SltNotificationSendInput {
                                TargetType="Guest", GuestId=guest.Id, Title=item.Title,
                                MessageText=item.Message, IdempotencyKey="slt-auto-" + item.Id.ToString(CultureInfo.InvariantCulture)
                            }, adminId, ConfigurationManager.AppSettings["SLTAutomationAdminEmail"] ?? "SLT-Automation", token);
                            // Inbox persistence is not proof that Web Push provider accepted delivery.
                            // A failed push remains eligible for the existing scheduled retry cycle.
                            push = answer.PushStatus == "Accepted";
                            if (!push) throw new InvalidOperationException("Browser push status: " + answer.PushStatus);
                            await SetChannelAsync(item.Id, "PushAccepted", token);
                        }
                    }
                }
                catch (Exception ex)
                {
                    error = ex.GetType().Name + ": " + ex.Message;
                    if (error.Length > 400) error = error.Substring(0, 400);
                    System.Diagnostics.Trace.TraceWarning("Operational alert " + item.Id + " failed: " + ex.GetType().Name);
                }
                bool complete = (item.Channels == "Sms" || sms) && (item.Channels == "Push" || push);
                using (var connection = new SqlConnection(ConnectionString()))
                using (var cmd = new SqlCommand(@"UPDATE dbo.SltOperationalAlerts SET
 Status=CASE WHEN @done=1 THEN 'Sent' WHEN Attempts>=4 THEN 'Failed' ELSE 'Pending' END,
 LastError=@error, CompletedAtUtc=CASE WHEN @done=1 THEN SYSUTCDATETIME() ELSE NULL END
 WHERE Id=@id", connection))
                {
                    cmd.Parameters.AddRange(new[] { P("@done", complete ? 1 : 0), P("@error", error), P("@id", item.Id) });
                    await connection.OpenAsync(token);
                    await cmd.ExecuteNonQueryAsync(token);
                }
                if (complete) sent++; else retry++;
            }
            return new { Claimed=work.Count, Completed=sent, PendingOrFailed=retry };
        }

        private static async Task SetChannelAsync(long id, string column, CancellationToken token)
        {
            // Column is one of two fixed internal literals, never user-supplied.
            if (column != "SmsAccepted" && column != "PushAccepted") throw new ArgumentException("Invalid channel flag.");
            using (var connection = new SqlConnection(ConnectionString()))
            using (var cmd = new SqlCommand("UPDATE dbo.SltOperationalAlerts SET " + column + "=1 WHERE Id=@id", connection))
            {
                cmd.Parameters.Add(P("@id", id));
                await connection.OpenAsync(token);
                await cmd.ExecuteNonQueryAsync(token);
            }
        }
    }
}
