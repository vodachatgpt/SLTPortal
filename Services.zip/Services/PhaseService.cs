﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using SLTProject.Data;

namespace SLTProject.Services
{
    // ============================================================
    // PHASE INPUT DTO
    // ============================================================

    public class PhaseInput
    {
        [Required(
            ErrorMessage = "Phase title is required.")]
        [StringLength(250)]
        public string Title { get; set; }

        [Required(
            ErrorMessage = "Phase date is required.")]
        public DateTime? Date { get; set; }

        public string EventWelcomeMessage { get; set; }

        public string EventSloganMessage { get; set; }
    }

    // ============================================================
    // PHASE RESPONSE DTO
    // ============================================================

    public class PhaseView
    {
        public long Id { get; set; }

        public string Title { get; set; }

        // Date-only business value.
        public DateTime Date { get; set; }

        public string EventWelcomeMessage { get; set; }

        public string EventSloganMessage { get; set; }

        // Egypt-local audit timestamps.
        public DateTime RetentionDateCreated { get; set; }

        public DateTime? RetentionDateModified { get; set; }

        public string CreatedBy { get; set; }

        public string ModifiedBy { get; set; }

        public bool IsDeleted { get; set; }

        public string DeletedBy { get; set; }

        public DateTime? DeletedAt { get; set; }
    }

    // ============================================================
    // PHASE SERVICE
    //
    // EF6 DATABASE FIRST
    // EGYPT LOCAL AUDIT DATE/TIME
    // ============================================================

    public class PhaseService
    {
        // ========================================================
        // EGYPT LOCAL DATE AND TIME
        // ========================================================

        private static DateTime NowEgypt
        {
            get
            {
                return EgyptDateTimeService.Now;
            }
        }

        // ========================================================
        // ENTITY TO DTO MAPPING
        // ========================================================

        private static PhaseView Map(
            Phase entity)
        {
            if (entity == null)
            {
                return null;
            }

            return new PhaseView
            {
                Id = entity.Id,

                Title = entity.Title,

                Date = entity.Date,

                EventWelcomeMessage =
                    entity.EventWelcomeMessage,

                EventSloganMessage =
                    entity.EventSloganMessage,

                RetentionDateCreated =
                    entity.RetentionDateCreated,

                RetentionDateModified =
                    entity.RetentionDateModified,

                CreatedBy = entity.CreatedBy,

                ModifiedBy = entity.ModifiedBy,

                IsDeleted = entity.IsDeleted,

                DeletedBy = entity.DeletedBy,

                DeletedAt = entity.DeletedAt
            };
        }

        // ========================================================
        // INPUT VALIDATION
        // ========================================================

        private static void Validate(
            PhaseInput input)
        {
            if (input == null)
            {
                throw new ArgumentException(
                    "Phase data is required.");
            }

            if (string.IsNullOrWhiteSpace(input.Title))
            {
                throw new ArgumentException(
                    "Phase title is required.");
            }

            if (input.Title.Trim().Length > 250)
            {
                throw new ArgumentException(
                    "Phase title must not exceed 250 characters.");
            }

            if (!input.Date.HasValue ||
                input.Date.Value == DateTime.MinValue)
            {
                throw new ArgumentException(
                    "Phase date is required.");
            }

            // SQL Server datetime supports dates from 1753.
            // Keep this validation for compatibility
            // with your existing database model.

            if (input.Date.Value.Date <
                new DateTime(1753, 1, 1))
            {
                throw new ArgumentException(
                    "Phase date is invalid.");
            }

            // Ensure dates are valid for the database.
            if (input.Date.Value.Date >
                new DateTime(9999, 12, 31))
            {
                throw new ArgumentException(
                    "Phase date is out of range.");
            }
        }

        // ========================================================
        // GET ALL ACTIVE PHASES
        //
        // No pagination.
        // Ordered by phase date.
        // ========================================================

        public async Task<List<PhaseView>>
            GetAllAsync()
        {
            using (var db = new SLTEntities())
            {
                var phases = await db.Phases
                    .AsNoTracking()
                    .Where(x => !x.IsDeleted)
                    .OrderBy(x => x.Date)
                    .ThenBy(x => x.Id)
                    .ToListAsync();

                return phases
                    .Select(Map)
                    .ToList();
            }
        }

        // ========================================================
        // GET ACTIVE PHASE BY ID
        // ========================================================

        public async Task<PhaseView> GetAsync(
            long id)
        {
            if (id <= 0)
            {
                return null;
            }

            using (var db = new SLTEntities())
            {
                var entity = await db.Phases
                    .AsNoTracking()
                    .FirstOrDefaultAsync(x =>
                        x.Id == id &&
                        !x.IsDeleted);

                return Map(entity);
            }
        }

        // ========================================================
        // CREATE PHASE
        // ========================================================

        public async Task<PhaseView> CreateAsync(
            PhaseInput input,
            string actor)
        {
            Validate(input);

            DateTime nowEgypt =
                NowEgypt;

            DateTime phaseDate =
                input.Date.Value.Date;

            using (var db = new SLTEntities())
            {
                var entity = new Phase
                {
                    Title =
                        input.Title.Trim(),

                    // Preserve the date selected
                    // by the administrator.
                    // Do not apply UTC conversion.
                    Date = phaseDate,

                    EventWelcomeMessage =
                        input.EventWelcomeMessage,

                    EventSloganMessage =
                        input.EventSloganMessage,

                    CreatedBy = actor,

                    RetentionDateCreated =
                        nowEgypt,

                    IsDeleted = false
                };

                db.Phases.Add(entity);

                await db.SaveChangesAsync();

                return Map(entity);
            }
        }

        // ========================================================
        // UPDATE PHASE
        // ========================================================

        public async Task<PhaseView> UpdateAsync(
            long id,
            PhaseInput input,
            string actor)
        {
            if (id <= 0)
            {
                return null;
            }

            Validate(input);

            using (var db = new SLTEntities())
            {
                var entity = await db.Phases
                    .FirstOrDefaultAsync(x =>
                        x.Id == id &&
                        !x.IsDeleted);

                if (entity == null)
                {
                    return null;
                }

                DateTime nowEgypt =
                    NowEgypt;

                entity.Title =
                    input.Title.Trim();

                // Phase date is a calendar date,
                // not a UTC timestamp.
                entity.Date =
                    input.Date.Value.Date;

                entity.EventWelcomeMessage =
                    input.EventWelcomeMessage;

                entity.EventSloganMessage =
                    input.EventSloganMessage;

                entity.ModifiedBy = actor;

                entity.RetentionDateModified =
                    nowEgypt;

                await db.SaveChangesAsync();

                return Map(entity);
            }
        }

        // ========================================================
        // SOFT DELETE PHASE
        // ========================================================

        public async Task<bool> DeleteAsync(
            long id,
            string actor)
        {
            if (id <= 0)
            {
                return false;
            }

            using (var db = new SLTEntities())
            {
                var entity = await db.Phases
                    .FirstOrDefaultAsync(x =>
                        x.Id == id &&
                        !x.IsDeleted);

                if (entity == null)
                {
                    return false;
                }

                DateTime nowEgypt =
                    NowEgypt;

                // ----------------------------------------
                // SOFT DELETE
                // ----------------------------------------

                entity.IsDeleted = true;

                entity.DeletedBy = actor;

                entity.DeletedAt = nowEgypt;

                // ----------------------------------------
                // UPDATE AUDIT INFORMATION
                // ----------------------------------------

                entity.ModifiedBy = actor;

                entity.RetentionDateModified =
                    nowEgypt;

                await db.SaveChangesAsync();

                return true;
            }
        }
    }
}
