using System;
using System.Configuration;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace SLTProject.Services
{
    // Reusable SLT SMS gateway. Uses the existing VCarRevamp payload contract.
    // Does not own SMS templates or recipients: GuestOperationsService supplies those.
    public sealed class SmsService
    {
        private static readonly HttpClient Client = new HttpClient
        {
            Timeout = TimeSpan.FromSeconds(25)
        };

        public async Task<bool> SendSmsAsync(string mobile, string message)
        {
            if (string.IsNullOrWhiteSpace(mobile))
                throw new ArgumentException("Recipient mobile is required.", "mobile");
            if (string.IsNullOrWhiteSpace(message))
                throw new ArgumentException("SMS message is required.", "message");
            string url = ConfigurationManager.AppSettings["SmsApiUrl"];
            string senderName = ConfigurationManager.AppSettings["SMSSenderName"];
            Uri endpoint;
            if (string.IsNullOrWhiteSpace(url) ||
                !Uri.TryCreate(url, UriKind.Absolute, out endpoint) ||
                endpoint.Scheme != Uri.UriSchemeHttps)
                throw new InvalidOperationException("Configure a valid HTTPS SmsApiUrl.");

            string json = JsonConvert.SerializeObject(new
            {
                from = senderName ?? "SLT",
                To = mobile,
                Message = message
            });

            using (var content = new StringContent(json, Encoding.UTF8, "application/json"))
            using (var response = await Client.PostAsync(endpoint, content).ConfigureAwait(false))
            {
                // 2xx = gateway accepted. Handset delivery must be verified
                // through the provider's delivery status/callback if supplied.
                return response.IsSuccessStatusCode;
            }
        }
    }
}
