﻿
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using SLTProject.Data;
using SLTProject.Models.Dtos;

namespace SLTProject.Services
{
    public class WeatherForecastService
    {
        // ========================================================
        // CONFIGURATION
        // ========================================================

        private const int RetentionMinutes = 60;
        private const int MaxBatchSize = 100;

        // ========================================================
        // EGYPT DATE AND TIME
        //
        // All new database timestamps are Egypt-local.
        //
        // IMPORTANT:
        // Existing database properties still end in "Utc".
        // They are retained for EDMX compatibility only.
        //
        // These columns must contain Egypt-local values
        // consistently after migration.
        // ========================================================

        private static DateTime EgyptNow
        {
            get
            {
                return EgyptDateTimeService.Now;
            }
        }

        private static DateTimeOffset EgyptNowWithOffset
        {
            get
            {
                return EgyptDateTimeService.NowWithOffset;
            }
        }

        // Calculate expiry using real elapsed minutes,
        // including periods when Egypt changes DST.

        private static DateTimeOffset CalculateExpiry(
            DateTimeOffset startedAt)
        {
            DateTimeOffset expiryUtc =
                startedAt.ToUniversalTime()
                    .AddMinutes(RetentionMinutes);

            return TimeZoneInfo.ConvertTime(
                expiryUtc,
                EgyptDateTimeService.TimeZone);
        }

        // Convert a stored Egypt-local datetime2 into
        // an offset-aware value for existing response DTOs.
        //
        // This relies on the Egypt timezone rules.
        // An ambiguous autumn clock-change time cannot
        // always recover its original offset from datetime2.

        private static DateTimeOffset ToEgyptOffset(
            DateTime egyptLocal)
        {
            DateTime local = DateTime.SpecifyKind(
                egyptLocal,
                DateTimeKind.Unspecified);

            TimeSpan offset =
                EgyptDateTimeService.TimeZone
                    .GetUtcOffset(local);

            return new DateTimeOffset(
                local,
                offset);
        }

        private static DateTimeOffset? ToEgyptOffset(
            DateTime? egyptLocal)
        {
            if (!egyptLocal.HasValue)
            {
                return null;
            }

            return ToEgyptOffset(
                egyptLocal.Value);
        }

        // ========================================================
        // VALIDATE COORDINATES
        // ========================================================

        private static void ValidateCoordinates(
            decimal latitude,
            decimal longitude)
        {
            if (latitude < -90 || latitude > 90)
            {
                throw new ArgumentException(
                    "Latitude must be between -90 and 90.");
            }

            if (longitude < -180 || longitude > 180)
            {
                throw new ArgumentException(
                    "Longitude must be between -180 and 180.");
            }
        }

        // ========================================================
        // VALIDATE WEATHER VALUES
        // ========================================================

        private static void ValidateWeatherValues(
            decimal? max,
            decimal? min,
            int? code,
            decimal? precipitation,
            decimal? wind)
        {
            if (max.HasValue &&
                (max.Value < -100 || max.Value > 70))
            {
                throw new ArgumentException(
                    "Invalid maximum temperature.");
            }

            if (min.HasValue &&
                (min.Value < -100 || min.Value > 70))
            {
                throw new ArgumentException(
                    "Invalid minimum temperature.");
            }

            if (max.HasValue &&
                min.HasValue &&
                max.Value < min.Value)
            {
                throw new ArgumentException(
                    "Maximum temperature cannot be below minimum.");
            }

            if (code.HasValue &&
                (code.Value < 0 || code.Value > 99))
            {
                throw new ArgumentException(
                    "Invalid weather code.");
            }

            if (precipitation.HasValue &&
                (precipitation.Value < 0 ||
                 precipitation.Value > 99999999))
            {
                throw new ArgumentException(
                    "Invalid precipitation.");
            }

            if (wind.HasValue &&
                (wind.Value < 0 ||
                 wind.Value > 999999))
            {
                throw new ArgumentException(
                    "Invalid wind speed.");
            }
        }

        // ========================================================
        // VALIDATE ONE FORECAST DAY
        //
        // Preserves existing Open-Meteo input DTO structure.
        // ========================================================

        private static DateTime ValidateInput(
            WeatherForecastInput input)
        {
            if (input == null)
            {
                throw new ArgumentException(
                    "Forecast data is required.");
            }

            ValidateCoordinates(
                input.Latitude,
                input.Longitude);

            if (input.LocationName != null &&
                input.LocationName.Length > 150)
            {
                throw new ArgumentException(
                    "Location name exceeds 150 characters.");
            }

            if (string.IsNullOrWhiteSpace(input.TimeZone) ||
                input.TimeZone.Length > 100)
            {
                throw new ArgumentException(
                    "Valid timezone is required.");
            }

            if (input.Daily == null)
            {
                throw new ArgumentException(
                    "Daily weather is required.");
            }

            var daily = input.Daily;

            if (daily.Time == null ||
                daily.Time.Count != 1)
            {
                throw new ArgumentException(
                    "Exactly one forecast day is required.");
            }

            if (daily.MaxTemperature == null)
            {
                throw new ArgumentException(
                    "Daily.MaxTemperature is missing.");
            }

            if (daily.MinTemperature == null)
            {
                throw new ArgumentException(
                    "Daily.MinTemperature is missing.");
            }

            if (daily.WeatherCode == null)
            {
                throw new ArgumentException(
                    "Daily.WeatherCode is missing.");
            }

            if (daily.Precipitation == null)
            {
                throw new ArgumentException(
                    "Daily.Precipitation is missing.");
            }

            if (daily.MaxWindSpeed == null)
            {
                throw new ArgumentException(
                    "Daily.MaxWindSpeed is missing.");
            }

            if (daily.MaxTemperature.Count != 1 ||
                daily.MinTemperature.Count != 1 ||
                daily.WeatherCode.Count != 1 ||
                daily.Precipitation.Count != 1 ||
                daily.MaxWindSpeed.Count != 1)
            {
                throw new ArgumentException(
                    "Every daily array must contain " +
                    "exactly one value.");
            }

            DateTime forecastDate;

            if (!DateTime.TryParseExact(
                daily.Time[0],
                "yyyy-MM-dd",
                CultureInfo.InvariantCulture,
                DateTimeStyles.None,
                out forecastDate))
            {
                throw new ArgumentException(
                    "Invalid forecast date. Use yyyy-MM-dd.");
            }

            ValidateWeatherValues(
                daily.MaxTemperature[0],
                daily.MinTemperature[0],
                daily.WeatherCode[0],
                daily.Precipitation[0],
                daily.MaxWindSpeed[0]);

            return forecastDate.Date;
        }

        // ========================================================
        // MAP ENTITY TO RESPONSE DTO
        //
        // Database values are already Egypt-local.
        // Do not convert them from UTC again.
        // ========================================================

        private static WeatherForecastRow Map(
            WeatherForecast entity)
        {
            if (entity == null)
            {
                return null;
            }

            return new WeatherForecastRow
            {
                Id = entity.Id,

                BatchId = entity.BatchId,

                LocationName = entity.LocationName,

                Latitude = entity.Latitude,
                Longitude = entity.Longitude,

                ForecastDate = entity.ForecastDate,

                MaxTemperatureC =
                    entity.MaxTemperatureC,

                MinTemperatureC =
                    entity.MinTemperatureC,

                WeatherCode =
                    entity.WeatherCode,

                PrecipitationMm =
                    entity.PrecipitationMm,

                MaxWindSpeedKmh =
                    entity.MaxWindSpeedKmh,

                TimeZone = entity.TimeZone,

                // No UTC-to-Cairo conversion here.
                // These values are stored in Cairo time.

                FetchedAt = ToEgyptOffset(
                    entity.FetchedAtUtc),

                ExpiresAt = ToEgyptOffset(
                    entity.ExpiresAtUtc),

                ModifiedAt = ToEgyptOffset(
                    entity.ModifiedAtUtc),

                CreatedBy = entity.CreatedBy,
                ModifiedBy = entity.ModifiedBy
            };
        }

        // ========================================================
        // BUILD A WEATHER FORECAST ENTITY
        //
        // Shared by SaveAsync and SaveBatchAsync.
        // ========================================================

        private static WeatherForecast BuildEntity(
            WeatherForecastInput input,
            DateTime forecastDate,
            Guid batchId,
            DateTime fetchedAtEgypt,
            DateTime expiresAtEgypt,
            string actor)
        {
            var daily = input.Daily;

            return new WeatherForecast
            {
                BatchId = batchId,

                LocationName =
                    string.IsNullOrWhiteSpace(
                        input.LocationName)
                        ? null
                        : input.LocationName.Trim(),

                Latitude = input.Latitude,
                Longitude = input.Longitude,

                ForecastDate = forecastDate,

                MaxTemperatureC =
                    daily.MaxTemperature[0],

                MinTemperatureC =
                    daily.MinTemperature[0],

                WeatherCode =
                    daily.WeatherCode[0],

                PrecipitationMm =
                    daily.Precipitation[0],

                MaxWindSpeedKmh =
                    daily.MaxWindSpeed[0],

                TimeZone = input.TimeZone.Trim(),

                // These EF properties retain their old
                // names but now contain Egypt-local time.

                FetchedAtUtc = fetchedAtEgypt,
                ExpiresAtUtc = expiresAtEgypt,

                CreatedBy = actor
            };
        }

        // ========================================================
        // SAVE ONE FORECAST DAY
        // ========================================================

        public async Task<WeatherForecastSaveResult>
            SaveAsync(
                WeatherForecastInput input,
                string actor)
        {
            DateTime forecastDate =
                ValidateInput(input);

            DateTimeOffset nowEgypt =
                EgyptNowWithOffset;

            DateTimeOffset expiresEgypt =
                CalculateExpiry(nowEgypt);

            Guid batchId =
                Guid.NewGuid();

            var entity = BuildEntity(
                input,
                forecastDate,
                batchId,
                nowEgypt.DateTime,
                expiresEgypt.DateTime,
                actor);

            using (var db = new SLTEntities())
            {
                db.WeatherForecasts.Add(entity);

                await db.SaveChangesAsync();
            }

            return new WeatherForecastSaveResult
            {
                BatchId = batchId,

                SavedRecords = 1,

                FetchedAt = nowEgypt,

                ExpiresAt = expiresEgypt,

                Message =
                    "Weather forecast saved successfully."
            };
        }

        // ========================================================
        // SAVE MULTIPLE FORECAST RECORDS
        //
        // Every item contains one forecast day.
        // Maximum 100 items per batch.
        // ========================================================

        public async Task<WeatherForecastBatchResult>
            SaveBatchAsync(
                WeatherForecastBatchInput input,
                string actor)
        {
            if (input == null ||
                input.Items == null ||
                input.Items.Count == 0)
            {
                throw new ArgumentException(
                    "At least one weather record is required.");
            }

            if (input.Items.Count > MaxBatchSize)
            {
                throw new ArgumentException(
                    "Maximum 100 weather records per batch.");
            }

            Guid batchId =
                Guid.NewGuid();

            DateTimeOffset nowEgypt =
                EgyptNowWithOffset;

            DateTimeOffset expiresEgypt =
                CalculateExpiry(nowEgypt);

            var entities =
                new List<WeatherForecast>();

            foreach (var item in input.Items)
            {
                // Each item must contain one day only.
                DateTime forecastDate =
                    ValidateInput(item);

                var entity = BuildEntity(
                    item,
                    forecastDate,
                    batchId,
                    nowEgypt.DateTime,
                    expiresEgypt.DateTime,
                    actor);

                entities.Add(entity);
            }

            using (var db = new SLTEntities())
            {
                db.WeatherForecasts.AddRange(
                    entities);

                await db.SaveChangesAsync();

                return new WeatherForecastBatchResult
                {
                    BatchId = batchId,

                    SavedRecords = entities.Count,

                    FetchedAt = nowEgypt,

                    ExpiresAt = expiresEgypt,

                    RecordIds = entities
                        .Select(x => x.Id)
                        .ToList(),

                    Message =
                        "Weather forecast batch saved successfully."
                };
            }
        }

        // ========================================================
        // GET ALL ACTIVE FORECASTS
        //
        // No pagination.
        // Optional latitude / longitude filters.
        // ========================================================

        public async Task<List<WeatherForecastRow>>
            GetAllAsync(
                decimal? latitude = null,
                decimal? longitude = null)
        {
            if (latitude.HasValue &&
                (latitude.Value < -90 ||
                 latitude.Value > 90))
            {
                throw new ArgumentException(
                    "Invalid latitude.");
            }

            if (longitude.HasValue &&
                (longitude.Value < -180 ||
                 longitude.Value > 180))
            {
                throw new ArgumentException(
                    "Invalid longitude.");
            }

            DateTime nowEgypt =
                EgyptNow;

            using (var db = new SLTEntities())
            {
                var query =
                    db.WeatherForecasts
                        .AsNoTracking()
                        .Where(x =>
                            x.ExpiresAtUtc > nowEgypt);

                if (latitude.HasValue)
                {
                    decimal lat = latitude.Value;

                    query = query.Where(x =>
                        x.Latitude == lat);
                }

                if (longitude.HasValue)
                {
                    decimal lon = longitude.Value;

                    query = query.Where(x =>
                        x.Longitude == lon);
                }

                var records = await query
                    .OrderByDescending(
                        x => x.FetchedAtUtc)
                    .ThenBy(
                        x => x.ForecastDate)
                    .ThenByDescending(
                        x => x.Id)
                    .ToListAsync();

                return records
                    .Select(Map)
                    .ToList();
            }
        }

        // ========================================================
        // GET BY ID
        //
        // Only active, non-expired records.
        // ========================================================

        public async Task<WeatherForecastRow>
            GetByIdAsync(long id)
        {
            if (id <= 0)
            {
                return null;
            }

            DateTime nowEgypt =
                EgyptNow;

            using (var db = new SLTEntities())
            {
                var entity =
                    await db.WeatherForecasts
                        .AsNoTracking()
                        .FirstOrDefaultAsync(x =>
                            x.Id == id &&
                            x.ExpiresAtUtc > nowEgypt);

                return Map(entity);
            }
        }

        // ========================================================
        // GET LATEST FORECAST BATCH FOR A LOCATION
        // ========================================================

        public async Task<List<WeatherForecastRow>>
            GetLatestAsync(
                decimal latitude,
                decimal longitude)
        {
            ValidateCoordinates(
                latitude,
                longitude);

            DateTime nowEgypt =
                EgyptNow;

            using (var db = new SLTEntities())
            {
                var latest =
                    await db.WeatherForecasts
                        .AsNoTracking()
                        .Where(x =>
                            x.Latitude == latitude &&
                            x.Longitude == longitude &&
                            x.ExpiresAtUtc > nowEgypt)
                        .OrderByDescending(
                            x => x.FetchedAtUtc)
                        .ThenByDescending(
                            x => x.Id)
                        .FirstOrDefaultAsync();

                if (latest == null)
                {
                    return new List<WeatherForecastRow>();
                }

                var records =
                    await db.WeatherForecasts
                        .AsNoTracking()
                        .Where(x =>
                            x.BatchId == latest.BatchId &&
                            x.ExpiresAtUtc > nowEgypt)
                        .OrderBy(
                            x => x.ForecastDate)
                        .ToListAsync();

                return records
                    .Select(Map)
                    .ToList();
            }
        }

        // ========================================================
        // UPDATE WEATHER FORECAST
        //
        // Preserves existing method signature.
        // Modified timestamp is Egypt-local.
        // ========================================================

        public async Task<WeatherForecastRow>
            UpdateAsync(
                long id,
                WeatherForecastUpdateInput input,
                string actor)
        {
            if (input == null)
            {
                throw new ArgumentException(
                    "Update data is required.");
            }

            if (id <= 0)
            {
                return null;
            }

            ValidateWeatherValues(
                input.MaxTemperatureC,
                input.MinTemperatureC,
                input.WeatherCode,
                input.PrecipitationMm,
                input.MaxWindSpeedKmh);

            DateTime nowEgypt =
                EgyptNow;

            using (var db = new SLTEntities())
            {
                var entity =
                    await db.WeatherForecasts
                        .FirstOrDefaultAsync(x =>
                            x.Id == id &&
                            x.ExpiresAtUtc > nowEgypt);

                if (entity == null)
                {
                    return null;
                }

                entity.MaxTemperatureC =
                    input.MaxTemperatureC;

                entity.MinTemperatureC =
                    input.MinTemperatureC;

                entity.WeatherCode =
                    input.WeatherCode;

                entity.PrecipitationMm =
                    input.PrecipitationMm;

                entity.MaxWindSpeedKmh =
                    input.MaxWindSpeedKmh;

                // Egypt-local modification timestamp.
                entity.ModifiedAtUtc = nowEgypt;

                entity.ModifiedBy = actor;

                await db.SaveChangesAsync();

                return Map(entity);
            }
        }

        // ========================================================
        // DELETE FORECAST BY ID
        //
        // Physical deletion preserved from original service.
        // ========================================================

        public async Task<bool>
            DeleteAsync(long id)
        {
            if (id <= 0)
            {
                return false;
            }

            using (var db = new SLTEntities())
            {
                var entity =
                    await db.WeatherForecasts
                        .FirstOrDefaultAsync(
                            x => x.Id == id);

                if (entity == null)
                {
                    return false;
                }

                db.WeatherForecasts.Remove(entity);

                await db.SaveChangesAsync();

                return true;
            }
        }

        // ========================================================
        // DELETE ALL EXPIRED FORECASTS
        //
        // Can be called hourly by Hangfire.
        // Uses Egypt-local expiry comparisons.
        // ========================================================

        public async Task<int>
            DeleteExpiredAsync()
        {
            DateTime nowEgypt =
                EgyptNow;

            using (var db = new SLTEntities())
            {
                var expired =
                    await db.WeatherForecasts
                        .Where(x =>
                            x.ExpiresAtUtc <= nowEgypt)
                        .ToListAsync();

                if (expired.Count == 0)
                {
                    return 0;
                }

                db.WeatherForecasts.RemoveRange(
                    expired);

                await db.SaveChangesAsync();

                return expired.Count;
            }
        }
    }
}
