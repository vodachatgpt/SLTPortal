using System.Diagnostics;

namespace SLTProject.Services
{
    // Compatibility shim ONLY for projects where Global.asax still calls Start/Stop.
    // Global Hangfire now owns the recurring job, exactly as in Weather cleanup.
    // Remove calls to this class from Global.asax after deployment.
    [System.Obsolete("Use SltOperationalAlertsSchedulerService with Global Hangfire; no local Hangfire server is needed.")]
    public static class SltOperationalHangfireBootstrapper
    {
        public static void Start() { Trace.TraceInformation("SLT Alerts: local Hangfire disabled; register the Global Hangfire job via configure-scheduler."); }
        public static void Stop() { }
    }
}
