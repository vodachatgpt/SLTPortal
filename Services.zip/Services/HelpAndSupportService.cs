﻿
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using SLTProject.Data;
using SLTProject.Models.Dtos;

namespace SLTProject.Services
{
    // ============================================================
    // HELP AND SUPPORT SERVICE
    // EF6 DATABASE FIRST
    // EGYPT LOCAL DATE & TIME
    // ============================================================

    public class HelpAndSupportService
    {
        private const int MaxFieldLength = 100000;

        // ========================================================
        // EGYPT DATE & TIME
        // ========================================================

        private static DateTime NowEgypt
        {
            get
            {
                return EgyptDateTimeService.Now;
            }
        }

        // ========================================================
        // VALIDATE INPUT
        // ========================================================

        private static void ValidateInput(
            HelpAndSupportInput input)
        {
            if (input == null)
            {
                throw new ArgumentException(
                    "Help and support data is required.");
            }

            bool isEmpty =
                string.IsNullOrWhiteSpace(
                    input.EventContact) &&
                string.IsNullOrWhiteSpace(
                    input.Transportation) &&
                string.IsNullOrWhiteSpace(
                    input.Emergency) &&
                string.IsNullOrWhiteSpace(
                    input.HealthandSafety);

            if (isEmpty)
            {
                throw new ArgumentException(
                    "At least one support field is required.");
            }

            ValidateField(
                input.EventContact,
                "EventContact");

            ValidateField(
                input.Transportation,
                "Transportation");

            ValidateField(
                input.Emergency,
                "Emergency");

            ValidateField(
                input.HealthandSafety,
                "HealthandSafety");
        }

        // ========================================================
        // VALIDATE FIELD LENGTH
        // ========================================================

        private static void ValidateField(
            string value,
            string fieldName)
        {
            if (value != null &&
                value.Length > MaxFieldLength)
            {
                throw new ArgumentException(
                    fieldName +
                    " exceeds the maximum allowed size of " +
                    MaxFieldLength + " characters.");
            }
        }

        // ========================================================
        // CLEAN INPUT
        // ========================================================

        private static string Clean(
            string value)
        {
            return string.IsNullOrWhiteSpace(value)
                ? null
                : value.Trim();
        }

        // ========================================================
        // MAP ENTITY TO DTO
        // ========================================================

        private static HelpAndSupportDto Map(
            HelpAndSupport entity)
        {
            if (entity == null)
            {
                return null;
            }

            return new HelpAndSupportDto
            {
                Id = entity.Id,

                EventContact =
                    entity.EventContact,

                Transportation =
                    entity.Transportation,

                Emergency =
                    entity.Emergency,

                HealthandSafety =
                    entity.HealthandSafety,

                CreatedAt =
                    entity.CreatedAt,

                CreatedBy =
                    entity.CreatedBy,

                ModifiedAt =
                    entity.ModifiedAt,

                ModifiedBy =
                    entity.ModifiedBy,

                IsDeleted =
                    entity.IsDeleted,

                DeletedAt =
                    entity.DeletedAt,

                DeletedBy =
                    entity.DeletedBy,

                RetentionDateCreated =
                    entity.RetentionDateCreated,

                RetentionDateModified =
                    entity.RetentionDateModified
            };
        }

        // ========================================================
        // CREATE HELP & SUPPORT
        // ========================================================

        public async Task<HelpAndSupportDto> CreateAsync(
            HelpAndSupportInput input,
            string actor)
        {
            ValidateInput(input);

            DateTime nowEgypt =
                NowEgypt;

            var entity = new HelpAndSupport
            {
                EventContact =
                    Clean(input.EventContact),

                Transportation =
                    Clean(input.Transportation),

                Emergency =
                    Clean(input.Emergency),

                HealthandSafety =
                    Clean(input.HealthandSafety),

                CreatedAt = nowEgypt,

                CreatedBy = actor,

                IsDeleted = false,

                RetentionDateCreated = nowEgypt
            };

            using (var db = new SLTEntities())
            {
                db.HelpAndSupports.Add(entity);

                await db.SaveChangesAsync();

                return Map(entity);
            }
        }

        // ========================================================
        // GET ALL HELP & SUPPORT
        // NO PAGINATION
        // ========================================================

        public async Task<List<HelpAndSupportDto>>
            GetAllAsync()
        {
            using (var db = new SLTEntities())
            {
                var records =
                    await db.HelpAndSupports
                        .AsNoTracking()
                        .Where(
                            x => !x.IsDeleted)
                        .OrderByDescending(
                            x => x.CreatedAt)
                        .ThenByDescending(
                            x => x.Id)
                        .ToListAsync();

                return records
                    .Select(Map)
                    .ToList();
            }
        }

        // ========================================================
        // GET HELP & SUPPORT BY ID
        // ========================================================

        public async Task<HelpAndSupportDto>
            GetByIdAsync(long id)
        {
            if (id <= 0)
            {
                return null;
            }

            using (var db = new SLTEntities())
            {
                var entity =
                    await db.HelpAndSupports
                        .AsNoTracking()
                        .FirstOrDefaultAsync(
                            x =>
                                x.Id == id &&
                                !x.IsDeleted);

                return Map(entity);
            }
        }

        // ========================================================
        // UPDATE HELP & SUPPORT
        // ========================================================

        public async Task<HelpAndSupportDto> UpdateAsync(
            long id,
            HelpAndSupportInput input,
            string actor)
        {
            if (id <= 0)
            {
                return null;
            }

            ValidateInput(input);

            using (var db = new SLTEntities())
            {
                var entity =
                    await db.HelpAndSupports
                        .FirstOrDefaultAsync(
                            x =>
                                x.Id == id &&
                                !x.IsDeleted);

                if (entity == null)
                {
                    return null;
                }

                DateTime nowEgypt =
                    NowEgypt;

                entity.EventContact =
                    Clean(input.EventContact);

                entity.Transportation =
                    Clean(input.Transportation);

                entity.Emergency =
                    Clean(input.Emergency);

                entity.HealthandSafety =
                    Clean(input.HealthandSafety);

                entity.ModifiedAt = nowEgypt;

                entity.ModifiedBy = actor;

                entity.RetentionDateModified =
                    nowEgypt;

                await db.SaveChangesAsync();

                return Map(entity);
            }
        }

        // ========================================================
        // SOFT DELETE HELP & SUPPORT
        // ========================================================

        public async Task<bool> DeleteAsync(
            long id,
            string actor)
        {
            if (id <= 0)
            {
                return false;
            }

            using (var db = new SLTEntities())
            {
                var entity =
                    await db.HelpAndSupports
                        .FirstOrDefaultAsync(
                            x =>
                                x.Id == id &&
                                !x.IsDeleted);

                if (entity == null)
                {
                    return false;
                }

                DateTime nowEgypt =
                    NowEgypt;

                // Soft delete
                entity.IsDeleted = true;

                entity.DeletedAt = nowEgypt;

                entity.DeletedBy = actor;

                // Modification audit
                entity.ModifiedAt = nowEgypt;

                entity.ModifiedBy = actor;

                entity.RetentionDateModified =
                    nowEgypt;

                await db.SaveChangesAsync();

                return true;
            }
        }
    }
}
