using System;
using System.Diagnostics;
using System.Threading.Tasks;
namespace SLTProject.Services
{
    // Avoid reporting an already committed CRUD operation as failed if notification queuing fails.
    // Errors are always logged; monitor logs and retry using the admin outbox.
    public static class SltAlertHookRunner
    {
        public static async Task TryAsync(Func<Task> operation)
        {
            try { await operation(); }
            catch (Exception ex) { Trace.TraceError("Operational alert queue failed: " + ex.GetType().Name + " " + ex.Message); }
        }
    }
}
