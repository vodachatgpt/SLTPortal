﻿
using System;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using SLTProject.Data;

namespace SLTProject.Services
{
    internal static class AdminLocalRecovery
    {
#if DEBUG
        public static async Task RecoverAsync(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                throw new ArgumentException("Email is required.");

            string normalizedEmail =
                email.Trim().ToLowerInvariant();

            long adminId;

            using (var db = new SLTEntities())
            {
                var admin = await db.Admins
                    .AsNoTracking()
                    .FirstOrDefaultAsync(x =>
                        x.Email == normalizedEmail &&
                        !x.IsDeleted &&
                        x.IsActive);

                if (admin == null)
                    throw new InvalidOperationException(
                        "Active administrator not found.");

                adminId = admin.Id;
            }

            var service = new AdminService();

            string newPasscode =
                await service.ResetPasscodeAsync(
                    adminId,
                    "LocalAdminRecovery");

            if (string.IsNullOrEmpty(newPasscode))
                throw new InvalidOperationException(
                    "Passcode reset failed.");

            Debug.WriteLine(
                "ADMIN RECOVERY PASSCODE: " + newPasscode);
        }
#endif
    }
}
