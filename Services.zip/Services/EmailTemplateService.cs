﻿
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web;
using System.Web.Configuration;
using System.Web.Script.Serialization;
using SLTProject.Models;
using SLTProject.Data;

namespace SLTProject.Services
{
    public class EmailTemplateService
    {
        private static readonly HttpClient _httpClient =
            new HttpClient
            {
                Timeout = TimeSpan.FromSeconds(60)
            };

        public static readonly string[] RequiredTemplateKeys =
        {
            "GUEST_WELCOME",
            "GUEST_INVITATION",
            "GUEST_PASSCODE_RESET",
            "ADMIN_WELCOME",
            "ADMIN_PASSCODE_RESET"
        };

        private static string Config(string key)
        {
            var value = WebConfigurationManager.AppSettings[key];

            if (string.IsNullOrWhiteSpace(value))
                throw new ConfigurationErrorsException(
                    "Missing Web.config setting: " + key);

            return value.Trim();
        }

        private static string NormalizeKey(string key)
        {
            return (key ?? "").Trim().ToUpperInvariant();
        }

        public static bool IsRequiredTemplate(string key)
        {
            string normalized = NormalizeKey(key);

            foreach (var item in RequiredTemplateKeys)
            {
                if (item.Equals(
                    normalized,
                    StringComparison.OrdinalIgnoreCase))
                    return true;
            }

            return false;
        }

        private static string GetPortalUrl(string templateKey)
        {
            string configKey = templateKey.StartsWith(
                "ADMIN_", StringComparison.OrdinalIgnoreCase)
                ? "SLTAdminPortalUrl"
                : "SLTGuestPortalUrl";

            string url = Config(configKey);

            Uri uri;

            if (!Uri.TryCreate(url, UriKind.Absolute, out uri) ||
                uri.Scheme != Uri.UriSchemeHttps)
                throw new ConfigurationErrorsException(
                    configKey + " must be an HTTPS URL.");

            return url;
        }

        private static string ReplaceTokens(
            string template,
            IDictionary<string, string> values,
            bool isHtml)
        {
            return Regex.Replace(
                template ?? string.Empty,
                @"\{\{([A-Za-z][A-Za-z0-9]*)\}\}",
                match =>
                {
                    string key = match.Groups[1].Value;
                    string value;

                    if (!values.TryGetValue(key, out value))
                        throw new InvalidOperationException(
                            "Unsupported email placeholder: " + key);

                    value = value ?? string.Empty;

                    if (!isHtml)
                    {
                        return value.Replace("\r", " ")
                                    .Replace("\n", " ");
                    }

                    // PortalUrl is used in an HTML href attribute.
                    // This value is validated before replacement.
                    if (key.Equals(
                        "PortalUrl",
                        StringComparison.OrdinalIgnoreCase))
                        return HttpUtility.HtmlAttributeEncode(value);

                    return HttpUtility.HtmlEncode(value);
                },
                RegexOptions.CultureInvariant,
                TimeSpan.FromSeconds(2));
        }

        public async Task<bool> SendEmailViaApiAsync(
            string toEmail,
            string subject,
            string body,
            string ccTo = null)
        {
            string url = Config("MailApiUrl");

            var emailDto = new
            {
                SendEmailTo = toEmail,
                CcTo = ccTo ??
                    WebConfigurationManager.AppSettings[
                        "EmailService.CcTo"] ?? string.Empty,

                EmailSubject = subject,
                EmailBody = body
               

            };

            var serializer = new JavaScriptSerializer();
            string json = serializer.Serialize(emailDto);

            using (var content = new StringContent(
                json, Encoding.UTF8, "application/json"))
            using (var response = await _httpClient.PostAsync(
                url, content))
            {
                // Do not log the outgoing JSON. It may contain
                // newly issued guest or admin passcodes.
                return response.IsSuccessStatusCode;
            }
        }

        public async Task<bool> SendAsync(
            string templateKey,
            string recipientEmail,
            string fullName,
            string passcode,
            string ccTo = null)
        {
            string key = NormalizeKey(templateKey);

            if (string.IsNullOrWhiteSpace(key))
                throw new ArgumentException(
                    "Template key is required.");

            if (string.IsNullOrWhiteSpace(recipientEmail))
                throw new ArgumentException(
                    "Recipient email is required.");

            if (string.IsNullOrWhiteSpace(passcode) && key != "GUEST_INVITATION")
                throw new ArgumentException("Newly generated passcode is required.");

            string subject;
            string body;

            using (var db = new SLTEntities())
            {
                var template = await db.EmailTemplates
                    .AsNoTracking()
                    .FirstOrDefaultAsync(x =>
                        x.TemplateKey == key &&
                        x.IsActive &&
                        !x.IsDeleted);

                if (template == null)
                    throw new InvalidOperationException(
                        "Email template not found or inactive: " +
                        key);

                if (key == "GUEST_INVITATION" &&
                    (template.Subject ?? "").IndexOf("{{Passcode}}", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    key == "GUEST_INVITATION" &&
                    (template.BodyHtml ?? "").IndexOf("{{Passcode}}", StringComparison.OrdinalIgnoreCase) >= 0)
                    throw new InvalidOperationException("Invitation templates must not include a passcode.");

                if (key == "GUEST_INVITATION" &&
                    (template.BodyHtml ?? "").IndexOf("{{PortalUrl}}", StringComparison.OrdinalIgnoreCase) < 0)
                    throw new InvalidOperationException("Invitation email must contain {{PortalUrl}}.");

                string portalUrl = GetPortalUrl(key);

                var values = new Dictionary<string, string>(
                    StringComparer.OrdinalIgnoreCase)
                {
                    { "FullName", fullName ?? string.Empty },
                    { "Email", recipientEmail },
                    { "Passcode", passcode ?? string.Empty },
                    { "PortalUrl", portalUrl }
                };

                subject = ReplaceTokens(
                    template.Subject,
                    values,
                    false);

                body = ReplaceTokens(
                    template.BodyHtml,
                    values,
                    true);
            }

            return await SendEmailViaApiAsync(
                recipientEmail,
                subject,
                body,
                ccTo);
        }

        // Generate a safe email preview using sample values.
        // This does NOT send any email or expose real passcodes.
        public async Task<EmailPreviewResult> PreviewAsync(
            long templateId)
        {
            using (var db = new SLTEntities())
            {
                var template = await db.EmailTemplates
                    .AsNoTracking()
                    .FirstOrDefaultAsync(x =>
                        x.Id == templateId &&
                        !x.IsDeleted);

                if (template == null)
                    return null;

                string portalUrl = GetPortalUrl(
                    template.TemplateKey);

                var values = new Dictionary<string, string>(
                    StringComparer.OrdinalIgnoreCase)
                {
                    { "FullName", "Sample Guest" },
                    { "Email", "sample@example.com" },
                    { "Passcode", "ABCD2345EFGH" },
                    { "PortalUrl", portalUrl }
                };

                return new EmailPreviewResult
                {
                    TemplateKey = template.TemplateKey,
                    Subject = ReplaceTokens(
                        template.Subject, values, false),
                    BodyHtml = ReplaceTokens(
                        template.BodyHtml, values, true)
                };
            }
        }
    }

    public class EmailPreviewResult
    {
        public string TemplateKey { get; set; }
        public string Subject { get; set; }
        public string BodyHtml { get; set; }
    }
}
