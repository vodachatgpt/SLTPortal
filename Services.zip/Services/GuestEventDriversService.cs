using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using SLTProject.Data;
using SLTProject.Models.Dtos;

namespace SLTProject.Services
{
    public class GuestEventDriversService
    {
        private static string Email(string email)
        {
            email=ScheduleTransportExcel.Limit(email,320,"Email",true).ToLowerInvariant();
            try { var a=new System.Net.Mail.MailAddress(email); if(!a.Address.Equals(email,StringComparison.OrdinalIgnoreCase)) throw new Exception(); }
            catch { throw new ArgumentException("Invalid guest email."); }
            return email;
        }
        private static void Validate(GuestEventDriverInput v)
        {
            if(v==null) throw new ArgumentException("Event driver data is required.");
            Email(v.Email);
            if(v.DayScheduleId<=0) throw new ArgumentException("DayScheduleId is required.");
            ScheduleTransportExcel.Limit(v.DriverName,250,"DriverName",true);
            ScheduleTransportExcel.Limit(v.DriverPhone,50,"DriverPhone",true);
        }
        private static void Apply(GuestEventDriver x,GuestEventDriverInput v)
        {
            x.Email=Email(v.Email);x.DayScheduleId=v.DayScheduleId;
            x.DriverName=v.DriverName.Trim();x.DriverPhone=v.DriverPhone.Trim();x.WhatsApp=v.WhatsApp;
        }
        public static GuestEventDriverDto Map(GuestEventDriver x)
        {
            return x==null ? null : new GuestEventDriverDto { Id=x.Id, Email=x.Email,DayScheduleId=x.DayScheduleId,
                DriverName=x.DriverName,DriverPhone=x.DriverPhone,WhatsApp=x.WhatsApp,
                CreatedAt=x.CreatedAt,CreatedBy=x.CreatedBy,ModifiedAt=x.ModifiedAt,ModifiedBy=x.ModifiedBy,
                IsDeleted=x.IsDeleted,DeletedAt=x.DeletedAt,DeletedBy=x.DeletedBy,
                RetentionDateCreated=x.RetentionDateCreated,RetentionDateModified=x.RetentionDateModified };
        }
        private static async Task CheckLinks(SLTEntities db,string email,long dayScheduleId)
        {
            if(!await db.Guests.AnyAsync(x=>x.Email==email && !x.IsDeleted)) throw new ArgumentException("Guest email does not exist: " + email);
            if(!await db.DaySchedules.AnyAsync(x=>x.Id==dayScheduleId && !x.IsDeleted))
                throw new ArgumentException("Active DayScheduleId not found: " + dayScheduleId);
        }
        public async Task<List<GuestEventDriverDto>> GetAllAsync(string email=null,long? dayScheduleId=null)
        {
            using(var db=new SLTEntities())
            {
                var activeSchedules = db.DaySchedules.Where(s => !s.IsDeleted).Select(s => s.Id);
                var q=db.GuestEventDrivers.AsNoTracking().Where(x=>!x.IsDeleted && activeSchedules.Contains(x.DayScheduleId));
                if(!string.IsNullOrWhiteSpace(email)) { var e=Email(email); q=q.Where(x=>x.Email==e); }
                if(dayScheduleId.HasValue) { long id=dayScheduleId.Value;q=q.Where(x=>x.DayScheduleId==id); }
                return (await q.OrderBy(x=>x.DayScheduleId).ThenBy(x=>x.Email).ToListAsync()).Select(Map).ToList();
            }
        }
        public async Task<GuestEventDriverDto> GetAsync(long id)
        {
            using(var db=new SLTEntities()) return Map(await db.GuestEventDrivers.AsNoTracking()
                .FirstOrDefaultAsync(x=>x.Id==id && !x.IsDeleted && db.DaySchedules.Any(s => s.Id==x.DayScheduleId && !s.IsDeleted)));
        }
        public async Task<GuestEventDriverDto> CreateAsync(GuestEventDriverInput input,string actor)
        {
            Validate(input);
            using(var db=new SLTEntities())
            {
                var email=Email(input.Email);await CheckLinks(db,email,input.DayScheduleId);
                if(await db.GuestEventDrivers.AnyAsync(x=>!x.IsDeleted && x.Email==email && x.DayScheduleId==input.DayScheduleId))
                    throw new ArgumentException("An active guest driver assignment already exists for this activity.");
                var now=EgyptDateTimeService.Now;
                var entity = new GuestEventDriver { CreatedAt=now, CreatedBy=actor, RetentionDateCreated=now, IsDeleted=false };
                Apply(entity,input);db.GuestEventDrivers.Add(entity);await db.SaveChangesAsync();return Map(entity);
            }
        }
        public async Task<GuestEventDriverDto> UpdateAsync(long id,GuestEventDriverInput input,string actor)
        {
            Validate(input);
            using(var db=new SLTEntities())
            {
                var x=await db.GuestEventDrivers.FirstOrDefaultAsync(y=>y.Id==id && !y.IsDeleted);
                if(x==null) return null;
                var email=Email(input.Email);await CheckLinks(db,email,input.DayScheduleId);
                if(await db.GuestEventDrivers.AnyAsync(y=>y.Id!=id && !y.IsDeleted && y.Email==email && y.DayScheduleId==input.DayScheduleId))
                    throw new ArgumentException("An active Email + DayScheduleId assignment already exists.");
                Apply(x,input);x.ModifiedAt=EgyptDateTimeService.Now;x.ModifiedBy=actor;x.RetentionDateModified=x.ModifiedAt;
                await db.SaveChangesAsync();return Map(x);
            }
        }
        public async Task<bool> DeleteAsync(long id,string actor)
        {
            using(var db=new SLTEntities())
            {
                var x=await db.GuestEventDrivers.FirstOrDefaultAsync(y=>y.Id==id && !y.IsDeleted);
                if(x==null) return false;
                var now=EgyptDateTimeService.Now;x.IsDeleted=true;x.DeletedAt=now;x.DeletedBy=actor;
                x.ModifiedAt=now;x.ModifiedBy=actor;x.RetentionDateModified=now;
                await db.SaveChangesAsync();return true;
            }
        }
        public byte[] GetTemplate() { return ScheduleTransportExcel.Template("Email","DayScheduleId","DriverName","DriverPhone","WhatsApp"); }
        public async Task<ExcelImportResult> ImportAsync(Stream stream,string actor)
        {
            var report=new ExcelImportResult();
            using(var wb=ScheduleTransportExcel.Open(stream))
            {
                var sheet=wb.Worksheet(1);var headers=ScheduleTransportExcel.Headers(sheet);
                ScheduleTransportExcel.Require(headers,"Email","DayScheduleId","DriverName","DriverPhone","WhatsApp");
                var last=sheet.LastRowUsed();if(last==null) return report;
                if(last.RowNumber()>10001) throw new ArgumentException("Maximum 10000 rows per upload.");
                var seen=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                using(var db=new SLTEntities())
                using(var tx=db.Database.BeginTransaction())
                {
                    for(int i=2;i<=last.RowNumber();i++)
                    {
                        var row=sheet.Row(i);
                        if(ScheduleTransportExcel.Empty(row,headers)){report.Skipped++;continue;}
                        try
                        {
                            string email=Email(ScheduleTransportExcel.Text(row,headers,"Email"));
                            long scheduleId;
                            if(!long.TryParse(ScheduleTransportExcel.Text(row,headers,"DayScheduleId"),out scheduleId) || scheduleId<=0)
                                throw new ArgumentException("DayScheduleId must be an existing positive Id.");
                            if(!seen.Add(email+"|"+scheduleId)) throw new ArgumentException("Duplicate Email + DayScheduleId in file.");
                            await CheckLinks(db,email,scheduleId);
                            var x=await db.GuestEventDrivers.FirstOrDefaultAsync(v=>!v.IsDeleted && v.Email==email && v.DayScheduleId==scheduleId);
                            string name=ScheduleTransportExcel.Text(row,headers,"DriverName");
                            string phone=ScheduleTransportExcel.Text(row,headers,"DriverPhone");
                            string whats=ScheduleTransportExcel.Text(row,headers,"WhatsApp");
                            var value=new GuestEventDriverInput { Email=email,DayScheduleId=scheduleId,
                                DriverName=name.Length>0 ? name : (x==null ? null : x.DriverName),
                                DriverPhone=phone.Length>0 ? phone : (x==null ? null : x.DriverPhone),
                                WhatsApp=whats.Length>0 ? ScheduleTransportExcel.Bool(whats,"WhatsApp") : (x!=null && x.WhatsApp)
                            };
                            Validate(value);
                            var now=EgyptDateTimeService.Now;
                            if(x==null) { x=new GuestEventDriver { CreatedAt=now,CreatedBy=actor,RetentionDateCreated=now,IsDeleted=false };
                                Apply(x,value);db.GuestEventDrivers.Add(x);report.Inserted++; }
                            else { Apply(x,value);x.ModifiedAt=now;x.ModifiedBy=actor;x.RetentionDateModified=now;report.Updated++; }
                        }
                        catch(Exception e) when (e is ArgumentException || e is FormatException || e is OverflowException)
                        { report.Errors.Add("Row " + i + ": " + e.Message); }
                    }
                    if(report.Errors.Count>0){tx.Rollback();report.Inserted=0;report.Updated=0;return report;}
                    await db.SaveChangesAsync();tx.Commit();
                }
            }
            return report;
        }
        // ============================================================
        // ADMIN TABLE: DATABASE-SIDE PAGING AND FILTERED XLSX EXPORT
        // The public unpaged GetAllAsync API remains unchanged.
        // ============================================================
        public Task<SltTablePage<GuestEventDriverDto>> GetPagedAsync(SltTableQuery filter)
        {
            return SltTableDataService.DriversAsync(filter ?? new SltTableQuery());
        }

        public Task<byte[]> ExportFilteredAsync(SltTableQuery filter)
        {
            return SltTableDataService.ExportXlsxAsync<GuestEventDriverDto>(
                f => SltTableDataService.DriversAsync(f),
                filter ?? new SltTableQuery(),
                new[] { "Id", "Email", "DayScheduleId", "DriverName", "DriverPhone", "WhatsApp" });
        }

    }
}
