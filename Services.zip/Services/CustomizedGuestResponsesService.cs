﻿
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using SLTProject.Data;

namespace SLTProject.Services
{
    public class CustomizedGuestResponsesService
    {
        // ==========================================
        // EMAIL NORMALIZATION
        // ==========================================

        private static string NormalizeEmail(string email)
        {
            return (email ?? "")
                .Trim()
                .ToLowerInvariant();
        }

        // ==========================================
        // FULL NAME SPLITTING
        // ==========================================

        private static string GetFirstName(string fullName)
        {
            if (string.IsNullOrWhiteSpace(fullName))
                return null;

            string[] parts = fullName.Trim()
                .Split(new[] { ' ' },
                    StringSplitOptions.RemoveEmptyEntries);

            return parts.Length > 0 ? parts[0] : null;
        }

        private static string GetLastName(string fullName)
        {
            if (string.IsNullOrWhiteSpace(fullName))
                return null;

            string[] parts = fullName.Trim()
                .Split(new[] { ' ' },
                    StringSplitOptions.RemoveEmptyEntries);

            if (parts.Length <= 1)
                return null;

            return string.Join(" ", parts.Skip(1));
        }

        // ==========================================
        // DATE + TIME COMBINATION
        // ==========================================

        private static DateTime? CombineDateTime(
            DateTime? date,
            TimeSpan? time)
        {
            if (!date.HasValue || !time.HasValue)
                return null;

            return date.Value.Date.Add(time.Value);
        }

        // ==========================================
        // GET GUESTS WITH ALL DRIVER ASSIGNMENTS
        // ==========================================

        public async Task<List<Dictionary<string, object>>>
            GetGuestsAsync(
                string guestEmail,
                string qrUrlPrefix)
        {
            string email = NormalizeEmail(guestEmail);

            using (var db = new SLTEntities())
            {
                // ----------------------------------
                // 1. LOAD GUESTS
                // ----------------------------------

                var guestQuery = db.Guests
                    .AsNoTracking()
                    .Where(x => !x.IsDeleted);

                if (!string.IsNullOrWhiteSpace(email))
                {
                    guestQuery = guestQuery
                        .Where(x => x.Email == email);
                }

                // Project only required columns.
                // Avoid loading QR image binary data.
                var guests = await guestQuery
                    .OrderBy(x => x.FullName)
                    .ThenBy(x => x.Id)
                    .Select(x => new
                    {
                        x.Id,
                        x.FullName,
                        x.Email,
                        x.FirstLoginAt,
                        x.CheckInDate,
                        x.CheckInTime,
                        x.CheckOutDate,
                        x.CheckOutTime,
                        HasQR = x.QRCodeImage != null
                    })
                    .ToListAsync();

                if (guests.Count == 0)
                {
                    return new List<
                        Dictionary<string, object>>();
                }

                // ----------------------------------
                // 2. LOAD ALL ACTIVE SCHEDULE EVENTS
                // ----------------------------------

                var schedules = await db.DaySchedules
                    .AsNoTracking()
                    .Where(x => !x.IsDeleted)
                    .OrderBy(x => x.Date)
                    .ThenBy(x => x.StartTime)
                    .ThenBy(x => x.Id)
                    .Select(x => new
                    {
                        x.Id,
                        x.Date,
                        x.StartTime
                    })
                    .ToListAsync();

                // ----------------------------------
                // 3. ORGANIZE EVENTS BY DATE
                // ----------------------------------

                var days = schedules
                    .GroupBy(x => x.Date.Date)
                    .OrderBy(x => x.Key)
                    .Select(x => x.ToList())
                    .ToList();

                // ----------------------------------
                // 4. LOAD AIRPORT TRANSFERS
                // ----------------------------------

                var airportQuery = db.AirportTransfers
                    .AsNoTracking()
                    .Where(x => !x.IsDeleted);

                if (!string.IsNullOrWhiteSpace(email))
                {
                    airportQuery = airportQuery
                        .Where(x => x.Email == email);
                }

                var airportTransfers = await airportQuery
                    .ToListAsync();

                // ----------------------------------
                // 5. LOAD EVENT DRIVERS
                // ----------------------------------

                var eventDriversQuery = db.GuestEventDrivers
                    .AsNoTracking()
                    .Where(x => !x.IsDeleted);

                if (!string.IsNullOrWhiteSpace(email))
                {
                    eventDriversQuery = eventDriversQuery
                        .Where(x => x.Email == email);
                }

                var eventDrivers = await eventDriversQuery
                    .ToListAsync();

                // ----------------------------------
                // 6. BUILD AIRPORT LOOKUP
                // ----------------------------------

                var airportLookup = airportTransfers
                    .GroupBy(x =>
                        NormalizeEmail(x.Email) + "|" +
                        (x.Type ?? "")
                            .Trim()
                            .ToLowerInvariant())
                    .ToDictionary(
                        x => x.Key,
                        x => x.OrderBy(y => y.Id).First());

                // ----------------------------------
                // 7. BUILD EVENT DRIVER LOOKUP
                // ----------------------------------

                var eventDriverLookup = eventDrivers
                    .GroupBy(x =>
                        NormalizeEmail(x.Email) + "|" +
                        x.DayScheduleId.ToString(
                            CultureInfo.InvariantCulture))
                    .ToDictionary(
                        x => x.Key,
                        x => x.OrderBy(y => y.Id).First());

                // ----------------------------------
                // 8. BUILD RESULT
                // ----------------------------------

                var results =
                    new List<Dictionary<string, object>>();

                foreach (var guest in guests)
                {
                    string guestKey =
                        NormalizeEmail(guest.Email);

                    var row =
                        new Dictionary<string, object>();

                    // PERSONAL INFORMATION
                    row["FirstName"] =
                        GetFirstName(guest.FullName);

                    row["LastName"] =
                        GetLastName(guest.FullName);

                    row["FullName"] = guest.FullName;

                    // Not available in current Guests schema.
                    row["MobileNumber"] = null;

                    row["Email"] = guest.Email;

                    // Actual first-login timestamp.
                    row["FirstLogin"] =
                        guest.FirstLoginAt;

                    row["CheckInDateTime"] =
                        CombineDateTime(
                            guest.CheckInDate,
                            guest.CheckInTime);

                    row["CheckOutDateTime"] =
                        CombineDateTime(
                            guest.CheckOutDate,
                            guest.CheckOutTime);

                    // Not available in current schema.
                    row["TourRegisteration"] = null;

                    // URL points to the existing protected
                    // Guests QR image API.
                    row["QRUrl"] =
                        guest.HasQR &&
                        !string.IsNullOrWhiteSpace(qrUrlPrefix)
                        ? qrUrlPrefix + guest.Id + "/qr"
                        : null;

                    // ----------------------------------
                    // AIRPORT PICKUP
                    // ----------------------------------

                    AirportTransfer pickup = null;

                    airportLookup.TryGetValue(
                        guestKey + "|pickup",
                        out pickup);

                    row["AirportPickupDriverName"] =
                        pickup == null
                            ? null
                            : pickup.DriverName;

                    row["AirportPickupDriverNumber"] =
                        pickup == null
                            ? null
                            : pickup.DriverPhone;

                    // ----------------------------------
                    // AIRPORT DROP-OFF
                    // ----------------------------------

                    AirportTransfer dropOff = null;

                    airportLookup.TryGetValue(
                        guestKey + "|drop-off",
                        out dropOff);

                    row["AirportDropOffDriverName"] =
                        dropOff == null
                            ? null
                            : dropOff.DriverName;

                    row["AirportDropOffDriverNumber"] =
                        dropOff == null
                            ? null
                            : dropOff.DriverPhone;

                    // ----------------------------------
                    // DAILY EVENT DRIVERS
                    // ----------------------------------

                    // Minimum four days, as requested.
                    // Automatically expand if more
                    // schedule dates are available.
                    int totalDays = Math.Max(
                        4,
                        days.Count);

                    for (int dayIndex = 0;
                         dayIndex < totalDays;
                         dayIndex++)
                    {
                        bool hasDay =
                            dayIndex < days.Count;

                        int totalEvents = hasDay
                            ? Math.Max(
                                10,
                                days[dayIndex].Count)
                            : 10;

                        for (int eventIndex = 0;
                             eventIndex < totalEvents;
                             eventIndex++)
                        {
                            string prefix =
                                "Day" + (dayIndex + 1) +
                                "Event" + (eventIndex + 1);

                            string driverNameKey =
                                prefix + "DriverName";

                            string driverNumberKey =
                                prefix + "DriverNumber";

                            // Default empty assignment.
                            row[driverNameKey] = null;
                            row[driverNumberKey] = null;

                            if (!hasDay ||
                                eventIndex >=
                                days[dayIndex].Count)
                            {
                                continue;
                            }

                            var schedule =
                                days[dayIndex][eventIndex];

                            string lookupKey =
                                guestKey + "|" +
                                schedule.Id.ToString(
                                    CultureInfo.InvariantCulture);

                            GuestEventDriver driver = null;

                            if (!eventDriverLookup.TryGetValue(
                                lookupKey,
                                out driver))
                            {
                                continue;
                            }

                            row[driverNameKey] =
                                driver.DriverName;

                            row[driverNumberKey] =
                                driver.DriverPhone;
                        }
                    }

                    results.Add(row);
                }

                return results;
            }
        }
    }
}
