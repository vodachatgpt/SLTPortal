
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Configuration;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Security;
using ClosedXML.Excel;
using SLTProject.Data;
using SLTProject.Models;

namespace SLTProject.Services
{
    public class GuestInput
    {
        public string FullName { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public DateTime? ArrivalDate { get; set; }
        public string ArrivalFlight { get; set; }
        public TimeSpan? LandingTime { get; set; }
        public DateTime? DepartureDate { get; set; }
        public string DepartureFlight { get; set; }
        public TimeSpan? DepartureTime { get; set; }
        public string HotelName { get; set; }
        public DateTime? CheckInDate { get; set; }
        public TimeSpan? CheckInTime { get; set; }
        public DateTime? CheckOutDate { get; set; }
        public TimeSpan? CheckOutTime { get; set; }

        // Nullable so omitted values never reset an existing registration.
        // On guest creation, null is treated as false.
        public bool? TourRegister { get; set; }
    }

    public class GuestView : GuestInput
    {
        public long Id { get; set; }
        public bool Activated { get; set; }
        public bool HasQR { get; set; }
        public string QRFileName { get; set; }
        public string QRSource { get; set; }
        public string PasscodeLast4 { get; set; }
        public bool CanRevealPasscode { get; set; }
        public DateTime? SessionExpiresAt { get; set; }
        public DateTime RetentionDateCreated { get; set; }
        public DateTime? RetentionDateModified { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
    }

    public class GuestQrFolderStatus
    {
        public bool FolderExists { get; set; }
        public int ImagesInFolder { get; set; }
        public int ActiveGuests { get; set; }
        public int GuestsWithFolderQr { get; set; }
        public int GuestsMissingQr { get; set; }
        public string FolderName { get; set; }
        public string[] SupportedExtensions { get; set; }
    }

    public class GuestLoginInput
    {
        [Required]
        public string Passcode { get; set; }
    }

    public class GuestCreateResult
    {
        public GuestView Guest { get; set; }
        public string Passcode { get; set; }
    }

    public class GuestLoginResult
    {
        public string Token { get; set; }
        public DateTime ExpiresAt { get; set; }

    }

    public class ImportRowResult
    {
        public int Row { get; set; }
        public string Email { get; set; }
        public string Action { get; set; }
        public string Passcode { get; set; }
        public bool HasQR { get; set; }
        public string QRFileName { get; set; }
        public string QRSource { get; set; }
    }

    public class GuestImportResult
    {
        public Guid BatchId { get; set; }
        public int Created { get; set; }
        public int Updated { get; set; }
        public string ExcelServiceResponse { get; set; }

        public List<ImportRowResult> Rows { get; set; }
            = new List<ImportRowResult>();
    }

    public class StagedGuest
    {
        public long Id { get; set; }
        public Guid BatchId { get; set; }
        public int RowNumber { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        public string ArrivalDate { get; set; }
        public string ArrivalFlight { get; set; }
        public string LandingTime { get; set; }
        public string DepartureDate { get; set; }
        public string DepartureFlight { get; set; }
        public string DepartureTime { get; set; }
        public string HotelName { get; set; }
        public string CheckInDate { get; set; }
        public string CheckInTime { get; set; }
        public string CheckOutDate { get; set; }
        public string CheckOutTime { get; set; }
        public string UploadedBy { get; set; }
        public DateTime RetentionDateCreated { get; set; }
    }

    public class GuestsService
    {
        private static readonly HttpClient Http =
            new HttpClient
            {
                Timeout = TimeSpan.FromMinutes(5)
            };

        private static readonly string[] ImportFields =
        {
            "FullName", "Email", "ArrivalDate",
            "ArrivalFlight", "LandingTime",
            "DepartureDate", "DepartureFlight",
            "DepartureTime", "HotelName",
            "CheckInDate", "CheckInTime",
            "CheckOutDate", "CheckOutTime"
        };

        private static readonly string[] StageFields =
        {
            "Id", "BatchId", "RowNumber",
            "FullName", "Email", "ArrivalDate",
            "ArrivalFlight", "LandingTime",
            "DepartureDate", "DepartureFlight",
            "DepartureTime", "HotelName",
            "CheckInDate", "CheckInTime",
            "CheckOutDate", "CheckOutTime",
            "UploadedBy"
        };

        private static string Setting(string key)
        {
            string value =
                ConfigurationManager.AppSettings[key];

            if (string.IsNullOrWhiteSpace(value) ||
                value.StartsWith("REPLACE_WITH") ||
                value.StartsWith("YOUR_"))
            {
                throw new ConfigurationErrorsException(
                    "Missing setting: " + key);
            }

            return value;
        }

        public static string NormalizeEmail(string email)
        {
            return (email ?? "").Trim().ToLowerInvariant();
        }

        private static void ValidateEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email) ||
                email.Length > 320 ||
                !new EmailAddressAttribute().IsValid(email))
            {
                throw new ArgumentException(
                    "Valid guest email required.");
            }
        }

        // ============================================================
        // AUTOMATIC QR FOLDER RESOLUTION
        // File naming convention:
        //     normalized.guest@email.com.png
        //     normalized.guest@email.com.jpg / .jpeg / .webp
        //
        // Default folder: ~/App_Data/GuestQRCodes
        // Optional Web.config override: SLTGuestQrFolder
        // The configured path can be ~/relative/path or an absolute path.
        // Never accept a physical path from an API request.
        // ============================================================

        private static readonly string[] QrExtensions =
        {
            ".png", ".jpg", ".jpeg", ".webp"
        };

        private static string GetQrFolderPath()
        {
            string configured =
                ConfigurationManager.AppSettings["SLTGuestQrFolder"];

            string applicationRoot = HttpRuntime.AppDomainAppPath;
            if (string.IsNullOrWhiteSpace(applicationRoot))
                applicationRoot = AppDomain.CurrentDomain.BaseDirectory;

            string folder;

            if (string.IsNullOrWhiteSpace(configured))
            {
                folder = Path.Combine(
                    applicationRoot,
                    "App_Data",
                    "GuestQRCodes");
            }
            else if (configured.StartsWith(
                "~/", StringComparison.Ordinal))
            {
                folder = Path.Combine(
                    applicationRoot,
                    configured.Substring(2)
                        .Replace('/', Path.DirectorySeparatorChar));
            }
            else if (!Path.IsPathRooted(configured))
            {
                // Relative configured paths are resolved from the app root,
                // not from the IIS worker process current directory.
                folder = Path.Combine(applicationRoot, configured);
            }
            else
            {
                folder = configured;
            }

            return Path.GetFullPath(folder);
        }

        private static string FindFolderQr(string email)
        {
            string normalized = NormalizeEmail(email);
            if (string.IsNullOrWhiteSpace(normalized))
                return null;

            // Email is validated before it is ever used as a filename.
            ValidateEmail(normalized);

            if (normalized.IndexOfAny(
                Path.GetInvalidFileNameChars()) >= 0 ||
                normalized.Contains("/") ||
                normalized.Contains("\\") ||
                normalized.Contains(".."))
                return null;

            string folder = GetQrFolderPath();
            if (!Directory.Exists(folder))
                return null;

            foreach (string extension in QrExtensions)
            {
                string candidate = Path.Combine(
                    folder, normalized + extension);

                if (File.Exists(candidate))
                    return candidate;
            }

            // On Windows, email filename matching is case-insensitive by
            // default. This fallback also handles case-sensitive volumes.
            string expectedBaseName = normalized;
            foreach (string file in Directory.EnumerateFiles(folder))
            {
                string extension = Path.GetExtension(file);
                if (!QrExtensions.Contains(
                    extension, StringComparer.OrdinalIgnoreCase))
                    continue;

                string baseName = Path.GetFileNameWithoutExtension(file);
                if (string.Equals(
                    baseName,
                    expectedBaseName,
                    StringComparison.OrdinalIgnoreCase))
                    return file;
            }

            return null;
        }

        public static string FolderQrFileName(string email)
        {
            string path = FindFolderQr(email);
            return path == null ? null : Path.GetFileName(path);
        }

        private static string FolderQrMime(string path)
        {
            string extension = Path.GetExtension(path).ToLowerInvariant();
            return extension == ".png" ? "image/png" :
                extension == ".webp" ? "image/webp" : "image/jpeg";
        }

        private static bool IsValidQrImage(
            byte[] image,
            string extension)
        {
            if (image == null || image.Length == 0 ||
                image.Length > 2 * 1024 * 1024)
                return false;

            extension = (extension ?? "").ToLowerInvariant();

            return
                (extension == ".png" && image.Length >= 8 &&
                 image[0] == 0x89 && image[1] == 0x50 &&
                 image[2] == 0x4E && image[3] == 0x47 &&
                 image[4] == 0x0D && image[5] == 0x0A &&
                 image[6] == 0x1A && image[7] == 0x0A)
                ||
                ((extension == ".jpg" || extension == ".jpeg") &&
                 image.Length >= 3 && image[0] == 0xFF &&
                 image[1] == 0xD8 && image[2] == 0xFF)
                ||
                (extension == ".webp" && image.Length >= 12 &&
                 Encoding.ASCII.GetString(image, 0, 4) == "RIFF" &&
                 Encoding.ASCII.GetString(image, 8, 4) == "WEBP");
        }

        public async Task<GuestQrFolderStatus> GetQrFolderStatusAsync()
        {
            string folder = GetQrFolderPath();
            bool exists = Directory.Exists(folder);
            int imageCount = 0;

            if (exists)
            {
                imageCount = Directory.EnumerateFiles(folder)
                    .Count(file => QrExtensions.Contains(
                        Path.GetExtension(file),
                        StringComparer.OrdinalIgnoreCase));
            }

            using (var db = new SLTEntities())
            {
                var guests = await db.Guests
                    .AsNoTracking()
                    .Where(g => !g.IsDeleted)
                    .Select(g => g.Email)
                    .ToListAsync();

                int matched = 0;
                foreach (string email in guests)
                {
                    if (FindFolderQr(email) != null)
                        matched++;
                }

                return new GuestQrFolderStatus
                {
                    FolderExists = exists,
                    ImagesInFolder = imageCount,
                    ActiveGuests = guests.Count,
                    GuestsWithFolderQr = matched,
                    GuestsMissingQr = guests.Count - matched,
                    FolderName = "GuestQRCodes",
                    SupportedExtensions = QrExtensions.ToArray()
                };
            }
        }

        public static GuestView Map(Guest g)
        {
            if (g == null)
                return null;

            string folderQrPath = FindFolderQr(g.Email);
            bool hasDatabaseQr = g.QRCodeImage != null &&
                g.QRCodeImage.Length > 0;
            bool hasFolderQr = folderQrPath != null;

            return new GuestView
            {
                Id = g.Id,
                FullName = g.FullName,
                Email = g.Email,
                PhoneNumber = g.PhoneNumber,
                ArrivalDate = g.ArrivalDate,
                ArrivalFlight = g.ArrivalFlight,
                LandingTime = g.LandingTime,
                DepartureDate = g.DepartureDate,
                DepartureFlight = g.DepartureFlight,
                DepartureTime = g.DepartureTime,
                HotelName = g.HotelName,
                CheckInDate = g.CheckInDate,
                CheckInTime = g.CheckInTime,
                CheckOutDate = g.CheckOutDate,
                CheckOutTime = g.CheckOutTime,
                TourRegister = g.TourRegister,
                PasscodeLast4 = g.PasscodeLast4,
                CanRevealPasscode = g.PasscodeProtected != null,
                Activated = g.FirstLoginAt.HasValue,
                SessionExpiresAt = g.SessionExpiresAt,
                HasQR = hasFolderQr || hasDatabaseQr,
                QRFileName = hasFolderQr
                    ? Path.GetFileName(folderQrPath)
                    : g.QRFileName,
                QRSource = hasFolderQr
                    ? "Folder"
                    : hasDatabaseQr ? "Database" : null,
                RetentionDateCreated = g.RetentionDateCreated,
                RetentionDateModified = g.RetentionDateModified,
                CreatedBy = g.CreatedBy,
                ModifiedBy = g.ModifiedBy
            };
        }

        public static void Merge(Guest g, GuestInput input)
        {
            if (input == null)
                throw new ArgumentException(
                    "Guest information required.");

            if (!string.IsNullOrWhiteSpace(input.FullName))
                g.FullName = input.FullName.Trim();

            if (!string.IsNullOrWhiteSpace(input.Email))
            {
                string email = NormalizeEmail(input.Email);
                ValidateEmail(email);
                g.Email = email;
            }

            if (!string.IsNullOrWhiteSpace(input.PhoneNumber))
            {
                string phone = input.PhoneNumber.Trim();
                if (phone.Length > 30 ||
                    !System.Text.RegularExpressions.Regex.IsMatch(phone,
                        @"^\+[1-9]\d{0,3}(?:[ \-()]?\d){4,17}$"))
                    throw new ArgumentException("Phone number must contain an international code, for example +201001234567.");
                g.PhoneNumber = phone;
            }

            if (input.ArrivalDate.HasValue)
                g.ArrivalDate = input.ArrivalDate.Value.Date;

            if (!string.IsNullOrWhiteSpace(input.ArrivalFlight))
                g.ArrivalFlight = input.ArrivalFlight.Trim();

            if (input.LandingTime.HasValue)
                g.LandingTime = input.LandingTime.Value;

            if (input.DepartureDate.HasValue)
                g.DepartureDate = input.DepartureDate.Value.Date;

            if (!string.IsNullOrWhiteSpace(input.DepartureFlight))
                g.DepartureFlight = input.DepartureFlight.Trim();

            if (input.DepartureTime.HasValue)
                g.DepartureTime = input.DepartureTime.Value;

            if (!string.IsNullOrWhiteSpace(input.HotelName))
                g.HotelName = input.HotelName.Trim();

            if (input.CheckInDate.HasValue)
                g.CheckInDate = input.CheckInDate.Value.Date;

            if (input.CheckInTime.HasValue)
                g.CheckInTime = input.CheckInTime.Value;

            if (input.CheckOutDate.HasValue)
                g.CheckOutDate = input.CheckOutDate.Value.Date;

            if (input.CheckOutTime.HasValue)
                g.CheckOutTime = input.CheckOutTime.Value;

            // When an API request or Excel cell omits TourRegister,
            // preserve the guest's previous registration choice.
            if (input.TourRegister.HasValue)
                g.TourRegister = input.TourRegister.Value;
        }

        private static byte[] PasscodeHash(string code)
        {
            byte[] secret = Encoding.UTF8.GetBytes(
                Setting("SLTPasscodePepper"));

            using (var hmac = new HMACSHA256(secret))
            {
                return hmac.ComputeHash(
                    Encoding.UTF8.GetBytes(
                        (code ?? "").Trim()
                            .ToUpperInvariant()));
            }
        }

        private static byte[] TokenHash(string token)
        {
            using (var sha = SHA256.Create())
            {
                return sha.ComputeHash(
                    Encoding.UTF8.GetBytes(token ?? ""));
            }
        }

        private static bool ValidPasscode(string code)
        {
            return code != null &&
                   code.Length == 6 &&
                   code.All(c => c >= '0' && c <= '9');
        }

        private static string RandomPasscode()
        {
            const ulong range = 1000000UL;
            const ulong limit =
                (4294967296UL / range) * range;

            var bytes = new byte[4];

            using (var rng =
                RandomNumberGenerator.Create())
            {
                while (true)
                {
                    rng.GetBytes(bytes);

                    uint number =
                        BitConverter.ToUInt32(bytes, 0);

                    if ((ulong)number >= limit)
                        continue;

                    return ((ulong)number % range)
                        .ToString("D6");
                }
            }
        }

        private static string RandomToken()
        {
            var bytes = new byte[32];

            using (var rng =
                RandomNumberGenerator.Create())
            {
                rng.GetBytes(bytes);
            }

            return Convert.ToBase64String(bytes)
                .TrimEnd('=')
                .Replace('+', '-')
                .Replace('/', '_');
        }

        private static byte[] ProtectPasscode(string passcode)
        {
            if (!ValidPasscode(passcode))
                throw new ArgumentException("A valid six-digit passcode is required.", nameof(passcode));

            try
            {
                byte[] result = MachineKey.Protect(
                    Encoding.UTF8.GetBytes(passcode),
                    "SLTProject", "GuestPasscode", "v1");

                if (result == null || result.Length == 0)
                    throw new InvalidOperationException("Encryption returned no data.");

                return result;
            }
            catch (CryptographicException ex)
            {
                throw new InvalidOperationException(
                    "Unable to encrypt the guest passcode with the current ASP.NET machineKey.", ex);
            }
        }

        private static string UnprotectPasscode(byte[] encrypted)
        {
            if (encrypted == null || encrypted.Length == 0)
                throw new InvalidOperationException("No recoverable guest passcode is stored.");

            try
            {
                byte[] clear = MachineKey.Unprotect(
                    encrypted, "SLTProject", "GuestPasscode", "v1");

                if (clear == null || clear.Length == 0)
                    throw new InvalidOperationException("Decryption returned no data.");

                string passcode = Encoding.UTF8.GetString(clear);
                if (!ValidPasscode(passcode))
                    throw new InvalidOperationException("Decrypted passcode has an invalid format.");

                return passcode;
            }
            catch (CryptographicException ex)
            {
                throw new InvalidOperationException(
                    "The stored passcode cannot be decrypted with the current machineKey or application context. " +
                    "Check the original key before resetting guest credentials.", ex);
            }
        }

        private static string AssignPasscode(
            SLTEntities db, Guest guest)
        {
            for (int attempt = 0; attempt < 100; attempt++)
            {
                string passcode = RandomPasscode();
                byte[] hash = PasscodeHash(passcode);

                int count = db.Database.SqlQuery<int>(@"
SELECT COUNT(1)
FROM dbo.Guests
WHERE PasscodeHash = @hash
  AND Id <> @id",
                    new SqlParameter(
                        "@hash", SqlDbType.VarBinary, 32)
                    {
                        Value = hash
                    },
                    new SqlParameter(
                        "@id", SqlDbType.BigInt)
                    {
                        Value = guest.Id
                    }
                ).Single();

                bool localDuplicate = db.Guests.Local.Any(
                    x => x != guest &&
                         x.PasscodeHash != null &&
                         x.PasscodeHash.SequenceEqual(hash));

                if (count > 0 || localDuplicate)
                    continue;

                guest.PasscodeHash = hash;
                guest.PasscodeLast4 = passcode.Substring(2);
                guest.PasscodeProtected =
                    ProtectPasscode(passcode);

                return passcode;
            }

            throw new InvalidOperationException(
                "Unable to generate unique guest passcode.");
        }

        public static GuestCreateResult CreateInside(
            SLTEntities db,
            GuestInput input,
            string actor)
        {
            if (input == null ||
                string.IsNullOrWhiteSpace(input.FullName))
                throw new ArgumentException(
                    "Guest name is required.");

            string email = NormalizeEmail(input.Email);
            ValidateEmail(email);

            if (db.Guests.Any(g =>
                !g.IsDeleted && g.Email == email))
                throw new ArgumentException(
                    "Guest email already exists.");

            var guest = new Guest
            {
                FullName = input.FullName.Trim(),
                Email = email,
                CreatedBy = actor,
                RetentionDateCreated = EgyptDateTimeService.Now,
                IsDeleted = false,
                TourRegister = false,

                // Business provides the QR image.
                QRCodeImage = null,
                QRFileName = null,
                QRContentType = null
            };

            Merge(guest, input);

            string passcode = AssignPasscode(db, guest);

            db.Guests.Add(guest);

            return new GuestCreateResult
            {
                Guest = Map(guest),
                Passcode = passcode
            };
        }

        public async Task<GuestCreateResult> CreateAsync(
            GuestInput input,
            string actor)
        {
            using (var db = new SLTEntities())
            {
                var result = CreateInside(
                    db, input, actor);

                await db.SaveChangesAsync();

                result.Guest = Map(db.Guests.Local.First(
                    x => x.Email ==
                        NormalizeEmail(input.Email)));

                return result;
            }
        }

        public async Task<List<GuestView>> GetAllAsync()
        {
            using (var db = new SLTEntities())
            {
                var guests = await db.Guests
                    .AsNoTracking()
                    .Where(g => !g.IsDeleted)
                    .OrderByDescending(g => g.Id)
                    .ToListAsync();

                return guests.Select(Map).ToList();
            }
        }

        public async Task<GuestView> GetAsync(long id)
        {
            using (var db = new SLTEntities())
            {
                var guest = await db.Guests
                    .AsNoTracking()
                    .FirstOrDefaultAsync(g =>
                        g.Id == id && !g.IsDeleted);

                return guest == null ? null : Map(guest);
            }
        }

        public async Task<GuestView> UpdateAsync(
            long id,
            GuestInput input,
            string actor)
        {
            if (input == null)
                throw new ArgumentException(
                    "Guest data is required.");

            using (var db = new SLTEntities())
            {
                var guest = await db.Guests
                    .FirstOrDefaultAsync(g =>
                        g.Id == id && !g.IsDeleted);

                if (guest == null)
                    return null;

                if (!string.IsNullOrWhiteSpace(input.Email))
                {
                    string email =
                        NormalizeEmail(input.Email);

                    ValidateEmail(email);

                    if (await db.Guests.AnyAsync(g =>
                        g.Id != id &&
                        !g.IsDeleted &&
                        g.Email == email))
                        throw new ArgumentException(
                            "Another guest uses this email.");
                }

                Merge(guest, input);

                guest.ModifiedBy = actor;
                guest.RetentionDateModified = EgyptDateTimeService.Now;

                await db.SaveChangesAsync();

                return Map(guest);
            }
        }

        public async Task<bool> DeleteAsync(
            long id,
            string actor)
        {
            using (var db = new SLTEntities())
            {
                var guest = await db.Guests
                    .FirstOrDefaultAsync(g =>
                        g.Id == id && !g.IsDeleted);

                if (guest == null)
                    return false;

                guest.IsDeleted = true;
                guest.DeletedBy = actor;
                guest.DeletedAt = EgyptDateTimeService.Now;
                guest.ModifiedBy = actor;
                guest.RetentionDateModified = EgyptDateTimeService.Now;

                guest.FirstLoginAt = null;
                guest.SessionTokenHash = null;
                guest.SessionExpiresAt = null;

                await db.SaveChangesAsync();

                return true;
            }
        }

        public async Task<string> ResetPasscodeAsync(
            long id,
            string actor)
        {
            using (var db = new SLTEntities())
            {
                var guest = await db.Guests
                    .FirstOrDefaultAsync(g =>
                        g.Id == id && !g.IsDeleted);

                if (guest == null)
                    return null;

                string passcode =
                    AssignPasscode(db, guest);

                guest.FirstLoginAt = null;
                guest.SessionTokenHash = null;
                guest.SessionExpiresAt = null;
                guest.ModifiedBy = actor;
                guest.RetentionDateModified = EgyptDateTimeService.Now;

                await db.SaveChangesAsync();

                return passcode;
            }
        }

        public async Task<string> GetPasscodeForAdminAsync(
            long guestId,
            string actorEmail)
        {
            if (string.IsNullOrWhiteSpace(actorEmail))
                throw new UnauthorizedAccessException(
                    "Administrator identity required.");

            using (var db = new SLTEntities())
            using (var tx = db.Database.BeginTransaction())
            {
                var guest = await db.Guests
                    .AsNoTracking()
                    .Where(g =>
                        g.Id == guestId && !g.IsDeleted)
                    .Select(g => new
                    {
                        g.PasscodeProtected
                    })
                    .FirstOrDefaultAsync();

                if (guest == null)
                    return null;

                if (guest.PasscodeProtected == null)
                    throw new InvalidOperationException(
                        "Old passcode cannot be recovered. " +
                        "Reset this guest's passcode first.");

                string passcode = UnprotectPasscode(
                    guest.PasscodeProtected);

                await db.Database.ExecuteSqlCommandAsync(@"
INSERT INTO dbo.GuestPasscodeAccessLogs
(
    GuestId,
    ViewedBy,
    ViewedAt
)
VALUES
(
    @p0,
    @p1,
    @p2
)",
                    guestId, actorEmail, EgyptDateTimeService.Now);

                tx.Commit();

                return passcode;
            }
        }

        public async Task<bool> UploadQrAsync(
            long guestId,
            byte[] image,
            string fileName,
            string contentType,
            string actor)
        {
            if (image == null || image.Length == 0)
                throw new ArgumentException(
                    "QR image required.");

            if (image.Length > 2 * 1024 * 1024)
                throw new ArgumentException(
                    "Maximum QR image size is 2 MB.");

            if (string.IsNullOrWhiteSpace(fileName))
                throw new ArgumentException(
                    "Image filename required.");

            string ext = Path.GetExtension(fileName)
                .ToLowerInvariant();

            bool valid =
                (ext == ".png" &&
                 image.Length >= 8 &&
                 image[0] == 0x89 &&
                 image[1] == 0x50 &&
                 image[2] == 0x4E &&
                 image[3] == 0x47 &&
                 image[4] == 0x0D &&
                 image[5] == 0x0A &&
                 image[6] == 0x1A &&
                 image[7] == 0x0A)
                ||
                ((ext == ".jpg" || ext == ".jpeg") &&
                 image.Length >= 3 &&
                 image[0] == 0xFF &&
                 image[1] == 0xD8 &&
                 image[2] == 0xFF)
                ||
                (ext == ".webp" &&
                 image.Length >= 12 &&
                 Encoding.ASCII.GetString(
                     image, 0, 4) == "RIFF" &&
                 Encoding.ASCII.GetString(
                     image, 8, 4) == "WEBP");

            if (!valid)
                throw new ArgumentException(
                    "Unsupported or invalid image.");

            string mime =
                ext == ".png" ? "image/png" :
                ext == ".webp" ? "image/webp" :
                "image/jpeg";

            using (var db = new SLTEntities())
            {
                var guest = await db.Guests
                    .FirstOrDefaultAsync(g =>
                        g.Id == guestId && !g.IsDeleted);

                if (guest == null)
                    return false;

                guest.QRCodeImage = image;
                guest.QRFileName =
                    Path.GetFileName(fileName);
                guest.QRContentType = mime;
                guest.ModifiedBy = actor;
                guest.RetentionDateModified = EgyptDateTimeService.Now;

                await db.SaveChangesAsync();

                return true;
            }
        }

        public async Task<bool> RemoveQrAsync(
            long guestId,
            string actor)
        {
            using (var db = new SLTEntities())
            {
                var guest = await db.Guests
                    .FirstOrDefaultAsync(g =>
                        g.Id == guestId && !g.IsDeleted);

                if (guest == null)
                    return false;

                // Remove only the exact email-matched file in the configured
                // QR folder. No user-supplied path is ever used here.
                string folderQrPath = FindFolderQr(guest.Email);
                if (folderQrPath != null && File.Exists(folderQrPath))
                {
                    try
                    {
                        File.Delete(folderQrPath);
                    }
                    catch (Exception ex)
                    {
                        throw new InvalidOperationException(
                            "The QR file could not be removed from the configured folder. " +
                            "Grant the IIS application-pool identity Modify permission on the QR folder.", ex);
                    }
                }

                guest.QRCodeImage = null;
                guest.QRFileName = null;
                guest.QRContentType = null;
                guest.ModifiedBy = actor;
                guest.RetentionDateModified = EgyptDateTimeService.Now;

                await db.SaveChangesAsync();
                return true;
            }
        }

        public async Task<Tuple<byte[], string, string>>
            GetQrAsync(long guestId)
        {
            using (var db = new SLTEntities())
            {
                var guest = await db.Guests
                    .AsNoTracking()
                    .FirstOrDefaultAsync(g =>
                        g.Id == guestId && !g.IsDeleted);

                if (guest == null)
                    return null;

                // The folder is the primary source. Images are not copied
                // into SQL; they are served directly from this protected path.
                string path = FindFolderQr(guest.Email);
                if (path != null)
                {
                    try
                    {
                        byte[] fileBytes = await Task.Run(
                            () => File.ReadAllBytes(path));

                        string extension = Path.GetExtension(path);
                        if (IsValidQrImage(fileBytes, extension))
                        {
                            return Tuple.Create(
                                fileBytes,
                                FolderQrMime(path),
                                Path.GetFileName(path));
                        }
                    }
                    catch (IOException)
                    {
                        // Continue to the legacy database image if the
                        // folder image is temporarily unavailable.
                    }
                    catch (UnauthorizedAccessException)
                    {
                        // Continue to the legacy database image if IIS
                        // cannot read the folder file.
                    }
                }

                if (guest.QRCodeImage == null ||
                    guest.QRCodeImage.Length == 0)
                    return null;

                return Tuple.Create(
                    guest.QRCodeImage,
                    guest.QRContentType ?? "image/png",
                    guest.QRFileName ?? "guest-qr.png");
            }
        }

        public async Task<GuestLoginResult> LoginAsync(
            string passcode,
            string clientIp = null)
        {
            passcode = (passcode ?? "").Trim();

            // Consume the request limit before validating
            // against any guest account.
            if (!await SltLoginThrottle.TryConsumeAsync(
                "guest-ip",
                clientIp ?? "unknown",
                5, 15))
                return null;

            if (!await SltLoginThrottle.TryConsumeAsync(
                "guest-global",
                "all",
                60, 15))
                return null;

            if (!ValidPasscode(passcode))
                return null;

            byte[] hash = PasscodeHash(passcode);

            using (var db = new SLTEntities())
            using (var tx = db.Database.BeginTransaction(
                IsolationLevel.Serializable))
            {
                var guest = await db.Guests.SqlQuery(@"
SELECT *
FROM dbo.Guests WITH (UPDLOCK, HOLDLOCK)
WHERE PasscodeHash = @hash
  AND IsDeleted = 0",
                    new SqlParameter(
                        "@hash", SqlDbType.VarBinary, 32)
                    {
                        Value = hash
                    }
                ).FirstOrDefaultAsync();

                if (guest == null ||
                    guest.FirstLoginAt.HasValue)
                    return null;

                DateTime now = EgyptDateTimeService.Now;
                string token = RandomToken();

                guest.FirstLoginAt = now;
                guest.SessionExpiresAt = EgyptDateTimeService.AddDays(30);
                guest.SessionTokenHash = TokenHash(token);

                await db.SaveChangesAsync();
                tx.Commit();

                return new GuestLoginResult
                {
                    Token = token,
                    ExpiresAt = guest.SessionExpiresAt.Value
                };
            }
        }

        public async Task<GuestView> CurrentAsync(
            string token)
        {
            if (string.IsNullOrWhiteSpace(token) ||
                token.Length > 300)
                return null;

            byte[] hash = TokenHash(token);

            using (var db = new SLTEntities())
            {
                var guest = await db.Guests.SqlQuery(@"
SELECT *
FROM dbo.Guests
WHERE SessionTokenHash = @hash
  AND SessionExpiresAt > @nowEgypt
  AND IsDeleted = 0",
                    new SqlParameter(
                        "@hash", SqlDbType.VarBinary, 32)
                    {
                        Value = hash
                    },
                    new SqlParameter(
                        "@nowEgypt", SqlDbType.DateTime2)
                    {
                        Value = EgyptDateTimeService.Now
                    }
                ).FirstOrDefaultAsync();

                return guest == null ? null : Map(guest);
            }
        }

        private static string CleanHeader(string value)
        {
            return new string((value ?? "")
                .Where(c =>
                    !char.IsWhiteSpace(c) &&
                    c != '_' &&
                    c != '-')
                .ToArray());
        }

        private static bool? ParseTourRegister(string value, int row)
        {
            if (string.IsNullOrWhiteSpace(value))
                return null;

            switch (value.Trim().ToLowerInvariant())
            {
                case "1":
                case "true":
                case "yes":
                case "y":
                    return true;

                case "0":
                case "false":
                case "no":
                case "n":
                    return false;

                default:
                    throw new ArgumentException(
                        "Invalid TourRegister on Excel row " + row +
                        ". Allowed: Y/N, Yes/No, True/False, 1/0.");
            }
        }

        private static string DateText(
            string value,
            int row)
        {
            if (string.IsNullOrWhiteSpace(value))
                return "";

            DateTime date;

            if (!DateTime.TryParse(
                value,
                CultureInfo.InvariantCulture,
                DateTimeStyles.None,
                out date))
                throw new ArgumentException(
                    "Invalid date on row " + row);

            return date.ToString(
                "yyyy-MM-dd",
                CultureInfo.InvariantCulture);
        }

        private static string TimeText(
            string value,
            int row)
        {
            if (string.IsNullOrWhiteSpace(value))
                return "";

            TimeSpan time;

            if (!TimeSpan.TryParse(
                value,
                CultureInfo.InvariantCulture,
                out time) ||
                time < TimeSpan.Zero ||
                time >= TimeSpan.FromDays(1))
                throw new ArgumentException(
                    "Invalid time on row " + row);

            return time.ToString(@"hh\:mm\:ss");
        }

        private static GuestInput FromStage(
            StagedGuest row)
        {
            Func<string, DateTime?> date = text =>
                string.IsNullOrWhiteSpace(text)
                    ? (DateTime?)null
                    : DateTime.ParseExact(
                        text,
                        "yyyy-MM-dd",
                        CultureInfo.InvariantCulture);

            Func<string, TimeSpan?> time = text =>
                string.IsNullOrWhiteSpace(text)
                    ? (TimeSpan?)null
                    : TimeSpan.ParseExact(
                        text,
                        @"hh\:mm\:ss",
                        CultureInfo.InvariantCulture);

            return new GuestInput
            {
                FullName = row.FullName,
                Email = row.Email,
                ArrivalDate = date(row.ArrivalDate),
                ArrivalFlight = row.ArrivalFlight,
                LandingTime = time(row.LandingTime),
                DepartureDate = date(row.DepartureDate),
                DepartureFlight = row.DepartureFlight,
                DepartureTime = time(row.DepartureTime),
                HotelName = row.HotelName,
                CheckInDate = date(row.CheckInDate),
                CheckInTime = time(row.CheckInTime),
                CheckOutDate = date(row.CheckOutDate),
                CheckOutTime = time(row.CheckOutTime)
            };
        }

        private static byte[] PrepareExcel(
            byte[] original,
            Guid batchId,
            string actor,
            out int rowCount,
            out Dictionary<string, bool?> tourRegisters,
            out Dictionary<string, string> phoneNumbers)
        {
            rowCount = 0;
            tourRegisters = new Dictionary<string, bool?>(
                StringComparer.OrdinalIgnoreCase);
            phoneNumbers = new Dictionary<string, string>(
                StringComparer.OrdinalIgnoreCase);

            using (var stream =
                new MemoryStream(original))
            using (var input =
                new XLWorkbook(stream))
            using (var output =
                new XLWorkbook())
            {
                var source =
                    input.Worksheets.FirstOrDefault();

                if (source == null)
                    throw new ArgumentException(
                        "Excel worksheet missing.");

                var columns =
                    new Dictionary<string, int>(
                        StringComparer.OrdinalIgnoreCase);

                int lastColumn =
                    source.LastColumnUsed()
                        ?.ColumnNumber() ?? 0;

                for (int col = 1;
                    col <= lastColumn; col++)
                {
                    string heading = CleanHeader(
                        source.Cell(1, col).GetString());

                    if (heading.Length == 0)
                        continue;

                    if (columns.ContainsKey(heading))
                        throw new ArgumentException(
                            "Duplicate Excel header: " +
                            heading);

                    columns.Add(heading, col);
                }

                if (!columns.ContainsKey("FullName") ||
                    !columns.ContainsKey("Email"))
                    throw new ArgumentException(
                        "FullName and Email headers required.");

                var target =
                    output.Worksheets.Add("SLTGuests");

                for (int i = 0;
                    i < StageFields.Length; i++)
                {
                    target.Cell(1, i + 1).Value =
                        StageFields[i];
                }

                var seen =
                    new HashSet<string>(
                        StringComparer.OrdinalIgnoreCase);

                int lastRow =
                    source.LastRowUsed()
                        ?.RowNumber() ?? 1;

                if (lastRow > 10001)
                    throw new ArgumentException(
                        "Maximum 10000 rows allowed.");

                int outputRow = 2;

                for (int row = 2;
                    row <= lastRow; row++)
                {
                    var values =
                        new Dictionary<string, string>(
                            StringComparer.OrdinalIgnoreCase);

                    foreach (string field in ImportFields)
                    {
                        int column;

                        values[field] =
                            columns.TryGetValue(
                                field, out column)
                            ? source.Cell(row, column)
                                .GetFormattedString()
                                .Trim()
                            : "";
                    }

                    int tourColumn;
                    string tourValue = columns.TryGetValue(
                        "TourRegister", out tourColumn)
                        ? source.Cell(row, tourColumn)
                            .GetFormattedString().Trim()
                        : "";

                    // A row with just Email + TourRegister is a valid update.
                    if (values.Values.All(string.IsNullOrWhiteSpace)
                        && string.IsNullOrWhiteSpace(tourValue))
                        continue;

                    string email =
                        NormalizeEmail(values["Email"]);

                    ValidateEmail(email);

                    if (!seen.Add(email))
                        throw new ArgumentException(
                            "Duplicate Excel email: " + email);

                    values["Email"] = email;

                    int phoneColumn;
                    if (columns.TryGetValue("PhoneNumber", out phoneColumn))
                    {
                        string phone = source.Cell(row, phoneColumn)
                            .GetFormattedString().Trim();
                        if (phone.Length > 0) phoneNumbers[email] = phone;
                    }

                    // Keep the global Excel staging schema unchanged.
                    // Apply TourRegister only after staged rows are returned.
                    bool? registration = ParseTourRegister(
                        tourValue, row);
                    if (registration.HasValue)
                        tourRegisters[email] = registration;

                    foreach (string field in new[]
                    {
                        "ArrivalDate",
                        "DepartureDate",
                        "CheckInDate",
                        "CheckOutDate"
                    })
                    {
                        values[field] =
                            DateText(values[field], row);
                    }

                    foreach (string field in new[]
                    {
                        "LandingTime",
                        "DepartureTime",
                        "CheckInTime",
                        "CheckOutTime"
                    })
                    {
                        values[field] =
                            TimeText(values[field], row);
                    }

                    target.Cell(outputRow, 1).Value = "";
                    target.Cell(outputRow, 2).Value =
                        batchId.ToString("D");
                    target.Cell(outputRow, 3).Value = row;

                    for (int i = 0;
                        i < ImportFields.Length; i++)
                    {
                        target.Cell(
                            outputRow, i + 4).Value =
                            values[ImportFields[i]];
                    }

                    target.Cell(outputRow, 17).Value =
                        actor;

                    outputRow++;
                    rowCount++;
                }

                if (rowCount == 0)
                    throw new ArgumentException(
                        "Excel contains no guest records.");

                using (var result =
                    new MemoryStream())
                {
                    output.SaveAs(result);
                    return result.ToArray();
                }
            }
        }

        private static async Task<string>
            GlobalExcelUploadAsync(
                byte[] prepared,
                string fileName,
                string actor)
        {
            using (var form =
                new MultipartFormDataContent())
            {
                form.Add(new StringContent(
                    Setting("ExcelService_DatabaseName")),
                    "DatabaseName");

                form.Add(new StringContent(
                    Setting("ExcelService_SLTGuests_TableName")),
                    "TableName");

                form.Add(new StringContent(
                    Setting("ExcelService_ServerName")),
                    "ServerName");

                form.Add(new StringContent(actor),
                    "email");

                var file = new ByteArrayContent(prepared);

                file.Headers.ContentType =
                    new MediaTypeHeaderValue(
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

                form.Add(file, "file", fileName);

                using (var response = await Http.PostAsync(
                    Setting("ExcelServiceApiUrl"),
                    form))
                {
                    string body = await response.Content
                        .ReadAsStringAsync();

                    if (!response.IsSuccessStatusCode)
                        throw new HttpRequestException(
                            "Excel Service returned HTTP " +
                            (int)response.StatusCode);

                    return body;
                }
            }
        }

        public async Task<bool> RegisterForTourAsync(string token)
        {
            // Identify the guest using their existing token.
            var currentGuest = await CurrentAsync(token);

            if (currentGuest == null)
                return false;

            using (var db = new SLTEntities())
            {
                var guest = await db.Guests.FirstOrDefaultAsync(g =>
                    g.Id == currentGuest.Id &&
                    !g.IsDeleted &&
                    g.SessionExpiresAt > EgyptDateTimeService.Now);

                if (guest == null)
                    return false;

                guest.TourRegister = true;
                guest.ModifiedBy = guest.Email;
                guest.RetentionDateModified = EgyptDateTimeService.Now;

                await db.SaveChangesAsync();

                return true;
            }
        }



        public async Task<GuestImportResult> ImportAsync(
            byte[] workbook,
            string actor)
        {
            if (workbook == null ||
                workbook.Length == 0)
                throw new ArgumentException(
                    "Excel file is empty.");

            Guid batchId = Guid.NewGuid();
            int expected;
            Dictionary<string, bool?> tourRegisters;
            Dictionary<string, string> phoneNumbers;

            byte[] prepared = PrepareExcel(
                workbook,
                batchId,
                actor,
                out expected,
                out tourRegisters,
                out phoneNumbers);

            string excelResponse =
                await GlobalExcelUploadAsync(
                    prepared,
                    "SLTGuests_" +
                        batchId.ToString("N") +
                        ".xlsx",
                    actor);

            using (var db = new SLTEntities())
            {
                var staged = await db.Database
                    .SqlQuery<StagedGuest>(@"
SELECT *
FROM dbo.SLTGuestImportStaging
WHERE BatchId = @batch
ORDER BY RowNumber",
                        new SqlParameter(
                            "@batch",
                            SqlDbType.UniqueIdentifier)
                        {
                            Value = batchId
                        })
                    .ToListAsync();

                if (staged.Count != expected)
                    throw new InvalidOperationException(
                        "Staging count mismatch. Batch: " +
                        batchId);

                var result = new GuestImportResult
                {
                    BatchId = batchId,
                    ExcelServiceResponse = excelResponse
                };

                using (var tx =
                    db.Database.BeginTransaction(
                        IsolationLevel.Serializable))
                {
                    foreach (var row in staged)
                    {
                        GuestInput input = FromStage(row);
                        string importedPhone;
                        if (phoneNumbers.TryGetValue(
                            NormalizeEmail(row.Email), out importedPhone))
                            input.PhoneNumber = importedPhone;
                        string email =
                            NormalizeEmail(input.Email);

                        bool? tourRegister;
                        if (tourRegisters.TryGetValue(
                            email, out tourRegister))
                        {
                            input.TourRegister = tourRegister;
                        }

                        var existing = await db.Guests
                            .FirstOrDefaultAsync(g =>
                                !g.IsDeleted &&
                                g.Email == email);

                        if (existing == null)
                        {
                            var created = CreateInside(
                                db, input, actor);

                            result.Created++;

                            result.Rows.Add(
                                new ImportRowResult
                                {
                                    Row = row.RowNumber,
                                    Email = email,
                                    Action = "Created",
                                    Passcode = created.Passcode,
                                    HasQR = created.Guest != null && created.Guest.HasQR,
                                    QRFileName = created.Guest == null ? null : created.Guest.QRFileName,
                                    QRSource = created.Guest == null ? null : created.Guest.QRSource
                                });
                        }
                        else
                        {
                            // Blank cells don't overwrite data.
                            Merge(existing, input);

                            existing.ModifiedBy = actor;
                            existing.RetentionDateModified =
                                EgyptDateTimeService.Now;

                            result.Updated++;

                            GuestView updatedGuest = Map(existing);

                            result.Rows.Add(
                                new ImportRowResult
                                {
                                    Row = row.RowNumber,
                                    Email = email,
                                    Action = "Updated",
                                    HasQR = updatedGuest.HasQR,
                                    QRFileName = updatedGuest.QRFileName,
                                    QRSource = updatedGuest.QRSource
                                });
                        }
                    }

                    await db.SaveChangesAsync();

                    await db.Database.ExecuteSqlCommandAsync(
                        @"DELETE FROM dbo.SLTGuestImportStaging
                          WHERE BatchId = @p0",
                        batchId);

                    tx.Commit();
                }

                return result;
            }
        }



        public async Task<int> GetLoggedInGuestsCountAsync()
        {
            using (var db = new SLTEntities())
            {
                return await db.Guests
                    .AsNoTracking()
                    .CountAsync(g =>
                        !g.IsDeleted &&
                        g.FirstLoginAt != null
                    );
            }
        }

        // ============================================================
        // ADMIN TABLE: DATABASE-SIDE PAGING AND FILTERED XLSX EXPORT
        // The public unpaged GetAllAsync API remains unchanged.
        // ============================================================
        public async Task<SltTablePage<GuestView>> GetPagedAsync(
            SltTableQuery filter)
        {
            var page = await SltTableDataService.GuestsAsync(
                filter ?? new SltTableQuery());

            // SltTableDataService projects directly from SQL. Overlay the
            // folder-based QR metadata so the admin grid sees the same QR
            // state as GetAllAsync, GetAsync, and the guest QR endpoint.
            if (page != null && page.Items != null)
            {
                foreach (var guest in page.Items)
                {
                    string path = FindFolderQr(guest.Email);
                    if (path != null)
                    {
                        guest.HasQR = true;
                        guest.QRFileName = Path.GetFileName(path);
                        guest.QRSource = "Folder";
                    }
                    else if (guest.HasQR)
                    {
                        guest.QRSource = "Database";
                    }
                    else
                    {
                        guest.QRSource = null;
                    }
                }
            }

            return page;
        }

        public Task<byte[]> ExportFilteredAsync(SltTableQuery filter)
        {
            return SltTableDataService.ExportXlsxAsync<GuestView>(
                GetPagedAsync,
                filter ?? new SltTableQuery(),
                new[] { "Id", "FullName", "Email", "PhoneNumber", "ArrivalDate", "ArrivalFlight", "DepartureDate", "HotelName", "TourRegister", "Activated", "HasQR", "QRFileName", "QRSource" });
        }

    }
}
