﻿
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Xml;
using SLTProject.Data;
using SLTProject.Models.Dtos;

namespace SLTProject.Services
{
    public class BlurIconsService
    {
        // ========================================================
        // SVG CONSTANTS
        // ========================================================

        private const string SvgNamespace =
            "http://www.w3.org/2000/svg";

        private const int MaxSvgLength = 20000;

        private static readonly HashSet<string>
            AllowedElements =
                new HashSet<string>(
                    StringComparer.Ordinal)
                {
                    "svg",
                    "g",
                    "path",
                    "rect",
                    "circle",
                    "ellipse",
                    "line",
                    "polyline",
                    "polygon"
                };

        private static readonly HashSet<string>
            AllowedAttributes =
                new HashSet<string>(
                    StringComparer.Ordinal)
                {
                    "viewBox",
                    "width",
                    "height",

                    "fill",
                    "stroke",
                    "stroke-width",
                    "stroke-linecap",
                    "stroke-linejoin",
                    "stroke-miterlimit",
                    "stroke-dasharray",
                    "stroke-dashoffset",

                    "fill-rule",
                    "clip-rule",
                    "fill-opacity",
                    "stroke-opacity",
                    "opacity",

                    "d",
                    "x",
                    "y",
                    "x1",
                    "y1",
                    "x2",
                    "y2",
                    "cx",
                    "cy",
                    "r",
                    "rx",
                    "ry",
                    "points",
                    "transform"
                };

        // ========================================================
        // GLOBAL EGYPT TIME
        // ========================================================

        private static DateTime NowEgypt
        {
            get
            {
                return EgyptDateTimeService.Now;
            }
        }

        // ========================================================
        // SVG MARKUP VALIDATION
        // ========================================================

        private static string ValidateSvg(
            string svg)
        {
            if (string.IsNullOrWhiteSpace(svg))
            {
                throw new ArgumentException(
                    "SVG is required.");
            }

            svg = svg.Trim();

            if (svg.Length > MaxSvgLength)
            {
                throw new ArgumentException(
                    "SVG exceeds the allowed size.");
            }

            var settings = new XmlReaderSettings
            {
                DtdProcessing =
                    DtdProcessing.Prohibit,

                XmlResolver = null,

                MaxCharactersInDocument =
                    MaxSvgLength,

                MaxCharactersFromEntities = 0
            };

            var document = new XmlDocument
            {
                XmlResolver = null
            };

            try
            {
                using (var reader =
                    XmlReader.Create(
                        new StringReader(svg),
                        settings))
                {
                    document.Load(reader);
                }
            }
            catch (XmlException)
            {
                throw new ArgumentException(
                    "Invalid SVG markup.");
            }

            if (document.DocumentElement == null ||
                document.DocumentElement.LocalName != "svg" ||
                document.DocumentElement.NamespaceURI !=
                    SvgNamespace)
            {
                throw new ArgumentException(
                    "SVG must contain an SVG root element.");
            }

            ValidateSvgNode(
                document.DocumentElement);

            // Store only the validated SVG element.
            return document.DocumentElement.OuterXml;
        }

        // ========================================================
        // SVG NODE / ATTRIBUTE VALIDATION
        // ========================================================

        private static void ValidateSvgNode(
            XmlNode node)
        {
            if (node.NodeType != XmlNodeType.Element)
            {
                throw new ArgumentException(
                    "Unsupported SVG content.");
            }

            if (node.NamespaceURI != SvgNamespace ||
                !AllowedElements.Contains(
                    node.LocalName))
            {
                throw new ArgumentException(
                    "Unsupported SVG element: " +
                    node.LocalName);
            }

            if (node.Attributes != null)
            {
                foreach (
                    XmlAttribute attribute
                    in node.Attributes)
                {
                    // Only allow the default SVG namespace.
                    if (attribute.Prefix == "xmlns" ||
                        attribute.Name == "xmlns")
                    {
                        if (attribute.Name != "xmlns" ||
                            attribute.Value != SvgNamespace)
                        {
                            throw new ArgumentException(
                                "Unsupported SVG namespace.");
                        }

                        continue;
                    }

                    if (!string.IsNullOrEmpty(
                            attribute.NamespaceURI) ||
                        !AllowedAttributes.Contains(
                            attribute.LocalName))
                    {
                        throw new ArgumentException(
                            "Unsupported SVG attribute: " +
                            attribute.Name);
                    }

                    string value =
                        (attribute.Value ?? string.Empty)
                            .Trim();

                    if (value.IndexOf(
                            "url(",
                            StringComparison.OrdinalIgnoreCase)
                            >= 0 ||
                        value.IndexOf(
                            "javascript:",
                            StringComparison.OrdinalIgnoreCase)
                            >= 0 ||
                        value.IndexOf(
                            "expression(",
                            StringComparison.OrdinalIgnoreCase)
                            >= 0)
                    {
                        throw new ArgumentException(
                            "Unsafe SVG attribute value.");
                    }

                    if (value.IndexOf('#') >= 0 &&
                        attribute.LocalName != "fill" &&
                        attribute.LocalName != "stroke")
                    {
                        throw new ArgumentException(
                            "Unsupported SVG reference.");
                    }
                }
            }

            foreach (XmlNode child in node.ChildNodes)
            {
                if (child.NodeType ==
                        XmlNodeType.Whitespace ||
                    child.NodeType ==
                        XmlNodeType.SignificantWhitespace)
                {
                    continue;
                }

                ValidateSvgNode(child);
            }
        }

        // ========================================================
        // VALIDATE INPUT
        // ========================================================

        private static string ValidateInput(
            BlurIconInput input)
        {
            if (input == null)
            {
                throw new ArgumentException(
                    "Blurb icon data is required.");
            }

            if (string.IsNullOrWhiteSpace(input.Name))
            {
                throw new ArgumentException(
                    "Blurb icon name is required.");
            }

            if (input.Name.Trim().Length > 150)
            {
                throw new ArgumentException(
                    "Blurb icon name exceeds 150 characters.");
            }

            if (input.Shape != null &&
                input.Shape.Trim().Length > 100)
            {
                throw new ArgumentException(
                    "Shape exceeds 100 characters.");
            }

            return ValidateSvg(input.SVG);
        }

        // ========================================================
        // ENTITY TO DTO
        // ========================================================

        private static BlurIconDto Map(
            BlurIcon entity)
        {
            if (entity == null)
                return null;

            return new BlurIconDto
            {
                Id = entity.Id,

                Name = entity.Name,

                SVG = entity.SVG,

                Shape = entity.Shape,

                CreatedAt = entity.CreatedAt,

                CreatedBy = entity.CreatedBy,

                ModifiedAt = entity.ModifiedAt,

                ModifiedBy = entity.ModifiedBy,

                IsDeleted = entity.IsDeleted,

                DeletedAt = entity.DeletedAt,

                DeletedBy = entity.DeletedBy,

                RetentionDateCreated =
                    entity.RetentionDateCreated,

                RetentionDateModified =
                    entity.RetentionDateModified
            };
        }

        // ========================================================
        // CREATE BLURB ICON
        // ========================================================

        public async Task<BlurIconDto> CreateAsync(
            BlurIconInput input,
            string actor)
        {
            string safeSvg =
                ValidateInput(input);

            string name =
                input.Name.Trim();

            DateTime nowEgypt =
                NowEgypt;

            using (var db = new SLTEntities())
            {
                bool exists =
                    await db.BlurIcons.AnyAsync(
                        x =>
                            !x.IsDeleted &&
                            x.Name == name);

                if (exists)
                {
                    throw new ArgumentException(
                        "An active blurb icon with " +
                        "this name already exists.");
                }

                var entity = new BlurIcon
                {
                    Name = name,

                    SVG = safeSvg,

                    Shape =
                        string.IsNullOrWhiteSpace(
                            input.Shape)
                            ? null
                            : input.Shape.Trim(),

                    CreatedAt = nowEgypt,

                    CreatedBy = actor,

                    IsDeleted = false,

                    RetentionDateCreated =
                        nowEgypt
                };

                db.BlurIcons.Add(entity);

                await db.SaveChangesAsync();

                return Map(entity);
            }
        }

        // ========================================================
        // GET ALL BLURB ICONS
        // NO PAGINATION
        // ========================================================

        public async Task<List<BlurIconDto>>
            GetAllAsync()
        {
            using (var db = new SLTEntities())
            {
                var records =
                    await db.BlurIcons
                        .AsNoTracking()
                        .Where(
                            x => !x.IsDeleted)
                        .OrderBy(
                            x => x.Name)
                        .ToListAsync();

                return records
                    .Select(Map)
                    .ToList();
            }
        }

        // ========================================================
        // GET BLURB ICON BY ID
        // ========================================================

        public async Task<BlurIconDto>
            GetByIdAsync(long id)
        {
            if (id <= 0)
                return null;

            using (var db = new SLTEntities())
            {
                var entity =
                    await db.BlurIcons
                        .AsNoTracking()
                        .FirstOrDefaultAsync(
                            x =>
                                x.Id == id &&
                                !x.IsDeleted);

                return Map(entity);
            }
        }

        // ========================================================
        // UPDATE BLURB ICON
        // ========================================================

        public async Task<BlurIconDto>
            UpdateAsync(
                long id,
                BlurIconInput input,
                string actor)
        {
            if (id <= 0)
                return null;

            string safeSvg =
                ValidateInput(input);

            string name =
                input.Name.Trim();

            using (var db = new SLTEntities())
            {
                var entity =
                    await db.BlurIcons
                        .FirstOrDefaultAsync(
                            x =>
                                x.Id == id &&
                                !x.IsDeleted);

                if (entity == null)
                    return null;

                bool duplicate =
                    await db.BlurIcons.AnyAsync(
                        x =>
                            x.Id != id &&
                            !x.IsDeleted &&
                            x.Name == name);

                if (duplicate)
                {
                    throw new ArgumentException(
                        "An active blurb icon with " +
                        "this name already exists.");
                }

                DateTime nowEgypt =
                    NowEgypt;

                entity.Name = name;

                entity.SVG = safeSvg;

                entity.Shape =
                    string.IsNullOrWhiteSpace(
                        input.Shape)
                        ? null
                        : input.Shape.Trim();

                entity.ModifiedAt = nowEgypt;

                entity.ModifiedBy = actor;

                entity.RetentionDateModified =
                    nowEgypt;

                await db.SaveChangesAsync();

                return Map(entity);
            }
        }

        // ========================================================
        // SOFT DELETE BLURB ICON
        // ========================================================

        public async Task<bool> DeleteAsync(
            long id,
            string actor)
        {
            if (id <= 0)
                return false;

            using (var db = new SLTEntities())
            {
                var entity =
                    await db.BlurIcons
                        .FirstOrDefaultAsync(
                            x =>
                                x.Id == id &&
                                !x.IsDeleted);

                if (entity == null)
                    return false;

                DateTime nowEgypt =
                    NowEgypt;

                entity.IsDeleted = true;

                entity.DeletedAt = nowEgypt;

                entity.DeletedBy = actor;

                entity.ModifiedAt = nowEgypt;

                entity.ModifiedBy = actor;

                entity.RetentionDateModified =
                    nowEgypt;

                await db.SaveChangesAsync();

                return true;
            }
        }
    }
}
