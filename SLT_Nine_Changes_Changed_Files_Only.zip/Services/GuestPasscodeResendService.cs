﻿
using System;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using SLTProject.Data;

namespace SLTProject.Services
{
    public class GuestPasscodeResendResult
    {
        public bool Eligible { get; set; }
        public bool EmailSent { get; set; }
        public bool SmsSent { get; set; }
    }

    public class GuestPasscodeResendService
    {
        private readonly GuestsService _guestsService;
        private readonly EmailTemplateService _emailService;

        public GuestPasscodeResendService()
        {
            _guestsService = new GuestsService();
            _emailService = new EmailTemplateService();
        }

        // ==========================================
        // MAIN RESEND METHOD
        // ==========================================

        public async Task<GuestPasscodeResendResult>
            ResendAsync(string email, string clientIp)
        {
            var result = new GuestPasscodeResendResult
            {
                Eligible = false,
                EmailSent = false
            };

            // STEP 1: Validate email.
            email = (email ?? "").Trim().ToLowerInvariant();

            if (string.IsNullOrWhiteSpace(email) ||
                email.Length > 254 ||
                !new EmailAddressAttribute().IsValid(email))
            {
                return result;
            }

            // STEP 2: Apply request throttling.
            // Reuses your existing SltLoginThrottle.
            bool ipAllowed =
                await SltLoginThrottle.TryConsumeAsync(
                    "guest-resend-ip",
                    clientIp ?? "unknown",
                    5,
                    15);

            if (!ipAllowed)
                return result;

            bool emailAllowed =
                await SltLoginThrottle.TryConsumeAsync(
                    "guest-resend-email",
                    HashEmail(email),
                    1,
                    15);

            if (!emailAllowed)
                return result;

            bool globalAllowed =
                await SltLoginThrottle.TryConsumeAsync(
                    "guest-resend-global",
                    "all",
                    100,
                    15);

            if (!globalAllowed)
                return result;

            // STEP 3: Find guest by registered email.
            long guestId;
            string guestEmail;
            string guestName;
            string guestPhone;

            using (var db = new SLTEntities())
            {
                var guest = await db.Guests
                    .AsNoTracking()
                    .Where(g =>
                        !g.IsDeleted &&
                        g.Email == email)
                    .Select(g => new
                    {
                        g.Id,
                        g.Email,
                        g.FullName,
                        g.PhoneNumber
                    })
                    .FirstOrDefaultAsync();

                if (guest == null)
                    return result;

                guestId = guest.Id;
                guestEmail = guest.Email;
                guestName = guest.FullName;
                guestPhone = guest.PhoneNumber;
            }

            // STEP 4: Regenerate passcode.
            //
            // Existing ResetPasscodeAsync does:
            // - Generates unique 3-letter / 3-digit code
            // - Updates PasscodeHash
            // - Updates PasscodeLast4
            // - Updates PasscodeProtected
            // - Clears FirstLoginAt
            // - Revokes existing session
            // - Saves database changes

            string newPasscode =
                await _guestsService.ResetPasscodeAsync(
                    guestId,
                    "GuestSelfService");

            if (string.IsNullOrWhiteSpace(newPasscode))
                return result;

            result.Eligible = true;

            // STEP 5: Send new passcode by email.
            //
            // Reuses the existing email template:
            // GUEST_PASSCODE_RESET

            try
            {
                result.EmailSent =
                    await _emailService.SendAsync(
                        "GUEST_PASSCODE_RESET",
                        guestEmail,
                        guestName,
                        newPasscode);

                if (!result.EmailSent)
                {
                    Trace.TraceWarning(
                        "Guest passcode reset completed, " +
                        "but email delivery was not accepted. " +
                        "GuestId: " + guestId);
                }
            }
            catch (Exception ex)
            {
                result.EmailSent = false;

                // Never log the generated passcode.
                Trace.TraceError(
                    "Guest passcode email failed. " +
                    "GuestId: " + guestId +
                    ". Error type: " +
                    ex.GetType().Name);
            }

            // Also send the generated passcode by SMS. Do not log code or phone.
            try
            {
                if (!string.IsNullOrWhiteSpace(guestPhone))
                {
                    string body;
                    using (var db = new SLTEntities())
                    {
                        var template = await db.Set<SmsTemplate>().AsNoTracking()
                            .FirstOrDefaultAsync(x => x.TemplateKey == "GUEST_PASSCODE_SMS" && x.IsActive);
                        if (template == null || string.IsNullOrWhiteSpace(template.TemplateBody))
                            throw new InvalidOperationException("Active GUEST_PASSCODE_SMS template is missing.");
                        body = template.TemplateBody.Replace("{FullName}", guestName ?? "")
                            .Replace("{Passcode}", newPasscode);
                    }
                    result.SmsSent = await new SmsService().SendSmsAsync(guestPhone, body);
                }
            }
            catch (Exception ex)
            {
                Trace.TraceWarning("Guest passcode SMS dispatch failed: " + ex.GetType().Name);
            }
            // Do not return the passcode or disclose delivery results publicly.
            return result;
        }

        // ==========================================
        // HASH EMAIL FOR THROTTLING KEY
        // ==========================================

        private static string HashEmail(string email)
        {
            using (var sha = SHA256.Create())
            {
                byte[] bytes = Encoding.UTF8.GetBytes(
                    email ?? "");

                byte[] hash = sha.ComputeHash(bytes);

                return BitConverter.ToString(hash)
                    .Replace("-", "");
            }
        }
    }
}
