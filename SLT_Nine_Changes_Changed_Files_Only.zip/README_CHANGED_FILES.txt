SLTProject | Nine UI and Passcode Changes | Changed files only
===========================================================

Copy files over the same relative paths inside your SLTProject solution.
No controller source file required changes; existing API routes are retained.

Included changes:
1. GuestsService/AdminService generate 3 UPPERCASE letters + 3 numbers (e.g. ABC123). Existing six-digit issued codes remain accepted during migration. Backend normalizes entered values to uppercase.
2. Selected guests are visible by name/email in Guest Records and Invitations and removable individually.
3. Admin login has dark theme only; guest email/passcode screen is dark, returning to a light guest profile after login.
4. Other admin pages default to light; existing sidebar dark-mode switch remains available and persisted.
5. View QR opens an image modal with Download QR and Close.
6. New SMS Templates sidebar page directly below Email Templates. Old SMS tab removed from Guests.
7. Import warning notes added to Guests, Airport Transfers, Day Schedules, Event Drivers.
8. Invitation results display totals and detailed row errors in cards.
9. Email/SMS guest status shows 'Sent' instead of 'Accepted'.

Deploy notes:
- Add new assets/sms-templates-admin.js, assets/slt-guest-enhancements.css and sms-templates-admin.html to Visual Studio project with Build Action Content and Copy to Output Directory as appropriate.
- Rebuild and publish all changed backend and frontend files together. Invalidate browser caches if using service workers.
- Stored SQL email/SMS template descriptions that still say 'six-digit' need updating through the template administration pages (templates are DB records, not in these ZIP uploads).
- 'Sent' denotes accepted by delivery gateway, not verified final delivery.
- Run guest and admin login test with NEW generated codes, then retest OLD numeric codes for backward compatibility.
- Note: C# build could not be run without full solution/EDMX models; JavaScript syntax and HTML structure were checked.
- Guest invitation delivery flow, persistent session and throttle are unchanged.

Files included:
Frontend/admin-login.html
Frontend/airport-transfers-admin.html
Frontend/assets/guest-login.js
Frontend/assets/guests-admin.js
Frontend/assets/guests-operations.js
Frontend/assets/shell.js
Frontend/assets/slt-guest-enhancements.css
Frontend/assets/slt-login-theme.js
Frontend/assets/sms-templates-admin.js
Frontend/day-schedules-admin.html
Frontend/guest-event-drivers-admin.html
Frontend/guest-login.html
Frontend/guest-notifications-test.html
Frontend/guests-admin.html
Frontend/sms-templates-admin.html
Services/AdminService.cs
Services/GuestPasscodeResendService.cs
Services/GuestsService.cs
