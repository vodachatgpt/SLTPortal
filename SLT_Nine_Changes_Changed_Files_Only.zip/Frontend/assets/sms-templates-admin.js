(function(){"use strict";
const $=id=>document.getElementById(id);
const form=$("smsTemplateForm"), select=$("smsTemplateKey"), body=$("smsTemplateBody"), active=$("smsTemplateActive"), save=$("smsTemplateSave");
const status=$("smsStatus");
function show(message,error){status.textContent=message;status.className=error?"slt-error":"slt-success-report";if(typeof sltNotify==="function")sltNotify(message,error?"error":"success");}
async function load(){try{const items=await sltRequest("/guests/sms-templates");const found=(items||[]).find(x=>x.TemplateKey===select.value);body.value=found?found.TemplateBody||"":"";active.checked=!found||found.IsActive===true;status.textContent="";}catch(e){show("Unable to load templates: "+e.message,true);}}
select.addEventListener("change",load);
$("refreshSms").addEventListener("click",load);
form.addEventListener("submit",async event=>{event.preventDefault();save.disabled=true;try{await sltRequest("/guests/sms-templates",{method:"PUT",body:JSON.stringify({TemplateKey:select.value,TemplateBody:body.value,IsActive:active.checked})});show("SMS template saved successfully.",false);}catch(e){show("Unable to save: "+e.message,true);}finally{save.disabled=false;}});
load();
})();
