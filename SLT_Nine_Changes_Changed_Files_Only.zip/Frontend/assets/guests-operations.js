(function () {
    "use strict";

    const $ = id => document.getElementById(id);

    const selectedGuests = new Map();

    let authorized = false;
    let observer = null;

    // ==========================================
    // NOTIFICATIONS
    // ==========================================

    function notify(text, error) {
        sltNotify(
            text,
            error ? "error" : "success"
        );
    }

    // ==========================================
    // TAB MANAGEMENT
    // ==========================================

    const panes = Array.from(
        document.querySelectorAll("[data-pane]")
    );

    const tabs = Array.from(
        document.querySelectorAll("[data-guest-tab]")
    );

    function switchTab(name) {
        panes.forEach(function (pane) {
            pane.hidden = pane.dataset.pane !== name;
        });

        tabs.forEach(function (tab) {
            const active =
                tab.dataset.guestTab === name;

            tab.classList.toggle("is-active", active);

            tab.setAttribute(
                "aria-selected",
                String(active)
            );
        });

        if (name === "invitations") {
            updateSelectionDisplay();
        }
    }

    window.sltGuestSwitchTab = switchTab;

    tabs.forEach(function (tab) {
        tab.addEventListener("click", function () {
            switchTab(tab.dataset.guestTab);
        });
    });

    switchTab("records");

    // ==========================================
    // SELECTION MANAGEMENT
    // ==========================================

    function updateSelectionDisplay() {
        const count = selectedGuests.size;

        const target = document.querySelector(
            'input[name="target"]:checked'
        );

        const all = target && target.value === "all";

        $("invitationSelected").textContent =
            all
                ? "All eligible guests will receive the invitation."
                : count === 0
                    ? "No guests selected. Select guests from Guest Records."
                    : count + " guest(s) selected and ready for invitation.";

        $("invitationSelected").classList.toggle(
            "has-selection",
            count > 0 && !all
        );
        let tray = document.getElementById("sltSelectedGuestsTray");
        if (!tray) {
            tray = document.createElement("div");
            tray.id = "sltSelectedGuestsTray";
            tray.className = "slt-selected-guests-tray";
            tray.setAttribute("aria-live", "polite");
            const text = document.getElementById("invitationSelected");
            text.insertAdjacentElement("afterend", tray);
            tray.addEventListener("click", event => {
                const remove = event.target.closest("[data-remove-guest]");
                if (!remove) return;
                selectedGuests.delete(Number(remove.dataset.removeGuest));
                updateSelectionDisplay();
                updatePageCheckbox();
                document.querySelectorAll(".slt-select-guest").forEach(box => {
                    box.checked = selectedGuests.has(Number(box.dataset.guestId));
                });
            });
        }
        const escapeText = value => String(value || "").replace(/[&<>"']/g, character => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[character]));
        tray.hidden = all || count === 0;
        let recordTray = document.getElementById("sltGuestRecordSelection");
        if (!recordTray) {
            recordTray = document.createElement("section");
            recordTray.id = "sltGuestRecordSelection";
            recordTray.className = "slt-record-selected-summary";
            const recordsPane = document.querySelector('[data-pane="records"]');
            if (recordsPane) recordsPane.insertBefore(recordTray, recordsPane.firstChild);
            recordTray.addEventListener("click", event => {
                const remove = event.target.closest("[data-remove-guest]");
                if (remove) {
                    selectedGuests.delete(Number(remove.dataset.removeGuest));
                    updateSelectionDisplay();
                    restorePageSelection();
                }
            });
        }
        recordTray.hidden = count === 0;
        recordTray.innerHTML = count ? '<strong>'+count+' guest(s) selected</strong><div class="slt-selected-guests-tray">'+Array.from(selectedGuests.values()).map(g =>
            `<span class="slt-selected-guest-chip"><strong>${escapeText(g.FullName || g.Id)}</strong><small>${escapeText(g.Email)}</small><button type="button" data-remove-guest="${g.Id}" aria-label="Remove guest">×</button></span>`
        ).join("")+'</div>' : "";
        tray.innerHTML = all ? "" : Array.from(selectedGuests.values()).map(g =>
            `<span class="slt-selected-guest-chip"><strong>${escapeText(g.FullName || g.Email || g.Id)}</strong><small>${escapeText(g.Email)}</small><button type="button" data-remove-guest="${g.Id}" aria-label="Remove guest">×</button></span>`
        ).join("");
    }

    function updatePageCheckbox() {
        const boxes = Array.from(
            document.querySelectorAll(".slt-select-guest")
        );

        const master = $("selectPageGuests");

        if (!master) return;

        const checkedCount = boxes.filter(
            box => selectedGuests.has(
                Number(box.dataset.guestId)
            )
        ).length;

        master.checked =
            boxes.length > 0 &&
            checkedCount === boxes.length;

        master.indeterminate =
            checkedCount > 0 &&
            checkedCount < boxes.length;
    }

    function restorePageSelection() {
        document.querySelectorAll(
            ".slt-select-guest"
        ).forEach(function (box) {

            const id = Number(box.dataset.guestId);

            box.checked = selectedGuests.has(id);

        });

        updatePageCheckbox();
        updateSelectionDisplay();
    }

    $("guestRows").addEventListener(
        "change",
        function (event) {

            const box = event.target.closest(
                ".slt-select-guest"
            );

            if (!box) return;

            const id = Number(box.dataset.guestId);

            if (box.checked) {

                selectedGuests.set(id, {
                    Id: id,
                    FullName: box.dataset.fullName || "",
                    Email: box.dataset.email || ""
                });

            } else {
                selectedGuests.delete(id);
            }

            updatePageCheckbox();
            updateSelectionDisplay();
        }
    );

    $("selectPageGuests").addEventListener(
        "change",
        function (event) {

            const checked = event.target.checked;

            document.querySelectorAll(
                ".slt-select-guest"
            ).forEach(function (box) {

                const id = Number(box.dataset.guestId);

                box.checked = checked;

                if (checked) {

                    selectedGuests.set(id, {
                        Id: id,
                        FullName: box.dataset.fullName || "",
                        Email: box.dataset.email || ""
                    });

                } else {
                    selectedGuests.delete(id);
                }

            });

            updatePageCheckbox();
            updateSelectionDisplay();
        }
    );

    // Restore selections after the main table rerenders.

    observer = new MutationObserver(function () {
        restorePageSelection();
    });

    observer.observe(
        $("guestRows"),
        {
            childList: true
        }
    );

    // ==========================================
    // TARGET CHANGE
    // ==========================================

    document.querySelectorAll(
        'input[name="target"]'
    ).forEach(function (radio) {

        radio.addEventListener(
            "change",
            updateSelectionDisplay
        );

    });

    // ==========================================
    // STATISTICS
    // ==========================================

    async function loadStats() {
        try {

            const result = await sltRequest(
                "/guests/statistics"
            );

            $("statTotal").textContent =
                result.Total ?? "—";

            $("statLogged").textContent =
                result.LoggedIn ?? "—";

            $("statNotLogged").textContent =
                result.NotLoggedIn ?? "—";

            $("statTour").textContent =
                result.TourRegistered ?? "—";

            $("statNotTour").textContent =
                result.TourNotRegistered ?? "—";

        } catch (error) {

            console.error(
                "[SLT Guest Statistics]",
                error
            );

            notify(
                "Unable to load statistics: " +
                error.message,
                true
            );
        }
    }

    $("statRefresh").addEventListener(
        "click",
        async function () {

            const button = $("statRefresh");

            button.disabled = true;

            try {
                await loadStats();

            } finally {
                button.disabled = false;
            }
        }
    );

    // ==========================================
    // EXCEL DOWNLOAD
    // ==========================================

    function downloadExcel(result, fileName) {

        if (!(result instanceof Blob)) {
            throw new Error(
                "The server did not return an Excel file."
            );
        }

        if (result.size === 0) {
            throw new Error(
                "The returned Excel file is empty."
            );
        }

        sltDownload(
            result,
            fileName,
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        );
    }

    async function download(route, fileName) {
        const result = await sltRequest(route);

        downloadExcel(
            result,
            fileName
        );
    }

    // ==========================================
    // STATISTICS EXPORT BUTTONS
    // ==========================================

    $("guestMetrics").addEventListener(
        "click",
        async function (event) {

            const button = event.target.closest(
                "button[data-export]"
            );

            if (!button) return;

            const segment = button.dataset.export;

            button.disabled = true;

            try {

                await download(
                    "/guests/export-segment?segment=" +
                    encodeURIComponent(segment),

                    "SLT_Guests_" + segment + ".xlsx"
                );

                notify(
                    "Guest Excel export generated successfully."
                );

            } catch (error) {

                console.error(
                    "[SLT Guest Export]",
                    error
                );

                notify(
                    "Export failed: " + error.message,
                    true
                );

            } finally {
                button.disabled = false;
            }
        }
    );

    // ==========================================
    // DOWNLOAD EXCEL TEMPLATE
    // ==========================================

    $("downloadExcelTemplate").addEventListener(
        "click",
        async function () {

            const button = $("downloadExcelTemplate");

            button.disabled = true;

            try {

                await download(
                    "/guests/excel-template",
                    "SLT_Guests_Import_Template.xlsx"
                );

                notify("Excel template downloaded.");

            } catch (error) {

                notify(
                    "Template download failed: " +
                    error.message,
                    true
                );

            } finally {
                button.disabled = false;
            }
        }
    );

    // ==========================================
    // SEND INVITATIONS
    // ==========================================

    $("invitationForm").addEventListener(
        "submit",
        async function (event) {

            event.preventDefault();

            const sendEmail = $("sendEmail").checked;
            const sendSms = $("sendSms").checked;

            const target = document.querySelector(
                'input[name="target"]:checked'
            );

            const all =
                target && target.value === "all";

            if (!sendEmail && !sendSms) {
                notify(
                    "Please select at least one delivery channel.",
                    true
                );
                return;
            }

            if (!all && selectedGuests.size === 0) {
                notify(
                    "Please select at least one guest.",
                    true
                );
                return;
            }

            const description = all
                ? "all eligible guests"
                : selectedGuests.size + " selected guest(s)";

            if (!await sltConfirm(
                "Send invitations to " + description + "?"
            )) {
                return;
            }

            const button = $("sendInvitations");

            button.disabled = true;

            try {

                const payload = {
                    All: all,

                    GuestIds: Array.from(
                        selectedGuests.keys()
                    ),

                    SendEmail: sendEmail,

                    SendSms: sendSms,

                    ForceResend: $("forceResend").checked
                };

                const result = await sltRequest(
                    "/guests/send-invitations",
                    {
                        method: "POST",
                        body: JSON.stringify(payload)
                    }
                );

                const errors = result.Errors || [];

                const selected =
                    result.Selected ?? 0;

                const emailAccepted =
                    result.EmailAccepted ?? 0;

                const smsAccepted =
                    result.SmsAccepted ?? 0;

                const resultContainer = $("invitationResult");
                resultContainer.innerHTML = `<div class="slt-delivery-report" role="status">
                    <h3>Invitation delivery report</h3>
                    <div class="slt-delivery-metrics">
                      <div><span>Recipients selected</span><strong>${Number(selected)}</strong></div>
                      <div><span>Emails sent</span><strong>${Number(emailAccepted)}</strong></div>
                      <div><span>SMS sent</span><strong>${Number(smsAccepted)}</strong></div>
                      <div><span>Errors</span><strong>${errors.length}</strong></div>
                    </div>
                    ${errors.length ? `<details open><summary>Delivery issues (${errors.length})</summary><ul>${errors.map(e => `<li>${escapeText(typeof e === "string" ? e : JSON.stringify(e))}</li>`).join("")}</ul></details>` : `<p class="slt-success-report">No delivery errors reported.</p>`}
                    <p class="slt-report-footnote">Sent means the delivery gateway accepted the message; delivery to the device or inbox is not guaranteed.</p>
                </div>`;

                if (errors.length) {
                    console.warn(
                        "[SLT Invitation Errors]",
                        errors
                    );
                }

                notify(
                    errors.length
                        ? "Invitation processing completed with errors."
                        : "Invitation processing completed successfully.",
                    errors.length > 0
                );

                await Promise.all([
                    loadStats(),
                    refreshGuestTable()
                ]);

                updateSelectionDisplay();

            } catch (error) {

                console.error(
                    "[SLT Invitations]",
                    error
                );

                notify(
                    "Unable to send invitations: " +
                    error.message,
                    true
                );

            } finally {
                button.disabled = false;
            }
        }
    );

    async function refreshGuestTable() {
        const button = $("refresh");

        if (button) {
            button.click();
        }
    }

    // ==========================================
    // SMS TEMPLATE
    // ==========================================

    async function loadSmsTemplate() {
        try {

            const templates = await sltRequest(
                "/guests/sms-templates"
            );

            const template = (templates || []).find(
                item =>
                    item.TemplateKey === $("smsTemplateKey").value
            );

            if (!template) {
                $("smsTemplateBody").value = "";
                $("smsTemplateActive").checked = true;
                return;
            }

            $("smsTemplateBody").value =
                template.TemplateBody || "";

            $("smsTemplateActive").checked =
                template.IsActive === true;

        } catch (error) {

            console.error(
                "[SLT SMS Template]",
                error
            );

            notify(
                "Unable to load SMS template: " +
                error.message,
                true
            );
        }
    }

    // ==========================================
    // SAVE SMS TEMPLATE
    // ==========================================

    if ($("smsTemplateKey")) $("smsTemplateKey").addEventListener("change", loadSmsTemplate);

    if ($("smsTemplateForm")) $("smsTemplateForm").addEventListener(
        "submit",
        async function (event) {

            event.preventDefault();

            const button = $("smsTemplateSave");

            button.disabled = true;

            try {

                await sltRequest(
                    "/guests/sms-templates",
                    {
                        method: "PUT",

                        body: JSON.stringify({
                            TemplateKey: $("smsTemplateKey").value,

                            TemplateBody:
                                $("smsTemplateBody").value,

                            IsActive:
                                $("smsTemplateActive").checked
                        })
                    }
                );

                notify(
                    "SMS template saved successfully."
                );

            } catch (error) {

                notify(
                    "Unable to save SMS template: " +
                    error.message,
                    true
                );

            } finally {
                button.disabled = false;
            }
        }
    );

    // ==========================================
    // INITIALIZATION
    // ==========================================

    async function initialize() {
        try {

            authorized = window.sltGuestAdminReady
                ? await window.sltGuestAdminReady
                : false;

            if (!authorized) return;

            await Promise.all([
                loadStats()
            ]);

            restorePageSelection();

        } catch (error) {

            notify(
                "Guest operations initialization failed: " +
                error.message,
                true
            );
        }
    }

    initialize();

})();