(function () {
    "use strict";
    document.addEventListener("DOMContentLoaded", function () {
        var adminLogin = document.body.classList.contains("slt-login-body");
        if (adminLogin) {
            document.documentElement.classList.remove("slt-light-login");
            document.documentElement.classList.add("slt-dark-admin");
            document.body.classList.add("slt-dark-admin");
            return; // No light-theme switch on login screens.
        }
        if (document.body.classList.contains("slt-guest-experience")) {
            function applyGuestTheme() {
                var login = document.getElementById("loginSection");
                var visible = login && !login.classList.contains("slt-hidden");
                document.documentElement.classList.toggle("slt-dark-admin", !!visible);
                document.body.classList.toggle("slt-dark-admin", !!visible);
            }
            var target = document.getElementById("loginSection");
            if (target) new MutationObserver(applyGuestTheme).observe(target, {attributes:true,attributeFilter:["class"]});
            applyGuestTheme();
        }
    });
})();
