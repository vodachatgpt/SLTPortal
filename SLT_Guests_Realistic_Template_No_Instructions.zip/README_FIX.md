SLT Guests latest corrections
=============================

Replace GuestOperationsService.cs, GuestsController.cs, GuestsService.cs,
guests-admin.html, guests-admin.js with these files.

1. The template comes from GuestOperationsService.BuildTemplate() and has NO NotificationMode or NotificationChannels.
2. Two fully populated, realistic sample guest rows appear directly in the Guests worksheet; the importer skips the reserved sample emails if left unchanged. No Instructions worksheet is generated.
3. QRUrl Excel column is saved to existing Guests.QRFileName; no new QRUrl column needed. Remove earlier QRUrl column migration if not run.
4. QR URL field is explicitly rendered inside Edit/Create Guest form.
5. Phone accepts international number with +, or local without +.
6. Existing assets/guests-operations.js (not present in supplied ZIP) may override the Download Template behavior. Ensure that button calls GET /api/guests/excel-template, and deploy backend before redownloading. Clear browser cache.
7. IMPORTANT: Check length of QRFileName column; nvarchar(255) can truncate URLs. If intended max 2048, widen column and update EF DB-first EDMX. Example SQL:
   ALTER TABLE dbo.Guests ALTER COLUMN QRFileName NVARCHAR(2048) NULL;
8. Existing QR filename-based folder matching still works for non-URL values. URLs are validated as HTTPS addresses.
9. The compiled frontend requires the shared assets scripts from your existing application; only files uploaded here are modified.
10. This was not compiled against your full solution.
