-- Check your existing QRFileName type / maximum length.
SELECT c.name, t.name AS SqlType, c.max_length, c.is_nullable
FROM sys.columns c INNER JOIN sys.types t ON c.user_type_id=t.user_type_id
WHERE c.object_id=OBJECT_ID('dbo.Guests') AND c.name='QRFileName';

-- ONLY if the existing column is too short for your QR URLs:
-- ALTER TABLE dbo.Guests ALTER COLUMN QRFileName NVARCHAR(2048) NULL;
-- Afterwards refresh Guest entity in EF6 EDMX.
