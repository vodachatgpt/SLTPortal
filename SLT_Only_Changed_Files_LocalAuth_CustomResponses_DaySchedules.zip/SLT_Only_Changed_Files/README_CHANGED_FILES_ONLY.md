# SLT — Only Changed Files (Local Static Admin Login + JWT + Custom Responses + Day Schedules)

This package contains only the files that differ from the latest uploaded baseline files:
- `Controllers(9).zip`
- `Services(10).zip`
- `Frontend(20261110-181648).zip`

It includes the local-only static NT/password login, 24-hour admin JWT, removal of the Administrators tab, Custom Responses soft-delete corrections, and Day Schedules icon/date/import corrections.

## 1. Backend files to replace/add

### Authentication
- `Backend/Controllers/AuthController.cs` — ADD
- `Backend/Filters/SltAdminAttribute.cs` — REPLACE
- `Backend/Filters/SltAdminJwtAuthorization.cs` — ADD
- `Backend/Filters/SltAdminOrGuestAttribute.cs` — REPLACE
- `Backend/Models/ShareAuthModel.cs` — ADD
- `Backend/Services/ISharepointAuthService.cs` — ADD
- `Backend/Services/SharepointAuthService.cs` — ADD

### Custom Responses and Day Schedules
- `Backend/Controllers/CustomizedResponsesController.cs` — REPLACE
- `Backend/Services/CustomizedGuestResponsesService.cs` — REPLACE
- `Backend/Services/CustomizedResponsesService.cs` — REPLACE
- `Backend/Services/DaySchedulesService.cs` — REPLACE
- `Backend/Services/ScheduleTransportExcel.cs` — REPLACE

These are complete source files, not snippets.

## 2. Frontend files to replace

### Admin login and navigation
- `Frontend/admin-login.html`
- `Frontend/assets/admin-login.js`
- `Frontend/assets/api.js`
- `Frontend/assets/config.js`
- `Frontend/assets/shell.js`
- `Frontend/service-worker.js`

### Updated shared brand links / asset cache references
- `Frontend/airport-transfers-admin.html`
- `Frontend/blur-icons-admin.html`
- `Frontend/dashboard.html`
- `Frontend/day-schedules-admin.html`
- `Frontend/email-templates-admin.html`
- `Frontend/guest-event-drivers-admin.html`
- `Frontend/guest-login.html`
- `Frontend/guest-notifications-test.html`
- `Frontend/guests-admin.html`
- `Frontend/help-support-admin.html`
- `Frontend/notifications-admin.html`
- `Frontend/phases-admin.html`
- `Frontend/weather-admin.html`

These frontend HTML files were changed to remove links to the Administrators page and/or update shared asset cache versions. They depend on the unchanged assets already in your current frontend.

## 3. Web.config

Merge the entries from:
`Deployment/WEB_CONFIG_LOCAL_STATIC_ADMIN_JWT.xml`

into your existing `<appSettings>` section. Do not add a second `<appSettings>` section and do not duplicate existing keys.

Important:
- Set `Auth_ClientId` to your own value and copy the same value into `Frontend/assets/config.js` as `AUTH_CLIENT_ID`.
- Set `JwtSecretKey` to a unique random secret of at least 32 UTF-8 bytes.
- Set `LDAP_Path` to your actual AD DNS domain or reachable LDAP server.
- Set `SLTAdminStaticTestAdminId` to an existing active `dbo.Admins.Id`.
- The sample static credentials are for local development only and are accepted only for loopback API requests.
- Disable static login outside local development by setting `SLTAdminStaticTestEnabled` to `false` and removing the static password from non-local deployment configuration.
- JWT expiry is 1,440 minutes (24 hours).

The frontend API key is browser-visible; it is an application request gate, not a confidential secret or replacement for AD authentication.

## 4. Removed obsolete files

Delete these old files from the project and remove their `.csproj` Compile entries if present:
- `Controllers/AdminsController.cs`
- `Controllers/AdminsController .cs` (the uploaded source had a second filename with a space)
- `Services/AdminService.cs`
- `Services/AdminLocalRecovery.cs`
- `Frontend/admins-admin.html`
- `Frontend/assets/admins-admin.js`

The Administrators navigation item is removed from `Frontend/assets/shell.js`.

## 5. Project references

For an old-style .NET Framework `.csproj`, add Compile entries for these new files:
- `Controllers/AuthController.cs`
- `Filters/SltAdminJwtAuthorization.cs`
- `Models/ShareAuthModel.cs`
- `Services/ISharepointAuthService.cs`
- `Services/SharepointAuthService.cs`

Ensure references/packages exist:
- `System.DirectoryServices.AccountManagement`
- `System.IdentityModel.Tokens.Jwt`
- `Microsoft.IdentityModel.Tokens`
- Entity Framework 6

Keep your existing DB-first EDMX and generated entities; this package does not replace them.

## 6. Day Schedules Excel behavior

The updated importer handles the date input more explicitly and the updated template should be downloaded fresh from the application after deployment. Enter dates as `dd/MM/yyyy`, for example `08/12/2026` means 8 December 2026.

Excel may already have converted dates in older workbooks based on the machine's regional settings. Re-enter dates in the newly downloaded template rather than reusing cells that Excel has already interpreted as US-style dates.

The `BlurIconName` field must still match an active icon name in your database. Check:
```sql
SELECT Id, Name, IsDeleted
FROM dbo.BlurIcons
WHERE LOWER(LTRIM(RTRIM(Name))) = 'bus';
```
The import error is no longer assumed to be an icon-name problem merely because the import report points to `BlurIconName`; inspect the detailed database exception if the save still fails.

## 7. Custom Responses soft-delete behavior

The included service/controller changes exclude soft-deleted guests and events from the affected Custom Responses results and exclude related driver/event rows when their linked guest/event is deleted.

Test with:
1. Active guest + active event — should be included.
2. Deleted guest — should be excluded from guest-specific response data.
3. Deleted event — should be excluded from event response data.
4. Driver assignment linked to a deleted event — should be excluded.
5. Driver assignment linked to a deleted guest — should be excluded from guest-specific results.

## 8. Local static admin login test

The local-only sample credentials in the Web.config fragment are:
- NT account: `SLTLOCAL\\admin`
- Password: `SltLocalTest#2026!`

They are synthetic application credentials, not a Windows/AD account. The API must run on loopback and the request must reach the backend through localhost. The configured Admin ID must exist and be active in `dbo.Admins`.

The frontend does not hardcode or prefill these credentials. Enter them manually in the NT Account and Network Password fields.

## 9. Validation

This archive contains only the changed/new files listed above. Removed files are listed for manual deletion because ZIP archives cannot delete files from your working project automatically.

The package can be checked for archive integrity and JavaScript syntax, but a full .NET Framework build and live AD/database integration test must be run in your Visual Studio/IIS environment.
