(function () {
    "use strict";

    var form = document.getElementById("adminLoginForm");
    var button = document.getElementById("loginButton");
    var message = document.getElementById("message");
    var config = window.SLT_CONFIG || {};
    var localTestNotice = document.getElementById("localAdminTestNotice");

    if (!form || !button || !message) return;

    // This is a visual hint only. The backend independently enforces
    // Request.IsLocal + Request.Url.IsLoopback before accepting the test account.
    var host = (window.location.hostname || "").toLowerCase();
    var isLoopbackHost = host === "localhost" ||
        host === "127.0.0.1" || host === "::1" || host === "[::1]";

    if (localTestNotice && isLoopbackHost) {
        localTestNotice.hidden = false;
    }

    function showMessage(text, isError) {
        message.textContent = text || "";
        message.className = isError
            ? "slt-message slt-error"
            : "slt-message";
    }

    async function checkExistingSession() {
        var token = window.sltGetAdminToken();
        if (!token) return;

        try {
            var identity = await window.sltRequest("/admin-auth/me");
            if (identity && identity.Email) {
                localStorage.setItem("slt_admin_email", identity.Email);
            }
            window.location.replace("dashboard.html");
        } catch (error) {
            if (error && error.status === 401) {
                window.sltClearAdminSession();
                showMessage(
                    "Your administrator session has expired. Please sign in again.",
                    true
                );
                return;
            }

            // Preserve the token for temporary network/server failures.
            showMessage(
                "Unable to verify your existing session. Please retry.",
                false
            );
        }
    }

    form.addEventListener("submit", async function (event) {
        event.preventDefault();

        if (button.disabled) return;

        var loginName = document.getElementById("adminNTAccount").value.trim();
        var passwordInput = document.getElementById("adminPassword");
        var password = passwordInput.value;
        var apiKeyName = config.AUTH_API_KEY_NAME;
        var apiKeyValue = config.AUTH_CLIENT_ID;

        showMessage("", false);

        if (!loginName || !password) {
            showMessage("NT account and Windows password are required.", true);
            return;
        }

        if (!apiKeyName || !apiKeyValue ||
            String(apiKeyValue).indexOf("REPLACE_WITH_") === 0) {
            showMessage(
                "Authentication configuration is incomplete. Configure the API key in assets/config.js.",
                true
            );
            return;
        }

        button.disabled = true;

        try {
            var headers = {};
            headers[apiKeyName] = apiKeyValue;

            var result = await window.sltRequest("/admin-auth/login", {
                method: "POST",
                headers: headers,
                body: JSON.stringify({
                    LoginName: loginName,
                    Password: password
                })
            });

            if (!result || !result.Token) {
                throw new Error("Authentication did not return a valid token.");
            }

            window.sltSetAdminToken(result.Token);
            passwordInput.value = "";

            // Ask the API for the verified AD identity rather than trusting
            // an email/name supplied by the browser.
            var identity = await window.sltRequest("/admin-auth/me");

            localStorage.setItem(
                "slt_admin_email",
                identity.Email || loginName
            );

            window.location.replace("dashboard.html");
        } catch (error) {
            passwordInput.value = "";

            if (error && error.status === 401) {
                window.sltClearAdminSession();
            }

            showMessage(
                error && error.message
                    ? error.message
                    : "Administrator authentication failed.",
                true
            );
        } finally {
            button.disabled = false;
        }
    });

    checkExistingSession();
})();
