importScripts('./assets/slt-push-events.js');
/* SLT Admin PWA v13: dynamic frontend files are network-first; API/auth are NEVER cached. */
const CACHE = 'slt-admin-shell-v26-local-static-test';
const PRECACHE = ['./admin-login.html','./dashboard.html','./assets/app.css','./assets/premium.css','./assets/theme-2026.css','./assets/portal-unified-theme.css','./icons/icon-192.png','./icons/icon-512.png'];
self.addEventListener('install', e => e.waitUntil((async()=>{const c=await caches.open(CACHE);await Promise.all(PRECACHE.map(async path=>{try{await c.add(new Request(path,{cache:'reload'}));}catch(_){}}));await self.skipWaiting();})()));
self.addEventListener('activate',e=>e.waitUntil((async()=>{await Promise.all((await caches.keys()).filter(k=>k!==CACHE).map(k=>caches.delete(k)));await self.clients.claim();})()));
self.addEventListener('fetch',e=>{
 const r=e.request,u=new URL(r.url);
 if(r.method!=='GET'||u.origin!==self.location.origin||u.pathname.includes('/api/')||r.headers.has('Authorization'))return;
 if(r.mode==='navigate'){
  e.respondWith(fetch(r).catch(()=>caches.match(r,{ignoreSearch:true}).then(v=>v||caches.match('./dashboard.html'))));return;
 }
 if(!/\.(?:css|js|png|svg|ico|webmanifest)$/i.test(u.pathname))return;
 e.respondWith(fetch(r,{cache:'no-store'}).then(resp=>{if(resp.ok&&resp.type==='basic'){const clone=resp.clone();e.waitUntil(caches.open(CACHE).then(c=>c.put(r,clone)));}return resp;}).catch(()=>caches.match(r,{ignoreSearch:true})));
});
