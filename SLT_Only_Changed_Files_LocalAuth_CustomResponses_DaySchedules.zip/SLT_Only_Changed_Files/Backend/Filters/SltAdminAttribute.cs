using System;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;

namespace SLTProject.Filters
{
    public sealed class SltAdminAttribute : AuthorizationFilterAttribute
    {
        public override async Task OnAuthorizationAsync(
            HttpActionContext actionContext,
            CancellationToken cancellationToken)
        {
            if (AllowsAnonymous(actionContext))
                return;

            var authorization = actionContext.Request.Headers.Authorization;

            if (authorization == null ||
                !string.Equals(
                    authorization.Scheme,
                    "Bearer",
                    StringComparison.OrdinalIgnoreCase) ||
                string.IsNullOrWhiteSpace(authorization.Parameter))
            {
                SetUnauthorized(actionContext);
                return;
            }

            try
            {
                bool authorized = await SltAdminJwtAuthorization.TryAuthorizeAsync(
                    actionContext,
                    authorization.Parameter,
                    cancellationToken);

                if (!authorized)
                    SetUnauthorized(actionContext);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError(
                    "SLT admin JWT authorization failed: {0}",
                    ex);

                actionContext.Response = actionContext.Request.CreateResponse(
                    HttpStatusCode.ServiceUnavailable,
                    new
                    {
                        Message = "Administrator authorization is temporarily unavailable."
                    });
            }
        }

        private static bool AllowsAnonymous(HttpActionContext context)
        {
            return context.ActionDescriptor
                       .GetCustomAttributes<AllowAnonymousAttribute>()
                       .Any() ||
                   context.ControllerContext.ControllerDescriptor
                       .GetCustomAttributes<AllowAnonymousAttribute>()
                       .Any();
        }

        private static void SetUnauthorized(HttpActionContext context)
        {
            context.Response = context.Request.CreateResponse(
                HttpStatusCode.Unauthorized,
                new
                {
                    Message = "Administrator authentication is invalid, expired, or inactive."
                });
        }
    }
}
