using System;
using System.Data.Entity;
using System.Linq;
using System.Security.Claims;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http.Controllers;
using SLTProject.Data;
using SLTProject.Services;

namespace SLTProject.Filters
{
    internal static class SltAdminJwtAuthorization
    {
        private static readonly ISharepointAuthService AuthService =
            new SharepointAuthService();

        public static async Task<bool> TryAuthorizeAsync(
            HttpActionContext actionContext,
            string token,
            CancellationToken cancellationToken)
        {
            ClaimsPrincipal principal = AuthService.ValidateToken(token);

            if (principal == null ||
                principal.Identity == null ||
                !principal.Identity.IsAuthenticated)
            {
                return false;
            }

            string adminIdText = principal.FindFirst("AdminId")?.Value;
            string email = principal.FindFirst(ClaimTypes.Email)?.Value;
            string ntAccount = principal.FindFirst("NTAccount")?.Value
                ?? principal.Identity.Name;
            string fullName = principal.FindFirst("FullName")?.Value;

            long adminId;

            if (!long.TryParse(adminIdText, out adminId) ||
                adminId <= 0 ||
                string.IsNullOrWhiteSpace(email) ||
                string.IsNullOrWhiteSpace(ntAccount))
            {
                return false;
            }

            email = email.Trim().ToLowerInvariant();

            // Check the current allow-list status on every request. This makes
            // deactivation effective immediately, even before JWT expiration.
            using (var db = new SLTEntities())
            {
                bool active = await db.Admins
                    .AsNoTracking()
                    .AnyAsync(x =>
                        x.Id == adminId &&
                        x.Email == email &&
                        x.IsActive &&
                        !x.IsDeleted,
                        cancellationToken);

                if (!active)
                    return false;
            }

            actionContext.RequestContext.Principal = principal;
            Thread.CurrentPrincipal = principal;

            if (HttpContext.Current != null)
                HttpContext.Current.User = principal;

            actionContext.Request.Properties["SLTAdminId"] = adminId;
            actionContext.Request.Properties["SLTAdminEmail"] = email;
            actionContext.Request.Properties["SLTAdminNTAccount"] = ntAccount;
            actionContext.Request.Properties["SLTAdminFullName"] = fullName;

            return true;
        }
    }
}
