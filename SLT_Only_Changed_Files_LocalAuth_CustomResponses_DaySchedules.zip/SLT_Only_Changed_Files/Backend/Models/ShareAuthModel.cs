using System.ComponentModel.DataAnnotations;

namespace SLTProject.Models
{
    public class ShareAuthModel
    {
        [Required]
        [StringLength(256)]
        public string LoginName { get; set; }

        [Required]
        [StringLength(256)]
        public string Password { get; set; }
    }
}
