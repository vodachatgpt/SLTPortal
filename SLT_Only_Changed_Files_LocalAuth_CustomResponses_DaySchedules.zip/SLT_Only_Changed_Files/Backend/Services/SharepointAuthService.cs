using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.DirectoryServices.AccountManagement;
using System.IdentityModel.Tokens.Jwt;
using System.Globalization;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using SLTProject.Data;
using SLTProject.Models;

namespace SLTProject.Services
{
    public class SharepointAuthService : ISharepointAuthService
    {
        private const string Feature = "SharepointAuthService";

        private sealed class DirectoryUser
        {
            public string Email { get; set; }
            public string FullName { get; set; }
        }

        private static string Setting(string key, bool required = true)
        {
            string value = ConfigurationManager.AppSettings[key];

            if (required && string.IsNullOrWhiteSpace(value))
            {
                throw new ConfigurationErrorsException(
                    "Missing Web.config appSetting: " + key);
            }

            return (value ?? string.Empty).Trim();
        }

        private static string JwtSecret
        {
            get
            {
                string value = Setting("JwtSecretKey");

                if (Encoding.UTF8.GetByteCount(value) < 32)
                {
                    throw new ConfigurationErrorsException(
                        "JwtSecretKey must contain at least 32 UTF-8 bytes. " +
                        "Use a cryptographically random secret.");
                }

                return value;
            }
        }

        private static int JwtExpiryMinutes
        {
            get
            {
                int value;

                if (!int.TryParse(
                    Setting("JwtExpiryMinutes", false),
                    out value))
                {
                    value = 1440;
                }

                // SLT administrator JWT lifetime: maximum 24 hours.
                return Math.Max(5, Math.Min(value, 1440));
            }
        }

        // Compare fixed-length digests to avoid ordinary string comparison
        // timing differences when validating the API key.
        private static bool FixedTimeEquals(string expected, string actual)
        {
            if (expected == null || actual == null)
                return false;

            using (var sha = SHA256.Create())
            {
                byte[] left = sha.ComputeHash(Encoding.UTF8.GetBytes(expected));
                byte[] right = sha.ComputeHash(Encoding.UTF8.GetBytes(actual));
                int difference = 0;

                for (int i = 0; i < left.Length; i++)
                    difference |= left[i] ^ right[i];

                return difference == 0;
            }
        }

        private static bool ValidateApiKey(string suppliedName, string suppliedValue)
        {
            string configuredName = Setting("Auth_APIKeyName");
            string configuredValue = Setting("Auth_ClientId");

            return string.Equals(
                       configuredName,
                       suppliedName,
                       StringComparison.OrdinalIgnoreCase) &&
                   FixedTimeEquals(configuredValue, suppliedValue);
        }

        private static string ResolveDomain()
        {
            string configured = Setting("LDAP_Path", false);

            if (string.IsNullOrWhiteSpace(configured))
                return null; // Use the IIS server's joined domain.

            Uri uri;

            if (Uri.TryCreate(configured, UriKind.Absolute, out uri) &&
                (string.Equals(uri.Scheme, "LDAP", StringComparison.OrdinalIgnoreCase) ||
                 string.Equals(uri.Scheme, "LDAPS", StringComparison.OrdinalIgnoreCase)))
            {
                return uri.Host;
            }

            // Prefer a DNS domain (e.g. corp.example.com) or domain controller host.
            return configured;
        }

        private static string NormalizeLoginName(string loginName)
        {
            string value = (loginName ?? string.Empty).Trim();
            int slash = value.LastIndexOf('\\');

            if (slash >= 0 && slash < value.Length - 1)
                return value.Substring(slash + 1);

            return value;
        }

        private DirectoryUser AuthenticateDirectoryUser(
            string loginName,
            string password)
        {
            try
            {
                string domain = ResolveDomain();
                string normalizedLogin = NormalizeLoginName(loginName);

                if (string.IsNullOrWhiteSpace(normalizedLogin))
                    return null;

                using (var context = string.IsNullOrWhiteSpace(domain)
                    ? new PrincipalContext(ContextType.Domain)
                    : new PrincipalContext(ContextType.Domain, domain))
                {
                    bool valid = context.ValidateCredentials(
                        normalizedLogin,
                        password,
                        ContextOptions.Negotiate);

                    if (!valid)
                        return null;

                    IdentityType identityType = normalizedLogin.Contains("@")
                        ? IdentityType.UserPrincipalName
                        : IdentityType.SamAccountName;

                    UserPrincipal user = UserPrincipal.FindByIdentity(
                        context,
                        identityType,
                        normalizedLogin);

                    if (user == null)
                    {
                        user = UserPrincipal.FindByIdentity(
                            context,
                            IdentityType.SamAccountName,
                            normalizedLogin);
                    }

                    if (user == null)
                        return null;

                    using (user)
                    {
                        string email = user.EmailAddress;

                        if (string.IsNullOrWhiteSpace(email))
                            email = user.UserPrincipalName;

                        if (string.IsNullOrWhiteSpace(email))
                            return null;

                        string fullName = user.DisplayName;

                        if (string.IsNullOrWhiteSpace(fullName))
                            fullName = user.Name;

                        if (string.IsNullOrWhiteSpace(fullName))
                            fullName = normalizedLogin;

                        return new DirectoryUser
                        {
                            Email = email.Trim().ToLowerInvariant(),
                            FullName = fullName.Trim()
                        };
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError(
                    "[{0}] Active Directory authentication failed for {1}: {2}",
                    Feature,
                    loginName,
                    ex);

                return null;
            }
        }

        public async Task<string> AuthenticateUserAsync(
            ShareAuthModel request,
            string apiKeyName,
            string apiKeyValue,
            bool isLocalRequest)
        {
            try
            {
                if (request == null ||
                    string.IsNullOrWhiteSpace(request.LoginName) ||
                    string.IsNullOrEmpty(request.Password))
                {
                    return null;
                }

                if (!ValidateApiKey(apiKeyName, apiKeyValue))
                    return null;

                // Local static account is checked before Active Directory so
                // developers can test login without a reachable Domain Controller.
                // It is accepted only for loopback requests and only when explicitly enabled.
                if (IsConfiguredStaticLoginName(request.LoginName))
                {
                    if (!isLocalRequest || !IsStaticLocalTestEnabled())
                    {
                        System.Diagnostics.Trace.TraceWarning(
                            "[{0}] Static local admin login rejected because the request is not an enabled local test request.",
                            Feature);
                        return null;
                    }

                    string configuredPassword = Setting(
                        "SLTAdminStaticTestPassword", false);

                    if (string.IsNullOrEmpty(configuredPassword) ||
                        !FixedTimeEquals(configuredPassword, request.Password))
                    {
                        return null;
                    }

                    return await AuthenticateStaticLocalAdminAsync(
                        request.LoginName.Trim());
                }

                DirectoryUser directoryUser = AuthenticateDirectoryUser(
                    request.LoginName,
                    request.Password);

                if (directoryUser == null)
                    return null;

                // dbo.Admins is an authorization allow-list only.
                // No admin passcode or old session token is read or validated.
                using (var db = new SLTEntities())
                {
                    var admin = await db.Admins
                        .AsNoTracking()
                        .FirstOrDefaultAsync(x =>
                            x.Email == directoryUser.Email &&
                            x.IsActive &&
                            !x.IsDeleted);

                    if (admin == null)
                    {
                        System.Diagnostics.Trace.TraceWarning(
                            "[{0}] AD user is not provisioned as an active SLT administrator: {1}",
                            Feature,
                            directoryUser.Email);

                        return null;
                    }

                    return GenerateJwtToken(
                        request.LoginName.Trim(),
                        directoryUser,
                        Convert.ToString(admin.Id));
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError(
                    "[{0}] AuthenticateUserAsync failed: {1}",
                    Feature,
                    ex);

                return null;
            }
        }

        // =====================================================
        // LOCAL-ONLY STATIC TEST ACCOUNT
        // =====================================================

        private static bool IsStaticLocalTestEnabled()
        {
            bool enabled;
            return bool.TryParse(
                       Setting("SLTAdminStaticTestEnabled", false),
                       out enabled) && enabled;
        }

        private static bool IsConfiguredStaticLoginName(string loginName)
        {
            string configured = Setting(
                "SLTAdminStaticTestNTAccount", false);

            if (string.IsNullOrWhiteSpace(configured) ||
                string.IsNullOrWhiteSpace(loginName))
                return false;

            return string.Equals(
                configured.Trim(),
                loginName.Trim(),
                StringComparison.OrdinalIgnoreCase);
        }

        private async Task<string> AuthenticateStaticLocalAdminAsync(
            string loginName)
        {
            long configuredAdminId;

            if (!long.TryParse(
                Setting("SLTAdminStaticTestAdminId", false),
                NumberStyles.Integer,
                CultureInfo.InvariantCulture,
                out configuredAdminId) || configuredAdminId <= 0)
            {
                System.Diagnostics.Trace.TraceError(
                    "[{0}] SLTAdminStaticTestAdminId is missing or invalid.",
                    Feature);
                return null;
            }

            using (var db = new SLTEntities())
            {
                var admin = await db.Admins
                    .AsNoTracking()
                    .FirstOrDefaultAsync(x =>
                        x.Id == configuredAdminId &&
                        x.IsActive &&
                        !x.IsDeleted);

                if (admin == null)
                {
                    System.Diagnostics.Trace.TraceWarning(
                        "[{0}] Local static test AdminId {1} is not an active dbo.Admins record.",
                        Feature,
                        configuredAdminId);
                    return null;
                }

                var localUser = new DirectoryUser
                {
                    Email = (admin.Email ?? string.Empty).Trim().ToLowerInvariant(),
                    FullName = string.IsNullOrWhiteSpace(admin.FullName)
                        ? "SLT Local Test Administrator"
                        : admin.FullName.Trim()
                };

                if (string.IsNullOrWhiteSpace(localUser.Email))
                    return null;

                System.Diagnostics.Trace.TraceInformation(
                    "[{0}] Local static test administrator authenticated: AdminId={1}.",
                    Feature,
                    configuredAdminId);

                return GenerateJwtToken(
                    loginName,
                    localUser,
                    Convert.ToString(configuredAdminId, CultureInfo.InvariantCulture));
            }
        }

        private string GenerateJwtToken(
            string loginName,
            DirectoryUser directoryUser,
            string adminId)
        {
            string issuer = Setting("JwtIssuer");
            string audience = Setting("JwtAudience");
            string secret = JwtSecret;

            var key = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(secret));

            var credentials = new SigningCredentials(
                key,
                SecurityAlgorithms.HmacSha256);

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, loginName),
                new Claim("NTAccount", loginName),
                new Claim(ClaimTypes.Email, directoryUser.Email),
                new Claim("AdminId", adminId),
                new Claim("FullName", directoryUser.FullName ?? loginName),
                new Claim(ClaimTypes.Role, "Admin"),
                new Claim(ClaimTypes.Role, "SLTAdmin"),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString("N"))
            };

            DateTime nowUtc = DateTime.UtcNow;

            var token = new JwtSecurityToken(
                issuer: issuer,
                audience: audience,
                claims: claims,
                notBefore: nowUtc,
                expires: nowUtc.AddMinutes(JwtExpiryMinutes),
                signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        public ClaimsPrincipal ValidateToken(string token)
        {
            if (string.IsNullOrWhiteSpace(token) || token.Length > 8192)
                return null;

            try
            {
                var validationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(
                        Encoding.UTF8.GetBytes(JwtSecret)),
                    ValidateIssuer = true,
                    ValidIssuer = Setting("JwtIssuer"),
                    ValidateAudience = true,
                    ValidAudience = Setting("JwtAudience"),
                    ValidateLifetime = true,
                    RequireExpirationTime = true,
                    RequireSignedTokens = true,
                    ClockSkew = TimeSpan.FromMinutes(1),
                    NameClaimType = ClaimTypes.Name,
                    RoleClaimType = ClaimTypes.Role
                };

                SecurityToken validatedToken;
                var handler = new JwtSecurityTokenHandler();

                ClaimsPrincipal principal = handler.ValidateToken(
                    token,
                    validationParameters,
                    out validatedToken);

                var jwt = validatedToken as JwtSecurityToken;

                if (jwt == null ||
                    !string.Equals(
                        jwt.Header.Alg,
                        SecurityAlgorithms.HmacSha256,
                        StringComparison.Ordinal))
                {
                    return null;
                }

                return principal;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceWarning(
                    "[{0}] JWT validation failed: {1}",
                    Feature,
                    ex.GetType().Name);

                return null;
            }
        }
    }
}
