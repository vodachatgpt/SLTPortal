using System.Security.Claims;
using System.Threading.Tasks;
using SLTProject.Models;

namespace SLTProject.Services
{
    public interface ISharepointAuthService
    {
        Task<string> AuthenticateUserAsync(
            ShareAuthModel request,
            string apiKeyName,
            string apiKeyValue,
            bool isLocalRequest);

        ClaimsPrincipal ValidateToken(string token);
    }
}
