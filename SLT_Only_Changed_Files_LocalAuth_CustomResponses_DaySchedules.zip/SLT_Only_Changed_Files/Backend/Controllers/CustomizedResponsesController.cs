using SLTProject.Filters;

using System;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using SLTProject.Services;

namespace SLTProject.Controllers
{
    [SltAdminOrGuest]
    [RoutePrefix("api/customizedResponses")]
    public class CustomizedResponsesController : ApiController
    {
        private readonly CustomizedResponsesService
            _eventsService =
                new CustomizedResponsesService();

        private readonly CustomizedGuestResponsesService
            _guestsService =
                new CustomizedGuestResponsesService();

        // ==========================================
        // 1. COMBINED EVENTS BY DATE
        //
        // GET /api/customizedResponses/events
        // GET /api/customizedResponses/events?email=...
        // ==========================================

        [HttpGet]
        [Route("events")]
        public async Task<IHttpActionResult> GetEvents(
            [FromUri] string email = null)
        {
            if (!User.IsInRole("SLTAdmin") && !User.IsInRole("Admin"))
            {
                object guestEmail;
                if (!Request.Properties.TryGetValue("SLTGuestEmail", out guestEmail) ||
                    string.IsNullOrWhiteSpace(guestEmail as string))
                    return Unauthorized();

                // Guest cannot request another guest's data.
                email = (string)guestEmail;
            }

            try
            {
                var result = await _eventsService
                    .GetCombinedEventsAsync(email);

                return Ok(new
                {
                    Success = true,
                    TotalDays = result.Count,
                    GuestEmail = email,
                    Data = result
                });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // ==========================================
        // 2. COMBINED GUEST INFORMATION
        // AND INDIVIDUAL DRIVER ASSIGNMENTS
        //
        // GET /api/customizedResponses/guests
        // GET /api/customizedResponses/guests?email=...
        // ==========================================

        [HttpGet]
        [Route("guests")]
        public async Task<IHttpActionResult> GetGuests(
            [FromUri] string email = null)
        {
            if (!User.IsInRole("SLTAdmin") && !User.IsInRole("Admin"))
            {
                object guestEmail;
                if (!Request.Properties.TryGetValue("SLTGuestEmail", out guestEmail) ||
                    string.IsNullOrWhiteSpace(guestEmail as string))
                    return Unauthorized();

                // Guest cannot request another guest's data.
                email = (string)guestEmail;
            }

            try
            {
                // Build an absolute URL using the
                // application's actual virtual path.
                string relativeQrPath =
                    VirtualPathUtility.ToAbsolute(
                        "~/api/guests/");

                string qrUrlPrefix =
                    new Uri(
                        Request.RequestUri,
                        relativeQrPath
                    ).AbsoluteUri;

                var result = await _guestsService
                    .GetGuestsAsync(
                        email,
                        qrUrlPrefix);

                return Ok(new
                {
                    Success = true,
                    TotalGuests = result.Count,
                    Data = result
                });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
