DEMO QR IMAGES ONLY. Each QR scans to a test string, not a valid entry pass.
Rename PNG to the guest's exact normalized email, e.g. enjy@example.com.png, and deploy under backend App_Data/GuestQRCodes.
The existing GuestsService.FindFolderQr finds PNG/JPG/JPEG/WEBP by email and its authenticated QR APIs serve the bytes.
For guest frontend, QrUrl=/api/guest-auth/my-qr must be fetched with the guest Bearer token and rendered via URL.createObjectURL(blob).
For admin frontend, AdminQrUrl=/api/guests/{id}/qr needs an admin Bearer token.
