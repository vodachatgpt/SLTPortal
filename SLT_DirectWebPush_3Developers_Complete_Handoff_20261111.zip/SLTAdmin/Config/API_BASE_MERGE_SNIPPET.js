// Merge into existing assets/config.js; do NOT replace the whole config object.
// Production API base includes the /SPPowers/sltapi/ IIS application path.
window.SLT_CONFIG = window.SLT_CONFIG || {};
window.SLT_CONFIG.API_BASE = 'https://pulse.vodafone.com.eg/SPPowers/sltapi/api';
// Remove old GLOBAL_PUSH_BASE_URL and GLOBAL_PUSH_APPLICATION_CODE usage.
