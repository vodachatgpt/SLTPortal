# Developer 3 — SLTAdmin (Existing Notification Composer)

**Scope:** Minimal. SLTAdmin already has the notification editor, guest selector, sent history, and admin authentication. **No push SDK or service worker subscription is required on SLTAdmin.** It calls SLTAPI; the backend delivers push.

## File-by-file merge instructions

| File | Action | Exact section / function | Why |
|---|---|---|---|
| `assets/config.js` | EDIT IN NEWER BRANCH ONLY | Existing `window.SLT_CONFIG.API_BASE` | Point to actual production `https://pulse.vodafone.com.eg/SPPowers/sltapi/api`; preserve other newer settings |
| `notifications-admin.html` | MODIFIED | Remove `<script src="assets/slt-push-admin-integration.js">` from V12 era, retain `slt-notifications-admin.js` and current business UI; optional hint for destination | Eliminate obsolete `/admin/push/v12/integration` call and misleading CORS status; retain sender |
| `assets/slt-notifications-admin.js` | **NO CODE CHANGE** | Existing `auth('send')`, `guests()`, `refresh()`, `mark read` | Already calls SLTAPI `/slt-notifications/admin/send`; ensure existing contract in newer version |
| `assets/api.js` | **NO CODE CHANGE** | Existing `sltRequest` | Should construct URLs from configured API_BASE, not localhost |
| `manifest.webmanifest` | DEPLOYMENT FILE | Website root alongside `notifications-admin.html` | Was 404 due to missing IIS file/MIME mapping; issue is already fixed on your server |
| `service-worker.js` | **NO PUSH CHANGE** | Admin PWA worker, if retained | Admin browser is not the push receiver in this design |

## Important admin request details

The existing `assets/slt-notifications-admin.js` sends:

```json
{"TargetType":"Guest","GuestId":42,"Title":"Schedule changed","MessageText":"Your agenda has changed.","ClickUrl":"","IdempotencyKey":"<unique-key>"}
```

For broadcast: `TargetType="All"`, `GuestId=null`. `auth()` attaches the existing admin bearer token; SLTAPI authenticates with `[SltAdmin]` and resolves admin ID. No Global Push API key or app registration.

The admin UI reads `NotificationId`, `RecipientCount`, `PushStatus` and displays history. `RecipientCount` refers to existing guest inbox recipients, not necessarily mobile browsers. A `PushStatus=Accepted` means provider acceptance only.

For a **new** SLTUser origin `/slt2/`, leave optional `ClickUrl` blank. The backend uses `SltWebPush.ClickPath=html/Notifications.html`, and user worker opens its own `/slt2/html/Notifications.html`. Hardcoding old `/guest-login.html` or `/SPPowers/sltuser/` breaks new-domain navigation. Existing admin URL validation requires root-relative values if nonblank; do not type bare `html/Notifications.html` into the admin form.

## Merge sequence

1. Compare new branch `assets/config.js`, retain its business settings; fix API base. Do NOT replace it with tiny sample object from older overlay.
2. Inspect new `notifications-admin.html` scripts, remove ONLY the old `slt-push-admin-integration.js` reference. Keep all other scripts and sent/history logic.
3. Confirm `manifest.webmanifest` exists at published site root, with MIME mapping `.webmanifest=application/manifest+json`. This was already confirmed fixed; recheck only if deployment differs.
4. Postman/GUI: signed-in admin sends to one guest, then all eligible guests; check SQL inbox, push status, history, click target on migrated SLTUser.

## Do not change

No changes needed to auth, login, guest management, admin API client internals, notification composer sender, backend scheduler, SMS, manifest for SLTUser, VAPID keys, proxy, or SQL schema from this developer. The admin site may keep its PWA manifest; it is unrelated to user browser subscription.
