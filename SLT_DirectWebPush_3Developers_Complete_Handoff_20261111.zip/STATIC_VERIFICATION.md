# Package validation (2026-11-11)

- Verified JavaScript syntax with Node.js `node --check` for all five included SLTUser reference scripts and `sw.js`.
- Parsed `SLTProject.csproj`, `packages.config`, `SLTUser/web.config` as XML.
- Parsed two included Postman collections, the production environment, and admin webmanifest as JSON.
- Verified three developer ZIPs and consolidated ZIP contain readable entries with no ZIP integrity errors.
- The shared Web.config fragment contains placeholders, **not live VAPID private or other secret values**.
- Generated unified diffs against the three supplied baseline source ZIPs; these patches are **for review only** and have not been applied/tested on the newer developer branches.

## Not verified

No .NET Framework Windows compilation, restored NuGet packages, live SQL execution, IIS publish, CORS preflight, live proxy handshake, Android/iOS background delivery, or automated end-to-end UI deployment tests. These must be performed by the respective developers on their current branches.
