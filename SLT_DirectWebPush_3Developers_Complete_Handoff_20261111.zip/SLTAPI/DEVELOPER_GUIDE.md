# Developer 1 — SLTAPI (Backend + SQL + Direct Web Push)

**Scope:** Add push browser registration and direct push delivery; keep existing SLT admin/guest authentication, EF6 Database First entities, notification inbox, scheduler, SMS and business endpoints.

## File-by-file merge instructions

| File | Status | Function/section to import | Why / what to preserve |
|---|---|---|---|
| `Controllers/SltDirectPushController.cs` | NEW | Class `[RoutePrefix("api/slt-notifications/guest/push")]`, `GuestId`, `Config`, `Subscribe`, `Status`, `Unsubscribe` | Only existing `[SltGuest]` auth; use existing GuestId from request properties; no extra token or global service |
| `Services/SltDirectWebPushService.cs` | NEW | `Validate`, `SubscribeAsync`, `StatusAsync`, `UnsubscribeAsync`, `SendForNotificationAsync`, `CreateHttpClient`, `RecordAsync` | One SQL table; Web Push/VAPID encryption and provider requests; on/off proxy; upsert and owner-scoped opt-out |
| `Controllers/SltNotificationsController.cs` | MODIFIED | Retain `Send`, `Guests`, `Sent`, `ReadAdmin`, `Inbox`, `ReadGuest`; remove only obsolete `guest/push/v10.3`, registration-token, old Global Push bridge routes | Preserve all existing business routes, no duplicate route prefixes |
| `Services/SltNotificationsService.cs` | MODIFIED | `SltNotificationSendResult`, `SendAsync`, `PushText`, `SaveNotificationChangesAsync` | Save header and recipients first; invoke local `SltDirectWebPushService.SendForNotificationAsync`, save final PushStatus; keep guest inbox/admin sent/read methods |
| `Services/SltOperationalAlertsService.cs` | MODIFIED | Push branch in `ProcessDueAsync` | Schedule/SMS unchanged; use `answer.PushStatus == "Accepted"` before setting `PushAccepted` |
| `SLTProject.csproj` | MODIFIED | Compile includes for 2 new C# files; WebPush and BouncyCastle references with `Private=True` | Merge into current project XML; verify actual package paths; do not copy entire old .csproj |
| `packages.config` | MODIFIED | NuGet `WebPush` 1.0.12 and `Portable.BouncyCastle` 1.9.0 | Restore matching packages; avoid multiple conflicting DLLs |
| `Web.config` | MANUAL CONFIG ONLY | `SltWebPush.*`, CORS origin and BouncyCastle redirect | Do not overwrite newer Web.config or expose keys |
| `SQL/01_Create_SltGuestPushSubscriptions.sql` | NEW SQL | Single table, unique hash index, guest-active index | No new database; no EDMX update |
| `SQL/02_Allow_DirectWebPush_Statuses.sql` | PATCH SQL | Widen `CK_SltNotifications_Push` | Required for successful `Accepted`, `Partial`, `NoSubscribers` status persistence |

## Exact implementation behavior

**Config:** `Config()` returns `{publicKey: SltDirectWebPushService.PublicKey, enabled:true}`; key is public, not a secret. Guarded by existing guest auth in the reference.

**Subscribe:** `Subscribe()` gets `SLTGuestId` from `[SltGuest]`, validates provider HTTPS URL and browser keys, hashes endpoint for unique matching, inserts or reassigns a stored endpoint to authenticated GuestId. Response `{subscriptionId,subscribed:true}`. Never accept GuestId from browser JSON.

**Status/opt-out:** Both use `{endpoint}` and existing guest auth; server filters on `GuestId` AND endpoint hash AND full endpoint. Removing is a soft deactivate (`IsActive=0`).

**Send:** Existing `POST admin/send` works unchanged for SLTAdmin. `SendAsync()` selects eligible guests, inserts `SltNotifications` and `SltNotificationRecipients`, sends push directly, updates PushStatus and PushError. There is no WebPushAPI HTTP call and no application code. It converts markdown to plain text for popup only. Failed provider call must not remove inbox entries.

**Scheduled:** The existing scheduled alert worker uses `SltNotificationsService.SendAsync` and marks PushAccepted only for `Accepted`. On retry, `LastAcceptedNotificationId` prevents resending to already accepted browser subscriptions (verify against each new branch's current retry behavior).

**Proxy:** `CreateHttpClient()` reads `SltWebPush.UseProxy`: `true` -> explicit `WebProxy(http://proxylb:5110)` with optional IIS identity/default credentials; `false` -> `HttpClientHandler.UseProxy=false`. It only affects SLTAPI outbound provider requests; browser-origin permission and PushManager are not proxy-controlled by the API config.

**Assembly:** Reference version mismatch observed with WebPush 1.0.12 requesting `BouncyCastle.Crypto` assembly 1.8.1.0 and Portable.BouncyCastle 1.9.0 producing 1.9.0.0. Merge binding redirect and `<Private>True</Private>`, republish BOTH DLLs and recycle IIS. The last reference `SltNotificationsService.cs` also catches `FileLoadException`/`TypeLoadException` in the push-only catch and logs EF SQL root causes.

## Configuration per environment

Use `Config/WEB_CONFIG_MERGE_FRAGMENT.example.xml` as a **fragment only**. Keep existing VAPID keys once used. On development with direct network, `SltWebPush.UseProxy=false`. On IIS networks needing `proxylb:5110`, set `true` and confirm app pool identity can authenticate. `CorsAllowedOrigins` CSV must contain `https://webspace.vodafone.com.eg` (no `/slt2/`); preserve other origins. Set `SltWebPush.ClickPath=html/Notifications.html` relative to the *receiving worker scope*.

**Avoid:** adding back `SltPush.*`, `GlobalPush.Integration.*`, `X-Application-Code`, registration tokens or separate API key into the new push path. Old config may remain temporarily inert but must not be consumed.

## Acceptance checks

- Build solution; confirm new controllers compiled; inspect DLL files in deployed IIS `bin`.
- Run SQL 01 and SQL 02 on the SLT database; inspect `CK_SltNotifications_Push` and table indexes.
- `GET guest/push/config` returns public key; identified guest `POST subscriptions` upserts same endpoint without duplicates; status true; guest B cannot deactivate guest A endpoint.
- `POST admin/send` for one subscribed guest persists inbox and yields `Accepted` when provider accepts; no SQL check-constraint 500.
- For no active subscription, return `NoSubscribers` while inbox still persists.
- Scheduled alert uses existing Hangfire and does not claim PushAccepted for failed provider delivery; test retries and idempotency.
- Test proxy on/off **on the host actually executing SLTAPI**, not just development laptop.

## Caveats

Only source/static analysis is possible here. No verified Windows build/SQL migration/IIS provider test. The current sender runs provider calls inside the admin API request, so large broadcasts may time out: do not claim durable background queue guarantees. Keep existing EF models rather than regenerating EDMX.
