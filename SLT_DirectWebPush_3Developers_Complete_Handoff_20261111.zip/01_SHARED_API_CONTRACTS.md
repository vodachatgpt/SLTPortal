# Shared API Contract — SLT Direct Web Push

All routes are **relative to** `https://pulse.vodafone.com.eg/SPPowers/sltapi/api`; the SLTAPI existing authorization attributes are the only auth layer.

| Method | Relative API route | Who calls it | Authorization | Body/description |
|---|---|---|---|---|
| GET | `/slt-notifications/guest/push/config` | SLTUser SDK | Existing guest bearer token | Returns `{publicKey,enabled}` |
| POST | `/slt-notifications/guest/push/subscriptions` | SLTUser SDK | Guest bearer | `{endpoint,p256dh,auth}`; GuestId taken from token |
| POST | `/slt-notifications/guest/push/subscriptions/status` | SLTUser SDK | Guest bearer | `{endpoint}` -> `{subscribed}` |
| POST | `/slt-notifications/guest/push/subscriptions/unsubscribe` | SLTUser SDK | Guest bearer | `{endpoint}` -> `{removed}` |
| POST | `/slt-notifications/admin/send` | SLTAdmin | Existing admin bearer | Existing `{TargetType,GuestId,Title,MessageText,ClickUrl,IdempotencyKey}` |
| GET | `/slt-notifications/admin/guests?search=...` | SLTAdmin | Admin bearer | Guest selector |
| GET | `/slt-notifications/admin/sent?page=1&pageSize=15` | SLTAdmin | Admin bearer | Admin sent history |
| GET | `/slt-notifications/guest/inbox?page=1&pageSize=100` | SLTUser | Guest bearer | `{Items,UnreadCount,...}` from SLT database |
| POST | `/slt-notifications/guest/{notificationId}/read` | SLTUser | Guest bearer | Guest-owned read tracking |

## Browser registration payload

```json
{"endpoint":"<browser-PushSubscription.endpoint>","p256dh":"<subscription.toJSON().keys.p256dh>","auth":"<subscription.toJSON().keys.auth>"}
```

Browser must be on HTTPS, have permission, and subscribe through the **sltuser** worker. No browser-supplied GuestId and no Global Push application code. The SDK derives bearer token from existing `getSession()`.

## Admin send payload

```json
{"TargetType":"Guest","GuestId":42,"Title":"Schedule updated","MessageText":"Please check your schedule.","ClickUrl":"","IdempotencyKey":"<new-unique-key>"}
```

For a broadcast, use `"TargetType":"All"` and `"GuestId":null`. An empty `ClickUrl` is recommended across different PWA origins/scopes. Backend emits `SltWebPush.ClickPath` (e.g. `html/Notifications.html`), and the worker resolves it under its own `/slt2/` scope. The existing admin form validates nonempty click URLs as root-relative paths, so typing `html/Notifications.html` without a slash is rejected; **leave the field blank** rather than inventing a root path on the wrong domain.

## Results and behavior

Admin response retains `{NotificationId,RecipientCount,PushStatus,ProviderNotificationId,Duplicate}`. `ProviderNotificationId` remains null with direct Web Push. Status is one of `Pending`, `Queued`, `Accepted`, `Partial`, `Failed`, `NoSubscribers`, `NotConfigured` (existing records may have the old statuses). `RecipientCount` is inbox guest count, not number of push endpoints.

## PWA payload and click

Delivery service JSON: `{title,body,url,id}`. Existing root `sw.js` listens to `push`, displays via `self.registration.showNotification(...)` inside `event.waitUntil`, and handles `notificationclick`. The expected fallback is `https://webspace.vodafone.com.eg/slt2/html/Notifications.html?notificationId=<notificationId>`.

## SQL ownership

`dbo.SltGuestPushSubscriptions`: one row per browser endpoint; associated with current authenticated `GuestId`; active flag and delivery diagnostics. Existing `dbo.SltNotifications` and `dbo.SltNotificationRecipients` remain the inbox source of truth. SQL 02 adds accepted statuses to `CK_SltNotifications_Push` or successful Web Push can throw EF error while push already displayed.
