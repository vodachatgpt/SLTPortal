-- SLT Direct Web Push: widen status constraint for actual delivery outcomes.
-- Run once against the SLT database used by SLTAPI. Does not modify any notification rows.
USE [SLT];
GO
SET XACT_ABORT ON;
BEGIN TRY
    BEGIN TRANSACTION;

    IF OBJECT_ID(N'dbo.SltNotifications', N'U') IS NULL
        THROW 51000, 'dbo.SltNotifications was not found; verify your SLT database.', 1;

    IF EXISTS (SELECT 1 FROM sys.check_constraints
               WHERE name = N'CK_SltNotifications_Push'
                 AND parent_object_id = OBJECT_ID(N'dbo.SltNotifications'))
        ALTER TABLE dbo.SltNotifications DROP CONSTRAINT CK_SltNotifications_Push;

    ALTER TABLE dbo.SltNotifications WITH CHECK
    ADD CONSTRAINT CK_SltNotifications_Push
    CHECK (PushStatus IN (
      N'Pending', N'Queued', N'Accepted', N'Partial',
      N'Failed', N'NoSubscribers', N'NoSubscriptions', N'NotConfigured'
    ));

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO

-- Inspect recent notifications after deployment. Existing Pending rows are not rewritten.
SELECT TOP (20) Id, Title, PushStatus, PushError, CreatedAt
FROM dbo.SltNotifications ORDER BY Id DESC;
