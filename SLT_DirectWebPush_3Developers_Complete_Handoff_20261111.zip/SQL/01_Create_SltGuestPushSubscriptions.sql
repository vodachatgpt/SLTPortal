-- Run against the EXISTING SLT database (no new database; no EDMX regeneration).
-- SQL Server 2016+; safe to rerun.
IF OBJECT_ID(N'dbo.SltGuestPushSubscriptions',N'U') IS NULL
BEGIN
    CREATE TABLE dbo.SltGuestPushSubscriptions
    (
        Id BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_SltGuestPushSubscriptions PRIMARY KEY,
        GuestId BIGINT NOT NULL,
        Endpoint NVARCHAR(2048) NOT NULL,
        EndpointHash BINARY(32) NOT NULL,
        P256dh NVARCHAR(350) NOT NULL,
        Auth NVARCHAR(350) NOT NULL,
        IsActive BIT NOT NULL CONSTRAINT DF_SltGuestPushSubscriptions_Active DEFAULT(1),
        CreatedAtUtc DATETIME2(3) NOT NULL CONSTRAINT DF_SltGuestPushSubscriptions_Created DEFAULT SYSUTCDATETIME(),
        UpdatedAtUtc DATETIME2(3) NOT NULL CONSTRAINT DF_SltGuestPushSubscriptions_Updated DEFAULT SYSUTCDATETIME(),
        LastAcceptedAtUtc DATETIME2(3) NULL,
        LastAcceptedNotificationId BIGINT NULL,
        LastError NVARCHAR(250) NULL
    );
END;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID('dbo.SltGuestPushSubscriptions') AND name='UX_SltGuestPushSubscriptions_EndpointHash')
    CREATE UNIQUE INDEX UX_SltGuestPushSubscriptions_EndpointHash ON dbo.SltGuestPushSubscriptions(EndpointHash);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID('dbo.SltGuestPushSubscriptions') AND name='IX_SltGuestPushSubscriptions_GuestActive')
    CREATE INDEX IX_SltGuestPushSubscriptions_GuestActive ON dbo.SltGuestPushSubscriptions(GuestId,IsActive) INCLUDE(Id);
GO
