# SLT Direct Web Push — Three Developer Merge Handoff

**Purpose:** Transfer the working Direct Web Push integration into newer SLTUser, SLTAdmin, and SLTAPI branches **without overwriting newer development**. These reference files represent the staged changes from the packages supplied during this conversation; they are not guaranteed to match each team's newer branch.

## Ownership

| Developer | Responsibility | Handoff |
|---|---|---|
| SLTAPI | Web Push server, subscription storage, inbox/send, scheduled alerts, SQL, VAPID/proxy, NuGet | `SLTAPI/DEVELOPER_GUIDE.md` |
| SLTUser | Browser/PWA subscription, permission button, service worker, real inbox and click behavior | `SLTUser/DEVELOPER_GUIDE.md` |
| SLTAdmin | Existing notification composer/API; remove legacy Global Push checks, correct API base, ensure manifest | `SLTAdmin/DEVELOPER_GUIDE.md` |

**Use `ReferenceOnly/` files to compare and manually merge methods/hunks; DO NOT overwrite existing files from a newer branch.** `Patches/DIFF_AGAINST_UPLOADED_BASELINE.patch` is an audit of old-to-reference, not a patch guaranteed to apply to a newer branch. New files may be imported after checking namespaces, locations, and compile inclusion.

## Active architecture

SLTAdmin -> SLTAPI existing admin send/inbox -> SLT database -> SltDirectWebPushService -> Web Push providers -> SLTUser PWA `/slt2/sw.js`.

SLTUser -> existing passcode auth -> SLTAPI `/slt-notifications/guest/push/*` -> SLT guest subscription SQL table.

**Do not add GlobalPush V10/V11/V12 gateway, application code, app API key, registration-token flow, or extra service worker.** VAPID secrets and corporate proxy are solely SLTAPI concerns. SLTAPI never stores SLTUser business UI state.

## Production boundaries

- Admin UI: `https://pulse.vodafone.com.eg/SPPowers/sltadmin/`
- User UI: `https://webspace.vodafone.com.eg/slt2/`
- Backend API root: `https://pulse.vodafone.com.eg/SPPowers/sltapi/api`
- Browser CORS origin for user: `https://webspace.vodafone.com.eg` (no path)
- Browser push worker: `https://webspace.vodafone.com.eg/slt2/sw.js`; scope `/slt2/`

## Merge order

1. SLTAPI developer: merge services/controller/NuGet; apply SQL 01 then SQL 02; review config fragment, keep deployed VAPID keys; build/publish; verify API routes.
2. SLTUser developer: merge SDK + UI/worker + real inbox; configure actual API base; deploy worker and assets; re-enable/sync one device on new origin.
3. SLTAdmin developer: remove old V12 integration status script, set actual API base, keep existing sender; deploy manifest if still needed.
4. Joint: run Postman guest config/status/subscribe and admin send; test push popup, guest inbox, click deep link, no-subscription guest, multiple devices, scheduled alerts, proxy off/on on relevant hosts.

## Known distinctions / limitations

- A saved inbox record is different from a browser popup. `RecipientCount` counts guest inbox recipients; `Accepted` means push provider accepted requests, not guaranteed device display.
- Moving from old `pulse.../sltuser` to `webspace.../slt2/` requires a NEW browser subscription on the NEW origin. Reinstalling PWA alone does not prove the backend has linked the endpoint to the logged-in GuestId.
- The reference SDK synchronizes on AllowAccess/Notifications pages. Automatic background re-synchronization on every returning-user Home flow is **not implemented in these reference files**; consider a separate merge after login, with no permission prompt, so returning guests do not bypass subscription checks.
- `sw.js` cache activation in the reference deletes all caches except its own. On an origin shared with other PWAs, scope cleanup to an app-owned prefix before deployment. The new `webspace` domain may host other apps too.
- This does not implement a new durable broadcast delivery queue; the current admin send processes provider calls within the API request. Large broadcasts need operational acceptance testing.
- Full Visual Studio compilation, live IIS integration, mobile background/closed-app delivery, and SQL execution are deployment tests; the package contains source and static validation only.
