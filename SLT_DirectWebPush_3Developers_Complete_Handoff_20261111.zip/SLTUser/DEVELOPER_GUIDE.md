# Developer 2 — SLTUser (Passcode PWA + Web Push Receiver + Inbox)

**Scope:** Browser subscription and display. No VAPID private key or proxy config in frontend; no separate global push SDK.

## File-by-file merge instructions

| File | Status | Functions/markup to import | Preserve from newer branch |
|---|---|---|---|
| `js/guest-push.js` | Replace legacy SDK integration | `PartnerGuestPush.supported()`, `permission()`, `enable()`, `synchronize()`, `status()`, `disable()`, `beforeLogout()` | Existing `getSession()` and `APP_ROOT` from `js/app.js`; do not add another service worker |
| `js/AllowAccess.js` | MODIFIED | `showNotifyStep`, `notifyBtn` one click handler, silent `synchronize`, success/error messaging | PWA install, onboarding progress and passcode flow |
| `html/AllowAccess.html` | MODIFIED | Remove old Global Push scripts; load `guest-push.js` after `app.js`/`api.js` and before `AllowAccess.js`; existing notification button | Existing UI markup and styles |
| `html/Notifications.html` | MODIFIED | `pushState`, `enablePush`, `disablePush` controls; direct-push stylesheet and SDK script | Existing notification list and guest session |
| `css/direct-push-settings.css` | NEW | Isolated settings styling only | Other global styles |
| `js/Notifications.js` | MODIFIED | Push status/enable/disable handler + `?notificationId=` focus | Existing notification list and mark-read UI |
| `js/api.js` | MODIFIED | `getNotifications`, `markNotificationRead`, `getUnreadCount` | All other business API functions |
| `js/config.js` | MODIFIED | `apiBaseUrl` + `endpoints.notifications`, `markRead`, `notificationStatus`; remove `globalPush*` settings | All other endpoint settings |
| `sw.js` | MODIFIED | Preserve cache logic; add `push` and `notificationclick` listeners; update CACHE_NAME | Install/activate/offline fetch code; do not register second push worker |
| `web.config` | MODIFIED | CSP `connect-src` allow SLTAPI origin; other CSP settings preserved | Other headers, MIME, rewrite settings |

## Browser flow in detail

1. Guest signs in using existing passcode, producing session with bearer token via existing login implementation.
2. The UI's single Enable button calls `PartnerGuestPush.enable()` from user click. It checks HTTPS support and existing guest token, prompts for notification permission, calls SLTAPI `GET guest/push/config` to obtain public VAPID key, reuses the site's *root* worker (`APP_ROOT + 'sw.js'`), calls `pushManager.subscribe({userVisibleOnly:true, applicationServerKey})` if needed, then posts only `endpoint`, `p256dh`, `auth` to SLTAPI.
3. `synchronize()` **does not prompt**; if already granted and subscribed, it re-upserts endpoint under current authenticated GuestId. `status()` checks the browser and SLTAPI DB (not just Notification.permission). `disable()` calls owner-scoped SLTAPI unsubscribe then browser `unsubscribe()`. `beforeLogout()` preserves subscription by default.
4. On `Notifications.html`, show whether notifications are enabled and support manual Enable/Disable. Refresh existing subscription association for returning guests. **Do not automatically prompt on page load**; browsers require user activation for the permission prompt.
5. `js/config.js` sets live API base and real notifications endpoint, so `getNotifications()` returns actual SLT inbox data; `markNotificationRead()` posts to `guest/{id}/read`. Without these changes, the page uses `DUMMY.notifications` despite provider delivery.
6. The existing `sw.js` receives a `push` event even when tab is closed (subject to browser/OS runtime). `event.waitUntil(showNotification())` displays notification. On click, focus an existing matching tab or `clients.openWindow` to worker-scope `html/Notifications.html?notificationId=...`. Authentication still applies.

## Important new domain rules

Production user origin: `https://webspace.vodafone.com.eg`, app scope `/slt2/`, root worker `/slt2/sw.js`, manifest at `/slt2/manifest.webmanifest`; API base `https://pulse.vodafone.com.eg/SPPowers/sltapi/api`. Browser PWA origins can't reuse subscriptions from old `pulse.vodafone.com.eg/SPPowers/sltuser/`—each mobile device must re-enable/synchronize on the new host.

In the newer branch, ensure `js/app.js` calculates `APP_ROOT` based on current script URL. The reference code uses `new URL('../', document.currentScript.src).href`; there is no hardcoded `/SPPowers/` worker scope. Use only one worker for `/slt2/`. **Do not hardcode `sltuser` as an application code.**

For admin `ClickUrl`, empty string is preferred for cross-domain safe fallback; the backend's `html/Notifications.html` is resolved by `sw.js` relative to `/slt2/`. Custom URLs outside worker scope are rejected and fall back to inbox.

### Known follow-up for returning users (NOT already merged into reference)

The reference `Start.js` may bypass `AllowAccess.html` if onboarding flag exists. To ensure pre-existing users are linked on the **new domain**, the newer application's authenticated startup should load `guest-push.js` and call `synchronize()` **only if** `Notification.permission === 'granted'`. If it returns `needs-enable`, show an Enable button. Do not auto-call `enable()` (permission prompt). This is recommended future wiring; review your current login/HOME flow before adding it.

### PWA cache issue to review in newer branch

The reference `activate` deletes every cache with a name not equal to `CACHE_NAME`. If multiple PWAs share the `webspace.vodafone.com.eg` origin, this can delete another app's cache. Restrict deletion to an app-specific prefix; no destructive cache cleanup is needed to receive Web Push. Keep service worker script under `/slt2/`.

## Verification checklist

- With passcode session, `PartnerGuestPush.enable()` -> `{subscribed:true}` and `POST .../subscriptions` 200; status 200 true.
- `navigator.serviceWorker.getRegistration('/slt2/')` active worker `.../slt2/sw.js`, subscribed true, permission granted, controlled by correct worker.
- Same GuestId on Chrome and Edge receives one push per active browser; old-origin app may still have its own endpoint until migrated.
- Guest inbox fetch returns SQL messages; click and read mark works; notification click opens `/slt2/html/Notifications.html` with ID.
- Close only tab and send push; installed PWA window/fully closed browser behavior depends on OS/browser, not guaranteed by HTTP provider acceptance.
- After logout, subscription remains; on account change, first synchronize under current guest or opt out on shared devices; avoid sensitive content in lock-screen alerts.
