/* SLT App - service worker (needed for home-screen install, keeps pages available offline) */
const CACHE_NAME = "slt-app-v12-inbox-click";   // change this after every update

const FILES = [
  "./", "index.html", "manifest.webmanifest",
  "html/InvitationMail.html", "html/InvitationCode.html", "html/AllowAccess.html",
  "html/Splash.html", "html/Stories.html", "html/Home.html",
  "html/Notifications.html", "html/Contacts.html", "html/Day0.html", "html/EventDay.html",
  "bootstrap/bootstrap.min.css", "css/style.css", "css/Onboarding.css",
  "css/InvitationMail.css", "css/Splash.css", "css/Stories.css", "css/Home.css", "css/Pages.css", "css/Days.css",
  "js/config.js", "js/dummy-data.js", "js/app.js", "js/api.js", "js/Start.js",
  "js/InvitationMail.js", "js/InvitationCode.js", "js/AllowAccess.js",
  "js/Splash.js", "js/Stories.js", "js/Home.js", "js/Notifications.js", "js/Contacts.js",
  "js/config-days.js", "js/dummy-days.js", "js/api-days.js", "js/day-common.js", "js/Day0.js", "js/EventDay.js",
  "media/assets/VFLogo.svg", "media/assets/VFLogoWhite.png", "media/assets/FlagEgypt.svg", "media/assets/HelpSupportBanner.png", "media/assets/Bell.svg", "media/assets/AppShortcut.svg",
  "media/stories/story-1-pyramids.jpg", "media/stories/story-2-philae.jpg", "media/stories/story-3-museum.jpg",
  "media/stories/story-4-vodafone.jpg", "media/stories/story-5-leadership.jpg", "media/stories/story-6-5g.jpg",
  "media/home/getready-1-suit.png", "media/home/getready-2-dress.png", "media/home/getready-3-shoes.png",
  "media/home/tour-pyramids.jpg", "media/home/header-motion.jpg", "media/days/hero-pyramid.jpg", "media/day0/qr-sample.png",
  "media/weather/sun.svg", "media/weather/partly-cloudy.svg", "media/weather/cloudy.svg",
  "media/weather/fog.svg", "media/weather/rain.svg", "media/weather/storm.svg",
  "media/icons/icon-192.png", "media/icons/apple-touch-icon.png"
];

self.addEventListener("install", e => {
  e.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(FILES)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", e => {
  e.waitUntil(caches.keys()
    .then(keys => Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});

/* Network first (always fresh), cache only when offline. API calls are never cached. */
self.addEventListener("fetch", e => {
  const url = new URL(e.request.url);
  if (e.request.method !== "GET" || url.origin !== location.origin) return;
  if (url.pathname.endsWith(".mp4")) return;   // videos go straight to the network

  e.respondWith(
    fetch(e.request, { cache: "no-cache" })
      .then(response => {
        const copy = response.clone();
        if (response.ok) caches.open(CACHE_NAME).then(cache => cache.put(e.request, copy));
        return response;
      })
      .catch(() => caches.match(e.request, { ignoreSearch: true }))
  );
});


/* Native Web Push; added to existing root PWA service worker, without changing offline logic. */
self.addEventListener('push', event => {
  let data = {};
  try { data = event.data ? event.data.json() : {}; }
  catch (_) { data = {body: event.data ? event.data.text() : ''}; }
  const fallback = new URL('html/Notifications.html', self.registration.scope);
  let target = fallback;
  try {
    if (data.url) {
      const candidate = new URL(data.url, self.registration.scope);
      if (candidate.origin === fallback.origin && candidate.href.startsWith(self.registration.scope)) {
        // Old SLTAdmin samples used /guest-login.html, which is not a SLTUser page.
        // Preserve valid custom guest destinations; redirect only legacy missing paths.
        const legacy = /\/(?:frontend\/)?guest-login\.html$/i.test(candidate.pathname);
        target = legacy ? fallback : candidate;
      }
    }
  } catch (_) { /* fallback to inbox */ }
  if (data.id && target.pathname === fallback.pathname) target.searchParams.set('notificationId', String(data.id));
  event.waitUntil(self.registration.showNotification(String(data.title || 'SLT Notification').slice(0,120), {
    body: String(data.body || 'You have a new message.').slice(0,500),
    icon: new URL('media/icons/icon-192.png',self.registration.scope).href,
    tag: 'slt-notification-' + String(data.id || Date.now()),
    data: {url: target.href}
  }));
});
self.addEventListener('notificationclick', event => {
  event.notification.close();
  const fallback = new URL('html/Notifications.html',self.registration.scope);
  let target = fallback;
  try {
    const candidate = new URL(event.notification.data && event.notification.data.url || fallback.href, fallback);
    if (candidate.origin === fallback.origin && candidate.href.startsWith(self.registration.scope)) {
      const legacy = /\/(?:frontend\/)?guest-login\.html$/i.test(candidate.pathname);
      target = legacy ? fallback : candidate;
    }
  } catch (_) {}
  event.waitUntil((async () => {
    const windows = await clients.matchAll({type:'window',includeUncontrolled:true});
    for (const page of windows) if (page.url === target.href && page.focus) return page.focus();
    return clients.openWindow(target.href);
  })());
});
