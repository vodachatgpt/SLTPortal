/* =========================================================
   SLT App - Configuration
   ---------------------------------------------------------
   useLiveApi = false  -> OFF : every screen uses the dummy data (js/dummy-*.js)
   useLiveApi = true   -> ON  : screens call the back-end APIs below
   An endpoint left empty ("") keeps using its dummy data even when ON
   (for parts the back-end hasn't delivered yet).
   ========================================================= */
const CONFIG = {

  useLiveApi: true,  

  /* Testing only (set to false for the real event):
     - opens the Invitation Mail preview first
     - shows a "Reset demo" link and the testing panels
     - always shows the notifications step, even if already allowed */
  testMode: true,

  /* Back-end address (SLT-Users Postman collection: {{baseUrl}}api) */
  apiBaseUrl: "https://sltapi/api",

  endpoints: {
    /* 01 - Guest Authentication */
    verifyCode: "/guest-auth/login",                // POST { Passcode } -> token (30-day session)
    resendCode: "/guest-auth/resend-passcode",           // POST { Email }

    /* 02 - Weather Forecasts */
    getWeather: "/weather-forecasts",               // GET  -> [ forecast rows ] (expired rows are removed by the back-end)
    saveWeather: "/weather-forecasts/batch",        // POST { Items: [ { LocationName, Latitude, Longitude, TimeZone, Daily } ] }

    /* 03 - Guest */
    guestDetails: "/customizedResponses/guests",    // GET  -> the signed-in guest's row (Users table, no passcode)
    registerTour: "/guest-auth/tour-register",      // POST (no body, the token says who)

    /* 04 - Help & Support */
    contacts: "/help-support",                      // GET  -> { EventContact, Transportation, Emergency, HealthandSafety }

    /* Not in the back-end package yet -> dummy data until filled in */
    saveAccess: "",                                 // POST { installedApp, notifications }
    // Existing authenticated SLTAPI guest inbox; no separate Web Push service.
    notifications: "/slt-notifications/guest/inbox",   // GET -> { Items, UnreadCount, ... }
    markRead: "/slt-notifications/guest",            // POST /{notificationId}/read
    notificationStatus: "/slt-notifications/guest/inbox?page=1&pageSize=1" // GET -> UnreadCount
  },

  /* Event days (Cairo dates). Before Day0 the app shows "Before Arrival".
     Day0 -> Day0.html, Day1 ... Day3 -> EventDay.html, Day4 -> LastDay.html */
  eventDays: {
    Day0: "2026-12-08",
    Day1: "2026-12-09",
    Day2: "2026-12-10",
    Day3: "2026-12-11",
    Day4: "2026-12-12"
  },

  
  // Browser push is now served by this application's existing apiBaseUrl.

  /* Optional tour */
  tourId: "PYRAMIDS-2026-12-11",

  /* User fields sent with the tour registration in dummy mode (the live API reads the user from the token) */
  tourUserFields: ["id", "fullName", "email", "mobile"],

  /* Signed-in session length when the login answer doesn't say (back-end: 30-day session) */
  sessionDays: 30,

  /* External weather service (called only when our weather table is empty).
     Location values are also sent with the saved rows. */
  weatherLocation: { name: "Cairo", latitude: 30.0444, longitude: 31.2357, timeZone: "Africa/Cairo" },
  weatherUrl: "https://api.open-meteo.com/v1/forecast?latitude=30.0444&longitude=31.2357&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,wind_speed_10m_max&forecast_days=5&timezone=Africa%2FCairo",

  /* The weather table is cleared every hour (dummy mode copies this) */
  weatherKeepMinutes: 60,

  /* Passcode: true = letters and numbers (e.g. AB12CD), false = numbers only */
  codeAllowsLetters: true,

  /* true = letters typed in small are shown and sent as capitals (ab12cd -> AB12CD).
     Keep false if the back-end treats small and capital letters as different codes. */
  codeUpperCase: false,

  /* Code in the email link (?code=360990) fills the boxes automatically.
     true = also press Continue automatically; false = user taps Continue */
  autoSubmitCode: false,

  /* Seconds before "Resend code" is available */
  resendWaitSeconds: 30
};
