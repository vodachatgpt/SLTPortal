/* SLT direct Web Push integration: only depends on the existing passcode session.
 * No Global Push SDK, application code, device ID or registration-token API.
 * Uses the ROOT PWA service worker (sw.js), keeping the existing offline cache.
 */
(function (root) {
  'use strict';
  const service = '/slt-notifications/guest/push/';
  const base = () => String(CONFIG.apiBaseUrl || '').replace(/\/+$/, '');
  const bearer = () => {
    const session = getSession();
    if (!session || !session.token || !CONFIG.useLiveApi) throw Error('Please sign in using your SLT passcode.');
    return 'Bearer ' + session.token;
  };
  const supported = () => root.isSecureContext && 'Notification' in root && 'serviceWorker' in navigator && 'PushManager' in root;
  const urlKey = key => {
    const source = String(key || '').replace(/-/g, '+').replace(/_/g, '/');
    const raw = atob(source.padEnd(Math.ceil(source.length / 4) * 4, '='));
    return Uint8Array.from(raw, x => x.charCodeAt(0));
  };
  async function request(path, method, data) {
    const response = await fetch(base() + service + path, {
      method, headers: { Authorization: bearer(), ...(method !== 'GET' ? {'Content-Type':'application/json'} : {}) },
      body: method === 'GET' ? undefined : JSON.stringify(data || {}),
      credentials: 'omit', cache: 'no-store'
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw Error(result.Message || result.message || 'Web Push API HTTP ' + response.status);
    return result;
  }
  async function worker() {
    // Reuse the application's original root worker and its PWA scope.
    return navigator.serviceWorker.register(APP_ROOT + 'sw.js', { scope: APP_ROOT, updateViaCache: 'none' });
  }
  const body = subscription => {
    const data = subscription.toJSON();
    return { endpoint: data.endpoint, p256dh: data.keys.p256dh, auth: data.keys.auth };
  };
  const keyMatches = (subscription, key) => {
    const current = subscription && subscription.options && subscription.options.applicationServerKey;
    if (!current) return false;
    const a = new Uint8Array(current);
    return a.length === key.length && a.every((v,i) => v === key[i]);
  };
  async function sync() {
    if (!supported() || Notification.permission !== 'granted') return {subscribed:false,reason:'permission'};
    const registration = await worker();
    const subscription = await registration.pushManager.getSubscription();
    if (!subscription) return {subscribed:false,reason:'needs-enable'};
    // No permission prompt. On return/login, renew the database's guest association.
    const result = await request('subscriptions','POST',body(subscription));
    return { subscribed: !!result.subscribed, subscriptionId: result.subscriptionId };
  }
  const api = {
    supported,
    permission: () => ('Notification' in root ? Notification.permission : 'unsupported'),
    async enable() {
      if (!supported()) throw Error('Web Push requires HTTPS and a supported browser.');
      bearer(); // Ensure the guest is authenticated before asking permission.
      // Keep permission request directly inside the user's click handler.
      let permission = Notification.permission;
      if (permission === 'default') permission = await Notification.requestPermission();
      if (permission !== 'granted') throw Error('Browser notification permission was not granted.');
      const config = await request('config','GET');
      if (!config.enabled || !config.publicKey) throw Error('Browser push is not configured in SLTAPI.');
      const registration = await worker();
      const key = urlKey(config.publicKey);
      let subscription = await registration.pushManager.getSubscription();
      if (subscription && !keyMatches(subscription,key)) {
        await subscription.unsubscribe();
        subscription = null;
      }
      if (!subscription) subscription = await registration.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:key});
      const result = await request('subscriptions','POST',body(subscription));
      return { subscribed:!!result.subscribed, subscriptionId:result.subscriptionId };
    },
    async synchronize() { return sync(); },
    async status() {
      if (!supported() || Notification.permission !== 'granted') return {subscribed:false,reason:'permission'};
      const registration = await worker();
      const subscription = await registration.pushManager.getSubscription();
      if (!subscription) return {subscribed:false,reason:'needs-enable'};
      return request('subscriptions/status','POST',{endpoint:subscription.endpoint});
    },
    async disable() {
      const registration = await worker();
      const subscription = await registration.pushManager.getSubscription();
      if (!subscription) return {removed:false,subscribed:false};
      // Server confirms owner-scoped removal before removing the browser subscription.
      await request('subscriptions/unsubscribe','POST',{endpoint:subscription.endpoint});
      await subscription.unsubscribe();
      return {removed:true,subscribed:false};
    },
    beforeLogout() { return Promise.resolve({subscribed:true,keptAfterLogout:true}); }
  };
  root.PartnerGuestPush = api;
})(window);
