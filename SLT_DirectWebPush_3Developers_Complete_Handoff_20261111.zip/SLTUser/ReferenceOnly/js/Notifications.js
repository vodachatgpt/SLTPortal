const notifyList = document.getElementById('notifyList');

/* ================= INIT ================= */
document.addEventListener('DOMContentLoaded', async () => {
  if (!getSession()) {
    location.replace('../index.html');
    return;
  }

  try {
    const notifications = await getNotifications();
    showNotifications(notifications);
    // Notification clicks can link to ?notificationId=123. Focus the entry if present.
    const linkedId = new URLSearchParams(location.search).get('notificationId');
    if (linkedId && /^\d+$/.test(linkedId)) {
      const item = Array.from(notifyList.querySelectorAll('.notify-item'))
        .find(node => node.dataset.id === linkedId);
      if (item) { item.scrollIntoView({block: 'center'}); item.focus(); }
    }
  } catch (err) {
    notifyList.innerHTML = '<li class="page-message">' + escapeText(err.message) + '</li>';
  }
});

/* ================= SHOW THE LIST ================= */
function showNotifications(notifications) {
  if (!notifications || !notifications.length) {
    notifyList.innerHTML = '<li class="page-message">No notifications yet.</li>';
    return;
  }

  notifyList.innerHTML = notifications.map(n => {
    const unread = n.NotificationStatus === 'Unread';
    return `
      <li>
        <button type="button" class="notify-item ${unread ? 'unread' : ''}" data-id="${escapeText(n.NotificationID)}">
          <span class="notify-logo"><img src="../media/assets/VFLogo.svg" alt=""></span>
          <span class="notify-body">
            <span class="notify-title d-block">${escapeText(n.NotificationTitle)}</span>
            <span class="notify-text d-block">${escapeText(n.NotificationDetails)}</span>
            <span class="notify-time">
              ${escapeText(formatNotificationTime(n.NotificationTime))}
              ${unread ? '<span class="notify-dot" aria-label="Unread"></span>' : ''}
            </span>
          </span>
        </button>
      </li>`;
  }).join('');

  notifyList.querySelectorAll('.notify-item.unread').forEach(item => item.addEventListener('click', () => markAsRead(item)));
}

/* ================= TAP = MARK AS READ ================= */
async function markAsRead(item) {
  if (!item.classList.contains('unread')) return;

  item.classList.remove('unread');                 // update the screen straight away
  const dot = item.querySelector('.notify-dot');
  if (dot) dot.remove();

  try {
    await markNotificationRead(item.dataset.id);   // then tell the back-end
  } catch (err) {
    console.warn('markNotificationRead failed', err);
  }
}

/* ================= HELPERS ================= */

/* "10:15:00" -> "10:15 AM"; a full date-time from today -> "10:15 AM", other days -> "8 Dec, 10:15 AM" */
function formatNotificationTime(value) {
  if (!value) return '';

  const timeOnly = /^(\d{1,2}):(\d{2})/.exec(value);
  if (timeOnly && value.length <= 8) {
    const hours = Number(timeOnly[1]);
    const suffix = hours >= 12 ? 'PM' : 'AM';
    const hours12 = String(hours % 12 || 12).padStart(2, '0');
    return hours12 + ':' + timeOnly[2] + ' ' + suffix;
  }

  const date = new Date(value);
  if (isNaN(date)) return value;

  const options = { timeZone: 'Africa/Cairo', hour: '2-digit', minute: '2-digit', hour12: true };
  const isToday = new Intl.DateTimeFormat('en-CA', { timeZone: 'Africa/Cairo' }).format(date) ===
                  new Intl.DateTimeFormat('en-CA', { timeZone: 'Africa/Cairo' }).format(new Date());
  if (!isToday) Object.assign(options, { day: 'numeric', month: 'short' });
  return new Intl.DateTimeFormat('en-GB', options).format(date).toUpperCase();
}

/* text from the API is shown as text, never as HTML */
function escapeText(value) {
  return String(value == null ? '' : value).replace(/[&<>"']/g, ch =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
}


/* Push controls only; existing inbox rendering/read APIs remain unchanged. */
document.addEventListener('DOMContentLoaded', async () => {
  const state = document.getElementById('pushState');
  const enable = document.getElementById('enablePush');
  const disable = document.getElementById('disablePush');
  if (!state || !window.PartnerGuestPush) return;
  async function refresh() {
    try {
      const result = await PartnerGuestPush.status();
      state.textContent = result.subscribed ? 'Browser notifications enabled.' : 'Browser notifications not enabled.';
    } catch (error) { state.textContent = 'Unable to check push status: ' + error.message; }
  }
  enable.addEventListener('click', async () => {
    enable.disabled = true;
    try {
      const result = await PartnerGuestPush.enable();
      state.textContent = result.subscribed ? 'Browser notifications enabled.' : 'Registration not confirmed.';
    } catch (error) { state.textContent = 'Could not enable notifications: ' + error.message; }
    finally { enable.disabled = false; }
  });
  disable.addEventListener('click', async () => {
    disable.disabled = true;
    try { await PartnerGuestPush.disable(); state.textContent = 'Browser notifications disabled.'; }
    catch (error) { state.textContent = 'Could not disable notifications: ' + error.message; }
    finally { disable.disabled = false; }
  });
  // No permission prompt: renew the browser-to-guest association when possible.
  if (PartnerGuestPush.supported() && Notification.permission === 'granted') {
    try { await PartnerGuestPush.synchronize(); } catch (_) {}
  }
  await refresh();
});
