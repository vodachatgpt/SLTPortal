/* =========================================================
   SLT App - Back-end calls
   ---------------------------------------------------------
   Every function checks the switch first:
     OFF (CONFIG.useLiveApi = false) or empty endpoint -> answers from the dummy data
     ON                                               -> calls the real API
   Pages only call these functions, never fetch() directly.
   Answers are read in any letter case (firstName = FirstName), see anyCase().
   ========================================================= */

/* ON for this endpoint? (switch ON + endpoint filled in) */
function isLive(endpoint) {
  return CONFIG.useLiveApi && !!endpoint;
}

/* ================= SIGN IN WITH THE PASSCODE ================= */
async function verifyCode(inviteId, code) {

  if (!isLive(CONFIG.endpoints.verifyCode)) {
    await wait(DUMMY.delayMs);
    const user = DUMMY.validCodes[code];
    if (!user) throw new Error("This code isn't correct. Please check your email and try again.");
    return { user: user, token: "dummy-token-" + user.id, expiresAt: DUMMY.sessionExpiresAt };
  }

  // 1) login -> token
  let login;
  try {
    login = anyCase(firstRow(await callApi(CONFIG.endpoints.verifyCode, { Passcode: code })));
  } catch (err) {
    if (err.status >= 400 && err.status < 500) throw new Error("This code isn't correct. Please check your email and try again.");
    throw err;
  }

  const token = login.Token || login.AccessToken || login.GuestToken || login.JwtToken;
  if (!token) throw new Error("Sign-in answer has no token. Please try again.");

  const expiresAt = login.ExpiresAt || login.Expiry || login.ExpiryDate || login.SessionExpiresAt ||
                    new Date(Date.now() + CONFIG.sessionDays * 86400000).toISOString();

  // 2) the guest's own details (name for the greeting) - not blocking if it fails
  let guest = anyCase(login.Guest || login.User || login);
  if (isLive(CONFIG.endpoints.guestDetails)) {
    try { guest = anyCase(firstRow(await callApi(CONFIG.endpoints.guestDetails, null, 'GET', token))); } catch (e) { /* keep login data */ }
  }

  return { user: guestToUser(guest), token: token, expiresAt: expiresAt };
}

/* Users row -> the small user object kept in the session */
function guestToUser(guest) {
  const firstName = guest.FirstName || String(guest.FullName || '').split(' ')[0] || '';
  return {
    id: guest.Id || guest.GuestId || guest.UserId || guest.UserID || '',
    firstName: firstName,
    fullName: guest.FullName || [guest.FirstName, guest.LastName].filter(Boolean).join(' '),
    email: guest.Email || '',
    mobile: guest.MobileNumber || guest.Mobile || '',
    // Home (before arrival) hides the tour card when the back-end says the guest is registered
    tourRegistration: isYes(guest.TourRegisteration !== undefined ? guest.TourRegisteration : guest.TourRegistration) ? 'Yes' : ''
  };
}

/* ================= RESEND THE PASSCODE ================= */
async function resendCode(inviteId) {

  if (!isLive(CONFIG.endpoints.resendCode)) {
    await wait(DUMMY.delayMs);
    return { message: "A new code has been sent to your email." };
  }

  const email = getInviteEmail();
  if (!email) throw new Error("Please open the link in your invitation email to get a new code.");

  await callApi(CONFIG.endpoints.resendCode, { Email: email });
  return { message: "A new code has been sent to your email." };
}

/* ================= SAVE ACCESS CHOICES ================= */
async function saveAccess(installedApp, notifications) {
  const session = getSession();
  const body = { userId: session ? session.user.id : "", installedApp: installedApp, notifications: notifications };

  if (!isLive(CONFIG.endpoints.saveAccess)) {
    await wait(DUMMY.delayMs);
    console.log("[Dummy] saveAccess", body);
    return { saved: true };
  }

  return callApi(CONFIG.endpoints.saveAccess, body);
}

/* ================= TOUR REGISTRATION ================= */
async function registerTour(attending) {

  if (!isLive(CONFIG.endpoints.registerTour)) {
    await wait(DUMMY.delayMs);
    console.log('[Dummy] registerTour', { tourId: CONFIG.tourId, attending: attending, user: pickUserFields(CONFIG.tourUserFields) });
    return { registered: attending };
  }

  // the back-end knows the guest from the token: no body needed
  return callApi(CONFIG.endpoints.registerTour, null, 'POST');
}

/* copies the listed fields from the signed-in user's record */
function pickUserFields(fieldNames) {
  const session = getSession();
  const user = session ? session.user : {};
  const picked = {};
  fieldNames.forEach(name => {
    if (user[name] !== undefined) picked[name] = user[name];
  });
  return picked;
}

/* ================= NOTIFICATIONS ================= */
async function getNotifications() {
  if (!isLive(CONFIG.endpoints.notifications)) {
    await wait(400);
    const readIds = dummyReadIds();
    return DUMMY.notifications.map(n => Object.assign({}, n,
      readIds.includes(n.NotificationID) ? { NotificationStatus: 'Read' } : {}));
  }

  // SLTAPI: GET /api/slt-notifications/guest/inbox?page=1&pageSize=100
  // Existing guest bearer token is supplied by callApi() from getSession().
  const response = anyCase(await callApi(CONFIG.endpoints.notifications + '?page=1&pageSize=100', null, 'GET'));
  return listOf(response.Items).map(raw => {
    const n = anyCase(raw);
    return {
      NotificationID: n.NotificationId,
      NotificationTitle: n.Title,
      NotificationDetails: n.MessageText,
      NotificationTime: n.CreatedAt,
      NotificationStatus: n.IsRead ? 'Read' : 'Unread',
      ClickUrl: n.ClickUrl
    };
  });
}

async function markNotificationRead(notificationId) {
  if (!isLive(CONFIG.endpoints.markRead)) {
    const readIds = dummyReadIds();
    if (!readIds.includes(notificationId)) readIds.push(notificationId);
    writeStorage('slt.dummyReadIds', JSON.stringify(readIds));
    return { saved: true };
  }

  // SLTAPI: POST /api/slt-notifications/guest/{id}/read (no request body).
  const id = Number(notificationId);
  if (!Number.isSafeInteger(id) || id <= 0) throw new Error('Invalid notification ID.');
  return callApi(CONFIG.endpoints.markRead.replace(/\/$/, '') + '/' + id + '/read', null, 'POST');
}

function dummyReadIds() {
  try { return JSON.parse(readStorage('slt.dummyReadIds')) || []; } catch (e) { return []; }
}

/* ================= HELP & SUPPORT (contact numbers) ================= */
async function getContacts() {

  if (!isLive(CONFIG.endpoints.contacts)) {
    await wait(300);
    return DUMMY.contacts;
  }

  // Expected answer: { EventContact, Transportation, Emergency, HealthandSafety } (or a list with that row first)
  return anyCase(firstRow(await callApi(CONFIG.endpoints.contacts, null, 'GET')));
}

/* ================= NOTIFICATIONS: UNREAD COUNT (red dot on the bell) ================= */
async function getUnreadCount() {

  if (!isLive(CONFIG.endpoints.notificationStatus)) {
    const list = await getNotifications();
    return list.filter(n => n.NotificationStatus === 'Unread').length;
  }

  const data = anyCase(await callApi(CONFIG.endpoints.notificationStatus, null, 'GET'));
  return Number(data.UnreadCount) || 0;
}

/* ================= WEATHER =================
   1) ask our back-end for the saved forecast rows (expired rows are removed by the back-end)
   2) if empty -> call the external weather service, then save it for everyone (batch)
   Weather format used by the pages:
   { savedAt, days: [ { date: "2026-12-08", max: 28, min: 24, code: 0, rain: 0, wind: 12 }, ... ] } */
async function getSavedWeather() {

  if (!isLive(CONFIG.endpoints.getWeather)) {
    await wait(300);
    let saved = null;
    try { saved = JSON.parse(readStorage('slt.dummyWeatherTable')); } catch (e) { saved = null; }
    const ageMinutes = saved ? (Date.now() - new Date(saved.savedAt)) / 60000 : Infinity;
    return ageMinutes < CONFIG.weatherKeepMinutes ? saved : null;   // "table cleared" after one hour
  }

  const rows = listOf(await callApi(CONFIG.endpoints.getWeather, null, 'GET')).map(anyCase);
  const byDate = {};

  rows.forEach(row => {
    let daily = row.Daily;
    if (typeof daily === 'string') { try { daily = JSON.parse(daily); } catch (e) { daily = null; } }

    if (daily) {                                       // same shape as the batch: Daily { time: [...], ... }
      daily = anyCase(daily);
      listOf(daily.Time).forEach((date, i) => {
        byDate[String(date).slice(0, 10)] = {
          date: String(date).slice(0, 10),
          max: Math.round(listOf(daily.Temperature_2m_max)[i]),
          min: Math.round(listOf(daily.Temperature_2m_min)[i]),
          code: Number(listOf(daily.Weather_code)[i]) || 0
        };
      });
    } else if (row.Date || row.Time) {                 // or one flat row per day
      const date = String(row.Date || row.Time).slice(0, 10);
      byDate[date] = { date: date, max: Math.round(row.TemperatureMax), min: Math.round(row.TemperatureMin), code: Number(row.WeatherCode) || 0 };
    }
  });

  // from today on, in date order
  const today = todayInCairo();
  const days = Object.values(byDate).filter(d => d.date >= today).sort((a, b) => a.date.localeCompare(b.date));
  return days.length ? { savedAt: new Date().toISOString(), days: days } : null;
}

async function saveWeather(weather) {

  if (!isLive(CONFIG.endpoints.saveWeather)) {
    writeStorage('slt.dummyWeatherTable', JSON.stringify(weather));
    console.log('[Dummy] saveWeather', weather);
    return;
  }

  // one item per day, as in the Postman "Create batch" example
  const place = CONFIG.weatherLocation;
  const items = weather.days.map(d => ({
    LocationName: place.name,
    Latitude: place.latitude,
    Longitude: place.longitude,
    TimeZone: place.timeZone,
    Daily: {
      time: [d.date],
      temperature_2m_max: [d.max],
      temperature_2m_min: [d.min],
      weather_code: [d.code],
      precipitation_sum: [d.rain || 0],
      wind_speed_10m_max: [d.wind || 0]
    }
  }));

  return callApi(CONFIG.endpoints.saveWeather, { Items: items });
}

async function fetchExternalWeather() {
  const response = await fetch(CONFIG.weatherUrl);
  if (!response.ok) throw new Error('Weather service error');
  const data = await response.json();
  const daily = data.daily;

  // convert the external format into ours
  return {
    savedAt: new Date().toISOString(),
    days: daily.time.map((date, i) => ({
      date: date,
      max: Math.round(daily.temperature_2m_max[i]),
      min: Math.round(daily.temperature_2m_min[i]),
      code: daily.weather_code[i],
      rain: daily.precipitation_sum ? daily.precipitation_sum[i] : 0,
      wind: daily.wind_speed_10m_max ? daily.wind_speed_10m_max[i] : 0
    }))
  };
}

/* ================= HELPERS ================= */
/* token: only needed right after login (before the session is saved) */
async function callApi(endpoint, body, method, token) {
  method = method || 'POST';
  const session = getSession();
  token = token || (session ? session.token : '');

  const headers = {};
  if (body) headers["Content-Type"] = "application/json";
  if (token) headers.Authorization = "Bearer " + token;

  let response;
  try {
    response = await fetch(CONFIG.apiBaseUrl + endpoint, {
      method: method,
      headers: headers,
      body: body && method !== 'GET' ? JSON.stringify(body) : undefined
    });
  } catch (e) {
    throw new Error("No connection. Please check your internet and try again.");
  }

  // session ended or token refused -> sign in again
  if (response.status === 401 && session) {
    clearSession();
    location.replace(APP_ROOT + 'index.html');
    throw new Error("Your session has ended. Please sign in again.");
  }

  const text = await response.text();
  let data = {};
  try { data = text ? JSON.parse(text) : {}; } catch (e) { data = { message: text }; }

  if (!response.ok) {
    const answer = anyCase(data);
    const err = new Error(answer.Message || answer.Error || answer.Title || "Something went wrong. Please try again.");
    err.status = response.status;
    throw err;
  }
  return unwrap(data);
}

/* { success: true, data: {...} } -> {...}  (plain answers are kept as they are) */
function unwrap(data) {
  if (!data || typeof data !== 'object' || Array.isArray(data)) return data;
  const answer = anyCase(data);
  const isEnvelope = answer.Data !== undefined &&
    ['Success', 'IsSuccess', 'Succeeded', 'Status', 'StatusCode', 'Message'].some(key => answer[key] !== undefined);
  return isEnvelope ? answer.Data : data;
}

/* a list answer -> first row; a single row stays as it is */
function firstRow(data) {
  return Array.isArray(data) ? (data[0] || {}) : (data || {});
}

/* always a list */
function listOf(value) {
  return Array.isArray(value) ? value : (value === undefined || value === null ? [] : [value]);
}

/* read a row in any letter case: row.FirstName also finds firstName / firstname */
function anyCase(row) {
  if (!row || typeof row !== 'object' || Array.isArray(row)) return row;
  const names = {};
  Object.keys(row).forEach(key => names[key.toLowerCase()] = key);
  return new Proxy(row, {
    get: (target, name) => (typeof name === 'string' && !(name in target) && names[name.toLowerCase()])
      ? target[names[name.toLowerCase()]]
      : target[name]
  });
}

/* back-end dates "20/11/2026 11:00:00" (day/month/year) -> "2026-11-20T11:00:00"; other values are kept */
function isoDate(value) {
  const m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?/.exec(String(value || '').trim());
  if (!m) return value;
  const two = n => String(n).padStart(2, '0');
  const date = m[3] + '-' + two(m[2]) + '-' + two(m[1]);
  return m[4] === undefined ? date : date + 'T' + two(m[4]) + ':' + m[5] + ':' + (m[6] || '00');
}

/* "Yes" / true / "True" / 1 -> true */
function isYes(value) {
  return value === true || value === 1 || /^(yes|true|1)$/i.test(String(value || ''));
}

function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
