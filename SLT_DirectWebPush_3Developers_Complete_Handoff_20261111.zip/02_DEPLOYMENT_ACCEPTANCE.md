# Joint deployment and acceptance checklist

## Before merge

- [ ] Back up current code and SQL database. Each developer diff-imports only the source hunks relevant to the newer branch.
- [ ] Confirm direct Web Push is the intended current implementation; no leftover V10.3/V12 SDK script on SLTUser or integration checker on SLTAdmin.
- [ ] Coordinate existing SLT business and PWA changes before changing shared source files.

## SLTAPI

- [ ] NuGet installed (`WebPush 1.0.12`, `Portable.BouncyCastle 1.9.0`) with correct local DLL paths and Copy Local; binding redirect present.
- [ ] `Controllers/SltDirectPushController.cs` and `Services/SltDirectWebPushService.cs` compiled.
- [ ] SQL scripts `01`, `02` executed against the SAME database as SLTAPI connection string; check previous SQL constraint statuses.
- [ ] Existing VAPID keys retained. Configure `SltWebPush.UseProxy=false` on direct-access dev; `true` plus URL on proxy-dependent server. Test outbound provider connectivity as IIS identity.
- [ ] CORS allows `https://webspace.vodafone.com.eg` with `Authorization,Content-Type` for cross-origin SLTUser.
- [ ] Verify guest config, subscribe/status/unsubscribe and admin send with Postman.

## SLTUser

- [ ] Merge SDK, handlers, inbox API mapping. One notification permission handler, no second push worker.
- [ ] `js/config.js` production API base correct; `manifest.webmanifest` and `/slt2/sw.js` served with HTTP 200.
- [ ] New origin has its own subscription; post-success `Status` returns subscribed true for same guest.
- [ ] Guest inbox shows server records; mark read works; push click opens new `/slt2/` URL.
- [ ] If returning user bypasses onboarding, add synchronized startup hook after validating guest session; do not request permission without a click.

## SLTAdmin

- [ ] Existing sender calls `https://pulse.vodafone.com.eg/SPPowers/sltapi/api/slt-notifications/admin/send`.
- [ ] No `/admin/push/v12/integration` or `localhost:44394` URL remains in deployed source/network console.
- [ ] Manifest available at published admin website root if linked; MIME configured.
- [ ] One guest then broadcast: status persisted; 2 inbox recipients != 2 subscribed browsers.

## Scenarios to record

| Test | Expected |
|---|---|
| Guest with no subscription | Inbox still saved; `NoSubscribers` as push status |
| One guest, one browser | Provider accepted; one popup where OS supports it; one inbox row |
| One guest, two browsers | Both active browsers targeted, one guest inbox row |
| Different guest on shared browser | Successful sync/enable binds endpoint to newly authenticated guest |
| App closed, browser background active | Push can arrive via service worker; fully terminated browser not guaranteed |
| Notification click | New-domain `/slt2/html/Notifications.html?notificationId=...`, guest auth enforced |
| Provider unavailable | Inbox retained, `Failed` or `Partial`, useful error diagnostic |
| Scheduled alert due | Existing scheduler runs; only accepted push sets `PushAccepted` |
| Proxy false vs true | Provider HTTP uses direct/proxy respectively; never forces browser-side push through SLTAPI proxy |

**Do not replay historical notifications with `Pending` status blindly**. The provider may already have delivered them before the old SQL constraint rejected status update.
