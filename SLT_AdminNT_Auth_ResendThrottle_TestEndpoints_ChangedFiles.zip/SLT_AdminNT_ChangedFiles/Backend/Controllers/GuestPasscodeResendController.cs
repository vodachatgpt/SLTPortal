
using System;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using SLTProject.Services;

namespace SLTProject.Controllers
{
    public class GuestResendPasscodeDto
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }
    }

    [AllowAnonymous]
    [RoutePrefix("api/guest-auth")]
    public class GuestPasscodeResendController : ApiController
    {
        private readonly GuestPasscodeResendService _service =
            new GuestPasscodeResendService();

        private const string PublicMessage =
            "If your email is registered and eligible, " +
            "a passcode will be sent to your email and mobile.";

        // ==========================================
        // POST api/guest-auth/resend-passcode
        // ==========================================

        // Email-first login: request passcode by email and SMS.
        // Same generic response as resend; no resend throttle is applied.
        [AllowAnonymous]
        [HttpPost]
        [Route("request-passcode")]
        public Task<IHttpActionResult> RequestPasscode([FromBody] GuestResendPasscodeDto input)
        {
            return ResendPasscode(input);
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("resend-passcode")]
        public async Task<IHttpActionResult> ResendPasscode(
            [FromBody] GuestResendPasscodeDto input)
        {
            // Validate input.
            if (input == null ||
                string.IsNullOrWhiteSpace(input.Email))
            {
                return BadRequest("Email is required.");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(
                    "Please enter a valid email address.");
            }

            try
            {
                // Regenerate the passcode and send it through the
                // configured email and SMS delivery services.
                await _service.ResendAsync(input.Email);

                // Return the same generic response.
                //
                // Do not disclose:
                // - Whether email exists
                // - New passcode
                // - Guest ID
                return Ok(new
                {
                    Status = "Success",
                    Message = PublicMessage
                });
            }
            catch (Exception ex)
            {
                Trace.TraceError(
                    "Guest resend passcode failed. " +
                    "Error type: " +
                    ex.GetType().Name);

                // Keep the public response generic.
                return Ok(new
                {
                    Status = "Success",
                    Message = PublicMessage
                });
            }
        }
    }
}
