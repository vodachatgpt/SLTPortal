# SLTProject — changed files only

This package contains only the files changed for the latest request. Merge/replace the files at the same relative paths in your existing SLTProject.

## Files included

### Backend
- `Backend/Controllers/AdminsController.cs`
  - Changes the public admin login request from Email/Passcode to NTAccount/Password.
  - Keeps the existing `/api/admin-auth/me` session validation and existing protected admin management API class for backward compatibility.
- `Backend/Services/AdminService.cs`
  - Authenticates a real NT account against Active Directory.
  - Maps the AD user's `mail` (or UPN if mail is empty) to an active, non-deleted row in `dbo.Admins`.
  - Issues the existing random bearer token and stores only its SHA-256 hash in the existing Admins session fields. Existing `[SltAdmin]` session validation continues to use `CurrentAsync`.
  - Supports an explicitly configured static test identity, mapped to an existing active Admin row.
- `Backend/Controllers/GuestPasscodeResendController.cs`
- `Backend/Services/GuestPasscodeResendService.cs`
  - Removes the resend-only IP, email and global throttle checks. The generic anti-enumeration response remains.
- `Backend/Controllers/SltTestController.cs` (new)
  - `GET /api/test/app` checks whether the API is running.
  - `GET /api/test/database` executes `SELECT CAST(1 AS INT)` through EF6 and verifies the configured database connection.

### Frontend
- `Frontend/admin-login.html`
  - Changes the login form to NT Account + Network Password.
- `Frontend/assets/admin-login.js`
  - Posts `{ NTAccount, Password }` to `/api/admin-auth/login`.
- `Frontend/assets/shell.js`
  - Removes the Administrators item from the Workspace sidebar.
- `Frontend/service-worker.js`
  - Bumps the shell cache version so the updated admin login page and scripts are refreshed.

### Configuration
- `Deployment/WEB_CONFIG_ADMIN_NT_AUTH.xml`
  - Web.config appSettings fragment for the AD domain, static test identity and test endpoints.

## 1. Admin login behavior

### Production Active Directory login

1. Admin enters `DOMAIN\\username` or `username@domain` and their Windows password.
2. The backend validates the credentials through `PrincipalContext`.
3. The backend reads the AD user's `mail` attribute (falling back to UPN).
4. That email must match an active, non-deleted `dbo.Admins.Email` row.
5. The backend issues the existing 30-day bearer session and stores its hash in `dbo.Admins`.
6. All existing `[SltAdmin]` protected endpoints continue to validate the bearer token through the current Admin session.

**Important:** This does not grant admin access to every employee in Active Directory. The account must also be provisioned as an active row in `dbo.Admins`. The Administrators UI tab is removed, but the table remains the allow-list and session store.

Check which existing admin row to use for the static test account:

```sql
SELECT Id, FullName, Email, IsActive, IsDeleted
FROM dbo.Admins
WHERE IsActive = 1 AND IsDeleted = 0
ORDER BY Id;
```

Set `SLTAdminStaticTestAdminId` to the intended row's `Id`. For a real AD user, the AD `mail` value (or UPN fallback) must match that row's `Email`.

### Static test login

The static test login is enabled only when `SLTAdminStaticTestEnabled=true`.

Example:
- NT Account: `SLTTEST\\admin`
- Password: `SltTest#2026-Only`

It maps to `SLTAdminStaticTestAdminId`, which must be an existing active `dbo.Admins.Id`. Change the sample password and ID to values appropriate for your isolated test database.

**Before production:** set `SLTAdminStaticTestEnabled=false` and remove the static password setting. Do not deploy the sample test credentials.

### Required .NET Framework reference

Because the backend validates Windows credentials using `PrincipalContext`, add this framework reference to the .NET Framework project if it is not already present:

`System.DirectoryServices.AccountManagement`

In Visual Studio:
1. Right-click References.
2. Choose Add Reference.
3. Assemblies → Framework.
4. Select `System.DirectoryServices.AccountManagement`.
5. Rebuild.

The IIS server must be able to reach the configured AD domain/controller. `SLTAdminDomain` should be the actual AD DNS domain (not an example value).

## 2. Guest resend throttle

The following resend-only scopes are no longer consumed:
- `guest-resend-ip`
- `guest-resend-email`
- `guest-resend-global`

The endpoint remains:
`POST /api/guest-auth/request-passcode`

Body:
```json
{
  "Email": "guest@example.com"
}
```

The API continues to return a generic response to avoid confirming whether an email belongs to a registered guest.

This change removes resend throttling only. Guest login throttling remains in `GuestsService`, and administrator NT login throttling remains in `AdminService`.

## 3. Test endpoints

These are anonymous, read-only checks. They are available only when `SLTDiagnosticsEnabled=true`.

### Application check

```http
GET {{baseUrl}}/api/test/app
```

Expected:
```json
{
  "Status": "Running",
  "Application": "SLTProject",
  "CheckedAtUtc": "..."
}
```

### Database check

```http
GET {{baseUrl}}/api/test/database
```

Expected:
```json
{
  "Status": "Connected",
  "Database": "Available",
  "CheckedAtUtc": "..."
}
```

If the database is unavailable, it returns HTTP 503 without exposing the connection string or raw SQL exception.

For production, set `SLTDiagnosticsEnabled=false` unless these public health endpoints are explicitly required by your monitoring system.

## 4. Apply the changes

1. Back up your existing SLTProject.
2. Replace the five backend files at their matching relative paths.
3. Replace the four frontend files at their matching relative paths.
4. Merge `WEB_CONFIG_ADMIN_NT_AUTH.xml` into the existing `<appSettings>` in Web.config. Do not duplicate existing keys.
5. Add the `System.DirectoryServices.AccountManagement` framework reference if missing.
6. Add the new `SltTestController.cs` file to the project if your non-SDK `.csproj` uses explicit Compile entries.
7. Build the backend.
8. Publish the backend and frontend.
9. Hard-refresh the browser.

## 5. Test sequence

1. Set `SLTAdminStaticTestEnabled=true` in a non-production environment.
2. Set the static test NT/password values and an existing active `SLTAdminStaticTestAdminId`.
3. Open `admin-login.html`.
4. Sign in with the configured test NT account and password.
5. Verify redirect to `dashboard.html`.
6. Verify protected endpoints work with the returned bearer token.
7. Test a real AD user whose email matches an active `dbo.Admins.Email` row.
8. Test `GET /api/test/app`.
9. Test `GET /api/test/database`.
10. Call `POST /api/guest-auth/request-passcode` repeatedly to verify the resend-only throttle is no longer applied; use a test guest because each eligible call regenerates their passcode and sends email/SMS.
11. Confirm the Administrators sidebar item is gone.


## 6. How Push and SMS are fired / scheduled

The operational notification implementation already present in the consolidated project is retained; this request does not change its scheduling mechanism.

### A. Immediate change notification

When an Airport Transfer, Guest Check-in/Check-out or Event Driver record is saved/imported with:

- `NotificationMode = Immediate` (or `Automated`)
- `NotificationChannels = Push`, `Sms` or `Both`

the controller's post-save hook calls `SltOperationalAlertsService.EnqueueChangeAsync(...)`.

For `Immediate`, the service:
1. Inserts a row into `dbo.SltOperationalAlerts` with `DueAtUtc = SYSUTCDATETIME()`.
2. Calls `ProcessDueAsync(...)` immediately.
3. Sends the selected channels.

### B. Scheduled change notification

When the record is saved/imported with:

- `NotificationMode = Scheduled`
- `NotificationChannels = Push`, `Sms` or `Both`

the service inserts a pending queue row with `DueAtUtc = now + 15 minutes`.

It does not send immediately. The recurring Global Hangfire callback claims it when it becomes due.

### C. Event reminder

For an Event Driver import/edit with `Reminder = Yes`:
1. The hook resolves the related Day Schedule.
2. It reads the schedule date and start time.
3. It calculates `DueAtUtc = EventStartUtc - 15 minutes`.
4. Global Hangfire processes the row when due.

`Reminder = No` cancels any still-pending reminder for the same guest/schedule reference. A reminder cannot be queued if the event is already less than 15 minutes away.

### D. How the worker sends each channel

The Global Hangfire job calls:

```http
POST {{ApiUrl}}/api/operational-alerts/process-due
```

The job is registered every minute with:

```http
POST {{HangfireApiUrl}}/api/jobs/AddScheduleJob
```

Job key: `SLT_OperationalAlerts_EveryMinute`  
Cron: `* * * * *`

The callback:
1. Claims up to 25 due rows from `dbo.SltOperationalAlerts` using SQL update locks, avoiding two workers claiming the same row.
2. Resolves the active guest by email.
3. If SMS is selected, loads the active SMS template whose key is `{Category}_SMS`, fills `{FullName}`, `{Title}` and `{Message}`, then calls `SmsService.SendSmsAsync`.
4. If Push is selected, calls `SltNotificationsService.SendAsync` using the guest's SLT identity (`SLT-GUEST:{GuestId}`). This writes the in-app notification and invokes the Global Push delivery path for registered devices.
5. Stores per-channel acceptance flags. If one channel succeeds and the other fails, retry processing does not intentionally resend the already accepted channel.
6. Marks the queue row `Sent`, `Pending` (retry) or `Failed` after the configured retry count.

A provider HTTP 2xx means the provider accepted the request; it does not prove that an SMS handset or browser displayed it. Browser Push also requires the guest to have a valid browser subscription.

### E. SMS template keys used by the worker

The worker derives the SMS template key by appending `_SMS` to the alert category:

| Alert | Template key |
|---|---|
| Airport transfer change | `AIRPORT_TRANSFER_ALERT_SMS` |
| Guest check-in | `GUEST_CHECKIN_ALERT_SMS` |
| Guest check-out | `GUEST_CHECKOUT_ALERT_SMS` |
| Event driver change | `EVENT_DRIVER_ALERT_SMS` |
| Event reminder | `EVENT_REMINDER_SMS` |

Each template must be active and contain the placeholders required by the message (`{FullName}`, `{Title}`, `{Message}`).

### F. Register or remove the recurring job

After deploying, register it once with an Admin bearer token:

```http
POST {{baseUrl}}/api/operational-alerts/configure-scheduler
Authorization: Bearer {{adminToken}}
```

To remove it:

```http
DELETE {{baseUrl}}/api/operational-alerts/configure-scheduler
Authorization: Bearer {{adminToken}}
```

The registration service calls the same Global Hangfire `AddScheduleJob` and `RemoveJob` APIs used by the Weather cleanup integration. No local Hangfire server is started by SLT.

## 7. Notes / boundaries

- No database schema change is required for this implementation.
- The `dbo.Admins` table is retained for admin allow-listing and bearer session storage; only its frontend navigation tab is removed.
- The existing admin CRUD endpoints remain protected and are not deleted.
- The admin NT login still has its own rate limit. The requested resend throttle is the only throttle removed.
- A live Active Directory login cannot be verified from this build environment; test it on a server that can reach your domain controller.
