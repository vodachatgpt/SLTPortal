importScripts('./assets/slt-push-events.js');

/*
 * SLT PWA service worker.
 * - Handles PWA shell caching and Global Push notification events.
 * - Never caches API responses or authenticated API traffic.
 * - Only removes previous SLT shell caches; it does not clear unrelated
 *   applications' Cache Storage entries on the same origin.
 */
const CACHE_NAME = 'slt-admin-shell-v27-nt-auth';

const PRECACHE_URLS = [
    './admin-login.html',
    './dashboard.html',
    './guest-login.html',
    './guest-notifications-test.html',
    './notifications-admin.html',
    './guests-admin.html',
    './airport-transfers-admin.html',
    './day-schedules-admin.html',
    './guest-event-drivers-admin.html',
    './sms-templates-admin.html',
    './email-templates-admin.html',
    './weather-admin.html',
    './assets/admin-login.js',
    './assets/shell.js',
    './assets/app.css',
    './assets/premium.css',
    './assets/theme-2026.css',
    './assets/portal-unified-theme.css',
    './assets/slt-notifications.css',
    './assets/slt-guest-enhancements.css',
    './assets/slt-unified-tables.css',
    './assets/slt-import-tabs.css',
    './assets/slt-module-import-tabs.js',
    './assets/slt-notification-theme.css',
    './assets/slt-push-events.js',
    './assets/global-browser-push.v10.3.js',
    './assets/slt-guest-push.js',
    './assets/slt-notifications-guest.js',
    './assets/slt-notifications-ui.js',
    './icons/icon-192.png',
    './icons/icon-512.png'
];

self.addEventListener('install', function (event) {
    event.waitUntil((async function () {
        const cache = await caches.open(CACHE_NAME);

        await Promise.all(PRECACHE_URLS.map(async function (url) {
            try {
                await cache.add(new Request(url, { cache: 'reload' }));
            } catch (_) {
                // A missing optional page/asset must not block installation.
            }
        }));

        await self.skipWaiting();
    })());
});

self.addEventListener('activate', function (event) {
    event.waitUntil((async function () {
        const keys = await caches.keys();

        await Promise.all(keys.map(function (key) {
            const isOldSltCache =
                (key.indexOf('slt-admin-shell-') === 0 ||
                 key.indexOf('slt-frontend-shell-') === 0) &&
                key !== CACHE_NAME;

            return isOldSltCache ? caches.delete(key) : Promise.resolve(false);
        }));

        await self.clients.claim();
    })());
});

function isApiRequest(url, request) {
    return url.pathname.indexOf('/api/') >= 0 ||
        request.headers.has('Authorization') ||
        request.method !== 'GET';
}

function offlinePageFor(url) {
    const path = (url.pathname || '').toLowerCase();

    if (path.endsWith('/guest-login.html')) return './guest-login.html';
    if (path.endsWith('/guest-notifications-test.html')) return './guest-notifications-test.html';
    if (path.endsWith('/admin-login.html')) return './admin-login.html';

    return './dashboard.html';
}

self.addEventListener('fetch', function (event) {
    const request = event.request;
    const url = new URL(request.url);

    if (url.origin !== self.location.origin || isApiRequest(url, request)) {
        return;
    }

    if (request.mode === 'navigate') {
        event.respondWith(
            fetch(request).catch(async function () {
                const cache = await caches.open(CACHE_NAME);
                const fallback = offlinePageFor(url);
                return (await cache.match(request, { ignoreSearch: true })) ||
                    (await cache.match(fallback)) ||
                    new Response('This page is unavailable offline.', {
                        status: 503,
                        headers: { 'Content-Type': 'text/plain; charset=utf-8' }
                    });
            })
        );
        return;
    }

    if (!/\.(?:css|js|png|svg|ico|webmanifest)$/i.test(url.pathname)) {
        return;
    }

    event.respondWith(
        fetch(request, { cache: 'no-store' }).then(async function (response) {
            if (response.ok && response.type === 'basic') {
                const cache = await caches.open(CACHE_NAME);
                await cache.put(request, response.clone());
            }
            return response;
        }).catch(async function () {
            const cache = await caches.open(CACHE_NAME);
            return (await cache.match(request, { ignoreSearch: true })) ||
                new Response('', { status: 504 });
        })
    );
});
