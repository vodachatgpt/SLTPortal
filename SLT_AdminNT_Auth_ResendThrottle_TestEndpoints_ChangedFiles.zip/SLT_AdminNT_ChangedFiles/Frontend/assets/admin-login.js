
(function () {
    "use strict";

    var form = document.getElementById(
        "adminLoginForm"
    );

    var button = document.getElementById(
        "loginButton"
    );

    var msg = document.getElementById(
        "message"
    );

    // ==========================================
    // LOGIN
    // ==========================================

    form.addEventListener(
        "submit",
        async function (e) {
            e.preventDefault();

            button.disabled = true;
            msg.textContent = "";

            try {
                var ntAccount = document
                    .getElementById("adminNTAccount")
                    .value.trim();

                var password = document
                    .getElementById("adminPasscode")
                    .value;

                var result = await window.sltRequest(
                    "/admin-auth/login",
                    {
                        method: "POST",
                        body: JSON.stringify({
                            NTAccount: ntAccount,
                            Password: password
                        })
                    }
                );

                if (!result || !result.Token) {
                    throw new Error(
                        "Login succeeded but no token " +
                        "was returned."
                    );
                }

                // Save the token across browser
                // refreshes and app restarts.
                localStorage.setItem(
                    "slt_admin_token",
                    result.Token
                );

                // For the personalized Overview greeting.
                localStorage.setItem(
                    "slt_admin_email",
                    (result.Admin && result.Admin.Email) ? result.Admin.Email.toLowerCase() : ntAccount.toLowerCase()
                );

                document.getElementById("adminPasscode").value = "";
                document.getElementById("adminNTAccount").value = "";

                window.location.replace(
                    "dashboard.html"
                );
            }
            catch (error) {
                msg.textContent =
                    error.message ||
                    "Administrator login failed.";

                msg.className =
                    "slt-message slt-error";
            }
            finally {
                button.disabled = false;
            }
        }
    );

    // ==========================================
    // RESTORE EXISTING SESSION
    // ==========================================

    async function checkExistingSession() {
        var token = localStorage.getItem(
            "slt_admin_token"
        );

        if (!token) {
            return;
        }

        try {
            // Check if the stored token is valid.
            await window.sltRequest(
                "/admin-auth/me"
            );

            // Reuse the existing login.
            window.location.replace(
                "dashboard.html"
            );
        }
        catch (error) {
            console.warn(
                "[SLT Admin] Existing session check:",
                error
            );

            if (error.status === 401) {
                // The API explicitly rejected
                // the stored token.
                localStorage.removeItem(
                    "slt_admin_token"
                );

                msg.textContent =
                    "Your admin session has expired. " +
                    "Please log in again.";

                msg.className =
                    "slt-message slt-error";

                return;
            }

            // Keep the token for temporary errors.
            // Do not automatically log out on
            // 403, 404, 500 or network failures.

            msg.textContent =
                "Unable to verify your session. " +
                "Your saved token has been preserved.";

            msg.className = "slt-message";
        }
    }

    checkExistingSession();

})();
