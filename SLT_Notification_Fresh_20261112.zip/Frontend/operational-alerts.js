/* SLT administration frontend — optional integration helper.
   Include after your existing admin session/auth API setup.
   Template endpoints now return the two Yes/No Excel columns automatically.
   Authentication: pass existing admin Bearer token, never place it in URL.
*/
window.SLTAlerts = {
  async send({ apiBaseUrl = '/api', bearerToken, email, title, message,
               immediateNotification = false, scheduledNotification = false }) {
    if (!bearerToken) throw new Error('Admin login is required.');
    if (!immediateNotification && !scheduledNotification)
      throw new Error('Choose immediate and/or scheduled notification.');
    const response = await fetch(apiBaseUrl.replace(/\/$/, '') + '/operational-alerts/send', {
      method: 'POST',
      headers: { 'Authorization': 'Bearer ' + bearerToken, 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, title, message, immediateNotification, scheduledNotification })
    });
    const body = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(body.Message || body.message || 'Notification request failed.');
    return body;
  }
};
