/* SLT operational notification outbox — safe for repeat deployment.
   Existing guest, airport transfer, driver and schedule tables are unchanged.
   This creates the outbox only if it has not already been deployed. */
IF OBJECT_ID(N'dbo.SltOperationalAlerts', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.SltOperationalAlerts
    (
        Id bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_SltOperationalAlerts PRIMARY KEY,
        ReferenceKey nvarchar(250) NOT NULL,
        GuestEmail nvarchar(320) NOT NULL,
        Category nvarchar(100) NOT NULL,
        Channels nvarchar(10) NOT NULL,
        Title nvarchar(200) NOT NULL,
        MessageText nvarchar(2000) NOT NULL,
        DueAtUtc datetime2(3) NOT NULL,
        Status varchar(16) NOT NULL CONSTRAINT DF_SltAlerts_Status DEFAULT ('Pending'),
        Attempts int NOT NULL CONSTRAINT DF_SltAlerts_Attempts DEFAULT (0),
        LastAttemptAtUtc datetime2(3) NULL,
        LastError nvarchar(400) NULL,
        SmsAccepted bit NOT NULL CONSTRAINT DF_SltAlerts_Sms DEFAULT (0),
        PushAccepted bit NOT NULL CONSTRAINT DF_SltAlerts_Push DEFAULT (0),
        CreatedAtUtc datetime2(3) NOT NULL CONSTRAINT DF_SltAlerts_Created DEFAULT (SYSUTCDATETIME()),
        CompletedAtUtc datetime2(3) NULL,
        CONSTRAINT CK_SltAlerts_Status CHECK (Status IN ('Pending','Processing','Sent','Failed','Cancelled')),
        CONSTRAINT CK_SltAlerts_Channels CHECK (Channels IN ('Sms','Push','Both'))
    );
END;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'dbo.SltOperationalAlerts') AND name=N'IX_SltAlerts_Due')
    CREATE INDEX IX_SltAlerts_Due ON dbo.SltOperationalAlerts(Status,DueAtUtc,Id)
    INCLUDE (Attempts,LastAttemptAtUtc);
GO
-- These SMS template keys must exist and be active in the table mapped by
-- SLTProject.Data.SmsTemplate before the corresponding category can be sent:
-- AIRPORT_TRANSFER_ALERT_SMS
-- GUEST_CHECKIN_ALERT_SMS
-- GUEST_CHECKOUT_ALERT_SMS
-- EVENT_DRIVER_ALERT_SMS
-- MANUAL_ALERT_SMS
-- EVENT_REMINDER_SMS
-- Example tokens in SMS templates: {FullName}, {Title}, {Message}
SELECT TOP (20) Id,GuestEmail,Category,Channels,Status,DueAtUtc,
       SmsAccepted,PushAccepted,Attempts,LastError
FROM dbo.SltOperationalAlerts ORDER BY Id DESC;
