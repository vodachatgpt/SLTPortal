using System;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using SLTProject.Filters;
using SLTProject.Services;

namespace SLTProject.Controllers
{
    // No class-level SltAdmin: the Global Hangfire callback has its own network ACL.
    [RoutePrefix("api/operational-alerts")]
    public sealed class SltOperationalAlertsController : ApiController
    {
        private readonly SltOperationalAlertsSchedulerService _scheduler = new SltOperationalAlertsSchedulerService();


        // Ad-hoc admin dispatch for one guest. Both may be true. SMS and Push
        // delivery uses the same durable outbox and tracking as Excel imports.
        public sealed class ManualAlertInput
        {
            public string Email { get; set; }
            public string Title { get; set; }
            public string Message { get; set; }
            public string Reference { get; set; }
            public bool ImmediateNotification { get; set; }
            public bool ScheduledNotification { get; set; }
        }

        [SltAdmin]
        [HttpPost]
        [Route("send")]
        public async Task<IHttpActionResult> Send(ManualAlertInput input)
        {
            if (input == null || string.IsNullOrWhiteSpace(input.Email) ||
                string.IsNullOrWhiteSpace(input.Title) || string.IsNullOrWhiteSpace(input.Message))
                return BadRequest("Email, Title and Message are required.");
            if (!input.ImmediateNotification && !input.ScheduledNotification)
                return BadRequest("Select ImmediateNotification or ScheduledNotification.");
            if (input.Title.Length > 200 || input.Message.Length > 2000)
                return BadRequest("Title or Message exceeds the supported length.");
            string reference = "manual:" + Guid.NewGuid().ToString("N");
            try
            {
                await SltOperationalAlertHooks.SendSelectedAsync(mode =>
                    SltOperationalAlertsService.EnqueueChangeAsync(input.Email, "MANUAL_ALERT",
                        reference, input.Title, input.Message, mode, "Both"),
                    input.ImmediateNotification, input.ScheduledNotification);
                return Ok(new { Status="Queued", Immediate=input.ImmediateNotification,
                    Scheduled=input.ScheduledNotification, Channels="Both", ScheduledDelayMinutes=15 });
            }
            catch (ArgumentException ex) { return BadRequest(ex.Message); }
        }

        // Same scheduler-registration pattern as POST /api/weather-forecasts/schedule-cleanup.
        [SltAdmin]
        [HttpPost]
        [Route("configure-scheduler")]
        public async Task<IHttpActionResult> ConfigureScheduler()
        {
            try
            {
                var result = await _scheduler.ScheduleAsync().ConfigureAwait(false);
                return Ok(new
                {
                    Status = "Scheduled",
                    JobKey = SltOperationalAlertsSchedulerService.JobKey,
                    Cron = SltOperationalAlertsSchedulerService.Cron,
                    Execution = "Global Hangfire HTTP callback",
                    Message = result
                });
            }
            catch (ConfigurationErrorsException ex)
            {
                return Content(HttpStatusCode.ServiceUnavailable, new { Status = "ConfigurationError", Message = ex.Message });
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError("Global Hangfire registration failed: " + ex);
                return Content(HttpStatusCode.BadGateway, new { Status = "Failed", Message = "Could not register notification processing in Global Hangfire. See server logs." });
            }
        }

        [SltAdmin]
        [HttpDelete]
        [Route("configure-scheduler")]
        public async Task<IHttpActionResult> RemoveScheduler()
        {
            try
            {
                string result = await _scheduler.RemoveAsync().ConfigureAwait(false);
                return Ok(new { Status = "Removed", Message = result });
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError("Global Hangfire removal failed: " + ex);
                return Content(HttpStatusCode.BadGateway, new { Status = "Failed", Message = "Could not remove notification scheduler. See server logs." });
            }
        }

        [SltAdmin]
        [HttpGet]
        [Route("scheduler-status")]
        public IHttpActionResult SchedulerStatus()
        {
            // Configuration status is NOT proof that the external scheduler has the job registered.
            return Ok(new
            {
                Scheduler = "GlobalHangfire",
                JobKey = SltOperationalAlertsSchedulerService.JobKey,
                Cron = SltOperationalAlertsSchedulerService.Cron,
                HangfireUrlConfigured = !string.IsNullOrWhiteSpace(ConfigurationManager.AppSettings["HangfireApiUrl"]),
                ApiUrlConfigured = !string.IsNullOrWhiteSpace(ConfigurationManager.AppSettings["ApiUrl"]),
                SchedulerIpAllowlistConfigured = !string.IsNullOrWhiteSpace(ConfigurationManager.AppSettings["SLTAlertsAllowedSchedulerIps"]),
                Note = "Check Global Hangfire dashboard and alert queue to verify real execution."
            });
        }

        // Global Hangfire posts here every minute. NO shared secret is required.
        // For safety, fail closed unless the direct network peer IP is explicitly allowlisted.
        // Never trust X-Forwarded-For unless your reverse proxy validates and rewrites it.
        [AllowAnonymous]
        [HttpPost]
        [Route("process-due")]
        public async Task<IHttpActionResult> ProcessDue()
        {
            string configured = ConfigurationManager.AppSettings["SLTAlertsAllowedSchedulerIps"];
            if (string.IsNullOrWhiteSpace(configured))
                return Content(HttpStatusCode.ServiceUnavailable, new { Status = "ConfigurationError", Message = "Scheduler IP allowlist is not configured." });

            var remote = HttpContext.Current != null && HttpContext.Current.Request != null
                ? HttpContext.Current.Request.UserHostAddress : null;
            IPAddress remoteIp;
            if (!IPAddress.TryParse(remote, out remoteIp))
                return StatusCode(HttpStatusCode.Forbidden);

            if (remoteIp.IsIPv4MappedToIPv6) remoteIp = remoteIp.MapToIPv4();
            bool allowed = configured.Split(new[] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(part => part.Trim())
                .Any(part =>
                {
                    IPAddress allowedIp;
                    if (!IPAddress.TryParse(part, out allowedIp)) return false;
                    if (allowedIp.IsIPv4MappedToIPv6) allowedIp = allowedIp.MapToIPv4();
                    return allowedIp.Equals(remoteIp);
                });
            if (!allowed)
            {
                System.Diagnostics.Trace.TraceWarning("Operational alerts scheduler callback denied for remote peer: " + remote);
                return StatusCode(HttpStatusCode.Forbidden);
            }

            try
            {
                object result = await new SltOperationalAlertsService()
                    .ProcessDueAsync(CancellationToken.None).ConfigureAwait(false);
                return Ok(new { Status = "Success", JobKey = SltOperationalAlertsSchedulerService.JobKey, ExecutedAtUtc = DateTime.UtcNow, Result = result });
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError("Operational alert callback failed: " + ex);
                return Content(HttpStatusCode.InternalServerError, new { Status = "Failed", Message = "Operational alert processing failed. See server logs." });
            }
        }
    }
}
