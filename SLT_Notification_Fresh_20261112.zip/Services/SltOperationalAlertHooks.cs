using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Globalization;
using System.Threading.Tasks;
using ClosedXML.Excel;
using SLTProject.Data;
using SLTProject.Models.Dtos;

namespace SLTProject.Services
{
    public static class SltOperationalAlertHooks
    {
        private static string DateLabel(DateTime? d) { return d.HasValue ? d.Value.ToString("dd/MM/yyyy") : "date to be confirmed"; }
        private static string DateLabel(DateTime d) { return d.ToString("dd/MM/yyyy"); }
        public static async Task AirportAsync(AirportTransferDto value, string mode, string channels)
        {
            if (value == null || SltOperationalAlertsService.Mode(mode) == "None") return;
            await SltOperationalAlertsService.EnqueueChangeAsync(value.Email, "AIRPORT_TRANSFER_ALERT",
                "airport:" + value.Id, "Airport " + value.Type + " update",
                "Airport " + value.Type + " on " + DateLabel(value.Date) + ". Driver: " + value.DriverName + ", phone: " + value.DriverPhone,
                mode, channels);
        }

        public static async Task AirportAsync(string email, string type, string mode, string channels)
        {
            using (var db = new SLTEntities())
            {
                var row = await db.AirportTransfers.AsNoTracking().FirstOrDefaultAsync(x => !x.IsDeleted && x.Email == email && x.Type == type);
                if (row != null) await SltOperationalAlertsService.EnqueueChangeAsync(email, "AIRPORT_TRANSFER_ALERT", "airport:" + row.Id,
                    "Airport " + row.Type + " update", "Airport " + row.Type + " on " + DateLabel(row.Date) + ". Driver: " + row.DriverName + ", phone: " + row.DriverPhone,
                    mode, channels);
            }
        }

        public static async Task GuestAsync(long id, bool checkin, bool checkout, string mode, string channels)
        {
            if (SltOperationalAlertsService.Mode(mode) == "None") return;
            using (var db = new SLTEntities())
            {
                var g = await db.Guests.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && !x.IsDeleted);
                if (g == null) return;
                if (checkin && g.CheckInDate.HasValue)
                    await SltOperationalAlertsService.EnqueueChangeAsync(g.Email, "GUEST_CHECKIN_ALERT", "guest:" + id + ":checkin",
                        "Hotel check-in update", "Your hotel check-in date is " + DateLabel(g.CheckInDate) + ".", mode, channels);
                if (checkout && g.CheckOutDate.HasValue)
                    await SltOperationalAlertsService.EnqueueChangeAsync(g.Email, "GUEST_CHECKOUT_ALERT", "guest:" + id + ":checkout",
                        "Hotel check-out update", "Your hotel check-out date is " + DateLabel(g.CheckOutDate) + ".", mode, channels);
            }
        }

        public static async Task EventAsync(string email, long scheduleId, string mode, string channels, bool reminder)
        {
            using (var db = new SLTEntities())
            {
                var s = await db.DaySchedules.AsNoTracking().FirstOrDefaultAsync(x => x.Id == scheduleId && !x.IsDeleted);
                var driver = await db.GuestEventDrivers.AsNoTracking().FirstOrDefaultAsync(x => x.Email == email && x.DayScheduleId == scheduleId && !x.IsDeleted);
                if (s == null || driver == null) return;
                if (SltOperationalAlertsService.Mode(mode) != "None")
                    await SltOperationalAlertsService.EnqueueChangeAsync(email, "EVENT_DRIVER_ALERT",
                        "eventdriver:" + driver.Id, "Event driver update",
                        s.Title + " on " + DateLabel(s.Date) + ". Driver: " + driver.DriverName + ", phone: " + driver.DriverPhone,
                        mode, channels);
                // Event reminders have a different time rule: 15 minutes BEFORE StartTime.
                // Do not cancel an existing reminder when sending an immediate/scheduled
                // driver-change alert. Only an explicit Reminder=Yes creates/refreshes it.
                if (reminder)
                    await SltOperationalAlertsService.EnqueueReminderAsync(email, scheduleId, s.Title, s.Date,
                        s.StartTime, true, channels);
            }
        }

        // Both switches can be Yes. Each queues a separate delivery to SMS + PWA push.
        // This is used for Excel imports and can also be called after CRUD operations.
        public static async Task SendSelectedAsync(Func<string, Task> notificationForMode,
            bool immediateNotification, bool scheduledNotification)
        {
            if (immediateNotification) await notificationForMode("Immediate");
            if (scheduledNotification) await notificationForMode("Scheduled");
        }

        public static bool YesNo(string value, string column, int row)
        {
            string v = (value ?? "").Trim();
            if (v.Length == 0 || v.Equals("No", StringComparison.OrdinalIgnoreCase)) return false;
            if (v.Equals("Yes", StringComparison.OrdinalIgnoreCase)) return true;
            throw new ArgumentException("Row " + row.ToString(CultureInfo.InvariantCulture) +
                ": " + column + " must be Yes or No.");
        }

        // Validate switches before committing import data so failed notification flags
        // cannot silently create modified guests/transfers/drivers.
        public static void ValidateImportedFlags(byte[] excel)
        {
            using (var stream = new MemoryStream(excel))
            using (var workbook = new XLWorkbook(stream))
            {
                var sheet = workbook.Worksheet(1);
                var headings = ScheduleTransportExcel.Headers(sheet);
                var last = sheet.LastRowUsed();
                if (last == null) return;
                for (int rowNumber = 2; rowNumber <= last.RowNumber(); rowNumber++)
                {
                    var row = sheet.Row(rowNumber);
                    if (ScheduleTransportExcel.Empty(row, headings)) continue;
                    YesNo(ScheduleTransportExcel.Text(row, headings, "Immediate notification"), "Immediate notification", rowNumber);
                    YesNo(ScheduleTransportExcel.Text(row, headings, "Scheduled notification"), "Scheduled notification", rowNumber);
                }
            }
        }

        // Guests/Airport/EventDriver Scheduled notification: 15 minutes after approval/import.
        // Event Reminder: 15 minutes before linked DaySchedule.StartTime (Egypt time).
        // Excel headers are optional: Immediate notification, Scheduled notification, Reminder.
        // Invalid import rows are ignored; this function runs only after the import commits.
        public static async Task QueueImportedAsync(byte[] excel, string kind,
            ISet<int> failedRows, ISet<string> successfulGuestEmails)
        {
            using (var stream = new MemoryStream(excel))
            using (var workbook = new XLWorkbook(stream))
            {
                var sheet = workbook.Worksheet(1);
                var head = ScheduleTransportExcel.Headers(sheet);
                var last = sheet.LastRowUsed();
                if (last == null) return;
                for (int n = 2; n <= last.RowNumber(); n++)
                {
                    if (failedRows != null && failedRows.Contains(n)) continue;
                    var row = sheet.Row(n);
                    string email = ScheduleTransportExcel.Text(row, head, "Email").Trim().ToLowerInvariant();
                    if (email.Length == 0) continue;
                    if (successfulGuestEmails != null && !successfulGuestEmails.Contains(email)) continue;
                    bool immediate = YesNo(ScheduleTransportExcel.Text(row, head, "Immediate notification"), "Immediate notification", n);
                    bool scheduled = YesNo(ScheduleTransportExcel.Text(row, head, "Scheduled notification"), "Scheduled notification", n);
                    const string channels = "Both";
                    if (kind == "Airport")
                    {
                        string type = ScheduleTransportExcel.Text(row, head, "Type");
                        await SendSelectedAsync(m => AirportAsync(email, type, m, channels), immediate, scheduled);
                    }
                    else if (kind == "Guests")
                    {
                        if (!immediate && !scheduled) continue;
                        var checkin = !string.IsNullOrWhiteSpace(ScheduleTransportExcel.Text(row, head, "CheckInDate")) ||
                                      !string.IsNullOrWhiteSpace(ScheduleTransportExcel.Text(row, head, "CheckInTime"));
                        var checkout = !string.IsNullOrWhiteSpace(ScheduleTransportExcel.Text(row, head, "CheckOutDate")) ||
                                       !string.IsNullOrWhiteSpace(ScheduleTransportExcel.Text(row, head, "CheckOutTime"));
                        using (var db = new SLTEntities())
                        {
                            var g = await db.Guests.AsNoTracking().FirstOrDefaultAsync(x => x.Email == email && !x.IsDeleted);
                            if (g != null) await SendSelectedAsync(m => GuestAsync(g.Id, checkin, checkout, m, channels), immediate, scheduled);
                        }
                    }
                    else if (kind == "Event")
                    {
                        string title = ScheduleTransportExcel.Text(row, head, "ScheduleTitle");
                        string rawId = ScheduleTransportExcel.Text(row, head, "DayScheduleId");
                        string dateRaw = ScheduleTransportExcel.Text(row, head, "ScheduleDate");
                        bool reminder = SltOperationalAlertsService.Reminder(ScheduleTransportExcel.Text(row, head, "Reminder"));
                        if (!immediate && !scheduled && !reminder) continue;
                        using (var db = new SLTEntities())
                        {
                            long id;
                            if (!long.TryParse(rawId, out id) || id <= 0)
                            {
                                var normalized = title.Trim().ToLowerInvariant();
                                var q = db.DaySchedules.AsNoTracking().Where(x => !x.IsDeleted && x.Title.ToLower() == normalized);
                                if (!string.IsNullOrWhiteSpace(dateRaw))
                                {
                                    DateTime d = ScheduleTransportExcel.Date(dateRaw, "ScheduleDate").Date;
                                    DateTime e = d.AddDays(1);
                                    q = q.Where(x => x.Date >= d && x.Date < e);
                                }
                                var matches = await q.Select(x => x.Id).Take(2).ToListAsync();
                                if (matches.Count != 1) continue;
                                id = matches[0];
                            }
                            await SendSelectedAsync(m => EventAsync(email, id, m, channels, false), immediate, scheduled);
                            if (reminder) await EventAsync(email, id, "None", channels, true);
                        }
                    }
                }
            }
        }
    }
}
