using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using ClosedXML.Excel;
using SLTProject.Data;
using SLTProject.Models.Dtos;

namespace SLTProject.Services
{
    public class GuestEventDriversService
    {
        private static string Email(string email)
        {
            email=ScheduleTransportExcel.Limit(email,320,"Email",true).ToLowerInvariant();
            try { var a=new System.Net.Mail.MailAddress(email); if(!a.Address.Equals(email,StringComparison.OrdinalIgnoreCase)) throw new Exception(); }
            catch { throw new ArgumentException("Invalid guest email."); }
            return email;
        }
        private static void Validate(GuestEventDriverInput v)
        {
            if(v==null) throw new ArgumentException("Event driver data is required.");
            Email(v.Email);
            if(v.DayScheduleId<=0) throw new ArgumentException("DayScheduleId is required.");
            ScheduleTransportExcel.Limit(v.DriverName,250,"DriverName",true);
            ScheduleTransportExcel.Limit(v.DriverPhone,50,"DriverPhone",true);
        }
        private static void Apply(GuestEventDriver x,GuestEventDriverInput v)
        {
            x.Email=Email(v.Email);x.DayScheduleId=v.DayScheduleId;
            x.DriverName=v.DriverName.Trim();x.DriverPhone=v.DriverPhone.Trim();x.WhatsApp=v.WhatsApp;
        }
        public static GuestEventDriverDto Map(GuestEventDriver x)
        {
            return x==null ? null : new GuestEventDriverDto { Id=x.Id, Email=x.Email,DayScheduleId=x.DayScheduleId,
                DriverName=x.DriverName,DriverPhone=x.DriverPhone,WhatsApp=x.WhatsApp,
                CreatedAt=x.CreatedAt,CreatedBy=x.CreatedBy,ModifiedAt=x.ModifiedAt,ModifiedBy=x.ModifiedBy,
                IsDeleted=x.IsDeleted,DeletedAt=x.DeletedAt,DeletedBy=x.DeletedBy,
                RetentionDateCreated=x.RetentionDateCreated,RetentionDateModified=x.RetentionDateModified };
        }
        private static async Task CheckLinks(SLTEntities db,string email,long dayScheduleId)
        {
            if(!await db.Guests.AnyAsync(x=>x.Email==email && !x.IsDeleted)) throw new ArgumentException("Guest email does not exist: " + email);
            if(!await db.DaySchedules.AnyAsync(x=>x.Id==dayScheduleId && !x.IsDeleted))
                throw new ArgumentException("Active DayScheduleId not found: " + dayScheduleId);
        }
        public async Task<List<GuestEventDriverDto>> GetAllAsync(string email=null,long? dayScheduleId=null)
        {
            using(var db=new SLTEntities())
            {
                var activeSchedules = db.DaySchedules.Where(s => !s.IsDeleted).Select(s => s.Id);
                var q=db.GuestEventDrivers.AsNoTracking().Where(x=>!x.IsDeleted && activeSchedules.Contains(x.DayScheduleId));
                if(!string.IsNullOrWhiteSpace(email)) { var e=Email(email); q=q.Where(x=>x.Email==e); }
                if(dayScheduleId.HasValue) { long id=dayScheduleId.Value;q=q.Where(x=>x.DayScheduleId==id); }
                return (await q.OrderBy(x=>x.DayScheduleId).ThenBy(x=>x.Email).ToListAsync()).Select(Map).ToList();
            }
        }
        public async Task<GuestEventDriverDto> GetAsync(long id)
        {
            using(var db=new SLTEntities()) return Map(await db.GuestEventDrivers.AsNoTracking()
                .FirstOrDefaultAsync(x=>x.Id==id && !x.IsDeleted && db.DaySchedules.Any(s => s.Id==x.DayScheduleId && !s.IsDeleted)));
        }
        public async Task<GuestEventDriverDto> CreateAsync(GuestEventDriverInput input,string actor)
        {
            Validate(input);
            using(var db=new SLTEntities())
            {
                var email=Email(input.Email);await CheckLinks(db,email,input.DayScheduleId);
                if(await db.GuestEventDrivers.AnyAsync(x=>!x.IsDeleted && x.Email==email && x.DayScheduleId==input.DayScheduleId))
                    throw new ArgumentException("An active guest driver assignment already exists for this activity.");
                var now=EgyptDateTimeService.Now;
                var entity = new GuestEventDriver { CreatedAt=now, CreatedBy=actor, RetentionDateCreated=now, IsDeleted=false };
                Apply(entity,input);db.GuestEventDrivers.Add(entity);await db.SaveChangesAsync();return Map(entity);
            }
        }
        public async Task<GuestEventDriverDto> UpdateAsync(long id,GuestEventDriverInput input,string actor)
        {
            Validate(input);
            using(var db=new SLTEntities())
            {
                var x=await db.GuestEventDrivers.FirstOrDefaultAsync(y=>y.Id==id && !y.IsDeleted);
                if(x==null) return null;
                var email=Email(input.Email);await CheckLinks(db,email,input.DayScheduleId);
                if(await db.GuestEventDrivers.AnyAsync(y=>y.Id!=id && !y.IsDeleted && y.Email==email && y.DayScheduleId==input.DayScheduleId))
                    throw new ArgumentException("An active Email + DayScheduleId assignment already exists.");
                Apply(x,input);x.ModifiedAt=EgyptDateTimeService.Now;x.ModifiedBy=actor;x.RetentionDateModified=x.ModifiedAt;
                await db.SaveChangesAsync();return Map(x);
            }
        }
        public async Task<bool> DeleteAsync(long id,string actor)
        {
            using(var db=new SLTEntities())
            {
                var x=await db.GuestEventDrivers.FirstOrDefaultAsync(y=>y.Id==id && !y.IsDeleted);
                if(x==null) return false;
                var now=EgyptDateTimeService.Now;x.IsDeleted=true;x.DeletedAt=now;x.DeletedBy=actor;
                x.ModifiedAt=now;x.ModifiedBy=actor;x.RetentionDateModified=now;
                await db.SaveChangesAsync();return true;
            }
        }
        public byte[] GetTemplate()
        {
            using (var workbook = new XLWorkbook())
            using (var stream = new MemoryStream())
            {
                var sheet = workbook.Worksheets.Add("Import");
                ScheduleTransportExcel.WriteTemplateHeaders(
                    sheet,
                    "Email", "ScheduleTitle", "ScheduleDate",
                    "DriverName", "DriverPhone", "WhatsApp",
                    "Immediate notification", "Scheduled notification", "Reminder");

                ScheduleTransportExcel.WriteInstructions(
                    workbook,
                    "Import modes: UpdateOnly, Upsert, ReplaceAll.",
                    "Email must belong to an existing active Guest.",
                    "ScheduleTitle must match an active Day Schedule. Matching ignores letter case.",
                    "The system resolves ScheduleTitle to the internal DayScheduleId; you do not need to enter the ID.",
                    "ScheduleDate is optional when ScheduleTitle is unique. If multiple active schedules share the title, provide ScheduleDate.",
                    "UpdateOnly updates existing Email + ScheduleTitle assignments and never creates new assignments.",
                    "Upsert updates a matching assignment or creates it when missing.",
                    "ReplaceAll soft-deletes all active Event Driver assignments, then imports valid rows. Use only with a complete workbook.",
                    "For partial updates, provide Email + ScheduleTitle (and ScheduleDate if needed), then fill only fields to change. Empty cells preserve stored values.",
                    "New assignments require DriverName and DriverPhone. Phone cells are formatted as Text to retain + and leading zeros.",
                    "ScheduleDate must use d/MM/yy (for example 4/12/26). If title is unique it can be left blank.",
                    "WhatsApp accepts Yes/No, Y/N, True/False or 1/0.",
                    "Legacy DayScheduleId header is still accepted for backward compatibility.",
                    "Immediate notification: Yes/No. Scheduled notification: Yes/No (15 minutes after approval/import).",
                    "Both notification types send SMS and push. Reminder: Yes/No; Yes schedules 15 minutes BEFORE event StartTime (Cairo time).", 
                    "Event reminder is independent of the 15-minute-after-import driver update. Event Reminder SMS requires EVENT_REMINDER_SMS template.");

                workbook.SaveAs(stream);
                return stream.ToArray();
            }
        }

        private static async Task<long> ResolveScheduleIdAsync(
            SLTEntities db,
            Dictionary<string, int> headers,
            IXLRow row)
        {
            string title = ScheduleTransportExcel.Text(row, headers, "ScheduleTitle");

            if (!string.IsNullOrWhiteSpace(title))
            {
                string normalizedTitle = title.Trim().ToLowerInvariant();
                string dateText = ScheduleTransportExcel.Text(row, headers, "ScheduleDate");
                DateTime? scheduleDate = null;

                if (!string.IsNullOrWhiteSpace(dateText))
                    scheduleDate = ScheduleTransportExcel.Date(dateText, "ScheduleDate");

                var query = db.DaySchedules.AsNoTracking().Where(x =>
                    !x.IsDeleted && x.Title.ToLower() == normalizedTitle);

                if (scheduleDate.HasValue)
                {
                    // Compute CLR DateTime bounds before EF6 translates the query.
                    DateTime start = scheduleDate.Value.Date;
                    DateTime end = start.AddDays(1);
                    query = query.Where(x => x.Date >= start && x.Date < end);
                }

                var matches = await query
                    .Select(x => new { x.Id, x.Title, x.Date })
                    .Take(2)
                    .ToListAsync();

                if (matches.Count == 0)
                    throw new ArgumentException(
                        "ScheduleTitle '" + title + "' does not match an active Day Schedule.");

                if (matches.Count > 1)
                    throw new ArgumentException(
                        "ScheduleTitle '" + title + "' matches multiple active schedules. Provide ScheduleDate to identify the correct schedule.");

                return matches[0].Id;
            }

            // Backward compatibility for workbooks using DayScheduleId.
            string rawId = ScheduleTransportExcel.Text(row, headers, "DayScheduleId");
            long id;
            if (long.TryParse(rawId, out id) && id > 0)
                return id;

            throw new ArgumentException(
                "Provide ScheduleTitle (preferred) or a valid legacy DayScheduleId.");
        }

        private static void DetachPendingChanges(SLTEntities db)
        {
            var pending = db.ChangeTracker.Entries()
                .Where(x =>
                    x.State == System.Data.Entity.EntityState.Added ||
                    x.State == System.Data.Entity.EntityState.Modified ||
                    x.State == System.Data.Entity.EntityState.Deleted)
                .ToList();

            foreach (var entry in pending)
                entry.State = System.Data.Entity.EntityState.Detached;
        }

        public async Task<ExcelImportResult> ImportAsync(
            Stream stream,
            string actor,
            string mode = "Upsert")
        {
            mode = ScheduleTransportExcel.NormalizeImportMode(mode);
            var report = new ExcelImportResult { Mode = mode };

            using (var workbook = ScheduleTransportExcel.Open(stream))
            {
                var sheet = workbook.Worksheet(1);
                var headers = ScheduleTransportExcel.Headers(sheet);

                ScheduleTransportExcel.Require(headers, "Email");
                if (!headers.ContainsKey("ScheduleTitle") && !headers.ContainsKey("DayScheduleId"))
                    throw new ArgumentException("Missing Excel column: ScheduleTitle.");

                var last = sheet.LastRowUsed();
                if (last == null || last.RowNumber() < 2)
                    return report;

                if (last.RowNumber() > 10001)
                    throw new ArgumentException("Maximum 10000 rows per upload.");

                report.TotalRows = last.RowNumber() - 1;
                var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

                using (var db = new SLTEntities())
                {
                    if (mode == "ReplaceAll")
                    {
                        var prepared = new List<Tuple<int, GuestEventDriverInput>>();

                        for (int rowNumber = 2; rowNumber <= last.RowNumber(); rowNumber++)
                        {
                            var row = sheet.Row(rowNumber);
                            if (ScheduleTransportExcel.Empty(row, headers))
                            {
                                report.Skipped++;
                                continue;
                            }

                            string emailText = ScheduleTransportExcel.Text(row, headers, "Email");
                            string titleText = ScheduleTransportExcel.Text(row, headers, "ScheduleTitle");
                            string column = "Record";
                            string value = "";

                            try
                            {
                                string email = Email(emailText);
                                column = "ScheduleTitle";
                                value = titleText;
                                long scheduleId = await ResolveScheduleIdAsync(db, headers, row);
                                await CheckLinks(db, email, scheduleId);

                                var input = new GuestEventDriverInput
                                {
                                    Email = email,
                                    DayScheduleId = scheduleId,
                                    DriverName = ScheduleTransportExcel.Text(row, headers, "DriverName"),
                                    DriverPhone = ScheduleTransportExcel.Text(row, headers, "DriverPhone"),
                                    WhatsApp = ScheduleTransportExcel.Bool(
                                        ScheduleTransportExcel.Text(row, headers, "WhatsApp"), "WhatsApp")
                                };

                                column = "Record";
                                value = "";
                                Validate(input);

                                string key = email + "|" + scheduleId;
                                if (!seen.Add(key))
                                {
                                    column = "Email + ScheduleTitle";
                                    value = emailText + " | " + titleText;
                                    throw new ArgumentException(
                                        "Duplicate Email + ScheduleTitle in the Excel file.");
                                }

                                prepared.Add(Tuple.Create(rowNumber, input));
                            }
                            catch (Exception ex)
                            {
                                string inferred = ScheduleTransportExcel.ErrorColumn(ex.Message, headers.Keys);
                                if (inferred != "Record") column = inferred;
                                if (string.IsNullOrWhiteSpace(value))
                                    value = ScheduleTransportExcel.ErrorValue(row, headers, column);
                                if (column == "Email" && string.IsNullOrWhiteSpace(value)) value = emailText;
                                if (column == "ScheduleTitle" && string.IsNullOrWhiteSpace(value)) value = titleText;
                                report.AddError(rowNumber, column, value, ex.Message);
                            }
                        }

                        // Safety: never remove existing assignments if the workbook has no valid rows.
                        if (prepared.Count == 0)
                            return report;

                        DateTime deleteTime = EgyptDateTimeService.Now;
                        var existing = await db.GuestEventDrivers
                            .Where(x => !x.IsDeleted)
                            .ToListAsync();

                        foreach (var entity in existing)
                        {
                            entity.IsDeleted = true;
                            entity.DeletedAt = deleteTime;
                            entity.DeletedBy = actor;
                            entity.ModifiedAt = deleteTime;
                            entity.ModifiedBy = actor;
                            entity.RetentionDateModified = deleteTime;
                        }

                        await db.SaveChangesAsync();
                        report.SoftDeleted = existing.Count;

                        foreach (var item in prepared)
                        {
                            try
                            {
                                DateTime now = EgyptDateTimeService.Now;
                                var entity = new GuestEventDriver
                                {
                                    CreatedAt = now,
                                    CreatedBy = actor,
                                    RetentionDateCreated = now,
                                    IsDeleted = false
                                };

                                Apply(entity, item.Item2);
                                db.GuestEventDrivers.Add(entity);
                                await db.SaveChangesAsync();
                                report.Inserted++;
                            }
                            catch (Exception ex)
                            {
                                DetachPendingChanges(db);
                                report.AddError(item.Item1, "Record", item.Item2.Email, ex.Message);
                            }
                        }

                        return report;
                    }

                    // UpdateOnly / Upsert
                    for (int rowNumber = 2; rowNumber <= last.RowNumber(); rowNumber++)
                    {
                        var row = sheet.Row(rowNumber);
                        if (ScheduleTransportExcel.Empty(row, headers))
                        {
                            report.Skipped++;
                            continue;
                        }

                        string emailText = ScheduleTransportExcel.Text(row, headers, "Email");
                        string titleText = ScheduleTransportExcel.Text(row, headers, "ScheduleTitle");
                        string columnName = "Record";
                        string errorValue = "";

                        try
                        {
                            string email = Email(emailText);
                            columnName = "ScheduleTitle";
                            errorValue = titleText;

                            long scheduleId = await ResolveScheduleIdAsync(db, headers, row);
                            await CheckLinks(db, email, scheduleId);

                            string key = email + "|" + scheduleId;
                            if (!seen.Add(key))
                            {
                                columnName = "Email + ScheduleTitle";
                                errorValue = emailText + " | " + titleText;
                                throw new ArgumentException(
                                    "Duplicate Email + ScheduleTitle in the Excel file.");
                            }

                            var entity = await db.GuestEventDrivers.FirstOrDefaultAsync(x =>
                                !x.IsDeleted && x.Email == email && x.DayScheduleId == scheduleId);

                            if (mode == "UpdateOnly" && entity == null)
                            {
                                throw new ArgumentException(
                                    "Driver assignment was not found. UpdateOnly does not create assignments.");
                            }

                            string driverName = ScheduleTransportExcel.Text(row, headers, "DriverName");
                            string driverPhone = ScheduleTransportExcel.Text(row, headers, "DriverPhone");
                            string whats = ScheduleTransportExcel.Text(row, headers, "WhatsApp");

                            var input = new GuestEventDriverInput
                            {
                                Email = email,
                                DayScheduleId = scheduleId,
                                DriverName = driverName.Length > 0
                                    ? driverName : (entity == null ? null : entity.DriverName),
                                DriverPhone = driverPhone.Length > 0
                                    ? driverPhone : (entity == null ? null : entity.DriverPhone),
                                WhatsApp = whats.Length > 0
                                    ? ScheduleTransportExcel.Bool(whats, "WhatsApp")
                                    : (entity != null && entity.WhatsApp)
                            };

                            columnName = "Record";
                            errorValue = "";
                            Validate(input);

                            bool inserted = entity == null;
                            DateTime now = EgyptDateTimeService.Now;

                            if (inserted)
                            {
                                entity = new GuestEventDriver
                                {
                                    CreatedAt = now,
                                    CreatedBy = actor,
                                    RetentionDateCreated = now,
                                    IsDeleted = false
                                };
                                Apply(entity, input);
                                db.GuestEventDrivers.Add(entity);
                            }
                            else
                            {
                                Apply(entity, input);
                                entity.ModifiedAt = now;
                                entity.ModifiedBy = actor;
                                entity.RetentionDateModified = now;
                            }

                            await db.SaveChangesAsync();
                            if (inserted) report.Inserted++;
                            else report.Updated++;
                        }
                        catch (Exception ex)
                        {
                            DetachPendingChanges(db);
                            string inferred = ScheduleTransportExcel.ErrorColumn(ex.Message, headers.Keys);
                            string column = inferred != "Record" ? inferred : columnName;
                            if (string.IsNullOrWhiteSpace(errorValue))
                                errorValue = ScheduleTransportExcel.ErrorValue(row, headers, column);
                            if (column == "Email" && string.IsNullOrWhiteSpace(errorValue)) errorValue = emailText;
                            if (column == "ScheduleTitle" && string.IsNullOrWhiteSpace(errorValue)) errorValue = titleText;
                            report.AddError(rowNumber, column, errorValue, ex.Message);
                        }
                    }
                }
            }

            return report;
        }

        // ============================================================
        // ADMIN TABLE: DATABASE-SIDE PAGING AND FILTERED XLSX EXPORT
        // The public unpaged GetAllAsync API remains unchanged.
        // ============================================================
        public Task<SltTablePage<GuestEventDriverDto>> GetPagedAsync(SltTableQuery filter)
        {
            return SltTableDataService.DriversAsync(filter ?? new SltTableQuery());
        }

        public Task<byte[]> ExportFilteredAsync(SltTableQuery filter)
        {
            return SltTableDataService.ExportXlsxAsync<GuestEventDriverDto>(
                f => SltTableDataService.DriversAsync(f),
                filter ?? new SltTableQuery(),
                new[] { "Id", "Email", "DayScheduleId", "DriverName", "DriverPhone", "WhatsApp" });
        }

    }
}
