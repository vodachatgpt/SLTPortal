# Notification scheduling rules (12 November 2026)

| Item | Immediate notification = Yes | Scheduled notification = Yes | Reminder = Yes |
|---|---|---|---|
| Guests | Immediately after successful import/approval | 15 minutes AFTER successful import/approval | Not applicable |
| Airport transfers | Immediately | 15 minutes AFTER successful import/approval | Not applicable |
| Event drivers | Immediately | 15 minutes AFTER successful import/approval | Not applicable for driver update |
| Events (linked DaySchedule) | N/A | N/A | 15 minutes BEFORE Date + StartTime, Africa/Cairo |

The Event Drivers Excel template retains three Yes/No columns: Immediate notification, Scheduled notification, Reminder.
- Scheduled notification pertains ONLY to the event driver update.
- Reminder pertains ONLY to the event starting soon.
- Setting both Scheduled notification and Reminder to Yes queues two independent messages.
- No changes to Web.config or database tables are required beyond the prior package; add active SMS template `EVENT_REMINDER_SMS`.
- The global Hangfire runner processes the due queue every minute; actual arrival depends on provider response and worker availability.
- Reminder requires a future event with StartTime, and its scheduled send time must still be in the future.
- Recipients are currently the guests whose email is assigned to that DaySchedule in GuestEventDrivers, not all guests.
- Updates to DaySchedule.StartTime made later are not automatically reflected in already-queued reminders; re-queue reminder when rescheduling.
- Fix included: sending a driver-change notification no longer cancels an already queued Event Reminder.
