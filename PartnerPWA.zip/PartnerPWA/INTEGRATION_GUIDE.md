# SLT Partner PWA — standalone styled integration

## Why the previous version looked broken
The supplied ZIP lacked Bootstrap, base CSS, onboarding styles, the original logo/illustration files, `InvitationCode.html`, `Home.html`, the PWA manifest, and root service worker, although included pages referenced them. This package uses a self-contained responsive CSS file, SVG illustrations inside existing pages and app icons.

## What was updated
- Completely styled mobile-first InvitationCode, AllowAccess, Home, and Notifications pages. These use the **existing page names**; no additional onboarding page route is introduced.
- Replaced broken dependencies and external asset references in the rendered pages.
- Added manifest, icons, and root PWA service worker to make this uploaded subset installable.
- Corrected onboarding redirect to `Home.html` (prior code pointed at missing `Splash.html`).
- Kept Global Push SDK V10.3 with separate `/push/` worker.
- `AllowAccess.js` no longer calls the old unsupported `/users/access` endpoint.
- Added notification count to basic Home page.

## Setup and deployment
1. Set `js/config.js` `apiBaseUrl` to the actual SLTProject API HTTPS URL ending in `/api`.
2. Confirm `globalPushServiceUrl` and `globalPushApplicationCode` are correct.
3. Upload the **contents** of `PartnerPWA/` to a single HTTPS directory, preserving folder structure and the `push` directory.
4. Open `<PWA-BASE>/html/InvitationCode.html`, not `file://...`.
5. Enter a registered email, request the passcode and log in. Then complete installation and notification permission steps.
6. Use the Admin Notifications module to send a test message; verify it in `Notifications.html`.
7. In DevTools > Application, verify `manifest.webmanifest`, root `sw.js`, and the `/push/` worker separately.

## Important integration caveats
- This ZIP was an integration overlay without the user's full original PWA; the missing standard page names (`InvitationCode.html`, `Home.html`) have been supplied as styled equivalents, not claimed to preserve a non-uploaded original implementation.
- No real SMS, email, login, or Global Push service was accessible for testing.
- PWA installation must be tested on real supported devices. Safari iOS push requires a Home Screen installed web app on supported versions.
- The root worker is intentionally static-assets-only: it must not cache authenticated API responses, tokens or passcodes.
- Avoid putting guest authentication codes into invitation URLs.
- If replacing an existing PWA, review its existing `sw.js` before overwriting; this package includes a simple root worker because the uploaded ZIP did not contain one.
- If host is under a virtual directory, configure the deployed path and CORS to match your Partner origin.
